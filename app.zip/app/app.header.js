import React from 'react';
import ReactDOM from 'react-dom';
import { Router } from 'react-router';
import { Provider, ReactReduxContext } from 'react-redux';
import { getStoreRef } from '@bbb-app/utils/storeRefUtils';
import { select } from '@bbb-app/utils/sideEffects';
import siteInfo from '@bbb-app/utils/siteInfo';
import { isBrowser } from '@bbb-app/utils/common';
import { makeSelectSiteConfig } from '@bbb-app/selectors/configSelector';
import getCurrentSiteIdAtBrowser from '@bbb-app/utils/getCurrentSiteIdAtBrowser';
import history from '@bbb-app/utils/history';
import Header from '@bbb-app/header/containers/Header';

// this should return true only for "/store/static"
const isMobileApp = (deviceUserAgent, appUserAgent) => {
  // appUserAgent=["iosbbby","iosbaby","webview"].
  return (
    isBrowser() &&
    (window.location.pathname.startsWith('/store/static') ||
      window.location.pathname.startsWith('/store/page')) &&
    appUserAgent.some(str => deviceUserAgent.indexOf(str) >= 0)
  );
};

export const headerInit = () => {
  const userAgentConfig = select(makeSelectSiteConfig(['userAgent']));
  const deviceUserAgent = isBrowser() && window.navigator.userAgent;
  const isNotMobileApp = !isMobileApp(deviceUserAgent, userAgentConfig);
  const siteId = getCurrentSiteIdAtBrowser();
  siteInfo.setId(siteId);

  if (isNotMobileApp) {
    ReactDOM.hydrate(
      <Provider store={getStoreRef()} context={ReactReduxContext}>
        <Router history={history}>
          <Header />
        </Router>
      </Provider>,
      document.getElementById('headerApp')
    );
  }
};
