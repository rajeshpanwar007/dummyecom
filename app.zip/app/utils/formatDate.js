import { isBedBathCanada } from '@bbb-app/utils/common';

const conditionalDateFormat = (d, format, days, months, years) => {
  switch (format) {
    case 'dd/mm/yyyy':
      return `${days}/${months}/${years}`;
    case 'yyyy-mm-dd':
      return `${years}-${months}-${days}`;
    case 'mm/dd/yyyy':
      return `${months}/${days}/${years}`;
    case 'month dd, yyyy':
      return d.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });
    case 'mon dd, yyyy':
      return d.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    case 'dd mon, yyyy':
      return getCADateMonDDYYYYFormat(d);
    case 'dd month, yyyy':
      return getCADateMonthDDYYYYFormat(d);
    default:
      return `${months}/${days}/${years}`;
  }
};
export const formatDate = (d, format, type) => {
  const dateList = ['1', '3', '5', '7', '8', '10', '12'];
  /* istanbul ignore if */
  if (d && d instanceof Date && !isNaN(d.valueOf())) {
    const year = d.getFullYear();
    let day = d.getDate().toString();
    const dateModifier =
      dateList.indexOf(day) !== -1
        ? parseInt(day, 10) + 1 <= 31
        : parseInt(day, 10) + 1 <= 30;
    day =
      type === 'increment' && dateModifier
        ? (parseInt(day, 10) + 1).toString()
        : (1).toString();
    day = day.length > 1 ? day : `0${day}`;
    let month = (d.getMonth() + 1).toString();
    month =
      type === 'increment' && dateModifier && parseInt(month, 10) + 1 <= 12
        ? (parseInt(month, 10) + 1).toString()
        : (1).toString();
    month = month.length > 1 ? month : `0${month}`;
    return conditionalDateFormat(d, format, day, month, year);
  }
  return '';
};
export const dateAsPerLocale = d => {
  // To change date format from 'dd/mm/yyyy' to 'mm/dd/yyyy'for CA and return Date object.
  if (!isBedBathCanada()) {
    return new Date(d);
  }
  const dateParts = d.split('/');
  if (dateParts.length === 3) {
    return new Date(`${dateParts[1]}/${dateParts[0]}/${dateParts[2]}`);
  }
  return '';
};
function getCADateMonDDYYYYFormat(d) {
  const usFormatDate = d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  const [date, year] = usFormatDate.split(',');
  const formattedDate = date
    .split(' ')
    .reverse()
    .join(' ');
  return `${formattedDate},${year}`;
}
function getCADateMonthDDYYYYFormat(d) {
  const usFormatDate = d.toLocaleString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
  const [date, year] = usFormatDate.split(',');
  const formattedDate = date
    .split(' ')
    .reverse()
    .join(' ');
  return `${formattedDate},${year}`;
}
export default formatDate;
