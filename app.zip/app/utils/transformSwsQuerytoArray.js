import { SWS_TERM_DELIM } from '../constants/search';

/**
 * parse the query string into an array of strings the components can use
 * @param {string} queryStr the search within search param from url
 * @return {array} query string parsed into an array
 */
export const transformSwsQuerytoArray = queryStr => {
  return queryStr && queryStr.includes(SWS_TERM_DELIM)
    ? queryStr
        .replace(/[-]/g, ' ')
        .split(SWS_TERM_DELIM)
        .filter(item => item !== '')
    : [];
};
