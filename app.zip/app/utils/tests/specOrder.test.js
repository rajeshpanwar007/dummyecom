import specOrder from '../specOrder';

describe(__filename, () => {
  it('should run specOrder properly', () => {
    const features = [
      {
        key1: 'Material',
      },
      { key2: 'manufacturer' },
      { length: '3' },
    ];
    const actual = specOrder(features);
    const expected = [
      {
        key1: 'Material',
      },
      { length: '3' },
      { key2: 'manufacturer' },
    ];
    expect(actual).to.eql(expected);
  });
  it('should get empty array for specOrder because there are no features', () => {
    const actual = specOrder();
    const expected = [];
    expect(actual).to.eql(expected);
  });
});
