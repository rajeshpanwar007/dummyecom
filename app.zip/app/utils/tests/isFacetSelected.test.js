import { isFacetSelected } from '../isFacetSelected';

describe('#isFacetSelected', () => {
  it('should return false if the selelected Facets are not present', () => {
    const response = isFacetSelected();
    expect(response).to.equal(false);
  });
  it('should return false if the selelected Facets are empty', () => {
    const response = isFacetSelected({});
    expect(response).to.equal(false);
  });
  it('should return true if any of  the selelected Facets have values', () => {
    const selectedFacets = {
      brand: ['Zara'],
      LOW_PRICE: [],
    };
    const response = isFacetSelected(selectedFacets);
    expect(response).to.equal(true);
  });
  it('should return false if all the selelected Facets does not have values', () => {
    const selectedFacets = {
      brand: [],
      LOW_PRICE: [],
    };
    const response = isFacetSelected(selectedFacets);
    expect(response).to.equal(false);
  });
});
