import sinon from 'sinon';
import * as viewPortUtil from '@bbb-app/utils/viewPortUtils';
import CommonUtil from '@bbb-app/utils/commonUtil';

describe('#isMobileScreen', () => {
  let viewPortUtilStub;
  beforeEach(() => {
    viewPortUtilStub = sinon
      .stub(viewPortUtil, 'getWindowInnerWidth')
      .returns(1023);
  });
  afterEach(() => {
    viewPortUtilStub.restore();
  });
  it('should return true if the viewport size is for mobile.', () => {
    const desktopBreakpoint = 1024;
    const result = CommonUtil.isMobileScreen(desktopBreakpoint);
    expect(result).to.equal(true);
  });
});

describe('#join', () => {
  it('should handle empty arrays', () => {
    expect(CommonUtil.join([])).to.equal('');
  });
  it('should handle empty array items', () => {
    expect(CommonUtil.join([1, 2, '', 3])).to.equal('1, 2 & 3');
  });
  it('should join items with default separators', () => {
    expect(CommonUtil.join([1, 2, 3])).to.equal('1, 2 & 3');
  });
  it('should join items with custom separators', () => {
    expect(
      CommonUtil.join([1, 2, 3], { separator: ';', tailSeparator: 'and' })
    ).to.equal('1; 2 and 3');
  });
});

describe('#commontutil mergeDeep', () => {
  it('should not merge key with arrays', () => {
    const source = {
      key: {
        subKey: '1',
        arayKey: ['a', 'b', 'c'],
      },
    };

    const override = {
      key: {
        arayKey: ['e'],
      },
      key2: {
        arayKey: ['e'],
      },
    };

    const merged = {
      key: {
        subKey: '1',
        arayKey: ['e'],
      },
      key2: {
        arayKey: ['e'],
      },
    };
    const output = CommonUtil.mergeDeep(source, override);
    expect(output).to.deep.equal(merged);
  });
  it('should merge non object keys', () => {
    const source = {
      key: {
        subKey: '1',
        arayKey: ['a', 'b', 'c'],
      },
    };

    const override = {
      key: {
        arayKey: ['e'],
      },
    };

    const merged = {
      key: {
        subKey: '1',
        arayKey: ['e'],
      },
    };
    const output = CommonUtil.mergeDeep(source, override);
    expect(output).to.deep.equal(merged);
  });
  it('should add key from override object that is not present in source', () => {
    const source = {
      key: {
        arayKey: ['a', 'b', 'c'],
      },
    };
    const override = {
      key: {
        subKey: '1',
        arayKey: ['e'],
      },
    };

    const merged = {
      key: {
        subKey: '1',
        arayKey: ['e'],
      },
    };
    const output = CommonUtil.mergeDeep(source, override);
    expect(output).to.deep.equal(merged);
  });
});
