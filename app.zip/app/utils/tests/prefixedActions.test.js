import { checkForAction } from '../prefixedActions';

describe('prefixedActions util', () => {
  it('prefixactions passing integer', () => {
    expect(checkForAction(1)).to.equal(false);
  });
  it('prefixactions passing undefine', () => {
    expect(checkForAction(null)).to.equal(false);
  });
  it('prefixactions passing String', () => {
    expect(checkForAction('BBB/CART/TRIGGER_ONLINECC_APPLY_NOW')).to.equal(
      false
    );
  });
  it('prefixactions passing String contains', () => {
    expect(
      checkForAction('/action_BBB/CART/TRIGGER_ONLINECC_APPLY_NOW')
    ).to.equal(true);
  });
  it('prefixactions passing String contains', () => {
    expect(checkForAction('/action_BBB/CART/TRIGGER_ONLINECC_APPLY')).to.equal(
      false
    );
  });
});
