import { convertToProductProps, pickProductProps } from '../quickPicks';
import mockData from '../../../server/mockData/quickPicksCollection.json';

describe(__filename, () => {
  describe('#convertToProductProps for Registry QuickPicks Collection', () => {
    it('should convert objects to the shape of a product', () => {
      const actual = convertToProductProps(
        mockData.products[0].productInformation
      );

      expect(actual).to.have.property('productId');
      expect(actual).to.have.property('colors');
      expect(actual).to.have.property('price');
      expect(actual).to.have.property('title');
      expect(actual).to.have.property('url');
      expect(actual).to.have.property('isLTL');
    });
    it('#pickProductProps', () => {
      const obj = {
        price: '$1,99',
        productId: '1234',
        title: 'MyObject',
        variants: [{ a: '123' }],
        defaultSkuCMS: '4321',
        foo: 'bar',
      };

      const data = pickProductProps(obj);
      expect(data).to.deep.equal({
        price: '$1,99',
        productId: '1234',
        title: 'MyObject',
        variants: [{ a: '123' }],
        defaultSkuCMS: '4321',
      });
    });
  });
});
