import {
  transformProductDataParameters,
  transformSingleProduct,
  transformProductDataList,
} from '../transformProductData';

const xtCompatResultsData = {
  title: 'Bean Peeler',
  attributes: [
    {
      skuAttributeId: '13_1',
      text:
        "<p class='sddMessage prod-attrib-feo'>Same Day Delivery Eligible</p>",
      attributesList: 'PLSR,PDPM,PDPC,SHALL',
      priority: 1,
    },
  ],
  productId: '1013876487',
  salePrice: 0,
  lowPriceValue: 5.99,
  highPriceValue: 0,
  priceLabelCode: 0,
  priceRangeDescrip: '$%L',
  rating: 3.3,
  reviews: 9,
  url: '/product/bean-peeler/1013876487',
  swatchFlag: '1',
  collectionFlag: '0',
  rollupTypeCode: 0,
  eligibleCustomizationDescrip: null,
  freeShippingQualifier: '0',
  customizationOfferedFlag: ['No'],
  intlRestricted: false,
  skuId: ['13876487'],
  altImages: null,
  productVariation: 'NORMAL',
  brand: null,
  minimumQuantity: 0,
  relatedCategories: [
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
    },
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
    },
  ],
  beyondPlusProductCheck: '0',
  inventoryStatus: 'Positive',
  priceRangeString: '$5.99',
  priceRangeStringMX: 'MXN 129.00',
  salePriceMX: null,
  intlLowPriceValue: null,
  intlHighPriceValue: null,
  intlWasLowPriceValue: null,
  intlWasHighPriceValue: null,
  selectedColor: null,
  price: {
    normalValue: 0,
    lowValue: 5.99,
    pricingLabelCode: null,
    priceRangeDescription: '$%L',
    tbsPrice: null,
    normal: '$5.99',
    low: '9.99',
    lowPriceValueMX: 129,
    highPriceValueMX: 0,
    wasLowPriceMX: 0,
    wasHighPriceMX: 0,
    priceLabelCodeMX: 0,
  },
  inCartMX: false,
  isLtlFlag: false,
  variants: [],
  scene7imageUrl:
    'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
  scene7imageID: '4409713876487p',
  altImage: null,
  inCart: false,
};

const expected = {
  altImage: null,
  altImages: null,
  attributes: [
    {
      attributesList: 'PLSR,PDPM,PDPC,SHALL',
      priority: 1,
      skuAttributeId: '13_1',
      text:
        "<p class='sddMessage prod-attrib-feo'>Same Day Delivery Eligible</p>",
    },
    {
      freeShippingLabel: 'freeShippingMessage',
      key: 'singleFreeShippingMessage',
      shippingQualifier: '0',
      text: '{0}',
    },
  ],
  beyondPlusProductCheck: '0',
  brand: null,
  collectionFlag: '0',
  customizationOfferedFlag: ['No'],
  eligibleCustomizationDescrip: null,
  freeShippingQualifier: '0',
  highPriceValue: 0,
  inCart: false,
  inCartMX: false,
  intlHighPriceValue: null,
  intlLowPriceValue: null,
  intlRestricted: false,
  intlWasHighPriceValue: null,
  intlWasLowPriceValue: null,
  inventoryStatus: 'Positive',
  isLtlFlag: false,
  lowPriceValue: 5.99,
  minimumQuantity: 0,
  price: {
    highPriceValueMX: 0,
    low: '9.99',
    lowPriceValueMX: 129,
    lowValue: 5.99,
    normal: '$5.99',
    normalValue: 0,
    priceLabelCodeMX: 0,
    priceRangeDescription: '$%L',
    pricingLabelCode: null,
    tbsPrice: null,
    wasHighPriceMX: 0,
    wasLowPriceMX: 0,
  },
  priceLabelCode: 0,
  priceRangeDescrip: '$%L',
  priceRangeString: '$5.99',
  priceRangeStringMX: 'MXN 129.00',
  productId: '1013876487',
  productVariation: 'NORMAL',
  rating: 3.3,
  relatedCategories: [
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
    },
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
    },
  ],
  reviews: 9,
  rollupTypeCode: 0,
  salePrice: 0,
  salePriceMX: null,
  scene7imageID: '4409713876487p',
  scene7imageUrl:
    'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
  selectedColor: null,
  skuId: ['13876487'],
  swatchFlag: '1',
  title: 'Bean Peeler',
  url: '/product/bean-peeler/1013876487',
  variants: [],
};

describe('markacostatest', () => {
  it('#transformProductDataParameters', () => {
    expect(transformProductDataParameters()).to.deep.equal({
      country: 'US',
      isInternational: false,
      freeShippingQualifier: '0',
    });
  });

  it('#transformSingleProduct', () => {
    expect(transformSingleProduct(xtCompatResultsData)).to.deep.equal(expected);
  });

  it('#transformProductDataList', () => {
    expect(transformProductDataList([xtCompatResultsData])).to.deep.equal([
      expected,
    ]);
  });
});
