import checkSizeEquality from '../checkSizeEquality';

describe('checkSizeEquality', () => {
  it('should return false when no skuSize & size is passed', () => {
    const result = checkSizeEquality();
    expect(result).to.equal(false);
  });
});
