import sinon from 'sinon';
import * as utils from '@bbb-app/utils/common';
import { formatDate, dateAsPerLocale } from '../formatDate';

describe('#formatDate', () => {
  const format1 = 'dd/mmy/yyyy';
  const format2 = 'yyyy-mm-dd';
  const type = 'increment';

  it('should return empty string if no date', () => {
    expect(formatDate()).to.equal('');
  });
  it('should return proper date june 3', () => {
    const d = new Date(1970, 5, 3);
    expect(formatDate(d, format1, type)).to.equal('07/04/1970');
  });
  it('should return proper date december 20', () => {
    const d = new Date(2011, 11, 20);
    expect(formatDate(d, format2, type)).to.equal('2011-01-21');
  });
  it('should return proper date december 20 no format given', () => {
    const d = new Date(2011, 11, 20);
    expect(formatDate(d)).to.equal('01/01/2011');
  });
  it('should return date in format dd/mm/yyyy', () => {
    const d = new Date('02/12/2018');
    expect(formatDate(d, 'dd/mm/yyyy')).to.equal('01/01/2018');
  });
  it('should return date in format month dd, yyyy', () => {
    const d = new Date('03/02/2020');
    expect(formatDate(d, 'month dd, yyyy')).to.equal('March 2, 2020');
  });
  it('should return date in format mon dd, yyyy', () => {
    const d = new Date('03/02/2020');
    expect(formatDate(d, 'mon dd, yyyy')).to.equal('Mar 2, 2020');
  });
  it('should return date for CA', () => {
    const expected = new Date('03/11/2020');
    sinon.stub(utils, 'isBedBathCanada').returns(true);
    const actual = dateAsPerLocale('11/03/2020');
    utils.isBedBathCanada.restore();
    expect(actual.getDate()).to.equal(expected.getDate());
  });
  it('should return date for other than CA', () => {
    const expected = new Date('03/11/2020');
    sinon.stub(utils, 'isBedBathCanada').returns(false);
    const actual = dateAsPerLocale('03/11/2020');
    utils.isBedBathCanada.restore();
    expect(actual.getDate()).to.equal(expected.getDate());
  });
  it('should return date in format dd mon, yyyy', () => {
    const d = new Date('07/02/2020');
    expect(formatDate(d, 'dd mon, yyyy')).to.equal('2 Jul, 2020');
  });
  it('should return date in format dd month, yyyy', () => {
    const d = new Date('07/02/2020');
    expect(formatDate(d, 'dd month, yyyy')).to.equal('2 July, 2020');
  });
});
