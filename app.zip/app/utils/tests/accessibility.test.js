import React from 'react';
import { mount, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import sinon from 'sinon';
import {
  DIRECTION_BOTH,
  DIRECTION_HORIZONTAL,
  DIRECTION_VERTICAL,
  keyboardEventFocusNavigator,
  disableAria,
  enableAria,
} from '@bbb-app/utils/accessibility';
import KEY from '../../constants/keyEvents';

configure({ adapter: new Adapter() });

describe(__filename, () => {
  const setup = reactNode => {
    const mountElement = document.createElement('div');
    document.body.appendChild(mountElement);
    return mount(reactNode, { attachTo: mountElement });
  };
  const form = (
    <div>
      <form id="__test-form" className="js-aria-disableable">
        <input id="__test-form-text" type="text" value="field" />
        <button id="__test-form-button">My Button</button>
        <a href="/text" id="__test-a-href">
          A Link
        </a>
      </form>
    </div>
  );
  describe('#keyboardEventFocusNavigator', () => {
    it('should find parent node using selector', () => {
      const tree = setup(form);
      const options = {
        direction: DIRECTION_VERTICAL, // options include: vertical, horizontal, both
        bubbles: false,
        parent: '__test-form', // DOM or selector to focus on children under parent.
      };
      const preventDefault = sinon.stub();
      const keyboardEvent = { keyCode: KEY.KEY_DOWN, preventDefault };
      keyboardEventFocusNavigator(options)(keyboardEvent);
      tree.unmount();
    });

    it('should find parent node using DOM', () => {
      const tree = setup(form);
      const dom = tree.getDOMNode();
      const options = {
        direction: DIRECTION_HORIZONTAL, // options include: vertical, horizontal, both
        bubbles: false,
        parent: dom, // DOM or selector to focus on children under parent.
      };
      const preventDefault = sinon.stub();
      const keyboardEvent = { keyCode: KEY.KEY_RIGHT, preventDefault };
      keyboardEventFocusNavigator(options)(keyboardEvent);
      tree.unmount();
    });
  });

  describe('should handle key up and down events', () => {
    it('Arrow key up and down with wrapping', () => {
      const tree = setup(form);
      const dom = tree.getDOMNode();
      const options = {
        direction: DIRECTION_BOTH, // options include: vertical, horizontal, both
        bubbles: false,
        parent: dom, // DOM or selector to focus on children under parent.
        wrap: true,
      };
      const preventDefault = sinon.stub();
      const keyboardEvent = { keyCode: KEY.KEY_UP, preventDefault };
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_DOWN;
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_UP;
      keyboardEventFocusNavigator(options)(keyboardEvent);
      for (let i = 0; i < 5; i += 1) {
        keyboardEventFocusNavigator(options)(keyboardEvent);
      }

      options.direction = null;
      keyboardEventFocusNavigator(options)(keyboardEvent);
      tree.unmount();
    });
    it('Arrow key left and right with wrapping', () => {
      const tree = setup(form);
      const dom = tree.getDOMNode();
      const options = {
        direction: DIRECTION_HORIZONTAL, // options include: vertical, horizontal, both
        bubbles: false,
        parent: dom, // DOM or selector to focus on children under parent.
        wrap: true,
      };
      const preventDefault = sinon.stub();
      const keyboardEvent = { keyCode: KEY.KEY_LEFT, preventDefault };
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_RIGHT;
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_LEFT;
      keyboardEventFocusNavigator(options)(keyboardEvent);

      for (let i = 0; i < 5; i += 1) {
        keyboardEvent.keyCode = KEY.KEY_RIGHT;
        keyboardEventFocusNavigator(options)(keyboardEvent);
      }
      tree.unmount();
    });
    it('Arrow key left and right with wrapping Vertical', () => {
      const tree = setup(form);
      const dom = tree.getDOMNode();
      const options = {
        direction: DIRECTION_VERTICAL, // options include: vertical, horizontal, both
        bubbles: false,
        parent: dom, // DOM or selector to focus on children under parent.
        wrap: true,
      };
      const preventDefault = sinon.stub();
      const keyboardEvent = { keyCode: KEY.KEY_UP, preventDefault };
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_DOWN;
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEventFocusNavigator(options)(keyboardEvent);
      keyboardEvent.keyCode = KEY.KEY_UP;
      for (let i = 0; i < 5; i += 1) {
        keyboardEvent.keyCode = KEY.KEY_DOWN;
        keyboardEventFocusNavigator(options)(keyboardEvent);
      }
      tree.unmount();
    });
  });
  it('Should throw an error when parent is not a string or HTMLElement', () => {
    let hasError = false;
    const options = {
      direction: DIRECTION_VERTICAL, // options include: vertical, horizontal, both
      bubbles: false,
      parent: 123, // DOM or selector to focus on children under parent.
      wrap: true,
    };
    const preventDefault = sinon.stub();
    const keyboardEvent = { keyCode: KEY.KEY_UP, preventDefault };
    try {
      keyboardEventFocusNavigator(options)(keyboardEvent);
    } catch (e) {
      hasError = true;
    }
    expect(hasError).to.equal(true);
  });
  it('Should do nothing if any key is hit and checking callback', () => {
    const callback = sinon.spy();
    const options = {
      direction: DIRECTION_VERTICAL, // options include: vertical, horizontal, both
      bubbles: false,
      parent: '__test-form', // DOM or selector to focus on children under parent.
      wrap: true,
      callback,
    };
    const preventDefault = sinon.spy();
    const keyboardEvent = { keyCode: KEY.KEY_Q, preventDefault };
    keyboardEventFocusNavigator(options)(keyboardEvent);
    expect(callback.callCount).to.equal(0);
  });
  it.skip('Should disable aria', () => {
    const tree = setup(form);
    const aForm = tree.getDOMNode().querySelector('form');
    expect(aForm.hasAttribute('aria-disabled')).to.equal(false);
    expect(aForm.hasAttribute('aria-hidden')).to.equal(false);
    disableAria();
    expect(aForm.hasAttribute('aria-disabled')).to.equal(true);
    expect(aForm.hasAttribute('aria-hidden')).to.equal(true);
  });
  it.skip('Should enable aria', () => {
    const tree = setup(form);
    const aForm = tree.getDOMNode().querySelector('form');
    disableAria();
    expect(aForm.hasAttribute('aria-disabled')).to.equal(true);
    expect(aForm.hasAttribute('aria-hidden')).to.equal(true);
    enableAria();
    expect(aForm.hasAttribute('aria-disabled')).to.equal(false);
    expect(aForm.hasAttribute('aria-hidden')).to.equal(false);
  });
});
