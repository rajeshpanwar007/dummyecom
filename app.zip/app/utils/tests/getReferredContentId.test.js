import getReferredContentId from '../getReferredContentId';
describe('#getReferredContentId', () => {
  it('should return id of particular key from referred content array', () => {
    const referredContentObject = [
      {
        id: '12630',
        key: 'slotContent',
      },
      {
        id: '12635',
        key: 'pnhConfirmationModal',
      },
    ];
    const contentId = getReferredContentId(
      referredContentObject,
      'slotContent'
    );
    expect(contentId).to.equal('12630');
  });
});
