import { isPLP } from '../isPLP';

describe(__filename, () => {
  it('should run isPLP null because no route details', () => {
    const actual = isPLP();
    expect(actual).to.equal(null);
  });

  it('should run isPLP', () => {
    const locationBeforeTransitions = {
      location: {
        pathname: '/store/ideaboard/ib_foo/ff8f8d0bf588e3eeb41066ba996eef2c',
        search: '?abcd=1234',
      },
    };
    const actual = isPLP(locationBeforeTransitions);
    expect(actual).to.equal(null);
  });
});
