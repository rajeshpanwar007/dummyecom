import convertCanadaDateInUSFormat from '../convertCanadaDateInUSFormat';
describe('#convertCanadaDateInUSFormat', () => {
  it('should convert Canada date to US format', () => {
    expect(convertCanadaDateInUSFormat('20/01/2019')).to.equal('01/20/2019');
  });
});
