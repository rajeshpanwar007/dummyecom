import makeDefaultOption from '../makeDefaultOption';

describe('validate makeDefaultOption', () => {
  it('should return Empty Array if empty value is passed', () => {
    const emptyArr = [];
    const arr = [];
    const labels = {
      registration: {
        defaultFirstQuestion: 'Please Select First Question',
      },
    };
    const newArr = makeDefaultOption(
      labels,
      'registration.defaultFirstQuestion',
      arr
    );
    expect(newArr.toString()).to.be.equal(emptyArr.toString());
  });

  it('should return Empty Array if array passed is not an object', () => {
    const arr = 'value';
    const labels = {
      registration: {
        defaultFirstQuestion: 'Please Select First Question',
      },
    };
    const resultArr = makeDefaultOption(
      labels,
      'registration.defaultFirstQuestion',
      arr
    );
    expect(resultArr.toString()).to.be.equal([].toString());
  });

  it('should return Correct Data if correct value is passed', () => {
    const arr = [
      {
        label: 'Please Select First Question',
        props: {
          key: '',
        },
      },
    ];
    const labels = {
      registration: {
        defaultFirstQuestion: 'label value',
      },
    };
    makeDefaultOption(labels, 'registration.defaultFirstQuestion', arr);
    expect(arr[0].label).to.be.equal(labels.registration.defaultFirstQuestion);
    expect(arr.length).to.be.equal(2);
  });
});
