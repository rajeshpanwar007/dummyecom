import {
  PAGE_NAME_BRAND_PLP,
  PAGE_NAME_CATEGORY,
} from '@bbb-app/constants/route/route';
import {
  ROUTE_BRAND_PATH,
  ROUTE_CATEGORY_PATH,
} from '@bbb-app/constants/route/searchRoute';
import {
  parseHierarchy,
  parseSubcategoryHierarchy,
  toCanonicalPath,
  getSubcategoryLevel,
} from '../category';

describe(__filename, () => {
  describe('#', () => {
    it('should parse subCategories', () => {
      const input =
        '3/10002_Kitchen^/images/home/PopCats_Sept_2017_Kitchen_US CA.jpg$other$/10515_Coffee & Tea^/images/home/popcat_coffee_q3.JPG$other$/12051_Coffee Carafes^/images/home/popcat_coffee_q3.JPG$other$';
      const out = parseSubcategoryHierarchy(input);
      expect(out).to.be.a('object');
    });
    it('should not parse subCategories', () => {
      const input = '';
      const out = parseSubcategoryHierarchy(input);
      expect(out).to.equal(null);
    });
  });

  describe('#getSubcategoryLevel', () => {
    it('should return the correct subcategory level', () => {
      const input =
        '3/10002_Kitchen^/images/home/PopCats_Sept_2017_Kitchen_US CA.jpg$other$/10515_Coffee & Tea^/images/home/popcat_coffee_q3.JPG$other$/12051_Coffee Carafes^/images/home/popcat_coffee_q3.JPG$other$';
      const out = getSubcategoryLevel(input);
      expect(out).to.equal(3);
    });
    it('should not parse subCategories', () => {
      const input = undefined;
      const out = getSubcategoryLevel(input);
      expect(out).to.equal(null);
    });
  });

  describe('#toCanonicalPath', () => {
    it('should render a valid category path', () => {
      const params = { categoryId: '123' };
      expect(toCanonicalPath('/store/category/:categoryId', params)).to.equal(
        '/store/category/123/'
      );
    });
  });

  describe('#toCanonicalPath with Facets', () => {
    it('should render a valid category path with facets', () => {
      const path = ROUTE_CATEGORY_PATH;
      const params = {
        level1: 'l1',
        level2: 'l2',
        categoryId: '123',
        facets: 'abcd',
      };
      expect(toCanonicalPath(path, params)).to.equal(
        '/store/category/l1/l2/123/abcd'
      );
    });
  });

  describe('#toCanonicalPath with Facets for Brand', () => {
    it('should render a valid brand path with facets', () => {
      const path = ROUTE_BRAND_PATH;
      const params = {
        brandName: 'l1',
        brandId: '123',
        facets: 'abcd',
      };
      expect(toCanonicalPath(path, params, '', PAGE_NAME_BRAND_PLP)).to.equal(
        '/store/brand/l1/123/abcd'
      );
    });
  });

  describe('#toCanonicalPath with pageIdentifier', () => {
    it('should render a valid category path', () => {
      const params = { categoryId: '123', level1: 'foo', level2: 'bar' };
      expect(
        toCanonicalPath(ROUTE_CATEGORY_PATH, params, '', PAGE_NAME_CATEGORY)
      ).to.equal('/store/category/foo/bar/123/');
    });
  });

  describe('#toCanonicalPath with startPerPage', () => {
    it('should render a valid category path with startPerPage', () => {
      const params = {
        categoryId: '123',
        level1: 'foo',
        level2: 'bar',
        startPerPage: '1-12',
      };
      expect(
        toCanonicalPath(ROUTE_CATEGORY_PATH, params, '', PAGE_NAME_CATEGORY)
      ).to.equal('/store/category/foo/bar/123/');
    });
  });

  describe('#toCanonicalPath with pageIdentifier with categoryName', () => {
    it('should render a valid brand path', () => {
      const params = { brandId: '123', brandName: 'foobar' };
      expect(
        toCanonicalPath(
          ROUTE_BRAND_PATH,
          params,
          '',
          PAGE_NAME_BRAND_PLP,
          'foobar'
        )
      ).to.equal('/store/brand/foobar/123/');
    });
  });

  describe('#parseHierarchy', () => {
    it('should parse a category hierarchy string correctly', () => {
      const actual = parseHierarchy(
        '3/10001_Bedding/10504_Bedding/12016_Comforter Sets'
      );

      const expected = [
        {
          url: '/store/category/bedding/10001/',
          name: 'Bedding',
          id: '10001',
        },
        {
          url: '/store/category/bedding/bedding/10504/',
          name: 'Bedding',
          id: '10504',
        },
        {
          url: '/store/category/bedding/bedding/comforter-sets/12016/',
          name: 'Comforter Sets',
          id: '12016',
        },
      ];

      return expect(actual).to.deep.equal(expected);
    });

    it('should parse a category hierarchy string correctly when college category', () => {
      const actual = parseHierarchy('2/10017_College/10621_Kitchen & Dining');

      const expected = [
        {
          url: '/store/page/college/',
          name: 'College',
          id: '10017',
        },
        {
          url: '/store/category/college/kitchen-dining/10621/',
          name: 'Kitchen & Dining',
          id: '10621',
        },
      ];

      return expect(actual).to.deep.equal(expected);
    });
  });
});
