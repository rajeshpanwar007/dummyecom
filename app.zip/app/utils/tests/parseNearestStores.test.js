import { parseNearestStores } from '../parseNearestStores';
import { routeSelector } from '../../containers/Search/selectors';
describe(__filename, () => {
  it('should parse nearest store id', () => {
    const locationBeforeTransitions = {
      location: {
        search: '/store/s/sheets/store-627?&nearestStores=1194',
      },
    };
    const gen = parseNearestStores();
    gen.next(routeSelector);
    expect(gen.next({ locationBeforeTransitions }).value).to.deep.equal('1194');
  });

  it('should not parse if there is no nearest store', () => {
    const locationBeforeTransitions = {
      location: {
        search: '/store/s/sheets',
      },
    };
    const gen = parseNearestStores();
    gen.next(routeSelector);
    expect(gen.next({ locationBeforeTransitions }).value).to.deep.equal('');
  });
});
