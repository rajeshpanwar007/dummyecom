import isMultiSku from '../isMultiSku';
describe('#isMultiSku', () => {
  it('should return true when rollupType code is 1', () => {
    const rollupTypeCode = 1;
    const collectionFlag = '0';
    const output = isMultiSku(rollupTypeCode, collectionFlag);
    expect(output).to.equal(true);
  });

  it('should return true when rollupType code is 0 and collectionFlag is 1', () => {
    const rollupTypeCode = 0;
    const collectionFlag = '1';
    const output = isMultiSku(rollupTypeCode, collectionFlag);
    expect(output).to.equal(true);
  });

  it('should return false when rollupType code is 0 and collectionFlag is 0', () => {
    const rollupTypeCode = 0;
    const collectionFlag = '0';
    const output = isMultiSku(rollupTypeCode, collectionFlag);
    expect(output).to.equal(false);
  });
});
