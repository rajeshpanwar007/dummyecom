import autoSelectLTLOption from '../autoSelectLTLOption';

describe('#autoSelectLTLOption', () => {
  it('should return true if ltlMethod matches one of shipMethodId', () => {
    const ltlData = [
      {
        shipMethodId: 'LR',
      },
      {
        shipMethodId: 'LW',
      },
    ];
    const ltlMethod = 'LR';
    const props = {
      selectLTLOption: () => {},
    };
    expect(autoSelectLTLOption(ltlData, ltlMethod, props)).to.equal(true);
  });

  it('should return false if ltlMethod does not match one of shipMethodId', () => {
    const ltlData = [
      {
        shipMethodId: 'LR',
      },
      {
        shipMethodId: 'LW',
      },
    ];
    const ltlMethod = 'LT';
    const props = {
      selectLTLOption: () => {},
    };
    expect(autoSelectLTLOption(ltlData, ltlMethod, props)).to.equal(false);
  });

  it('should return false if selectLTLOption is not a function', () => {
    const ltlData = [
      {
        shipMethodId: 'LR',
      },
      {
        shipMethodId: 'LW',
      },
    ];
    const ltlMethod = 'LT';
    const props = {
      selectLTLOption: null,
    };
    expect(autoSelectLTLOption(ltlData, ltlMethod, props)).to.equal(false);
  });
});
