import isRegionHasSingleComponent from '../isRegionHasSingleComponent';

describe('#isRegionHasSingleComponent', () => {
  it('should return true when single component is passed', () => {
    const regions = {
      first: {
        components: [
          {
            params: {
              id: '7753',
              style: 'left-align',
            },
            name: 'CMSPageHeader',
          },
        ],
      },
    };

    expect(isRegionHasSingleComponent(regions)).to.equal(true);
  });

  it('should return false when multiple component is passed', () => {
    const regions = {
      first: {
        components: [
          {
            params: {
              id: '7753',
              style: 'left-align',
            },
            name: 'CMSPageHeader',
          },
          {
            params: {
              id: '7709',
              style: 'V5',
            },
            name: 'HeroModule',
          },
        ],
      },
    };

    expect(isRegionHasSingleComponent(regions)).to.equal(false);
  });
});
