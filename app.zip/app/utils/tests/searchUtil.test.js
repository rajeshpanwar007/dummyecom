/* eslint-disable max-lines */
import { fromJS } from 'immutable';
import { fork } from 'redux-saga/effects';
import {
  transformProductData,
  buildSearchUrl,
  buildSearchUrlForPagination,
  getRegions,
  toSearchPath,
  getMatchedPath,
  setupPerPageFilterParam,
  getInternationalPrice,
  getNormalPrice,
  getSalePrice,
  updateParamsForStore,
} from '@bbb-app/utils/searchUtil';
import { getRemoveQafObj } from '@bbb-app/utils/getRemoveQafObj';
import { LocalStorageUtil } from '@bbb-app/utils/localStorage';
import {
  SEARCH_RESULTS_EXPERIENCE_KEY,
  STATICPAGES_EXPERIENCE_KEY,
} from '@bbb-app/constants/experienceConstants';
import { getCanonical } from '../getCanonical';
import {
  getPageExperience,
  fetchDynamicRegionsMetadata,
} from '../../containers/Experience/sagas';
import getFormattedSkuIds from '../getFormattedSkuIds';

const xtCompatResultsData = {
  title: 'Bean Peeler',
  attributes: [
    {
      skuAttributeId: '13_1',
      text:
        "<p class='sddMessage prod-attrib-feo'>Same Day Delivery Eligible</p>",
      attributesList: 'PLSR,PDPM,PDPC,SHALL',
      priority: 1,
    },
  ],
  productId: '1013876487',
  salePrice: 0,
  lowPriceValue: 5.99,
  highPriceValue: 0,
  priceLabelCode: 0,
  priceRangeDescrip: '$%L',
  rating: 3.3,
  reviews: 9,
  url: '/product/bean-peeler/1013876487',
  swatchFlag: '1',
  collectionFlag: '0',
  rollupTypeCode: 0,
  eligibleCustomizationDescrip: null,
  freeShippingQualifier: '0',
  customizationOfferedFlag: ['No'],
  intlRestricted: false,
  skuId: ['13876487'],
  altImages: null,
  productVariation: 'NORMAL',
  brand: null,
  minimumQuantity: 0,
  relatedCategories: [
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
    },
    {
      CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
      CATEGORY_URL:
        '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
    },
  ],
  beyondPlusProductCheck: '0',
  inventoryStatus: 'Positive',
  priceRangeString: '$5.99',
  priceRangeStringMX: 'MXN 129.00',
  salePriceMX: null,
  intlLowPriceValue: null,
  intlHighPriceValue: null,
  intlWasLowPriceValue: null,
  intlWasHighPriceValue: null,
  selectedColor: null,
  price: {
    normalValue: 0,
    lowValue: 5.99,
    pricingLabelCode: null,
    priceRangeDescription: '$%L',
    tbsPrice: null,
    normal: '$5.99',
    low: '9.99',
    lowPriceValueMX: 129,
    highPriceValueMX: 0,
    wasLowPriceMX: 0,
    wasHighPriceMX: 0,
    priceLabelCodeMX: 0,
  },
  inCartMX: false,
  isLtlFlag: false,
  variants: [],
  scene7imageUrl:
    'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
  scene7imageID: '4409713876487p',
  altImage: null,
  inCart: false,
};

describe(__filename, () => {
  const transformProductParameters = {
    country: 'US',
    isInternational: false,
    freeShippingQualifier: '0',
  };
  it('#toSearchPath', () => {
    const params = { searchTerm: 'coffee' };
    expect(toSearchPath(params)).to.equal('/store/s/coffee');
  });

  it('#getCanonical', () => {
    expect(getCanonical('BedBathUS', 'sheets').includes('/store/s/sheets'));
    expect(getCanonical()).to.equal('/store/s/undefined');
  });

  it('#transformProductData', () => {
    const actual = transformProductData(
      xtCompatResultsData,
      transformProductParameters
    );
    const expected = {
      altImage: null,
      altImages: null,
      attributes: [
        {
          skuAttributeId: '13_1',
          text:
            "<p class='sddMessage prod-attrib-feo'>Same Day Delivery Eligible</p>",
          attributesList: 'PLSR,PDPM,PDPC,SHALL',
          priority: 1,
        },
        {
          key: 'singleFreeShippingMessage',
          text: '{0}',
          freeShippingLabel: 'freeShippingMessage',
          shippingQualifier: '0',
        },
      ],
      beyondPlusProductCheck: '0',
      brand: null,
      collectionFlag: '0',
      customizationOfferedFlag: ['No'],
      eligibleCustomizationDescrip: null,
      freeShippingQualifier: '0',
      highPriceValue: 0,
      inCart: false,
      inCartMX: false,
      intlHighPriceValue: null,
      intlLowPriceValue: null,
      intlRestricted: false,
      intlWasHighPriceValue: null,
      intlWasLowPriceValue: null,
      inventoryStatus: 'Positive',
      isLtlFlag: false,
      lowPriceValue: 5.99,
      minimumQuantity: 0,
      price: {
        highPriceValueMX: 0,
        low: '9.99',
        lowPriceValueMX: 129,
        lowValue: 5.99,
        normal: '$5.99',
        normalValue: 0,
        priceLabelCodeMX: 0,
        priceRangeDescription: '$%L',
        pricingLabelCode: null,
        tbsPrice: null,
        wasHighPriceMX: 0,
        wasLowPriceMX: 0,
      },
      priceLabelCode: 0,
      priceRangeDescrip: '$%L',
      priceRangeString: '$5.99',
      priceRangeStringMX: 'MXN 129.00',
      productId: '1013876487',
      productVariation: 'NORMAL',
      rating: 3.3,
      relatedCategories: [
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
        },
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
        },
      ],
      reviews: 9,
      rollupTypeCode: 0,
      salePrice: 0,
      salePriceMX: null,
      scene7imageID: '4409713876487p',
      scene7imageUrl:
        'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
      selectedColor: null,
      skuId: ['13876487'],
      swatchFlag: '1',
      title: 'Bean Peeler',
      url: '/product/bean-peeler/1013876487',
      variants: [],
    };
    expect(actual).to.deep.equal(expected);
  });
  it('#transformProductData without freeShipping atrribute', () => {
    const newdata = {
      ...xtCompatResultsData,
      storeOnly: true,
    };
    const actual = transformProductData(newdata, transformProductParameters);
    const expected = {
      altImage: null,
      altImages: null,
      attributes: [
        {
          skuAttributeId: '13_1',
          text:
            "<p class='sddMessage prod-attrib-feo'>Same Day Delivery Eligible</p>",
          attributesList: 'PLSR,PDPM,PDPC,SHALL',
          priority: 1,
        },
      ],
      beyondPlusProductCheck: '0',
      brand: null,
      collectionFlag: '0',
      customizationOfferedFlag: ['No'],
      eligibleCustomizationDescrip: null,
      freeShippingQualifier: '0',
      highPriceValue: 0,
      inCart: false,
      inCartMX: false,
      intlHighPriceValue: null,
      intlLowPriceValue: null,
      intlRestricted: false,
      intlWasHighPriceValue: null,
      intlWasLowPriceValue: null,
      inventoryStatus: 'Positive',
      isLtlFlag: false,
      lowPriceValue: 5.99,
      minimumQuantity: 0,
      price: {
        highPriceValueMX: 0,
        low: '9.99',
        lowPriceValueMX: 129,
        lowValue: 5.99,
        normal: '$5.99',
        normalValue: 0,
        priceLabelCodeMX: 0,
        priceRangeDescription: '$%L',
        pricingLabelCode: null,
        tbsPrice: null,
        wasHighPriceMX: 0,
        wasLowPriceMX: 0,
      },
      priceLabelCode: 0,
      priceRangeDescrip: '$%L',
      priceRangeString: '$5.99',
      priceRangeStringMX: 'MXN 129.00',
      productId: '1013876487',
      productVariation: 'NORMAL',
      rating: 3.3,
      relatedCategories: [
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
        },
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
        },
      ],
      reviews: 9,
      rollupTypeCode: 0,
      salePrice: 0,
      salePriceMX: null,
      scene7imageID: '4409713876487p',
      scene7imageUrl:
        'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
      selectedColor: null,
      skuId: ['13876487'],
      swatchFlag: '1',
      title: 'Bean Peeler',
      url: '/product/bean-peeler/1013876487',
      variants: [],
      storeOnly: true,
    };
    expect(actual).to.deep.equal(expected);
  });
  it('#convertToProductProps without attributes and with swatches', () => {
    const newData = {
      ...xtCompatResultsData,
      attributes: [],
      swatchFlag: '1',
      variants: [
        {
          color: 'RED',
          title: 'sku in red',
          swatchImage:
            'https://b3h2.scene7.com/is/image/BedBathandBeyond/1234p',
          skuId: 's201',
        },
        {
          color: 'BLUE',
          title: 'sku in blue',
          swatchImage:
            'https://b3h2.scene7.com/is/image/BedBathandBeyond/4444m',
          skuId: 's202',
        },
      ],
    };
    const actual = transformProductData(newData, transformProductParameters);
    const expected = {
      altImage: null,
      altImages: null,
      attributes: [
        {
          freeShippingLabel: 'freeShippingMessage',
          key: 'singleFreeShippingMessage',
          shippingQualifier: '0',
          text: '{0}',
        },
      ],
      beyondPlusProductCheck: '0',
      brand: null,
      collectionFlag: '0',
      customizationOfferedFlag: ['No'],
      eligibleCustomizationDescrip: null,
      freeShippingQualifier: '0',
      highPriceValue: 0,
      inCart: false,
      inCartMX: false,
      intlHighPriceValue: null,
      intlLowPriceValue: null,
      intlRestricted: false,
      intlWasHighPriceValue: null,
      intlWasLowPriceValue: null,
      inventoryStatus: 'Positive',
      isLtlFlag: false,
      lowPriceValue: 5.99,
      minimumQuantity: 0,
      price: {
        highPriceValueMX: 0,
        low: '9.99',
        lowPriceValueMX: 129,
        lowValue: 5.99,
        normal: '$5.99',
        normalValue: 0,
        priceLabelCodeMX: 0,
        priceRangeDescription: '$%L',
        pricingLabelCode: null,
        tbsPrice: null,
        wasHighPriceMX: 0,
        wasLowPriceMX: 0,
      },
      priceLabelCode: 0,
      priceRangeDescrip: '$%L',
      priceRangeString: '$5.99',
      priceRangeStringMX: 'MXN 129.00',
      productId: '1013876487',
      productVariation: 'NORMAL',
      rating: 3.3,
      relatedCategories: [
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/chef-central/cook-s-tools-gadgets/fruit-vegetable-tools/15178/',
        },
        {
          CATEGORY_DISP_NAME: 'Fruit & Vegetable Tools',
          CATEGORY_URL:
            '/store/category/kitchen/kitchen-tools-gadgets/fruit-vegetable-tools/14609/',
        },
      ],
      reviews: 9,
      rollupTypeCode: 0,
      salePrice: 0,
      salePriceMX: null,
      scene7imageID: '4409713876487p',
      scene7imageUrl:
        'https://b3h2.scene7.com/is/image/BedBathandBeyond/4409713876487p',
      selectedColor: null,
      skuId: ['13876487'],
      swatchFlag: '1',
      title: 'Bean Peeler',
      url: '/product/bean-peeler/1013876487',
      variants: [
        {
          color: 'RED',
          skuId: 's201',
          swatchImage:
            'https://b3h2.scene7.com/is/image/BedBathandBeyond/1234p',
          title: 'sku in red',
        },
        {
          color: 'BLUE',
          skuId: 's202',
          swatchImage:
            'https://b3h2.scene7.com/is/image/BedBathandBeyond/4444m',
          title: 'sku in blue',
        },
      ],
    };
    expect(actual).to.deep.equal(expected);
  });

  it('#convertToProductProps should return correct minimum qty in props', () => {
    const newData = {
      ...xtCompatResultsData,
      minimumQuantity: 4,
    };
    const actual = transformProductData(newData, transformProductParameters);
    expect(actual.minimumQuantity).to.be.equal(4);
  });

  it('#buildSearchUrl', () => {
    const locationBeforeTransitions = {
      location: {
        pathname: '/store/s/sleeping-bag',
        searchTerm: 'sleeping-bag',
      },
    };
    const data = {
      facets: null,
      itemsPerPage: 10,
      pageNum: 2,
      sort: 'aSort',
      view: 'grid',
      selectedStores: [1, 2],
    };

    expect(buildSearchUrl(locationBeforeTransitions, data)).to.deep.equal({
      path: '/store/s/sleeping-bag/2-10',
      search: '?view=grid&sort=aSort&nearestStores=1%2C2',
    });
  });

  it('#buildSearchUrlForPagination', () => {
    const locationBeforeTransitions = {
      pathname: '/store/s/sleeping-bag',
      searchTerm: 'sleeping-bag',
    };
    const pageNum = 2;
    const itemsPerPage = 10;

    expect(
      buildSearchUrlForPagination(
        locationBeforeTransitions,
        pageNum,
        itemsPerPage
      )
    ).to.equal('/store/s/sleeping-bag/2-10');
  });

  it('#buildSearchUrlForPagination for null ', () => {
    const locationBeforeTransitions = {
      pathname: '/store/s/sleeping-bag',
      searchTerm: 'sleeping-bag',
    };
    const pageNum = 1;
    const itemsPerPage = 10;
    const correctedQueryString = 'sheets';
    expect(
      buildSearchUrlForPagination(
        locationBeforeTransitions,
        pageNum,
        itemsPerPage,
        correctedQueryString
      )
    ).to.equal('/store/s/sheets');
  });

  it('#buildSearchUrlForPagination for next tag', () => {
    const locationBeforeTransitions = {
      pathname: '/store/s/sleeping-bag',
      searchTerm: 'sleeping-bag',
    };
    const pageNum = 2;
    const itemsPerPage = 10;
    const correctedQueryString = 'sheets';

    expect(
      buildSearchUrlForPagination(
        locationBeforeTransitions,
        pageNum,
        itemsPerPage,
        correctedQueryString
      )
    ).to.equal('/store/s/sheets/2-10');
  });

  const experience = fromJS({
    templates: {
      experience_4892_full_8252: {
        layout: 'layoutSingleColumn',
        'experience-type': 'Static Pages',
        regions: {
          first: {
            components: [
              {
                name: 'searchterm',
              },
            ],
          },
          second: {
            components: [
              {
                params: {
                  id: '4891',
                  style: 'round',
                },
                name: 'VisualFilter',
              },
            ],
          },
          third: {
            components: [
              {
                name: 'SocialAnnex',
              },
              {
                params: {
                  id: '4893',
                  style: '',
                },
                name: 'GoogleDFP',
              },
            ],
          },
        },
      },
    },
    mapping: {
      staticPages: {
        '/store/s': {
          templateId: 'experience_4892_full_8252',
          SEOData: {
            name: 'Search - Meta Name',
            description: 'Search - Description',
            keywords: 'Search - Meta Keywords',
          },
        },
      },
    },
  });
  const experienceContent = fromJS({
    '4891': {
      title: 'View Types of vacuums',
      field_visual_filter: [
        {
          field_alt_attribute: 'Upright vacuum',
          field_cta_label: 'Upright vacuum',
          field_cta_url: '/upright',
          field_image: '/116523661083349p?$229$',
        },
        {
          field_alt_attribute: 'Handheld vacuum',
          field_cta_label: 'Handheld',
          field_cta_url: '/specialized-kitchen-tools',
          field_image: '/67840244786502p?$229$',
        },
        {
          field_alt_attribute: 'Stick vacuum',
          field_cta_label: 'Stick vacuum',
          field_cta_url: '/baker-tools',
          field_image: '/116523061083288p?$229$',
        },
        {
          field_alt_attribute: 'Canister Vacuum',
          field_cta_label: 'Canister Vacuum',
          field_cta_url: '/party-favorites',
          field_image: '/116524061161580p?$229$',
        },
        {
          field_alt_attribute: 'Wet/Dry Vacuum',
          field_cta_label: 'Wet/Dry Vacuum',
          field_cta_url: '/ice-cream-tools',
          field_image: '/114547760769664p?$229$',
        },
      ],
    },
    '4893': {
      adIds: ['ad1', 'ad2', 'ad3'],
      statusCode: 200,
      Response: 'Success',
    },
  });

  const result = {
    third: [
      {
        name: 'SocialAnnex',
        data: null,
      },
      {
        params: {
          id: '4893',
          style: '',
        },
        name: 'GoogleDFP',
        data: {
          adIds: ['ad1', 'ad2', 'ad3'],
          statusCode: 200,
          Response: 'Success',
        },
      },
    ],
    second: [
      {
        params: {
          id: '4891',
          style: 'round',
        },
        name: 'VisualFilter',
        data: {
          title: 'View Types of vacuums',
          field_visual_filter: [
            {
              field_alt_attribute: 'Upright vacuum',
              field_cta_label: 'Upright vacuum',
              field_cta_url: '/upright',
              field_image: '/116523661083349p?$229$',
            },
            {
              field_alt_attribute: 'Handheld vacuum',
              field_cta_label: 'Handheld',
              field_cta_url: '/specialized-kitchen-tools',
              field_image: '/67840244786502p?$229$',
            },
            {
              field_alt_attribute: 'Stick vacuum',
              field_cta_label: 'Stick vacuum',
              field_cta_url: '/baker-tools',
              field_image: '/116523061083288p?$229$',
            },
            {
              field_alt_attribute: 'Canister Vacuum',
              field_cta_label: 'Canister Vacuum',
              field_cta_url: '/party-favorites',
              field_image: '/116524061161580p?$229$',
            },
            {
              field_alt_attribute: 'Wet/Dry Vacuum',
              field_cta_label: 'Wet/Dry Vacuum',
              field_cta_url: '/ice-cream-tools',
              field_image: '/114547760769664p?$229$',
            },
          ],
        },
      },
    ],
    first: [
      {
        name: 'searchterm',
        data: null,
      },
    ],
  };

  it('#getRegions', () => {
    const regions = getRegions(
      experience,
      STATICPAGES_EXPERIENCE_KEY,
      SEARCH_RESULTS_EXPERIENCE_KEY,
      experienceContent
    );
    expect(regions).to.deep.equal(result);
  });

  it('#fetchDynamicRegionsMetadata', () => {
    const inputs = { siteId: 1234, args: { foo: 'bar' } };
    const gen = fetchDynamicRegionsMetadata(inputs);
    const aResult = gen.next().value;
    expect(aResult).to.deep.equal(fork(getPageExperience, inputs));
    gen.next(); // To block...
  });

  it('#getMatchedPath', () => {
    expect(
      getMatchedPath({
        pathname: '/store/category/car-seats/car-seats/32593/',
      })
    ).to.be.a('object');
    expect(
      getMatchedPath({
        pathname: '/store/cagory/car-seats/car-seats/32593/',
      })
    ).to.be.a('object');
    expect(
      getMatchedPath({
        pathname:
          '/store/ideaboard/ib_ideaboard_remove_rearrange/ff8f8d0bf588e3eeb41066ba996eef2c/2-24',
      })
    ).to.be.a('object');
  });
  it('#setupPerPageFilterParam', () => {
    let param = null;
    const storageUtil = new LocalStorageUtil(true);
    const key = 'pageSizeFilter';
    const value = 12;
    param = setupPerPageFilterParam({
      params: {
        startPerPage: {},
      },
      pageNum: 1,
      itemsPerPage: value,
      pageChange: true,
    });
    storageUtil.saveItem(key, value);
    expect(param).to.be.a('object');
    param = setupPerPageFilterParam({
      params: {
        startPerPage: {},
      },
      pageNum: 2,
      itemsPerPage: value,
      pageChange: true,
    });
    storageUtil.saveItem(key, value);
    expect(param).to.be.a('object');
    param = setupPerPageFilterParam({
      params: {
        startPerPage: {},
      },
      pageNum: 1,
      itemsPerPage: value,
      pageChange: false,
    });
    storageUtil.saveItem(key, value);
    expect(param).to.be.a('object');
    param = setupPerPageFilterParam({
      params: {
        startPerPage: {},
      },
      pageNum: 1,
      itemsPerPage: value,
      pageChange: {},
    });
    storageUtil.saveItem(key, value);
    expect(param).to.be.a('object');
  });

  it('#updateParamsForStore', () => {
    let param = null;
    const selectedStores = ['1001', '1002'];
    const storeNumber = 1002;
    const storeAvailability = true;
    const pnhStoreId = 1003;
    param = updateParamsForStore({
      params: {
        startPerPage: {},
      },
      selectedStores,
      storeNumber,
      storeAvailability,
      pnhStoreId,
    });
    expect(param).to.be.a('object');

    param = updateParamsForStore({
      params: {
        startPerPage: {},
      },
      selectedStores,
      storeNumber,
      storeAvailability: false,
      pnhStoreId,
    });
    expect(param).to.be.a('object');
  });

  it('#getInternationalPrice', () => {
    const priceRangeDescription = '$%L - $%H';
    const intlLowPriceValue = '9.99';
    const intlHighPriceValue = '19.99';
    expect(
      getInternationalPrice(
        priceRangeDescription,
        intlLowPriceValue,
        intlHighPriceValue
      )
    ).to.equal('USD 9.99 - USD 19.99');
  });

  it('#getInternationalPrice without price', () => {
    const priceRangeDescription = '$%L';
    expect(getInternationalPrice(priceRangeDescription)).to.equal('USD %L');
  });

  it('#getInternationalNormalPrice 1', () => {
    const priceRangeDescription = 'TWIN XL $%L - QUEEN $%H';
    const intlWasLowPriceValue = '19.99';
    const intlWasHighPriceValue = '29.99';
    const intlLowPriceValue = '9.99';
    const intlHighPriceValue = '19.99';
    expect(
      getInternationalPrice(
        priceRangeDescription,
        intlLowPriceValue,
        intlHighPriceValue,
        intlWasLowPriceValue,
        intlWasHighPriceValue
      )
    ).to.equal('TWIN XL USD 19.99 - QUEEN USD 29.99');
  });

  it('#getInternationalNormalPrice without was price', () => {
    const priceRangeDescription = 'TWIN XL $%L - QUEEN $%H';
    const intlWasLowPriceValue = null;
    const intlWasHighPriceValue = null;
    const intlLowPriceValue = '9.99';
    const intlHighPriceValue = '19.99';
    expect(
      getInternationalPrice(
        priceRangeDescription,
        intlLowPriceValue,
        intlHighPriceValue,
        intlWasLowPriceValue,
        intlWasHighPriceValue
      )
    ).to.equal('TWIN XL USD 9.99 - QUEEN USD 19.99');
    expect(
      getInternationalPrice(priceRangeDescription, '', '', '', '')
    ).to.equal('TWIN XL USD  - QUEEN USD ');
  });

  it('#transformProductData', () => {
    const priceRangeStringMX = 'abc';
    const priceRangeDescription = 'def';
    const intlWasLowPriceValue = '9.99';
    const intlWasHighPriceValue = '19.99';
    const intlLowPriceValue = '10.00';
    const intlHighPriceValue = '20.00';
    const salePrice = '9.99';
    const salePriceMX = '10.99';
    const priceLabelCode = 'abc';

    const data = {
      price: {
        priceRangeStringMX,
        priceRangeDescrip: priceRangeDescription,
        priceLabelCode,
        intlWasLowPriceValue,
        intlWasHighPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        low: salePrice,
        salePriceMX,
      },
      attributes: [],
    };

    expect(
      transformProductData(data, transformProductParameters)
    ).to.deep.equal({
      price: {
        intlHighPriceValue: '20.00',
        intlLowPriceValue: '10.00',
        intlWasHighPriceValue: '19.99',
        intlWasLowPriceValue: '9.99',
        low: '9.99',
        normal: '',
        priceLabelCode: 'abc',
        priceRangeDescrip: 'def',
        priceRangeStringMX: 'abc',
        salePriceMX: '10.99',
      },
      attributes: [],
      freeShippingQualifier: '0',
    });
  });

  it('#getNormalPrice', () => {
    const priceRangeStringMX = 'abc';
    const priceRangeDescription = 'def';
    const intlWasLowPriceValue = '9.99';
    const intlWasHighPriceValue = '19.99';
    const intlLowPriceValue = '10.00';
    const intlHighPriceValue = '20.00';
    const priceLabelCode = 'ghi';
    expect(
      getNormalPrice(
        priceRangeStringMX,
        priceRangeDescription,
        intlWasLowPriceValue,
        intlWasHighPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        priceLabelCode,
        'MX'
      )
    ).to.equal('abc');
    expect(
      getNormalPrice(
        '',
        priceRangeDescription,
        intlWasLowPriceValue,
        intlWasHighPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        priceLabelCode,
        'MX'
      )
    ).to.equal('');

    expect(
      getNormalPrice(
        priceRangeStringMX,
        priceRangeDescription,
        intlWasLowPriceValue,
        intlWasHighPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        priceLabelCode,
        'IND'
      )
    ).to.equal('def');
    expect(
      getNormalPrice(
        priceRangeStringMX,
        priceRangeDescription,
        '',
        intlWasHighPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        'IND'
      )
    ).to.equal('def');
  });
  it('#getSalePrice', () => {
    const salePrice = '9.99';
    const salePriceMX = '10.99';
    const priceRangeDescription = 'abc';
    const intlWasLowPriceValue = '8.99';
    const intlLowPriceValue = '9.12';
    const intlHighPriceValue = '20.00';
    const priceLabelCode = 'def';

    expect(
      getSalePrice(
        salePrice,
        salePriceMX,
        priceRangeDescription,
        intlWasLowPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        priceLabelCode,
        'MX'
      )
    ).to.equal('10.99');
    expect(
      getSalePrice(
        salePrice,
        salePriceMX,
        priceRangeDescription,
        intlWasLowPriceValue,
        intlLowPriceValue,
        intlHighPriceValue,
        priceLabelCode,
        'IND'
      )
    ).to.equal('abc');
  });

  it('#getInternationalNormalPrice without was price', () => {
    const mockResponse = [
      { sku: '1', title: 'Product name 1' },
      { sku: '2', title: 'Product name 2' },
      { sku: '3', title: 'Product name 3' },
    ];
    const expectedResponse = '1|2|3';
    expect(getFormattedSkuIds(mockResponse)).to.equal(expectedResponse);
  });

  describe('Check Qaf respose object', () => {
    it('make comma seprated string into object', () => {
      const inputStr = 'product_type,brand';
      const expString = { product_type: 'f', brand: 'f' };
      const resultObj = getRemoveQafObj(inputStr);
      expect(resultObj).to.deep.equal(expString);
    });
    it('will return empty string for no parameter passed', () => {
      const resultObj = getRemoveQafObj();
      expect(resultObj).to.equal('');
    });
  });
});
