import isBrowser from '@bbb-app/utils/isBrowser';
describe('#isBrowser', () => {
  it('should be true', () => {
    expect(isBrowser()).to.equal(true);
  });
});
