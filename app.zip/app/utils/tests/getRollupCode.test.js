import getRollupCode from '../getRollupCode';
describe('#getRollupCode', () => {
  it('should return multiRollupFlag false when rollupType code is 1', () => {
    const rollupTypeCode = 1;
    const collectionFlag = '0';
    const output = getRollupCode(rollupTypeCode, collectionFlag);
    expect(output).to.equal(false);
  });
  it('should return multiRollupFlag true when rollupTypeCode is 4', () => {
    const rollupTypeCode = 4;
    const collectionFlag = '0';
    const output = getRollupCode(rollupTypeCode, collectionFlag);
    expect(output).to.equal(true);
  });
});
