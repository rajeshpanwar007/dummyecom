import truncateWithEllipses from '../truncateWithEllipses';

describe(__filename, () => {
  it('should run truncateWithEllipses without str', () => {
    const str = 'we need';
    const len = 15;
    const actual = truncateWithEllipses({ str, len });
    expect(actual).to.equal(str);
  });

  it('should run truncateWithEllipses without ... or separator', () => {
    const str = 'we need to shorten this';
    const len = 8;
    const actual = truncateWithEllipses({ str, len });
    const expected = 'we need ...';
    expect(actual).to.equal(expected);
  });

  it('should run truncateWithEllipses', () => {
    const str = 'we will need, to perhaps, shorten this';
    const len = 5;
    const isEllipses = false;
    const separator = ',';
    const actual = truncateWithEllipses({ str, len, isEllipses, separator });
    const expected = 'we wi';
    expect(actual).to.equal(expected);
  });

  it('should run truncateWithEllipses with regex separator', () => {
    const str = 'we will need, to perhaps, shorten this';
    const len = 5;
    const isEllipses = false;
    const separator = /^[0-9,;]+$/;
    const actual = truncateWithEllipses({ str, len, isEllipses, separator });
    const expected = 'we wi';
    expect(actual).to.equal(expected);
  });
});
