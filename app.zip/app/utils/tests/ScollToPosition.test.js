import { scrollToPosition } from '../ScrollToPosition';

describe('ScrollToPositionUtil', () => {
  it('should call scrollToPosition function correctly', () => {
    const titleId = 'app';
    window.location.hash = '#app';
    scrollToPosition(titleId);
    expect(titleId).to.equal('app');
  });
});
