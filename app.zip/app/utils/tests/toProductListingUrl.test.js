import toProductListingUrl from '../toProductListingUrl';

describe('#toProductListingUrl', () => {
  it('should output a URL with no type provided', () => {
    expect(
      toProductListingUrl({ level1: 'foo', level2: 'bar', categoryId: '1' })
    ).to.equal('/store/category/foo/bar/1');
  });
  it('should output a brand URL', () => {
    expect(
      toProductListingUrl({ brandId: '1', brandName: 'cool' }, 'brand')
    ).to.equal('/store/brand/cool/1');
  });
  it('should output a search URL', () => {
    expect(toProductListingUrl({ searchTerm: 'coffee' }, 'search')).to.equal(
      '/store/s/coffee'
    );
  });
  it('should omit optional segments by default', () => {
    expect(
      toProductListingUrl({ searchTerm: 'coffee', facets: 'abc123' }, 'search')
    ).to.equal('/store/s/coffee');
  });
  it('should allow omitted segments to be specified', () => {
    expect(
      toProductListingUrl(
        {
          searchTerm: 'coffee',
          facets: 'abc123',
          startPerPage: '2-48',
        },
        'search',
        []
      )
    ).to.equal('/store/s/coffee/2-48/abc123');
  });
  it('should output a URL for CLP PLP page', () => {
    expect(
      toProductListingUrl({ level1: 'clearance-savings', categoryId: '123' })
    ).to.equal('/store/category/clearance-savings/123');
  });
});
