import { createFriendlyFacetString } from '../departmentFacetUtil';
const selectedFilters = {
  BRAND: ['olivia-oliver'],
  CATEGORY_HIERARCHY: [''],
  LOW_PRICE: ['0-25-99'],
  RATINGS: ['5-0'],
  s_f_binProduct_Type: ['ring-holder'],
};
const expectedFilters = {
  BRAND: ['olivia-oliver'],
  LOW_PRICE: ['0-25-99'],
  RATINGS: ['5-0'],
  s_f_binProduct_Type: ['ring-holder'],
};
describe(__filename, () => {
  it('should return filtered facated object', () => {
    const funCaller = createFriendlyFacetString(selectedFilters);
    expect(JSON.stringify(funCaller)).to.equal(JSON.stringify(expectedFilters));
  });
});
