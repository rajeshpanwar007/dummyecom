import validatePDPError from '../validatePDPError';

describe(__filename, () => {
  it('should run validatePDPError', () => {
    const selectedSKU = {
      colorVariation: { label: 'HONEY', index: 0 },
      sizeVariation: 'FULL',
      skuId: '47131958',
    };
    const selectedProduct = {
      price: '1.99',
      QUANTITY: 1,
      ROLLUP_TYPE_CODE: '1',
    };
    const labels = { err_cart_outOfStockItem: 'Out of Stock' };
    const actual = validatePDPError(selectedSKU, selectedProduct, labels);
    const expected = '';
    expect(actual).to.equal(expected);
  });
  it('should run validatePDPError no finish or sku id', () => {
    const selectedSKU = {
      colorVariation: { index: 0 },
      sizeVariation: 'FULL',
    };
    const selectedProduct = {
      price: '1.99',
      QUANTITY: 1,
      ROLLUP_TYPE_CODE: '3',
    };
    const labels = { err_cart_outOfStockItem: 'Out of Stock' };
    const actual = validatePDPError(selectedSKU, selectedProduct, labels);
    const expected = 'NO_FINISH';
    expect(actual).to.equal(expected);
  });
  it('should run validatePDPError no color or sku id', () => {
    const selectedSKU = {
      colorVariation: { index: 0 },
      sizeVariation: 'FULL',
    };
    const selectedProduct = {
      price: '1.99',
      QUANTITY: 1,
      ROLLUP_TYPE_CODE: '4',
    };
    const labels = { err_cart_outOfStockItem: 'Out of Stock' };
    const actual = validatePDPError(selectedSKU, selectedProduct, labels);
    const expected = 'NO_COLOR';
    expect(actual).to.equal(expected);
  });
  it('should run validatePDPError no size or sku id', () => {
    const selectedSKU = {
      colorVariation: { index: 0 },
    };
    const selectedProduct = {
      price: '1.99',
      QUANTITY: 1,
      ROLLUP_TYPE_CODE: '2',
    };
    const labels = { err_cart_outOfStockItem: 'Out of Stock' };
    const actual = validatePDPError(selectedSKU, selectedProduct, labels);
    const expected = 'NO_SIZE';
    expect(actual).to.equal(expected);
  });
  it('should run validatePDPError error message because of ROLLUP_TYPE_CODE', () => {
    const selectedSKU = {
      colorVariation: { index: 0 },
      sizeVariation: 'FULL',
    };
    const selectedProduct = {
      price: '1.99',
      QUANTITY: 1,
      ROLLUP_TYPE_CODE: '0',
    };
    const labels = { err_cart_outOfStockItem: 'Out of Stock' };
    const actual = validatePDPError(selectedSKU, selectedProduct, labels);
    const expected = '';
    expect(actual).to.equal(expected);
  });
});
