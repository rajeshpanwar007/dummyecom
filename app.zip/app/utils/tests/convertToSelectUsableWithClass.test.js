import convertToSelectUsableWithClass from '../convertToSelectUsableWithClass';
describe('#convertToSelectUsableWithClass', () => {
  it('should return an array of length 2 ', () => {
    const data = [
      {
        url: '/store/account/myaccount',
        displayName: 'Overview',
        name: 'overview',
        id: 'overview',
        target: '_self',
      },
      {
        url: '/store/account/myaccount',
        displayName: 'Overview',
        name: 'overview',
        id: 'overview',
        target: '_self',
      },
    ];
    const result = convertToSelectUsableWithClass(data);
    expect(result.length).to.equal(2);
  });
});
