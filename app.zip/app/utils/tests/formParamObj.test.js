import sinon from 'sinon';
import * as utils from '@bbb-app/utils/countryCurrencyUtils';
import * as cdpUtilsObj from '@bbb-app/utils/cdpUtils';
import { formParamObj } from '../formParamObj';

describe(__filename, () => {
  it('should form Params Object for dynamic-content', () => {
    const categoryId = '12345';
    const searchTerm = 'Bedding';
    const productId = '234';
    const cdpUtilsObjStub = sinon
      .stub(cdpUtilsObj, 'getUserSegment')
      .returns('userSegment');
    const targetedSegment = sinon
      .stub(utils, 'getCountryCurrencyValue')
      .returns('USD');
    const expected = {
      type: 'type',
      user_segment: 'userSegment',
      targeted_segment: 'USD',
      prod_id: productId,
      cat_id: categoryId,
      search_term: searchTerm,
    };
    const params = {
      type: 'type',
      user_segment: 'placeholder',
      targeted_segment: 'placeholder',
      prod_id: 'placeholder',
      cat_id: 'placeholder',
      search_term: 'searchTerm',
    };
    const actual = formParamObj(params, categoryId, searchTerm, productId);
    expect(actual).to.deep.equal(expected);
    cdpUtilsObjStub.restore();
    targetedSegment.restore();
  });
});
