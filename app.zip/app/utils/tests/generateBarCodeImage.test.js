import sinon from 'sinon';
import generateBarcodeImage from '../generateBarCodeImage';

describe('#generateBarCodeImage', () => {
  it('should return null if non browser', () => {
    sinon.stub(window, 'PDF417').returns(() => {});
    expect(generateBarcodeImage('X211')).to.equal('');
  });
  it('should return bar code', () => {
    const bcodeArr = [[1, 1], [0, 0]];
    global.setTimeout(3000);
    global.window.PDF417 = {
      init: sinon.stub(),
      getBarcodeArray: sinon
        .stub()
        .returns({ num_cols: 1, num_rows: 1, bcode: bcodeArr }),
    };
    expect(generateBarcodeImage('U5T8')).to.equal(
      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAYAAABWKLW/AAAAEklEQVQYV2NkYGD4zwAFjDg5AEIzAwEJC2aVAAAAAElFTkSuQmCC'
    );
  });
});
