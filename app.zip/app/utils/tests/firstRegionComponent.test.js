import { firstRegionComponent } from '../firstRegionComponent';

describe(__filename, () => {
  const regionComponents = [
    { name: 'MarketingBanner', params: {} },
    { name: 'abc', params: {} },
  ];
  it('should return null for non-array regionComponents', () => {
    const result = firstRegionComponent(null);
    expect(result).to.equal(null);
  });
  it('should render firstRegionComponent for MarketingBanner', () => {
    const expected = [{ name: 'MarketingBanner', params: {} }];
    const actual = firstRegionComponent(
      regionComponents,
      ['MarketingBanner'],
      true
    );
    expect(actual).to.deep.equal(expected);
  });
  it('should render firstRegionComponent for other then MarketingBanner', () => {
    const expected = [{ name: 'abc', params: {} }];
    const actual = firstRegionComponent(regionComponents, ['MarketingBanner']);
    expect(actual).to.deep.equal(expected);
  });
});
