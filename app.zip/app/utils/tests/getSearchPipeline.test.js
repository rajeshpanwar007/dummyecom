import { returnSearchPipeline } from '../getSearchPipeline';

describe('#returnSearchPipeline', () =>
  it('should return pipeline string', () => {
    const pipeline = '/api/apps/bedbath/query/s5?web3feo=abc';
    const actual = returnSearchPipeline(pipeline);
    expect('s5').to.equal(actual);
  }));
