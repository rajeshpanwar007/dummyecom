import sinon from 'sinon';
import * as ServiceUtil from '@bbb-app/utils/serviceUtil';
import { reArrangeGBBProductList } from '../expertPicks';

describe(__filename, () => {
  describe('#ExpertPicksUtill', () => {
    const CMSProductList = [
      [
        {
          product_id: '11',
          scene7_id: 'image11',
          selling_point: 'Awsome Product 11',
        },
        {
          product_id: '12',
          scene7_id: 'image12',
          selling_point: 'Awsome Product 12',
        },
      ],
      [
        {
          product_id: '21',
          scene7_id: 'image21',
          selling_point: 'Awsome Product 21',
        },
        {
          product_id: '22',
          scene7_id: 'image22',
          selling_point: 'Awsome Product 22',
        },
      ],
      [
        {
          product_id: '31',
          scene7_id: 'image31',
          selling_point: 'Awsome Product 31',
        },
        {
          product_id: '32',
          scene7_id: 'image32',
          selling_point: 'Awsome Product 32',
        },
      ],
    ];
    const solrProductList = [
      {
        PRODUCT_ID: '11',
        SEO_URL: 'url11',
        DISPLAY_NAME: 'Awsome Product 11',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
      {
        PRODUCT_ID: '12',
        SEO_URL: 'url12',
        DISPLAY_NAME: 'Awsome Product 12',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
      {
        PRODUCT_ID: '21',
        SEO_URL: 'url21',
        DISPLAY_NAME: 'Awsome Product 21',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
      {
        PRODUCT_ID: '22',
        SEO_URL: 'url22',
        DISPLAY_NAME: 'Awsome Product 22',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
      {
        PRODUCT_ID: '31',
        SEO_URL: 'url31',
        DISPLAY_NAME: 'Awsome Product 31',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
      {
        PRODUCT_ID: '32',
        SEO_URL: 'url32',
        DISPLAY_NAME: 'Awsome Product 32',
        SKU_ID: ['123'],
        PRICE_RANGE_STRING: '123',
        INVENTORY_STATUS: 'Positive',
        IS_PRICE: '$10',
        WAS_PRICE: '$12',
        LOW_PRICE: '10',
        PRICE_RANGE_DESCRIP: 'yes',
        INCART_FLAG: false,
      },
    ];

    beforeEach(() => {
      sinon.stub(ServiceUtil, 'logErrorsToService').callsFake(() => {
        return true;
      });
    });
    afterEach(() => {
      ServiceUtil.logErrorsToService.restore();
    });

    it('Should return three Main products', () => {
      const expected = [
        {
          product_id: '11',
          seo_url: 'url11',
          display_name: 'Awsome Product 11',
          scene7_id: 'image11',
          sku_id: '',
          selling_point: 'Awsome Product 11',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '21',
          seo_url: 'url21',
          display_name: 'Awsome Product 21',
          scene7_id: 'image21',
          sku_id: '',
          selling_point: 'Awsome Product 21',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '31',
          seo_url: 'url31',
          display_name: 'Awsome Product 31',
          scene7_id: 'image31',
          sku_id: '',
          selling_point: 'Awsome Product 31',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
      ];
      const actual = reArrangeGBBProductList(CMSProductList, solrProductList);
      expect(actual).to.deep.equal(expected);
    });
    it('Should return one Main and two Backup products', () => {
      const expected = [
        {
          product_id: '11',
          seo_url: 'url11',
          display_name: 'Awsome Product 11',
          scene7_id: 'image11',
          sku_id: '',
          selling_point: 'Awsome Product 11',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '22',
          seo_url: 'url22',
          display_name: 'Awsome Product 22',
          scene7_id: 'image22',
          sku_id: '',
          selling_point: 'Awsome Product 22',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '32',
          seo_url: 'url32',
          display_name: 'Awsome Product 32',
          scene7_id: 'image32',
          sku_id: '',
          selling_point: 'Awsome Product 32',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
      ];
      solrProductList[2].INVENTORY_STATUS = 'Zero';
      solrProductList[4].INVENTORY_STATUS = 'Zero';
      const actual = reArrangeGBBProductList(CMSProductList, solrProductList);
      expect(actual).to.deep.equal(expected);
    });
    it('Should return three Backup products', () => {
      const expected = [
        {
          product_id: '12',
          seo_url: 'url12',
          display_name: 'Awsome Product 12',
          scene7_id: 'image12',
          sku_id: '',
          selling_point: 'Awsome Product 12',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '22',
          seo_url: 'url22',
          display_name: 'Awsome Product 22',
          scene7_id: 'image22',
          sku_id: '',
          selling_point: 'Awsome Product 22',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '32',
          seo_url: 'url32',
          display_name: 'Awsome Product 32',
          scene7_id: 'image32',
          sku_id: '',
          selling_point: 'Awsome Product 32',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
      ];
      solrProductList[0].INVENTORY_STATUS = '0';
      solrProductList[2].INVENTORY_STATUS = '0';
      solrProductList[4].INVENTORY_STATUS = '0';
      const actual = reArrangeGBBProductList(CMSProductList, solrProductList);
      expect(actual).to.deep.equal(expected);
    });
    it('Should return less than three products', () => {
      const expected = [
        {
          product_id: '12',
          seo_url: 'url12',
          display_name: 'Awsome Product 12',
          scene7_id: 'image12',
          sku_id: '',
          selling_point: 'Awsome Product 12',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
        {
          product_id: '22',
          seo_url: 'url22',
          display_name: 'Awsome Product 22',
          scene7_id: 'image22',
          sku_id: '',
          selling_point: 'Awsome Product 22',
          normal: '$12',
          low: '$10',
          lowValue: '10',
          priceRangeDescription: 'yes',
          inCart: false,
        },
      ];
      solrProductList[0].INVENTORY_STATUS = '0';
      solrProductList[2].INVENTORY_STATUS = '0';
      solrProductList[4].INVENTORY_STATUS = '0';
      solrProductList[5].INVENTORY_STATUS = '0';
      const actual = reArrangeGBBProductList(CMSProductList, solrProductList);
      expect(actual).to.deep.equal(expected);
    });
    it('Should return no product', () => {
      const expected = [];
      solrProductList[0].INVENTORY_STATUS = 'Zero';
      solrProductList[1].INVENTORY_STATUS = 'Zero';
      solrProductList[2].INVENTORY_STATUS = 'Zero';
      solrProductList[3].INVENTORY_STATUS = 'Zero';
      solrProductList[4].INVENTORY_STATUS = 'Zero';
      solrProductList[5].INVENTORY_STATUS = 'Zero';
      const actual = reArrangeGBBProductList(CMSProductList, solrProductList);
      expect(actual).to.deep.equal(expected);
    });
  });
});
