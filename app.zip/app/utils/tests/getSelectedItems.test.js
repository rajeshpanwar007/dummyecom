import { getSelectedItems } from '../getSelectedItems';
import { getXHRRequestHeaders } from '../getXHRRequestHeaders';
import removeElementFromArray from '../removeElementFromArray';
import shorten from '../shorten';

const facetData = {
  RATINGS: {
    id: 'RATINGS',
    displayName: 'Ratings',
    type: 'range',
    items: [
      {
        label: '1.0',
        value: '1.0',
        count: 4,
        selected: true,
        key: '1-0',
      },
      {
        label: '2.0',
        value: '2.0',
        count: 9,
        selected: true,
        key: '2-0',
      },
      {
        label: '3.0',
        value: '3.0',
        count: 7,
        selected: false,
        key: '3-0',
      },
      {
        label: '4.0',
        value: '4.0',
        count: 13,
        selected: false,
        key: '4-0',
      },
      {
        label: '5.0',
        value: '5.0',
        count: 11,
        selected: false,
        key: '5-0',
      },
    ],
  },
  LOW_PRICE: {
    id: 'LOW_PRICE',
    displayName: 'Price',
    type: 'interval',
    items: [
      {
        label: '20-60',
        value: '20-60',
        count: '10',
        selected: false,
        key: '20-60',
        range: true,
      },
      {
        label: '0 to 25.99',
        value: '0-25.99',
        count: '579',
        range: undefined,
        selected: false,
        key: '0-to-25-99',
      },
      {
        label: '26 to 50.99',
        value: '26-50.99',
        count: '129',
        range: undefined,
        selected: false,
        key: '26-to-50-99',
      },
      {
        label: '51 to 100.99',
        value: '51-100.99',
        count: '27',
        range: undefined,
        selected: false,
        key: '51-to-100-99',
      },
      {
        label: '101 to 200.99',
        value: '101-200.99',
        count: '1',
        range: undefined,
        selected: false,
        key: '101-to-200-99',
      },
      {
        label: '201 to 300.99',
        value: '201-300.99',
        count: '0',
        range: undefined,
        selected: false,
        key: '201-to-300-99',
      },
      {
        label: '301 to 400.99',
        value: '301-400.99',
        count: '0',
        range: undefined,
        selected: false,
        key: '301-to-400-99',
      },
      {
        label: '401 to 500.99',
        value: '401-500.99',
        count: '0',
        range: undefined,
        selected: false,
        key: '401-to-500-99',
      },
      {
        label: '501 to 600.99',
        value: '501-600.99',
        count: '0',
        range: undefined,
        selected: false,
        key: '501-to-600-99',
      },
      {
        label: '601 to 700.99',
        value: '601-700.99',
        count: '0',
        range: undefined,
        selected: false,
        key: '601-to-700-99',
      },
      {
        label: '701 to 800.99',
        value: '701-800.99',
        count: '0',
        selected: false,
        key: '701-to-800-99',
      },
      {
        label: '801 to 1000.99',
        value: '801-1000.99',
        count: '0',
        selected: false,
        key: '801-to-1000-99',
      },
      {
        label: '1001 to 1500.99',
        value: '1001-1500.99',
        count: '0',
        selected: false,
        key: '1001-to-1500-99',
      },
      {
        label: '1501 to 2000.99',
        value: '1501-2000.99',
        count: '0',
        selected: false,
        key: '1501-to-2000-99',
      },
      {
        label: '2001 to 3000.99',
        value: '2001-3000.99',
        count: '0',
        selected: false,
        key: '2001-to-3000-99',
      },
      {
        label: '3001 to 100000',
        value: '3001-100000',
        count: '0',
        selected: false,
        key: '3001-to-100000',
      },
    ],
  },
};

const selectedFilters = {
  RATINGS: ['1-0', '2-0'],
  LOW_PRICE: ['20-60', '0-25', '26-50'],
};

describe(__filename, () => {
  it('#getSelectedItems', () => {
    const result = getSelectedItems(facetData.RATINGS.items);
    expect(result.length).to.equal(2);
  });
  it('#getXHRRequestHeaders', () => {
    const result = getXHRRequestHeaders(
      selectedFilters,
      facetData,
      { start: 1 },
      'some-desc',
      10,
      false,
      ['testSws']
    );
    expect(result).to.be.a('object');
  });
});

describe('shorten', () => {
  it('should return shortened string ...', () => {
    const text = '123456789101112';
    const maxLength = 10;
    const actual = shorten(text, maxLength);
    const expected = '1234567…';
    expect(actual).to.equal(expected);
  });
});

describe('#removeElementFromArray', () => {
  it('should remove the element from the array', () => {
    const arr = [1, 2, 3, 4];
    expect(removeElementFromArray(arr, 2)).to.deep.equal([1, 3, 4]);
  });
});
