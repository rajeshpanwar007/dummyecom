import {
  parseHierarchy,
  getUrlLevel,
  parseBreadcrumbHierarchy,
  parseSubcategoryHierarchy,
} from '../checklistCategory';

const checklistId = 'DC32';
const checklistName = 'baby-registry';
const hierarchyStr = '2/DC3427_Newborn Essentials/DC3460_Footies';

describe(__filename, () => {
  describe('# parse hierarchies', () => {
    it('should parse the hierarchy str', () => {
      const result = parseHierarchy({
        hierarchyStr,
        checklistId,
        checklistName,
        urlKey: 'url',
        nameKey: 'text',
        leafOnly: true,
      });
      const mockHierarchy = {
        text: 'Footies',
        url:
          '/store/checklist/baby-registry/Newborn-Essentials/Footies/dc3460/dc32',
      };

      expect(result.url).to.equal(mockHierarchy.url);
      expect(result.text).to.equal(mockHierarchy.text);
    });

    it('should get the  url for the level', () => {
      const categoryId = 'DC3318';
      const categoryNames = ['Nursery & Decor', 'Baby Blanket'];
      const result = getUrlLevel({
        checklistId,
        checklistName,
        categoryId,
        categoryNames,
      });
      const mockUrl =
        '/store/checklist/baby-registry/Nursery-Decor/Baby-Blanket/dc3318/dc32';

      expect(result).to.equal(mockUrl);
    });

    it('should parse breadcrumb hierarchy', () => {
      const result = parseBreadcrumbHierarchy(
        hierarchyStr,
        checklistId,
        checklistName
      );
      const mockHierarchy = [
        {
          id: 'DC3427',
          name: 'Newborn Essentials',
          url: '/store/checklist/baby-registry/Newborn-Essentials/dc3427/dc32',
        },
        {
          id: 'DC3460',
          name: 'Footies',
          url:
            '/store/checklist/baby-registry/Newborn-Essentials/Footies/dc3460/dc32',
        },
      ];

      expect(result[0].url).to.equal(mockHierarchy[0].url);
      expect(result[1].url).to.equal(mockHierarchy[1].url);
    });

    it('should parse subCategory hierarchy', () => {
      const result = parseSubcategoryHierarchy(
        hierarchyStr,
        checklistId,
        checklistName
      );
      const mockHierarchy = {
        text: 'Footies',
        url:
          '/store/checklist/baby-registry/Newborn-Essentials/Footies/dc3460/dc32',
      };

      expect(result.url).to.equal(mockHierarchy.url);
      expect(result.text).to.equal(mockHierarchy.text);
    });
  });
});
