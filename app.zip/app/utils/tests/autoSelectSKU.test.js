import autoSelectSKU from '../autoSelectSKU';
describe('#autoSelectSKU', () => {
  it('should test autoSelectSKU with proper data', () => {
    const swatchDetails = {
      skuId: '46374677',
      skuDetails: [
        {
          COLOR: 'PINK',
          SKU_ID: '46374677',
          SKU_SIZE: 'KING',
        },
      ],
    };
    const colorToSelect = 'PINK';
    const sizeToSelect = 'KING';
    const skuIdToSelect = '46374677';
    const obj = autoSelectSKU(swatchDetails);
    expect(obj).to.deep.equal({
      colorToSelect,
      sizeToSelect,
      skuIdToSelect,
    });
  });
});
