import createTimeSlot from '../createTimeSlot';
describe('#ReturnTimeSlot', () => {
  it('should return createTimeSlot length', () => {
    const actualResult = createTimeSlot();
    expect(actualResult.length).to.equal(13);
  });
});
