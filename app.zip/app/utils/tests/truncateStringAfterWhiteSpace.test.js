import truncateStringAfterWhitespace from '../truncateStringAfterWhiteSpace';
describe('truncateStringAfterWhitespace', () => {
  it('should truncate String After given number of Whitespace', () => {
    const orgString = 'red and black flannel sheet cover';
    const nthNumberOfWhitespace = 5;
    const expString = 'red and black flannel sheet';
    const obj = truncateStringAfterWhitespace(orgString, nthNumberOfWhitespace);
    expect(obj).to.deep.equal(expString);
  });
  it('should truncate String After given number or less of Whitespace', () => {
    const orgString = 'red and black flannel sheet';
    const nthNumberOfWhitespace = 5;
    const expString = 'red and black flannel sheet';
    const obj = truncateStringAfterWhitespace(orgString, nthNumberOfWhitespace);
    expect(obj).to.deep.equal(expString);
  });
});
