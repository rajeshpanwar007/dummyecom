import fetchDataForRoute from '../fetchDataForRoute';
import { fetchProductDetails } from '../../../app/containers/Pages/PDP/ProductDetails/ProductDetailsActions';

describe('fetch Data For Route with no actions', () => {
  // const input = {
  //   routes: [
  //     {
  //       path: '/',
  //       exact: true,
  //     },
  //   ],
  //
  // };
  // const res = [];

  const matchedRoute = {
    path: '/',
    url: '/',
    isExact: true,
    params: {
      experienceIdentifier: 'staticPages',
      multipleAction: false,
      pagePath: '/',
      query: {},
    },
    fetchData: [fetchProductDetails],
    pageName: 'HOMEPAGE',
    search: '',
  };

  it('should fetch array of actions for matched route', () => {
    expect(fetchDataForRoute({ matchedRoute })).to.have.length(5);
  });
  //   it('should fetch mached actions for a route or an emptyarray', () => {
  //     expect(fetchDataForRoute({ routes2, url }).to.equal(res2));
  //   });
});
