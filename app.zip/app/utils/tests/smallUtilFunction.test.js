import { transformSwsQuerytoArray } from '../transformSwsQuerytoArray';
import { removeElementFromArray } from '../removeElementFromArray';
describe('small_util_file', () => {
  it('should transform sws array to query string for blank', () => {
    const result = transformSwsQuerytoArray('');
    expect(result.length).to.equal(0);
  });

  it('should transform sws array to query string', () => {
    const result = transformSwsQuerytoArray(
      '/store/s/sheets/fl_red/sddZip-07083?ta=typeahead&view=GRID&removeInStock=true'
    );
    expect(result.length).to.equal(2);
  });

  it('should not removeElementFromArray', () => {
    const arry = ['12', '23', '34'];
    const elemToRemove = '12';
    const result = removeElementFromArray(arry, elemToRemove);
    expect(result.length).to.equal(2);
  });
});
