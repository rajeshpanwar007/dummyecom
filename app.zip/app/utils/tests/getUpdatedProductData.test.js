import getUpdatedProductData, {
  createFilteredObj,
} from '../getUpdatedProductData';

describe('#getUpdatedProductData', () => {
  it('#getUpdatedProductData', () => {
    const productDetails = {
      TYPE: 'MSWP',
      PRODUCT_ID: '123',
      SEO_URL: '/product/vinyl-table-pad-in-white/100331',
    };

    const skuDetails = [
      {
        SKU_ID: '1234',
        DISPLAY_NAME: 'Refrigerator',
        ONLINE_INVENTORY: 'true',
      },
    ];

    const selectedSKU = {
      colorVariation: {
        label: 'GREEN',
        index: 4,
      },
      skuId: '1234',
    };

    expect(
      getUpdatedProductData(productDetails, skuDetails, selectedSKU)
    ).to.deep.equal({
      SKU_ID: '1234',
      PRODUCT_ID: '123',
      DISPLAY_NAME: 'Refrigerator',
      ONLINE_INVENTORY: 'true',
      WAS_PRICE: null,
      INCART_FLAG: 'false',
      IS_PRICE_RANGE_STR: null,
      SEO_URL: '/product/vinyl-table-pad-in-white/100331',
      TYPE: 'MSWP',
    });
  });
  it('should return the filteredObj if skuId is nor present', () => {
    const productDetails = {
      TYPE: 'MSWP',
      PRODUCT_ID: '123',
      SEO_URL: '/product/vinyl-table-pad-in-white/100331',
    };
    const skuDetails = '';
    const selectedSKU = '';
    const output = getUpdatedProductData(
      productDetails,
      skuDetails,
      selectedSKU
    );
    expect(output).to.deep.equal({
      INCART_FLAG: 'false',
      IS_PRICE_RANGE_STR: null,
      PRODUCT_ID: '123',
      SEO_URL: '/product/vinyl-table-pad-in-white/100331',
      TYPE: 'MSWP',
      WAS_PRICE: null,
    });
  });
});

describe('#getUpdatedProductData Util', () => {
  const productDetails = {
    TYPE: 'MSWP',
    PRODUCT_ID: '123',
    SEO_URL: '/product/vinyl-table-pad-in-white/100331',
  };

  const skuDetails = [
    {
      SKU_ID: '1234',
      DISPLAY_NAME: 'Refrigerator',
      ONLINE_INVENTORY: 'true',
      COLOR: 'white',
      SCENE7_URL: 'abcd',
    },
  ];

  const colorVariation = {
    label: 'white',
  };
  const skuId = '1234';

  it('#createFilteredObj will return skuDetails when skuId is available', () => {
    expect(
      createFilteredObj(productDetails, skuDetails, colorVariation, skuId)
    ).to.deep.equal(skuDetails[0]);
  });

  it('#createFilteredObj will return object when obj.SCENE7_URL is available', () => {
    expect(
      createFilteredObj(productDetails, skuDetails, colorVariation)
    ).to.deep.equal({
      SCENE7_URL: 'abcd',
      ALT_IMG: undefined,
      SCENE7_ALT_IMAGE_ID: undefined,
      SKU_SCENE7_URL: undefined,
    });
  });

  it('#createFilteredObj will return productDetails when obj.SCENE7_URL is not available', () => {
    expect(
      createFilteredObj(productDetails, skuDetails, { label: 'black' })
    ).to.deep.equal(productDetails);
  });

  it('#createFilteredObj will return productDetails when skuId is not available', () => {
    expect(createFilteredObj(productDetails, skuDetails)).to.deep.equal(
      productDetails
    );
  });
});
