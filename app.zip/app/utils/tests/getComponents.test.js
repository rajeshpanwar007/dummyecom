/**
 * Test get components
 */
import { getComponents, findComponent } from '../getComponents';

describe('fetch getComponents without component', () => {
  const component = [{}];
  const region = 'first';

  it('should fetch getComponents', () => {
    expect(getComponents(component, region)).to.equal(null);
  });
});

describe('fetch getComponents with component', () => {
  const components = [
    {
      params: {
        id: '10417205471',
      },
      name: 'Teaser',
    },
    {
      name: 'CountdownClock',
      params: { id: '21378', style: 'V1' },
    },
  ];
  const regions = {
    first: {
      components,
    },
  };

  const region = 'first';

  const allComponents = {
    first: {
      components,
    },
    second: {
      components,
    },
    third: {
      components,
    },
  };

  const componentMap = {
    OpenContainer: () => {},
  };

  const index = 0;

  it('should fetch getComponents, get region, findComponent', () => {
    expect(
      getComponents(regions, region, undefined, componentMap)
    ).to.have.length(2);
  });

  it('should invoke if first Component is Open Container', () => {
    const keyValue = 'f0';
    const controllerProps = {};

    const props = {
      name: 'OpenContainer',
    };
    const firstComponents = [
      {
        params: {
          id: '7834',
        },
        name: 'OpenContainer',
      },
    ];

    const returnedComponent = findComponent(
      props,
      keyValue,
      controllerProps,
      firstComponents,
      region,
      index,
      allComponents,
      componentMap
    );
    expect(returnedComponent.props.isFirstComponent).to.equal(true);
  });
});
