import sinon from 'sinon';
import { fetchContentForUserSegment } from '../fetchContentForUserSegment';

describe(__filename, () => {
  const components = [
    { key: '5685', params: { id: '5685' } },
    { key: '134', params: { id: '134' } },
    {
      key: 'tools_service_module_Upcoming Mover Two Months',
      params: {
        user_segment: 'Upcoming Mover Two Months',
        type: 'tools_service_module',
      },
    },
  ];
  const categoryId = '12345';
  const searchTerm = 'Bedding';
  const productId = '12345';
  const fetchDynamicContent = sinon.spy();
  it('should render fetchContentForUserSegment', () => {
    fetchContentForUserSegment(
      components,
      categoryId,
      searchTerm,
      productId,
      fetchDynamicContent
    );
    expect(fetchDynamicContent.called).to.equal(true);
  });
});
