import sinon from 'sinon';
import scrollToTopBar from '../scrollToTopBar';

describe('#scrollToTopBar', () => {
  it('should fire scrollToTopReset if scrollToTop is true', () => {
    const scrollToTopResetSpy = sinon.spy();
    scrollToTopBar(true, scrollToTopResetSpy);
    expect(scrollToTopResetSpy.called);
  });
});
