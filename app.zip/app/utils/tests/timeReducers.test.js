import timeReducers from '../timeReducers';

describe('#timeReducers', () => {
  it('should return timeReducers with default', () => {
    expect(timeReducers({ value1: 'test', value2: 'test' })).to.not.equal('');
  });
  it('should return timeReducers with prop', () => {
    expect(timeReducers('')).to.equal('');
  });
});
