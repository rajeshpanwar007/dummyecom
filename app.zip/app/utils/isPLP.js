import { isEmpty, getOr } from 'lodash/fp';
import { matchPath } from 'react-router';
import {
  ROUTE_CATEGORY_PATH,
  ROUTE_CATEGORY_L1_AS_L2_PATH,
  ROUTE_BRAND_PATH,
  ROUTE_CHECKLIST_CATEGORY_PATH,
} from '@bbb-app/constants/route/searchRoute';

export const isPLP = locationBeforeTransitions => {
  const routes = [
    ROUTE_CATEGORY_PATH,
    ROUTE_CATEGORY_L1_AS_L2_PATH,
    ROUTE_BRAND_PATH,
    ROUTE_CHECKLIST_CATEGORY_PATH,
  ];
  let aMatchedPath = null;
  let route = null;
  const defaultPathname = getOr('', 'pathname', locationBeforeTransitions);
  const pathname = getOr(
    defaultPathname,
    'location.pathname',
    locationBeforeTransitions
  );
  for (let i = 0; i < routes.length; i += 1) {
    route = routes[i];
    aMatchedPath = matchPath(pathname, route, {
      exact: true,
    });
    if (!isEmpty(aMatchedPath)) {
      break;
    }
  }
  return aMatchedPath && route && { matchedPath: aMatchedPath, route };
};
