import { pathOr, isEmpty, isArray } from 'lodash/fp';
import { getStoreRef } from '@bbb-app/utils/storeRefUtils';
import { getContentId } from '@bbb-app/utils/experience';
import { formParamObj } from './formParamObj';

const getMainParams = (categoryId, searchTerm, productId) => {
  const mainParam = {};
  if (categoryId) {
    mainParam.categoryId = categoryId;
  }
  if (searchTerm) {
    mainParam.searchTerm = searchTerm;
  }
  if (productId) {
    mainParam.productId = productId;
  }
  return mainParam;
};

export const fetchContentForUserSegment = (
  components,
  categoryId,
  searchTerm,
  productId,
  fetchDynamicContent
) => {
  const userSegmentcomponentsList =
    isArray(components) &&
    components.filter(val => {
      if (pathOr(false, 'params.user_segment', val)) {
        const store = getStoreRef();
        const state = store && store.getState();
        const experienceContent = state.get('experienceContent');
        return !experienceContent.has(
          getContentId(
            val.params,
            '',
            productId,
            categoryId,
            '',
            '',
            searchTerm
          )
        );
      }
      return false;
    });
  const contentParams =
    isArray(userSegmentcomponentsList) &&
    userSegmentcomponentsList.map(val =>
      formParamObj(val.params, categoryId, searchTerm, productId)
    );

  if (!isEmpty(contentParams)) {
    const mainParams = getMainParams(categoryId, searchTerm, productId);
    fetchDynamicContent(contentParams, mainParams);
  }
};
