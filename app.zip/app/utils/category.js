import { compile } from 'path-to-regexp';
import { isBedBathCanada } from '@bbb-app/utils/common';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import sanitizeSearchTerm from '@bbb-app/utils/sanitizeSearchTerm';
import { checkTrailingSlash } from '@bbb-app/utils/checkTrailingSlash';
import { HOSTNAMES } from '@bbb-app/seo/components/constants';
import { COLLEGE_URL } from '@bbb-app/constants/appConstants';
import { PAGE_NAME_BRAND_PLP } from '@bbb-app/constants/route/route';
import { COLLEGE, UNIVERSITY } from '../constants/search';
export const toPath = path => compile(path);
const trailingSlash = '/';

/**
 * @param {*} params
 */
export const toCanonicalPath = (
  path,
  paramsArg,
  siteId,
  pageIdentifier,
  categoryName = ''
) => {
  const hostname = HOSTNAMES.get(siteId) || '';
  let params;
  if (paramsArg && paramsArg.level1) {
    params = Object.assign(paramsArg, {
      level1: paramsArg.level1.toLowerCase(),
    });
  } else {
    params = { ...paramsArg };
  }
  if (pageIdentifier === PAGE_NAME_BRAND_PLP && categoryName) {
    params.brandName = sanitizeSearchTerm(params.brandName);
  }
  if (params.startPerPage && /^1-\d+$/.test(params.startPerPage)) {
    delete params.startPerPage;
  }
  if (params.store && params.store.length > 0) delete params.store;
  let subPath = toPath(path)(params, { encode: val => val });

  subPath = checkTrailingSlash(subPath);

  return hostname + subPath;
};

/**
 * This sanatizes names so they are ready to be urls
 **/
export const sanitizeName = name => {
  if (typeof name !== 'string') {
    return '';
  }
  return (
    name
      /* Replace anything that isn't a number or letter or space with blank */
      .replace(/[^a-zA-Z0-9 ]/g, '')
      /* Replace double spaces resulting from first replace with a single space(this happens with & in titles)*/
      .replace('  ', ' ')
      /* Replace anything that isn't a number or letter with a dash. Essentially replace all spaces with dashes.*/
      .replace(/[^a-zA-Z0-9]/g, '-')
  );
};

/**
 * Determines if the category is a College category.
 * If the level name matches the  college string, it will return true
 *
 * @param  {string}   levelName    The name of the [category] level that determines if it is college.
 * @return {boolean}  The boolean value of whether or not the path is a college one.
 */
export const isCollege = (levelName = '') => {
  const normalizedLevelName = levelName.toString().toLowerCase();
  if (levelName) {
    return (
      normalizedLevelName === COLLEGE || normalizedLevelName === UNIVERSITY
    );
  }
  return false;
};

/**
 * This formats ids into urls appropriate for multilevel category routes
 * id is a category id string like '10001' or '/10001'
 * names is an array of category titles like ['Kitchen', 'Small Appliances'] or ['Tea & Coffee', 'Tea sets']
 * There are some exceptions the common 'category/:level1/:level2?/:level3?/:categoryId' URL pattern for the
 * category hierarchy (breadcrumb) URLs;
 * (e.g. for college L1s, URLs should be, '/store/page/college/:categoryId' rather than '/store/category/college')
 **/
export const getUrlLevel = (id, names = []) => {
  const cleanId = id.replace(/[^0-9]/g, '');
  const namesList = names.map(sanitizeName);
  let uri = `/store/category/${namesList.join('/')}/${cleanId}`;

  // college L1 exception
  if (namesList.length === 1 && isCollege(namesList[0]))
    uri = !isBedBathCanada()
      ? `/store/page/${namesList.join('/')}`
      : COLLEGE_URL;

  uri = String(uri).toLowerCase();
  return uri.lastIndexOf('/') !== uri.length - 1
    ? `${uri}${trailingSlash}`
    : uri;
};

/**
 * This parses category hierarchy strings like:
 * "3/10001_Bedding/10504_Bedding/12016_Comforter Sets"
 * and turns them into arrays of objects shaped like:
 * [
 *   {
 *     id: '10001',
 *     name: 'Bedding'
 *     url: '/store/category/10001',
 *   },
 *   {
 *     id: '10504',
 *     name: 'Bedding'
 *     url: '/store/category/10504',
 *   },
 *   {
 *     id: '12016',
 *     name: 'Comforter Sets'
 *     url: '/store/category/12016',
 *   }
 * ]
 */
export const parseHierarchy = hierarchyStr => {
  const LEVEL_DELIMITER = '/';
  const NAME_ID_DELIMITER = '_';
  const namesList = [];
  const categoryArray = hierarchyStr
    /** Split by category level */
    .split(LEVEL_DELIMITER)
    /** Discard the leading number since we don't need it */
    .slice(1);
  /** Map over and split category ID and name into objects */
  for (let i = 0; i < categoryArray.length; i += 1) {
    const name = categoryArray[i].split(NAME_ID_DELIMITER)[1];
    namesList.push(name);
  }
  return categoryArray.map((category, index) => {
    const [id, name] = category.split(NAME_ID_DELIMITER);
    return {
      url: getUrlLevel(id, namesList.slice(0, index + 1)),
      name,
      id,
    };
  });
};
/**
 * This parses category hierarchy strings like:
 * "3/10002_Kitchen^/images/home/PopCats_Sept_2017_Kitchen_US CA.jpg$other$/10515_Coffee & Tea^/images/home/popcat_coffee_q3.JPG$other$/12051_Coffee Carafes^/images/home/popcat_coffee_q3.JPG$other$
 *
 * As well as strings like:
 * "3/DC354_Kitchen/DC371_Bakeware/DC372_Nonstick Bakeware Set"
 *
 * and turns them into an object shaped like:
 *
 *   {
 *     text: '10001',
 *     url: '/store/category/12051'
 *     img:'https://s7d9.scene7.com/is/image/BedBathandBeyond/images/home/popcat_coffee_q3.JPG'
 *   }
 */
export const parseSubcategoryHierarchy = SubhierarchyStr => {
  /* istanbul ignore else */
  if (SubhierarchyStr.indexOf('^') > -1) {
    // get all ids from response string
    const id = SubhierarchyStr.match(/(?:\/)([0-9]+)(?=_)/g);
    // get all names from response string
    const name = SubhierarchyStr.match(/([^_]*\^)/g);
    // take the last name from array
    const lastName = name[name.length - 1];
    // get last image in response
    const img = SubhierarchyStr.match(/([^^]*_*)$/g)[0];

    return {
      text: lastName.slice(0, -1),
      url: getUrlLevel(id.slice(-1)[0], name),
      img: (img !== 'null' && getConcatenatedScene7URLWithImageId(img)) || null,
    };
  }

  return null;
};

/**
 * This gets the level of the category from urls like
 * "3/10002_Kitchen^/images/home/PopCats_Sept_2017_Kitchen_US CA.jpg$other$/10515_Coffee & Tea^/images/home/popcat_coffee_q3.JPG$other$/12051_Coffee Carafes^/images/home/popcat_coffee_q3.JPG$other$
 *
 * and returns that level as a number
 */
export const getSubcategoryLevel = SubhierarchyStr => {
  /* istanbul ignore else */
  if (SubhierarchyStr && SubhierarchyStr.indexOf('^') > -1) {
    // get all category names from response string
    const name = SubhierarchyStr.match(/([^_]*\^)/g);
    return name.length;
  }

  return null;
};
