import { setTimeoutCustom } from '@bbb-app/utils/timers';

export const scrollToPosition = titleId => {
  if (typeof window !== 'undefined' && window.location) {
    if (window.location.hash === `#${titleId}`) {
      const ele = document.getElementById(titleId);
      let timer;
      let topPos;
      const jumpToElement = () => {
        topPos = ele.getBoundingClientRect().y + window.scrollY - 150;
        window.scrollTo({ top: topPos, left: 0, behavior: 'smooth' });
      };

      // It will remove all the intervals and eventListeners
      const resetTimerAndEvent = () => {
        clearInterval(timer);
        window.removeEventListener('load', windowLoad, true);
        window.removeEventListener('scroll', windowScroll, true);
      };

      const windowScroll = () => {
        if (Math.ceil(topPos) === window.scrollY) {
          resetTimerAndEvent();
        }
      };
      const windowLoad = () => {
        resetTimerAndEvent();
        jumpToElement();
        timer = setInterval(() => {
          jumpToElement();
        }, 500);

        // pageScroll validate the position of the element
        window.addEventListener('scroll', windowScroll);

        // For the safe side, need to clean the setInterval after 3 sec
        setTimeoutCustom(() => {
          resetTimerAndEvent();
        }, 3000);
      };

      if (ele) {
        window.addEventListener('load', windowLoad);
      }
    }
  }
};
