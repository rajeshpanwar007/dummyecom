/* Return the updated product after selcting color variation */

import { isEmpty, isArray, pathOr } from 'lodash/fp';
export const createFilteredObj = (
  productDetails,
  skuDetails,
  colorVariation,
  skuId
) => {
  let filteredObj;
  if (skuId && isArray(skuDetails)) {
    filteredObj = skuDetails.find(item => item.SKU_ID === skuId);
  } else if (!isEmpty(colorVariation) && isArray(skuDetails)) {
    const obj = skuDetails.find(item => item.COLOR === colorVariation.label);
    if (obj && obj.SCENE7_URL) {
      filteredObj = {
        SCENE7_URL: obj.SCENE7_URL,
        ALT_IMG: obj.ALT_IMG,
        SKU_SCENE7_URL: obj.SKU_SCENE7_URL,
        SCENE7_ALT_IMAGE_ID: obj.SCENE7_ALT_IMAGE_ID,
      };
    } else {
      filteredObj = productDetails;
    }
  } else {
    filteredObj = productDetails;
  }
  return filteredObj;
};

const getUpdatedProductData = (productDetails, skuDetails, selectedSKU) => {
  const colorVariation = pathOr(null, 'colorVariation', selectedSKU);
  const skuId = pathOr(null, 'skuId', selectedSKU);
  const filteredObj = createFilteredObj(
    productDetails,
    skuDetails,
    colorVariation,
    skuId
  );
  /* istanbul ignore else  */
  if (filteredObj) {
    filteredObj.PRODUCT_ID = productDetails.PRODUCT_ID;
    filteredObj.IS_PRICE_RANGE_STR = pathOr(
      null,
      'IS_PRICE_RANGE_STR',
      filteredObj
    );
    filteredObj.WAS_PRICE = pathOr(null, 'WAS_PRICE', filteredObj);
    filteredObj.INCART_FLAG = pathOr('false', 'INCART_FLAG', filteredObj);
  }
  return Object.assign({}, productDetails, filteredObj);
};
export default getUpdatedProductData;
