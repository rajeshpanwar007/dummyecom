import { isEmpty } from 'lodash/fp';
/**
 *
 * @param selectedFacets
 * @return true if there's a selected facet.
 */
export const isFacetSelected = selectedFacets => {
  if (isEmpty(selectedFacets)) {
    return false;
  }
  const keys = Object.keys(selectedFacets);
  for (let i = 0; i < keys.length; i += 1) {
    /* istanbul ignore else */
    if (!isEmpty(selectedFacets[keys[i]])) {
      return true;
    }
  }
  return false;
};
