/**
 * Created by Ashish Bansal on 3/21/2020
 */

import { pathOr } from 'lodash/fp';
import qs from 'qs';

/**
 * It will return the key from url param.
 * @param props
 * @param key
 * @returns {null}
 */
const getParamFromUrl = (props, key) => {
  const search = pathOr('', 'location.search', props);
  const query = qs.parse(search, { ignoreQueryPrefix: true });
  const value = query ? query[key] : null;
  return value;
};

export default getParamFromUrl;
