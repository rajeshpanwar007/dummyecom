import LabelsUtil from '@bbb-app/utils/labelsUtil';
/**
 * @param [labels, label, arr] labels-> used from labelUtil library, label-> the label we want to
 * fetch data for, arr -> on which we want to add label
 * The method finds the label using the LabelsUtil and puts that in the array as default state
 */
const makeDefaultOption = (labels, label, arr) => {
  if (typeof arr === 'object' && arr.length && arr[0].props.key !== 'default') {
    const defaultOption = {
      label: LabelsUtil.getLabel(labels, label),
      props: {
        value: '',
        key: '',
      },
    };

    arr.unshift(defaultOption);
    return arr;
  }
  return [];
};
export default makeDefaultOption;
