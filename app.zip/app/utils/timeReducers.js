/**
 * This is for debugging only. It will wrap all reducers with a
 * function that times the execution of each. This is an
 * alternate version of the redux-log-slow-reducers package that
 * uses the timing API so that we can see the results in the
 * performance timeline in addition to the console.
 *
 * Usage: combineReducers(timeReducers({ ... }))
 *
 * @param {*} reducers
 */
export default function timeReducers(reducers) {
  /* istanbul ignore next  */
  Object.keys(reducers).forEach(name => {
    const originalReducer = reducers[name];
    // eslint-disable-next-line
    reducers[name] = (state, action) => {
      const label = `reducer [${name}] ${action.type}`;
      // eslint-disable-next-line no-console
      console.time(label);
      const result = originalReducer(state, action);
      // eslint-disable-next-line no-console
      console.timeEnd(label);
      return result;
    };
  });
  /* istanbul ignore next  */
  return reducers;
}
