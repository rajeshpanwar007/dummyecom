// To filter out particular component(s) from an array
// "isInverse" mode filters out everything else but the passed in components
export const firstRegionComponent = (
  regionComponents,
  componentNames,
  isInverse
) => {
  if (Array.isArray(regionComponents)) {
    return regionComponents.filter(component => {
      const condition = componentNames.includes(component.name);
      return isInverse ? condition : !condition;
    });
  }
  return null;
};
