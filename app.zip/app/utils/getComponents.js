/**
* @Description:
    This file has mainly following three methods to get components.
    method : findComponent - To get react element
    @param {Object} - _props parameter, which is props object for element
    @param {String} - keyValue parameter, unique value for react element and will use for key reference
    @param {Object} componentMap - Complete map of components, from which we will choose to render our experience.
    @return {Object} - Returns a Object
    Sample Usage:
       findComponent(objs, 2)
    method : getComponentsForRegion - To get single element from object
    @param {Object} - objs parameter, which is a refrence of component object from store
    @param {String} - region parameter, which is a refrence of region
    @param {Object} componentMap - Complete map of components, from which we will choose to render our experience.
    @return {Object} - Returns a html object
    Sample Usage:
       getComponentsForRegion(elements, region)
    method : getComponents - To get single element from object
    @param {Object} - components parameter, which is a refrence of component object from store
    @param {String} - region parameter, which is a refrence of region
    @param {Object} controllerProps - Props to be given the created component
    @param {Object} componentMap - Complete map of components, from which we will choose to render our experience.
    @return {Object} - Returns a html object
    Sample Usage:
       getComponents(components, 'first', controllerProps, componentMap)
*
*/

import React from 'react';
import { cloneDeep } from 'lodash/fp';
import LazyLoad from '@bbb-app/core-ui/lazy-load';

export const getFirstComponent = (allComponents, index) => {
  const componentsLength = allComponents && allComponents.length;
  const firstIndex = index === 0;
  const indexProps = {};
  if (componentsLength === 1 && firstIndex) {
    indexProps.isFirstComponent = true;
    return indexProps;
  }

  if (
    (allComponents.first || allComponents.second || allComponents.third) &&
    firstIndex
  ) {
    indexProps.isFirstComponent = true;
  }
  return indexProps;
};

/* eslint max-params: ["error", 8]*/
export const findComponent = (
  _props,
  keyValue,
  controllerProps,
  allObjs,
  region,
  index,
  allComponents,
  componentMap
) => {
  const element = componentMap[_props.name];
  // adding experience label data in props
  // indexProps is used to find out first component is Open container inside first region - BBBFEO-27541
  const indexProps = getFirstComponent(allComponents, index);

  const props = Object.assign(
    {},
    _props,
    {
      labels: controllerProps.labels,
      ...controllerProps,
    },
    indexProps
  );

  if (element) {
    const ReactElement = getReactElement(
      element,
      _props,
      allObjs,
      keyValue,
      region,
      props
    );

    if (_props.name === 'GoogleDFP') {
      return <div className={'componentWrapper-GoogleDFP'}>{ReactElement}</div>;
    }

    if (_props.name === 'CountdownClock') {
      return (
        <section className={'componentWrapper-CDT'}>{ReactElement}</section>
      );
    }

    if (region === 'second' && controllerProps.pageName !== 'PDP') {
      return <LazyLoad thresold={100}>{ReactElement}</LazyLoad>;
    }

    return ReactElement;
  }
  return (
    <div data-log={`component not available ${_props.name}`} key={keyValue} />
  );
};

export const getReactElement = (
  element,
  _props,
  allObjs,
  keyValue,
  region,
  props
) => {
  return React.createElement(element, {
    dataID: `${_props.name.toLowerCase()}`,
    components: allObjs,
    key: keyValue,
    region,
    ...props,
  });
};

export const getComponentsForRegion = (
  objs,
  region,
  controllerProps,
  allComponents,
  componentMap
) => {
  if (objs) {
    const components = [];
    if (objs.constructor === Array) {
      const updatedObj = cloneDeep(objs);
      Object.keys(updatedObj).forEach(key => {
        if (updatedObj[key].params && updatedObj[key].params.college_id) {
          updatedObj[key].params.college_id = controllerProps.collegeId;
        }
        components.push(
          findComponent(
            updatedObj[key],
            `${region[0]}${key}`,
            controllerProps,
            updatedObj,
            region,
            components.length,
            allComponents,
            componentMap
          )
        );
      });

      if (region === 'first' && controllerProps.pageName === 'HOMEPAGE') {
        components.push(
          findComponent(
            { name: 'UXTimer' },
            `${region[0]}${components.length}`,
            controllerProps,
            {},
            region,
            components.length,
            allComponents,
            componentMap
          )
        );
      }

      return components;
    }
  }
  return null;
};

export const getComponents = (
  components,
  region,
  controllerProps = {},
  componentMap = {}
) => {
  const exist = components[region];
  if (exist !== undefined) {
    const elements = components[region].components;
    return getComponentsForRegion(
      elements,
      region,
      controllerProps,
      components,
      componentMap
    );
  }
  return null;
};
