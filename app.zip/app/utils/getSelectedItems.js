import { kebabCase } from 'lodash/fp';
/**
 * Returns an array of selected items
 *
 * @param {array} data
 */
export const getSelectedItems = data => {
  return data
    .filter(item => {
      return item.selected;
    })
    .map(item => kebabCase(item.label));
};
