export const findValue = (obj, value) => {
  for (let key = 0; key < obj.length; key += 1) {
    if (obj[key].name === value) {
      if (obj[key].params && obj[key].params !== '') {
        return key;
      }
    }
  }
  return null;
};
