import { isBrowser } from '@bbb-app/utils/common';

export const isMarkAlreadyExists = marker => {
  if (!isBrowser()) return false;
  if (window.performance !== undefined) {
    return window.performance
      .getEntriesByType('mark')
      .filter(itm => itm.name === marker)[0];
  }
  return false;
};
