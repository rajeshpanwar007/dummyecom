import { isEmpty, pathOr } from 'lodash/fp';
/**
 * handles the SKU slection on the basis on skuId or color in the url
 * specific SKU is fetched from the array of SKUs
 * specific color (finish) and size are fetched from the specific SKU
 * color in the url is used if skuId not present in the url
 * @param swatchDetails
 * @memberof ProductDetails & QuickView
 */
const autoSelectSKU = swatchDetails => {
  let skuToSelect;
  let sizeToSelect = pathOr('', 'size', swatchDetails);
  let colorToSelect = pathOr('', 'color', swatchDetails);
  let skuIdToSelect = pathOr('', 'skuId', swatchDetails);
  const skuDetails = pathOr([], 'skuDetails', swatchDetails);
  const isTbs = pathOr(false, 'isTbs', swatchDetails);

  // filter out the sku to preselect based on given skuId
  if (!isEmpty(skuDetails)) {
    if (skuIdToSelect) {
      skuToSelect = skuDetails.find(itemSKU => {
        return skuIdToSelect === itemSKU.SKU_ID;
      });
    } else if (isTbs) {
      // filter out the sku to preselect based on given color
      if (colorToSelect) {
        const selectedColor = colorToSelect.toLowerCase();
        skuToSelect = skuDetails.find(itemSKU => {
          return selectedColor === pathOr('', 'COLOR', itemSKU).toLowerCase();
        });
      }

      // select the first sku
      if (isEmpty(skuToSelect)) {
        skuToSelect = skuDetails[0];
      }
    }
  }

  /* istanbul ignore else  */
  if (!isEmpty(skuToSelect)) {
    // get size
    sizeToSelect = skuToSelect.SKU_SIZE;
    // get color (finish)
    colorToSelect = skuToSelect.COLOR;
    // get skuId (based on either color or skuId)
    skuIdToSelect = skuToSelect.SKU_ID;
  }
  return {
    sizeToSelect,
    colorToSelect,
    skuIdToSelect,
  };
};

export default autoSelectSKU;
