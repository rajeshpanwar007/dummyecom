/**
 * @description it will return the heading, subheading, firstname for  my account user specific
 */

import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';

const generateMyAccountLayoutHeadings = data => {
  const firstName = pathOr('', 'firstName', data.profile);
  const heading = `${LabelsUtil.getLabel(
    data.labels,
    'personalisedInfo.personalInfoSubHeading'
  )}`;
  const subHeading = data.subHeadingLabel
    ? LabelsUtil.getLabel(data.labels, data.subHeadingLabel)
    : '';
  return {
    heading,
    subHeading,
    firstName,
  };
};

export default generateMyAccountLayoutHeadings;
