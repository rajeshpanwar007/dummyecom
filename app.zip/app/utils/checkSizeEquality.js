/**
 * Check Size Equality in SKU & Query Params(Swatch transition from PLP/QV to PDP)
 * ie. Size in SKU: "17&quot; DEEP" & Size in Query Param:"17-DEEP"
 * @param {string} skuSize: Size from product sku
 * @param {string} size: Size from Query Param
 * @returns {boolean}
 */
const checkSizeEquality = (skuSize, size) => {
  if (skuSize && size) {
    return (
      skuSize
        .replace(/&#39;/g, '')
        .replace(/&quot;/g, '')
        .replace(/[^a-zA-Z0-9]/g, '') === size.replace(/-/g, '')
    );
  }
  return false;
};

export default checkSizeEquality;
