/**
 * @function - convertCanadaDateInUSFormat
 * This function will convert 'dd/mm/yyyy' to 'mm/dd/yyyy' format
 * @param {string} - date
 * @return {string} - formatted date
 **/
const convertCanadaDateInUSFormat = date => {
  const dateSplit = date.split('/');
  const [dd, mm, yyyy] = dateSplit;
  return `${mm}/${dd}/${yyyy}`;
};
export default convertCanadaDateInUSFormat;
