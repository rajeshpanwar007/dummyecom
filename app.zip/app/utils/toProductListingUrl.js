import { compile, parse } from 'path-to-regexp';
import omit from 'lodash/fp/omit';
import consoleLog from '@bbb-app/utils/logger';
import {
  ROUTE_PRODUCT_SEARCH_PATH,
  ROUTE_CATEGORY_PATH,
  ROUTE_BRAND_PATH,
  ROUTE_BOPIS_PATH,
  ROUTE_SDD_PATH,
} from '@bbb-app/constants/route/searchRoute';
import {
  ROUTE_PLP_FILTERABLE_PATH,
  ROUTE_CLP_CATEGORY_PATH,
} from '../constants/search';
import { ROUTE_CHECKLIST_CATEGORY_PATH } from '../containers/Search/ChecklistCategory/mainChunkConstants';
import { CPLP } from './constants';
/**
 * Path-to-regexp patterns turned into functions.
 * @see https://github.com/pillarjs/path-to-regexp
 */
const toSearch = compile(ROUTE_PRODUCT_SEARCH_PATH);
const toCategory = compile(ROUTE_CATEGORY_PATH);
const toCPLP = compile(ROUTE_CLP_CATEGORY_PATH);
const toBrand = compile(ROUTE_BRAND_PATH);
const toChecklist = compile(ROUTE_CHECKLIST_CATEGORY_PATH);
const toBopis = compile(ROUTE_BOPIS_PATH);
const toSdd = compile(ROUTE_SDD_PATH);

/**
 * Map of fuzzy page identifiers to associate
 * the correct URL path compiler.
 */
const compilers = new Map([
  ['category', toCategory],
  ['PLP', toCategory],
  ['search', toSearch],
  ['SearchResults', toSearch],
  ['CPLP', toCPLP],
  ['brand', toBrand],
  ['BrandLanding', toBrand],
  ['checklist', toChecklist],
  ['bopisPLP', toBopis],
  ['sddPLP', toSdd],
]);

/**
 * Any URL path segment token where the optional
 * property is false. This is used as a default
 * "omission" array for building the base URLs.
 */
const optionalSegments = parse(ROUTE_PLP_FILTERABLE_PATH)
  .filter(token => token.optional)
  .map(token => token.name);

/**
 * Output a valid (optionally faceted) PLP URL for Category, Search, Brand, etc.
 *
 * @param {*} params
 * @param {*} type
 */
const toProductListingUrl = (
  params,
  type = 'category',
  omitParams = optionalSegments,
  url
) => {
  let compiler = compilers.get(type);

  if (CPLP.includes(params.level1)) {
    compiler = compilers.get('CPLP');
  }
  try {
    if (!compiler) {
      throw new Error(`No PLP URL compiler exists for type "${type}"`);
    }
    /**
   * Special case needed to handle checklist PLP since it has
   * the same pageIdentifier but a different route config and path.
   */
    if (compiler === toCategory && params.checklistName) {
      compiler = toChecklist;
    }
    if (url && url.includes('/store/pickup/')) {
      compiler = toBopis;
    }
    if (url && url.includes('/store/same-day-delivery')) {
      compiler = toSdd;
    }
    return compiler(omit(omitParams, params));
  } catch (error) {
    consoleLog.error(error);
    return '';
  }
};

export default toProductListingUrl;
