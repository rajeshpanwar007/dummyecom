const isRegionHasSingleComponent = regions => {
  let totalCompCount = 0;
  const regionsCollection = ['first', 'second', 'third'];
  for (let i = 0; i < regionsCollection.length; i += 1) {
    const section = regionsCollection[i];
    /* istanbul ignore if */
    if (
      regions[section] &&
      regions[section].components &&
      Array.isArray(regions[section].components)
    ) {
      totalCompCount += regions[section].components.length;
    }
  }
  /* istanbul ignore if */
  if (totalCompCount > 1 || totalCompCount === 0) {
    return false;
  }
  return true;
};
export default isRegionHasSingleComponent;
