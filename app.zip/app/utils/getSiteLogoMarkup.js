import { isBedBathCanada } from '@bbb-app/utils/common';

/**
 * Function which takes in stringified markup and from it returns the markup for site-logo svg.
 * @param {string} componentHTML - Stringified markup of whole app, from which we need to pick out
 * site-logo markup
 */

const getSiteLogoMarkup = componentHTML => {
  const regExpString = isBedBathCanada()
    ? '<span id="site-logo-wrapper">(.*?)</span>'
    : '<span class="site-logo">(.*?)</span>';
  const RE = new RegExp(regExpString);

  const logoMarkupArr =
    typeof componentHTML === 'string' && componentHTML.match(RE);

  return Array.isArray(logoMarkupArr) && logoMarkupArr[1];
};

export default getSiteLogoMarkup;
