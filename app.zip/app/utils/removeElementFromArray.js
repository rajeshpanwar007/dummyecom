/**
 * It will remove the element from Array
 * @param {Array} arr 
 * @param {Element which we need to remove} elemToRemove 
 */

export const removeElementFromArray = (arr, elemToRemove) => {
  return arr.filter(elem => {
    return elem !== elemToRemove;
  });
};

export default removeElementFromArray;
