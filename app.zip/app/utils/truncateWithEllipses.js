/**
 * it will truncate the string with regex, separator, length
 * @param {json array with following keys str, len, isEllipses, separator} param0 
 */
const truncateWithEllipses = ({
  str,
  len,
  isEllipses = true,
  separator = null,
}) => {
  if (str && len && str.length > len) {
    let truncatedStr = str;
    if (separator) {
      if (separator instanceof RegExp) {
        separator = new RegExp(separator).exec(str); // eslint-disable-line no-param-reassign
      }
      truncatedStr = str.split(separator, 1)[0];
    }
    truncatedStr = truncatedStr.substring(0, len);
    if (isEllipses) {
      truncatedStr += `...`;
    }
    return truncatedStr;
  }
  return str;
};
export default truncateWithEllipses;
