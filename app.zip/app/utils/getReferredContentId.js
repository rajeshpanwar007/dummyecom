import pathOr from 'lodash/fp/pathOr';

/**
 * It will return content ID from referred content array
 * @param {* referred content array} referedContentArray
 * @param {* key name} key
 */
const getReferredContentId = (referedContentArray, key) => {
  let contentId;
  if (referedContentArray && referedContentArray.length > 0) {
    referedContentArray.forEach(obj => {
      if (obj.key === key) contentId = obj.id;
    });
  }
  return contentId;
};

/**
 * will return the content data with respect to content ID
  * @param referredContent
 * @param id
 * @returns {undefined|*}
 */
export const getRefContent = (referredContent, id) => {
  const content = pathOr(null, 'content', referredContent);
  if (!content || !id) {
    return undefined;
  }
  return content[id];
};

export default getReferredContentId;
