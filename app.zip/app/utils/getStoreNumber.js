import { REGEX_STORE_NUMBER } from '../constants/search';
/**
 * Helper function to return store number from regex.
 *
 * E.g. store-333 indicates store number 333
 * @param {string} storeParam in store-xxx formisBat
 * @return {number} The parsed number.
 */
export const getStoreNumber = storeParam =>
  storeParam ? parseInt(storeParam.match(REGEX_STORE_NUMBER)[1], 10) : null;
