import sanitizeSearchTerm from '@bbb-app/utils/sanitizeSearchTerm';
import { SWS_TERM_DELIM } from '../constants/search';
/**
 * parse the swsterm array into string for url
 * @param {array} terms the search within search param from url
 * @return {string} array combined into a querystring
 */
export const transformSwsArraytoQuery = swsTerms => {
  const swsArray = [];
  if (swsTerms && swsTerms.length > 0) {
    for (let i = 0; i < swsTerms.length; i += 1) {
      if (swsTerms[i] !== '')
        swsArray.push(`${SWS_TERM_DELIM}${sanitizeSearchTerm(swsTerms[i])}`);
    }
  }
  return swsArray.join('');
};
