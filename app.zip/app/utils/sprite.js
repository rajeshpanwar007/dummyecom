import Sprite from 'svg-baker-runtime/src/sprite';

export default new Sprite({ attrs: { id: '__SVG_SERVER_SPRITE_NODE__' } });
