const createTimeSlot = () => {
  const timeSlot = [
    {
      id: '',
      label: 'Preferred Time',
      props: {
        value: '',
      },
    },
  ];
  for (let i = 1; i < 13; i += 1) {
    let num = i.toFixed(2).toString();
    num = num.replace('.', ':');
    const newTimeSlot = Object.assign(
      {},
      {
        id: num,
        label: num,
        props: {
          value: num,
        },
      }
    );
    timeSlot.push(newTimeSlot);
  }
  return timeSlot;
};
export default createTimeSlot;
