import { isEmpty, pathOr } from 'lodash/fp';
/**
 * @param {any} color
 * @param {any} size
 * @param {any} skuId
 * @param {any} data
 * @param {any} props
 * @memberof ProductDetails and QuickView
 */

const triggerSwatchSelect = (color, size, skuId, data, props) => {
  // check if color has variations
  const colorVariations = pathOr([], 'VARIATIONS.ALL_COLORS', data);
  const sizeVariations = pathOr([], 'VARIATIONS.ALL_SIZES', data);
  const hasColorVariations = colorVariations.length > 0;
  // check if size has variations
  const hasSizeVariations = sizeVariations.length > 0;
  // dispatch select color  (finish) action
  /* istanbul ignore if  */
  if (hasColorVariations && !isEmpty(color)) {
    const index = colorVariations.findIndex(item => {
      return item.COLOR === color;
    });

    const selectedSwatch = {
      label: color,
      index,
    };
    if (typeof props.skuSelectionAction === 'function') {
      props.skuSelectionAction('selectswatch', selectedSwatch);
    }
  }
  // dispatch select size action
  /* istanbul ignore if  */
  if (
    hasSizeVariations &&
    !isEmpty(size) &&
    typeof props.skuSelectionAction === 'function'
  ) {
    props.skuSelectionAction('selectSize', size);
  } else {
    props.skuSelectionAction('selectSize', null);
  }
  // dispatch select select SKU action
  /* istanbul ignore if  */
  if (!isEmpty(skuId) && typeof props.selectTransitionSku === 'function') {
    props.selectTransitionSku(skuId);
  }
};

export default triggerSwatchSelect;
