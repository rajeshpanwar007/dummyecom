/**
 * getRollupCode Returns whether or not this is rollup type includes multiple rollups or is a collection
 * @param { number }    rollupTypeCode The code for rollup type (0=NONE, 1=COLOR, 2=SIZE, 3=FINISH, 4=SIZE,COLOR, 5=FINISH,SIZE)
 * @param { boolean }   collectionFlag Describes if the product is part of a collection
 * @return { boolean }
 **/
const getRollupCode = (rollupTypeCode, collectionFlag) => {
  let isMultiRollUpFlag = false;
  let rollupFlag = false;
  if (
    rollupTypeCode !== undefined &&
    ((rollupTypeCode && rollupTypeCode.toString() === '4') ||
      (rollupTypeCode && rollupTypeCode.toString() === '5'))
  ) {
    rollupFlag = true;
  }
  if (rollupFlag || (collectionFlag && collectionFlag.toString() === '1')) {
    isMultiRollUpFlag = true;
  }
  return isMultiRollUpFlag;
};
export default getRollupCode;
