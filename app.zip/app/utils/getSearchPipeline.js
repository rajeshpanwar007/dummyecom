import { getSiteSpectAssignment } from '@bbb-app/utils/siteSpectUtil';
import { extractSearchPipeline } from '@bbb-app/utils/checkPipelineUtil';
import {
  SEARCH_PLP_ARGUMENTS,
  SEARCH_PLP_VARIANTS,
} from '@bbb-app/constants/abtests/constants';

export const returnSearchPipeline = pipelineProps => {
  const testSearchRoutes = {
    fallback: pipelineProps,
    tests: SEARCH_PLP_VARIANTS,
  };
  const searchAPI = getSiteSpectAssignment(
    null,
    testSearchRoutes,
    false,
    SEARCH_PLP_ARGUMENTS
  );
  return extractSearchPipeline(searchAPI);
};
