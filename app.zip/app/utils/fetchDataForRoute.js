/**
 * @Description:
 This file matches requested route with React Application routes and returns all actions specified for a route, as an array.
 In case no actions are specified, but a route is matched, it returns an array
 In case no React routes are matched, it returns false.
 *
 */

import { flatten } from 'lodash';
import { universalActions } from './universalConfig';

function fetchDataForRoute({
  matchedRoute,
  state,
  siteId,
  headerCookies,
  assignedCampaigns,
}) {
  const universalActionsArr = universalActions.getUniversalActions();
  const fetchDataHandler = matchedRoute
    ? [...matchedRoute.fetchData, ...universalActionsArr]
    : false;
  return fetchDataHandler
    ? flatten(
        fetchDataHandler.map(action =>
          action(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            headerCookies,
            assignedCampaigns
          )
        )
      )
    : false;
}

export default fetchDataForRoute;
