import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';

const getPDPTooltipErrorMessage = (notSelectedItems, labels) => {
  let errorMessage = '';
  if (notSelectedItems.length === 1) {
    errorMessage = LabelsUtil.getLabel(labels, notSelectedItems[0]);
  } else if (
    notSelectedItems.length === 2 &&
    notSelectedItems.indexOf('NO_FINISH') > -1
  ) {
    errorMessage = LabelsUtil.getLabel(labels, 'NO_FINISH_SIZE');
  } else {
    errorMessage = LabelsUtil.getLabel(labels, 'NO_COLOR_SIZE');
  }
  return errorMessage;
};

const validatePDPError = (selectedSKU, selectedProduct, labels) => {
  const { colorVariation, sizeVariation, skuId } = selectedSKU;
  const rollUpCode = pathOr('', 'ROLLUP_TYPE_CODE', selectedProduct);
  const rollUpTypeCode = rollUpCode.toString();
  const notSelectedItems = [];
  const errorMessage = '';
  if (rollUpTypeCode === '0') {
    return errorMessage;
  }
  if (!skuId && !colorVariation.label) {
    if (rollUpTypeCode === '1' || rollUpTypeCode === '4') {
      notSelectedItems.push('NO_COLOR');
    } else if (rollUpTypeCode === '3' || rollUpTypeCode === '5') {
      notSelectedItems.push('NO_FINISH');
    }
  }
  if (
    rollUpTypeCode !== '1' &&
    rollUpTypeCode !== '3' &&
    rollUpTypeCode !== '' &&
    rollUpTypeCode !== '0' &&
    !skuId &&
    !sizeVariation
  ) {
    notSelectedItems.push('NO_SIZE');
  }
  return notSelectedItems.length > 0
    ? getPDPTooltipErrorMessage(notSelectedItems, labels)
    : errorMessage;
};

export default validatePDPError;
