import { HOSTNAMES } from '@bbb-app/seo/components/constants';
/**
 *
 * @param {*} params
 */

export const getCanonical = (siteId, correctedQueryString) => {
  const hostname = HOSTNAMES.get(siteId) || '';
  let path;
  const params = ['brand', 'category'];
  const requiredParams = params.some(
    param => correctedQueryString && correctedQueryString.includes(param)
  );
  if (correctedQueryString && requiredParams && requiredParams !== '/') {
    path = `/${correctedQueryString}`;
  } else path = `/store/s/${correctedQueryString}`;
  return `${hostname}${path}`;
};
