/**
 * @return {func} Responsible for logging messages to console and log file
 */
const isPreviewEnv = isPreview =>
  /* eslint-disable no-underscore-dangle */
  /* istanbul ignore next */
  !isPreview && typeof window !== 'undefined'
    ? window.__IS_PREVIEW__
    : isPreview === true;
export default isPreviewEnv;
