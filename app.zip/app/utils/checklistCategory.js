import { sanitizeName } from './category';

/**
 * This formats ids into urls appropriate for multilevel checklist category routes
 * checklistId {string} the checklist ID, like 'dc32'
 * categoryId {string} the category ID, like 'dc3300'
 * categoryNames is an array of category titles like ['Nursery & Decor']
 **/
export const getUrlLevel = ({
  checklistId = 'dcxx',
  checklistName,
  categoryId,
  categoryNames,
}) => {
  const namesList = categoryNames.map(sanitizeName);
  return `/store/checklist/${checklistName}/${namesList.join(
    '/'
  )}/${categoryId.toLowerCase()}/${checklistId.toLowerCase()}`;
};

/**
 * This parses hierarchy strings like:
 * "2/DC3427_Newborn Essentials/DC3460_Footies"
 * and turns them into arrays of objects shaped like,
 * [
 *   {
 *     id: 'DC3427',
 *     name: 'Newborn Essentials'
 *     url: '/store/checklist/baby-registry/newborn-essentials/dc3427/dc32',
 *   },
 *   {
 *     id: 'DC3460',
 *     name: 'Footies'
 *     url: '/store/checklist/baby-registry/newborn-essentials/footies/dc3460/dc32',
 *   },
 * ]
 */
export const parseHierarchy = ({
  hierarchyStr,
  checklistId,
  checklistName,
  urlKey,
  nameKey,
  leafOnly = false,
}) => {
  const ids = hierarchyStr.match(/\/[a-zA-Z0-9]+(?=_)/g);
  // get all names from response string
  const names = hierarchyStr.split(/\/[a-zA-Z0-9]+_/).slice(1);
  // id of the category
  let id = (ids && (ids.length && ids.slice(-1)[0].slice(1))) || '';

  // if we should return only leaf obj rather than array of objects
  if (leafOnly) {
    return {
      [urlKey]: getUrlLevel({
        checklistId,
        checklistName,
        categoryId: id,
        categoryNames: names,
      }),
      [nameKey]: (names && (names.length && names.slice(-1)[0])) || '',
      id,
    };
  }

  // want to create array of all levels of the hierarchy string
  return names.map((name, index) => {
    id = (ids[index] && ids[index].slice(1)) || '';
    return {
      [urlKey]: getUrlLevel({
        checklistId,
        checklistName,
        categoryId: id,
        categoryNames: names.slice(0, index + 1),
      }),
      [nameKey]: name,
      id,
    };
  });
};

/**
 * This parses breadcrumb hierarchy strings like:
 * "2/DC3427_Newborn Essentials/DC3460_Footies"
 * and turns them into arrays of objects shaped like:
 * [
 *   {
 *     id: 'DC3427',
 *     name: 'Newborn Essentials'
 *     url: '/store/checklist/baby-registry/newborn-essentials/dc3427/dc32',
 *   },
 *   {
 *     id: 'DC3460',
 *     name: 'Footies'
 *     url: '/store/checklist/baby-registry/newborn-essentials/footies/dc3460/dc32',
 *   },
 * ]
 */
export const parseBreadcrumbHierarchy = (
  hierarchyStr,
  checklistId,
  checklistName
) => {
  return parseHierarchy({
    hierarchyStr,
    checklistId,
    checklistName,
    urlKey: 'url',
    nameKey: 'name',
  });
};

/**
 * This parses category hierarchy strings like: *
 * As well as strings like:
 * "2/DC3300_Nursery & Decor/DC3318_Baby Blanket"
 *
 * and turns them into an object shaped like:
 *
 *  {
 *    text: 'Baby Blanket',
 *    url: '/store/checklist/baby-registry/nusery-decor/baby-blanket/dc3318/dc32'
 *  }
 */
export const parseSubcategoryHierarchy = (
  hierarchyStr,
  checklistId,
  checklistName
) => {
  return parseHierarchy({
    hierarchyStr,
    checklistId,
    checklistName,
    urlKey: 'url',
    nameKey: 'text',
    leafOnly: true,
  });
};
