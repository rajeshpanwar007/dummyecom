const getFormattedSkuIds = response =>
  response &&
  response
    .map(obj => {
      return obj.sku;
    })
    .join('|');

export default getFormattedSkuIds;
