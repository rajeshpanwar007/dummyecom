/**
 *
 * This function is used for anchoring to searchbar on any search request.
 */
const scrollToTopBar = (scrollToTop, scrollToTopReset) => {
  if (scrollToTop) {
    window.scrollTo(0, 0);
    scrollToTopReset();
  }
};

export default scrollToTopBar;
