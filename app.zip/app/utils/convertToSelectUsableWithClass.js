const convertToSelectUsableWithClass = data => {
  const template = [];
  /* istanbul ignore if */
  if (data) {
    for (let pos = 0; pos < data.length; pos += 1) {
      // eslint-disable-next-line
      const id = data[pos].id
        ? data[pos].id
        : data[pos].cardID ? data[pos].cardID : data[pos].name;
      const label = data[pos].displayName || data[pos].name;
      const val = id;
      const classToAdd = data[pos].type || '';
      const href = data[pos].url || '';
      template.push(
        Object.assign(
          {},
          {
            id,
            label,
            classToAdd,
            props: {
              value: val,
              href,
            },
          }
        )
      );
    }
  }
  return template;
};
export default convertToSelectUsableWithClass;
