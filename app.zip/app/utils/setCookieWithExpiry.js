import Cookies from 'universal-cookie';
import { isBrowser } from '@bbb-app/utils/common';
export const IS_BROWSER = isBrowser();
/**
 * @description  Set Cookie with given cookieName and cookieValue for the specified pathName and Expiry
 *
 * @param {string} cookieName - name for cookie which need to be set
 * @param {string} cookieValue - value for cookie which need to be set
 * @param {string} pathName - path where the specified cookie has to be set. Default is '/'
 * @param {string} cookieExpiryDays - expiry days after which the specified cookie will get deleted.
 */
const setCookieWithExpiry = (
  cookieName,
  cookieValue,
  cookieExpiryDays,
  pathName = '/'
) => {
  let expires = null;
  if (cookieExpiryDays) {
    expires = new Date(Date.now() + 24 * 3600 * 1000 * cookieExpiryDays);
  }
  if (IS_BROWSER) {
    new Cookies().set(cookieName, cookieValue, {
      path: pathName,
      expires,
    });
  }
};

export default setCookieWithExpiry;
