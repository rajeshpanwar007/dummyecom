import { getCountryCurrencyValue } from '@bbb-app/utils/countryCurrencyUtils';
import { getUserSegment } from '@bbb-app/utils/cdpUtils';

export const formParamObj = (params, categoryId, searchTerm, productId) => {
  const contentParams = { type: params.type };
  /* istanbul ignore else */
  if (params.user_segment) {
    contentParams.user_segment = getUserSegment();
  }
  /* istanbul ignore else */
  if (params.targeted_segment) {
    contentParams.targeted_segment = getCountryCurrencyValue();
  }
  /* istanbul ignore else */
  if (params.prod_id) {
    contentParams.prod_id = productId;
  }
  /* istanbul ignore else */
  if (params.cat_id) {
    contentParams.cat_id = categoryId;
  }
  /* istanbul ignore else */
  if (params.search_term) {
    contentParams.search_term = searchTerm;
  }
  return contentParams;
};
