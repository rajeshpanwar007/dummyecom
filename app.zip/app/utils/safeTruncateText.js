import { decodeHtmlEntities } from '@bbb-app/utils/common';
import truncateWithEllipses from './truncateWithEllipses';

const safeTruncateText = (str, length) =>
  truncateWithEllipses({
    str: decodeHtmlEntities(str),
    len: length,
    isEllipses: true,
  });

export default safeTruncateText;
