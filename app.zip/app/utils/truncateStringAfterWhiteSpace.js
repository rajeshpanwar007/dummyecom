/**
 * truncate String After given number of Whitespace
 * @returns {string}
 */
const truncateStringAfterWhitespace = (orgString, nthNumberOfWhitespace) => {
  let truncatedString = orgString.trim();
  let searchTermArr = orgString.split(' ');
  if (searchTermArr.length > nthNumberOfWhitespace) {
    searchTermArr = searchTermArr.slice(0, nthNumberOfWhitespace);
    truncatedString = searchTermArr.join(' ');
  }
  return truncatedString;
};
export default truncateStringAfterWhitespace;
