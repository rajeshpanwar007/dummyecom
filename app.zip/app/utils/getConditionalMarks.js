export const getConditionalMarks = () => {
  /** this function is used for
     * search specific conditional marks for mPulse */
  return {
    'ux-destination-verified': [],
    'ux-primary-content-displayed': [],
    'ux-primary-action-available': [],
    'ux-secondary-content-displayed': ['ux-secondary-text-related-search'],
  };
};
