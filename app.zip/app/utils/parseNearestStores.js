import { pathOr } from 'lodash/fp';
import { select } from 'redux-saga/effects';
import { parse } from 'qs';
import { routeSelector } from '../containers/Search/selectors';

export function* parseNearestStores() {
  const { locationBeforeTransitions } = yield select(routeSelector);
  return parseNearestStoresFromLocation(locationBeforeTransitions);
}

export const parseNearestStoresFromLocation = locationBeforeTransitions => {
  let nearestStoresUrl = '';
  const newLocationBeforeTransitions = pathOr(
    '',
    'search',
    locationBeforeTransitions.location
  );
  const queryParams = parse(newLocationBeforeTransitions, {
    ignoreQueryPrefix: true,
  });
  if (queryParams && queryParams.nearestStores) {
    nearestStoresUrl = queryParams.nearestStores;
  }
  return nearestStoresUrl;
};
