const specOrder = features => {
  if (features && features[0]) {
    const firstHalf = features.slice(0, Math.ceil(features.length / 2));
    const secondHalf = features.slice(
      Math.ceil(features.length / 2),
      features.length
    );

    const finalArray = [];
    let j = 0;
    let k = 0;
    for (let i = 0; i < features.length; i += 2) {
      finalArray[i] = firstHalf[j];
      j += 1;
    }

    for (let i = 1; i < features.length; i += 2) {
      finalArray[i] = secondHalf[k];
      k += 1;
    }

    return finalArray;
  }
  return [];
};

export default specOrder;
