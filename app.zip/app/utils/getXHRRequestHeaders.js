import { isEmpty } from 'lodash/fp';

import {
  DEFAULT_SORT_BY,
  DEFAULT_SEARCH_SORT_BY,
} from '@bbb-app/constants/searchConstants';

/**
 * Gets required request headers for Category API endpoint.
 *
 * @param {object} paging
 * @param {string} sort
 * @param {number} itemsPerPage
 * @param {bool} storeAvailability
 * @return {{sort: *, start: number, perPage: *, view: string, storeId: string, storeOnlyProducts: *}}
 */
export const getXHRRequestHeaders = (
  paging,
  sort,
  itemsPerPage,
  storeAvailability,
  searchWithinSearchTerms,
  storeId
) => {
  const headers = {
    sort,
    start: paging.start - 1,
    perPage: itemsPerPage,
    view: 'grid',
    sws: searchWithinSearchTerms,
    storeOnlyProducts: false,
    countOnly: false, // Just shut this off.
  };

  if (headers.perPage === 0) {
    delete headers.perPage;
  }
  if (storeId) {
    headers.storeId = storeId;
  }
  if (storeId && storeAvailability) {
    headers.storeOnlyProducts = true;
  }

  if (
    isEmpty(sort) ||
    sort === DEFAULT_SORT_BY ||
    sort === DEFAULT_SEARCH_SORT_BY
  ) {
    delete headers.sort;
  }
  return headers;
};
