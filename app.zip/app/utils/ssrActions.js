/* istanbul ignore file */
/**
 * @Description:
 * Appending SSR specific actions here based on the Page Name.
 * The actions specific to the routes are pushed to the actions current actions array.
 */
import getOr from 'lodash/fp/getOr';
import { isCombinedGroupByPLPCall } from '@bbb-app/utils/groupBy';
import {
  COLLEGE_EXPERIENCE_KEY,
  STATICPAGES_EXPERIENCE_KEY,
} from '@bbb-app/constants/experienceConstants';
import {
  PAGE_NAME_GIFT_GIVER,
  PAGE_NAME_REGISTRY_QUICK_PICKS_LANDING,
  PAGE_NAME_REGISTRY_QUICK_PICKS_COLLECTION,
  PAGE_NAME_CATEGORY,
  PAGE_NAME_PRODUCT_SEARCH,
  PAGE_NAME_BRAND_PLP,
} from '@bbb-app/constants/route/route';
import {
  CHECKLIST_CATEGORY_IDENTIFIER,
  CATEGORY_IDENTIFIER,
} from '../constants/search';
import { fetchRegistryDataonServer } from '../containers/Pages/Registry/RegistryOwner/RegistryDetailsSagaInjectionOnServer';
import { fetchCollegeSEOMapData } from '../../app/containers/Pages/CollegeLanding/actionWithSagaAndInjection';
import { fetchQuickPicksCollection } from '../../app/containers/Pages/Registry/QuickPicks/Collection/actionWithReducerInjection';
import { fetchQuickPicks } from '../../app/containers/Pages/Registry/QuickPicks/Landing/actionWithReducerInjection';
import { fetchLeftNavigationOnServer } from '../containers/Pages/RegistryTools/RegistryToolsNavigation/actionWithSagaInjection';
import { fetchChecklistCategory } from '../containers/Search/ChecklistCategory/actions';
import {
  fetchSearchResults,
  fetchFacetResults,
  fetchBrand,
  fetchBrandFacet,
  fetchCategory,
  fetchCategoryFacet,
} from '../containers/Search/actions';

// eslint-disable-next-line complexity
function ssrActions({
  actions,
  matchedRoute,
  state,
  siteId,
  req,
  headerCookies,
  currentChannel,
}) {
  const uniqueIdentifier = getOr(
    '',
    ['params', 'uniqueIdentifier'],
    matchedRoute
  );
  switch (matchedRoute && matchedRoute.pageName) {
    case PAGE_NAME_GIFT_GIVER:
      actions.push(fetchRegistryDataonServer(matchedRoute.params));
      break;

    case COLLEGE_EXPERIENCE_KEY:
      if (req.url.includes('/store/university/')) {
        actions.push(fetchCollegeSEOMapData());
      }
      break;

    case PAGE_NAME_REGISTRY_QUICK_PICKS_COLLECTION:
      actions.push(
        fetchQuickPicksCollection(
          matchedRoute.params,
          matchedRoute.pageName,
          matchedRoute.search,
          state,
          siteId
        )
      );
      break;

    case PAGE_NAME_REGISTRY_QUICK_PICKS_LANDING:
      actions.push(
        fetchQuickPicks(
          matchedRoute.params,
          matchedRoute.pageName,
          matchedRoute.search,
          state,
          siteId
        )
      );

      break;

    case STATICPAGES_EXPERIENCE_KEY:
      if (req.url.includes('/store/registry/')) {
        actions.push(
          fetchLeftNavigationOnServer(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId
          )
        );
      }
      break;

    case PAGE_NAME_CATEGORY:
      if (uniqueIdentifier.includes(CHECKLIST_CATEGORY_IDENTIFIER)) {
        actions.push(
          fetchChecklistCategory(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId
          )
        );
      } else if (uniqueIdentifier.includes(CATEGORY_IDENTIFIER)) {
        actions.push(
          fetchCategory(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            '',
            currentChannel
          )
        );

        actions.push(
          fetchCategoryFacet(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            '',
            true
          )
        );
      }
      break;

    case PAGE_NAME_BRAND_PLP:
      actions.push(
        fetchBrand(
          matchedRoute.params,
          matchedRoute.pageName,
          matchedRoute.search,
          state,
          siteId
        )
      );

      actions.push(
        fetchBrandFacet(
          matchedRoute.params,
          matchedRoute.pageName,
          matchedRoute.search,
          state,
          siteId,
          '',
          true
        )
      );

      break;

    case PAGE_NAME_PRODUCT_SEARCH:
      if (isCombinedGroupByPLPCall()) {
        const nfacets = 'allFacets';
        actions.push(
          fetchFacetResults(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            nfacets,
            headerCookies,
            currentChannel
          )
        );
      } else {
        actions.push(
          fetchSearchResults(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            headerCookies,
            currentChannel
          )
        );
        actions.push(
          fetchFacetResults(
            matchedRoute.params,
            matchedRoute.pageName,
            matchedRoute.search,
            state,
            siteId,
            true,
            headerCookies,
            currentChannel
          )
        );
      }
      break;
    default:
      break;
  }
}

export default ssrActions;
