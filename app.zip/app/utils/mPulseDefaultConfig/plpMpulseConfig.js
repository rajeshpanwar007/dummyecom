export const getPageViewMarks = () => ({
  'ux-destination-verified': ['ux-image-inline-logo'],
  'ux-primary-content-displayed': [],
  'ux-primary-action-available': [],
  'ux-secondary-content-displayed': [],
});

export const getPageSpecificMarks = () => ({
  'ux-destination-verified': [],
  'ux-primary-content-displayed': [
    'ux-text-products-count',
    'ux-section-product-list',
    'ux-text-page-title',
  ],
  'ux-primary-action-available': ['ux-text-product-grid'],
  'ux-secondary-content-displayed': ['ux-section-items-per-page'],
});

export const getConditionalMarksFlag = () => ({
  'ux-destination-verified': [],
  'ux-primary-content-displayed': ['ux-text-category-header'],
  'ux-primary-action-available': [],
  'ux-secondary-content-displayed': [
    'ux-text-departments',
    'ux-text-content-module',
  ],
});
