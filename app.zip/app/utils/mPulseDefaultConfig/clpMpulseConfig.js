export const getPageSpecificMarks = () => ({
  'ux-destination-verified': [],
  'ux-primary-content-displayed': [],
  'ux-primary-action-available': [],
  'ux-secondary-content-displayed': [],
});

export const getConditionalMarksFlag = () => ({
  'ux-destination-verified': [],
  'ux-primary-content-displayed': [],
  'ux-primary-action-available': [],
  'ux-secondary-content-displayed': [],
});
