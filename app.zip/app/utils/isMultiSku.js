/**
 * isMultiSku Returns whether or not the product is multi-SKU by rollupTypeCode & collectionFlag
 * @param { number }    rollupTypeCode The code for rollup type (0=NONE, 1=COLOR, 2=SIZE, 3=FINISH, 4=SIZE,COLOR, 5=FINISH,SIZE)
 * @param { boolean }   collectionFlag Describes if the product is part of a collection
 * @return { boolean }
 **/
const isMultiSku = (rollupTypeCode, collectionFlag) => {
  return Boolean(
    (rollupTypeCode && parseInt(rollupTypeCode, 10)) ||
      (collectionFlag && collectionFlag.toString() === '1')
  );
};
export default isMultiSku;
