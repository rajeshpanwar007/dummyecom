import isBrowser from '@bbb-app/utils/isBrowser';
/**
 * @method - To convert coupon code into barcode image.
 * @param {object} - bcode - the bar code
 * @return {string} - data url of image
 **/
const generateBarcodeImage = bcode => {
  /* istanbul ignore if */
  if (!isBrowser() || !window.PDF417) {
    return '';
  }
  /* istanbul ignore next */
  const canvas = document.createElement('canvas');
  const bw = 3;
  const bh = 3;
  let y = 0;
  let ctx = '';
  let barcode = '';
  window.PDF417.init(bcode);
  barcode = window.PDF417.getBarcodeArray();
  canvas.width = bw * barcode.num_cols;
  canvas.height = bh * barcode.num_rows;
  ctx = canvas.getContext('2d');
  for (let r = 0; r < barcode.num_rows; r += 1) {
    let x = 0;
    for (let c = 0; c < barcode.num_cols; c += 1) {
      if (barcode.bcode[r][c].toString() === '1') {
        ctx.fillRect(x, y, bw, bh);
      }
      x += bw;
    }
    y += bh;
  }
  return canvas.toDataURL('image/png');
};
export default generateBarcodeImage;
