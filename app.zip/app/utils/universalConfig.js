/* add multiple actions for all routes */
import { isBrowser } from '@bbb-app/utils/common';
import { updateWattsData } from '@bbb-app/site-spect/actions';
import { setPreviewSiteConfig } from '@bbb-app/redux/site-configuration/actions';
import { setPreviewLabels } from '@bbb-app/redux/labels/actions';
import { setPageIdentifier } from '@bbb-app/redux/route-data/actions';
import { fetchMetaTag } from '@bbb-app/seo/containers/actions';
import { IS_PREVIEW as envPreview } from '../../server/config/appConfig';

const getUniversalActions = () => {
  /* eslint-disable no-underscore-dangle */
  const windowPreview = isBrowser() && window.__IS_PREVIEW__;
  const actionArr =
    envPreview || windowPreview
      ? [
          setPreviewLabels,
          setPreviewSiteConfig,
          setPageIdentifier,
          fetchMetaTag,
        ]
      : [setPageIdentifier, fetchMetaTag, updateWattsData];
  return actionArr;
};
export const universalActions = { getUniversalActions };
