import { isEmpty } from 'lodash/fp';

const autoSelectLTLOption = (ltlData, ltlMethod, props) => {
  /* istanbul ignore if */
  if (ltlMethod) {
    const ltlDeliveryMethod = ltlData.find(ltlItem => {
      return ltlMethod === ltlItem.shipMethodId;
    });
    /* istanbul ignore if */
    if (!isEmpty(ltlDeliveryMethod)) {
      const deliveryMethod = ltlDeliveryMethod.shipMethodDescription;
      if (typeof props.selectLTLOption === 'function') {
        props.selectLTLOption({ deliveryMethod, value: ltlMethod });
        return true;
      }
    }
  }
  return false;
};

export default autoSelectLTLOption;
