import { pathOr } from 'lodash/fp';
import qs from 'qs';

export const getQsParams = route => {
  const locationSearch = pathOr(null, 'search', route);
  const qsData = qs.parse(locationSearch, { ignoreQueryPrefix: true });
  let qsmcid = qsData && qsData.mcid;
  qsmcid = qsmcid && (Array.isArray(qsmcid) ? qsmcid[0] : qsmcid);
  const mcidData =
    qsmcid && typeof qsmcid === 'string' && qsmcid.startsWith('PS_googlepla_');
  return { qsData, mcidData };
};

export const fetchGooglePLAProductList = (mcidData, qsData) => {
  return qsData && qsData.adtype === 'pla' && mcidData;
};
