import { compact, kebabCase } from 'lodash/fp';
import {
  DEPARTMENT_FACETS_REGEX,
  DEPARTMENT_FACETS_KEY,
} from '../constants/search';
/* This will return friendly facet string for Department Facet */
export const createFriendlyFacetString = (selectedFilters) => {
  const isDepartmentFacet =
    DEPARTMENT_FACETS_KEY in selectedFilters &&
    compact(selectedFilters.CATEGORY_HIERARCHY).length > 0;
  const copySelectedFilters = selectedFilters;

  if (isDepartmentFacet) {
    const departmentLength = selectedFilters.CATEGORY_HIERARCHY.length;
    const selectedDepFilter = compact(selectedFilters.CATEGORY_HIERARCHY)[departmentLength - 1];
    let facetLabel = '';
    facetLabel = selectedDepFilter.replace(DEPARTMENT_FACETS_REGEX, '');
    const modifiedSelectedDepFacet = kebabCase(facetLabel);
    copySelectedFilters.CATEGORY_HIERARCHY = [modifiedSelectedDepFacet];
  } else {
    delete copySelectedFilters.CATEGORY_HIERARCHY;
  }
  return copySelectedFilters;
};
