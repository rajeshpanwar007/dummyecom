import { noop } from 'lodash';
import { getStoreRef } from '@bbb-app/utils/storeRefUtils';

export const ACTION_PREFIX = '/action_';
export const TRIGGER_ONLINECC_APPLY_NOW = 'BBB/CART/TRIGGER_ONLINECC_APPLY_NOW';
export const acceptableActions = [TRIGGER_ONLINECC_APPLY_NOW];
const prefixStrip = ctaString => ctaString.slice(ACTION_PREFIX.length);
/**
 * verifies whether a string is a prefixed action or not
 * @param {String} actionWithPrefix
 */
export function checkForAction(actionWithPrefix) {
  if (!actionWithPrefix || typeof actionWithPrefix !== 'string') {
    return false;
  }
  if (actionWithPrefix.indexOf(ACTION_PREFIX) !== 0) {
    return false;
  }
  const action = prefixStrip(actionWithPrefix);
  if (acceptableActions.indexOf(action) !== -1) {
    return true;
  }
  return false;
}
/**
 * returns a runnable function dispatching the specified action
 * @param {String} actionWithPrefix
 */
export function createActionDispatcher(actionWithPrefix) {
  let shouldDispatch =
    typeof actionWithPrefix === 'string' &&
    actionWithPrefix.indexOf(ACTION_PREFIX) === 0;
  const index = acceptableActions.indexOf(prefixStrip(actionWithPrefix));
  shouldDispatch = shouldDispatch && index !== -1;
  const store = getStoreRef();

  if (shouldDispatch) {
    return e => {
      /* istanbul ignore if */
      if (e && e.preventDefault) {
        e.preventDefault();
      }
      store.dispatch({
        type: acceptableActions[index],
      });
    };
  }
  /* istanbul ignore next */
  return noop;
}
