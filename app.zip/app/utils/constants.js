import { SITE_KEYS } from '@bbb-app/constants/appConstants';
export const LOGGED_IN = 'logged in';
export const RECOGNIZED = 'recognized user';
export const GUEST = 'guest';
export const TWO = '2';
export const FOUR = '4';
export const CPLP = ['clearance-savings', 'whats-new'];
export const googlePLAUpdatedParam = 'resetGoogleAddFlow';
export const VDC_TYPE_FOR_PRODUCT = '121';
export const TEALIUM_VA_BBB = 'tealium_va';
export const AUDIENCES = 'audiences';
export const DEFAULT = 'default';
export const SITE_MAP = {
  [SITE_KEYS.BBB_CANADA]: 'CA',
  [SITE_KEYS.BBB]: 'US',
  [SITE_KEYS.BABY]: 'US',
  [SITE_KEYS.TBS_BBB]: 'US',
  [SITE_KEYS.TBS_BABY]: 'US',
  [SITE_KEYS.TBS_BBB_CANADA]: 'CA',
};
export const GLOBAL = 'Global';
export const PREFERRED_USER_SEGMENT_COOKIE = 'PREFERRED_USER_SEGMENT';
export const QUERY_USER_SEGMENT_COOKIE = 'QUERY_PARAM_USER_SEGMENT';
export const CDP_OPT_OUT = 'cdpOptOut';
