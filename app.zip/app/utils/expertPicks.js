import { pathOr } from 'lodash/fp';
import { getCookie } from '@bbb-app/utils/universalCookie';
import { logErrorsToService } from '@bbb-app/utils/serviceUtil';

const PRODUCT_OUT_OF_STOCK = 'PRODUCT_OUT_OF_STOCK';
const PRODUCT_MISSING = 'PRODUCT_MISSING';
const EXPERT_PICKS = 'EXPERT_PICKS';

// fetch Indivisdual product.
const findProduct = (solrProductList, CMSProduct) => {
  //  Find Main product from Solr
  const mainSolrProduct = solrProductList.find(
    product =>
      product.PRODUCT_ID ===
      pathOr(null, '[0].product_id', CMSProduct).toString()
  );
  // Is Main product in stock
  const price = pathOr('Zero', 'INVENTORY_STATUS', mainSolrProduct);
  if (price === 'Positive') {
    return {
      product_id: mainSolrProduct.PRODUCT_ID,
      seo_url: mainSolrProduct.SEO_URL,
      display_name: mainSolrProduct.DISPLAY_NAME,
      scene7_id: CMSProduct[0].scene7_id,
      sku_id: '',
      selling_point: CMSProduct[0].selling_point,
      normal: mainSolrProduct.WAS_PRICE || mainSolrProduct.IS_PRICE,
      low: mainSolrProduct.WAS_PRICE ? mainSolrProduct.IS_PRICE : null,
      lowValue: mainSolrProduct.LOW_PRICE,
      priceRangeDescription: mainSolrProduct.PRICE_RANGE_DESCRIP,
      inCart: mainSolrProduct.INCART_FLAG === 'true',
    };
  }
  /*
    If main product is out of stock
    Raise flag for Main product out of stock.
    Find Backup product
  */
  // logXTErrors for product out of stock
  const data = {
    productStatus: mainSolrProduct ? PRODUCT_OUT_OF_STOCK : PRODUCT_MISSING,
    moduleName: EXPERT_PICKS,
    productId: pathOr(null, '[0].product_id', CMSProduct).toString(),
    quantumMetricSessionID: getCookie('QuantumMetricSessionID'),
    quantumMetricUserID: getCookie('QuantumMetricUserID'),
  };
  logErrorsToService(data);
  // Find the backut product from cms in solr
  const backupProduct = solrProductList.find(product => {
    const path = pathOr(null, '[1].product_id', CMSProduct);
    return product.PRODUCT_ID === path && path.toString();
  });
  const BackUpprice = pathOr('Zero', 'INVENTORY_STATUS', backupProduct);
  if (BackUpprice === 'Positive') {
    return {
      product_id: backupProduct.PRODUCT_ID,
      seo_url: backupProduct.SEO_URL,
      display_name: backupProduct.DISPLAY_NAME,
      scene7_id: CMSProduct[1].scene7_id,
      sku_id: '',
      selling_point: CMSProduct[1].selling_point,
      normal: backupProduct.WAS_PRICE || backupProduct.IS_PRICE,
      low: backupProduct.WAS_PRICE ? backupProduct.IS_PRICE : null,
      lowValue: backupProduct.LOW_PRICE,
      priceRangeDescription: backupProduct.PRICE_RANGE_DESCRIP,
      inCart: backupProduct.INCART_FLAG === 'true',
    };
  }
  // if backupProduct is also out of stock
  // logXTErrors for product out of stock
  const productIdPath = pathOr(null, '[1].product_id', CMSProduct);
  const backUpData = {
    productStatus: backupProduct ? PRODUCT_OUT_OF_STOCK : PRODUCT_MISSING,
    moduleName: EXPERT_PICKS,
    productId: productIdPath && productIdPath.toString(),
    quantumMetricSessionID: getCookie('QuantumMetricSessionID'),
    quantumMetricUserID: getCookie('QuantumMetricUserID'),
  };
  logErrorsToService(backUpData);
  return null;
};

// Generate final product list of three products for Expert Pick Component for good better best.
export const reArrangeGBBProductList = (CMSProductList, solrProductList) => {
  const expertPickArr = [];
  CMSProductList.forEach(CMSProduct => {
    const product = findProduct(solrProductList, CMSProduct);
    if (product) {
      expertPickArr.push(product);
    }
  });
  return expertPickArr;
};
