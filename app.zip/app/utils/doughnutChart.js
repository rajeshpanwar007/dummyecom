import { setTimeoutCustom } from '@bbb-app/utils/timers';
import { NON_EXPIRY } from '../components/Pages/MyFunds/constants';

/*eslint-disable */
/* istanbul ignore next */
export function createElementFromHTML(htmlString) {
  const div = document.createElement("div");
  div.innerHTML = htmlString.trim();

  // Change this to div.childNodes to support multiple top-level nodes
  return div.firstChild;
}
/*eslint-disable */
/* istanbul ignore next */
export function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? "pm" : "am";
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? "0" + minutes : minutes;
  var strTime = hours + ":" + minutes + " " + ampm;
  return strTime;
}
/*eslint-disable */
/* istanbul ignore next */
export function formattedDateParam(local) {
  let d = local;
  if (local) {
    const t = local.split(/[- :]/);
    if (t.length === 6) {
      d = new Date(t[0], t[1] - 1, t[2], t[3], t[4], t[5]);
    }
  }
  const utcDate = new Date(d);
  const offset = new Date().getTimezoneOffset();
  const utcTime = utcDate.getTime();
  const newTime = utcTime - offset * 60000;
  const localDate = new Date(newTime);
  return localDate;
}
/*eslint-disable */
/* istanbul ignore next */
/* eslint complexity: ["error", 55]*/
export function drawDoughnutChart(
  data,
  options,
  elem,
  dcLabels,
  LOCATORS
) {
  const $this = elem;
  if ($this) {
    const W = Math.min(280, $this.offsetWidth);
    const H = Math.min(280, $this.offsetWidth);
    const centerX = W / 2;
    const centerY = H / 2;
    const cos = Math.cos;
    const sin = Math.sin;
    const PI = Math.PI;

    const settings = Object.assign(
      {},
      {
        segmentShowStroke: true,
        svgTitle: "",
        svgDesc: "",
        segmentStrokeColor: "#ffffff",
        segmentStrokeWidth: 0,
        baseColor: "#ccc",
        baseOffset: 0,
        edgeOffset: 10, // offset from edge of $this
        percentageInnerCutout: 90,
        animation: true,
        animationSteps: 90,
        animationEasing: "easeInOutExpo",
        animateRotate: true,
        tipOffsetX: -8,
        tipOffsetY: -45,
        tipClass: "doughnutTip",
        summaryClass: "doughnutSummary",
        summaryTitle: "TOTAL:",
        summaryTitleClass: "doughnutSummaryTitle",
        summaryNumberClass: "doughnutSummaryNumber",
        beforeDraw() {},
        afterDrawed() {},
        onPathEnter(e, data) {},
        onPathLeave(e, data) {},
      },
      options
    );

    const animationOptions = {
      linear(t) {
        return t;
      },
      easeInOutExpo(t) {
        const v = t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t;

        return v > 1 ? 1 : v;
      },
    };

    const requestAnimFrame = (() =>
      window.requestAnimationFrame ||
      window.webkitRequestAnimationFrame ||
      window.mozRequestAnimationFrame ||
      window.oRequestAnimationFrame ||
      window.msRequestAnimationFrame ||
      (callback => {
        setTimeoutCustom(callback, 1000 / 60);
      }))();

    settings.beforeDraw.call($this);

    const htmlPart = createElementFromHTML(
      `<div class="fundsSvg"><svg class="chartSvg" width="100%" height="100%" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  role="img" aria-labelledby="title  desc"><title id="title">${settings.svgTitle}</title><desc id="desc">${settings.svgDesc}</desc></svg></div>`
    );

    $this.appendChild(htmlPart);
    const $svg = document.querySelectorAll(".chartSvg")[0];
    const $paths = [];
    const easingFunction = animationOptions[settings.animationEasing];
    const doughnutRadius = Min([H / 2, W / 2]) - settings.edgeOffset;
    const cutoutRadius =
      doughnutRadius * (settings.percentageInnerCutout / 100);
    let segmentTotal = 0;

    // Draw base doughnut
    const baseDoughnutRadius = doughnutRadius + settings.baseOffset;

    const baseCutoutRadius = cutoutRadius - settings.baseOffset;

    const drawBaseDoughnut = (() => {
      const svgBase = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "path"
      );

      // Calculate values for the path.
      // We needn't calculate startRadius, segmentAngle and endRadius, because base doughnut doesn't animate.
      // -Math.PI/2
      const startRadius = -1.57;

      // 1 * ((99.9999/100) * (PI*2)),
      const segmentAngle = 6.2831;

      // startRadius + segmentAngle
      const endRadius = 4.7131;

      const startX = centerX + cos(startRadius) * baseDoughnutRadius;
      const startY = centerY + sin(startRadius) * baseDoughnutRadius;
      const endX2 = centerX + cos(startRadius) * baseCutoutRadius;
      const endY2 = centerY + sin(startRadius) * baseCutoutRadius;
      const endX = centerX + cos(endRadius) * baseDoughnutRadius;
      const endY = centerY + sin(endRadius) * baseDoughnutRadius;
      const startX2 = centerX + cos(endRadius) * baseCutoutRadius;
      const startY2 = centerY + sin(endRadius) * baseCutoutRadius;
      const cmd = [
        "M",
        startX,
        startY,
        "A",
        baseDoughnutRadius,
        baseDoughnutRadius,
        0,
        1,
        1,
        endX,
        endY,
        "L",
        startX2,
        startY2,
        "A",
        baseCutoutRadius,
        baseCutoutRadius,
        0,
        1,
        0,
        endX2,
        endY2, // reverse
        "Z",
      ];
      svgBase.setAttributeNS(null, "d", cmd.join(" "));
      svgBase.setAttributeNS(null, "fill", settings.baseColor);
      $svg.appendChild(svgBase);
    })();

    // Set up pie segments wrapper
    const pathGroup = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "g"
    );
    pathGroup.setAttributeNS(null, "opacity", 0);
    pathGroup.setAttributeNS(null, "id", "pathGroupDC");
    $svg.appendChild(pathGroup);
    const $pathGroup = document.getElementById("pathGroupDC");

    // Set up tooltip
    /* var $tip = $('<div class="' + settings.tipClass + '" />').appendTo('body').hide(),
       tipW = $tip.width(),
       tipH = $tip.height();
  */
    // Set up center text area
    const summarySize = (cutoutRadius - (doughnutRadius - cutoutRadius)) * 2;

    const $summary = createElementFromHTML(
      `<div  data-locator=${LOCATORS.TOTAL_FUNDS_SECTION_TOTAL_FUNDS_MSG} class="${settings.summaryClass}" ><h2>${dcLabels.dChartHeading}</h2><p>${dcLabels.dChartSubHeading}</p> </div>`
    );
    $this.appendChild($summary);
    Object.assign($summary.style, {
      width: `${summarySize}px`,
      height: "auto",
    });

    const $summaryNumber = createElementFromHTML(
      `<p data-locator=${LOCATORS.TOTAL_FUNDS_SECTION_TOTAL_FUNDS_AMOUNT} id="salNum" class="${settings.summaryNumberClass}"></p>`
    );
    $summary.appendChild($summaryNumber);
    Object.assign($summaryNumber.style, { opacity: 0 });

    if (options.drawLedgend) {
      drawLedgend(data, $this, this);
    }

    const $summaryTitle = createElementFromHTML(
      `<div data-locator=${LOCATORS.TOTAL_FUNDS_SECTION_TOTAL_FUNDS_DATE} class="grid-x large-12 ${settings.summaryTitleClass}">${settings.summaryTitle}</div>`
    );
    $this.parentNode.appendChild($summaryTitle);
    for (let i = 0, len = data.length; i < len; i++) {
      segmentTotal += data[i].value;
      const p = document.createElementNS("http://www.w3.org/2000/svg", "path");

      p.setAttributeNS(null, "stroke-width", settings.segmentStrokeWidth);
      p.setAttributeNS(null, "stroke", settings.segmentStrokeColor);
      p.setAttributeNS(null, "fill", data[i].color);
      p.setAttributeNS(null, "data-order", i);
      p.setAttributeNS(null, "id", `${i}pDC`);
      $pathGroup.appendChild(p);
      $paths[i] = document.getElementById(`${i}pDC`);
    }

    // Animation start
    animationLoop(drawPieSegments);
    function drawPieSegments(animationDecimal) {
      let // -90 degree
      startRadius = -Math.PI / 2;
      let rotateAnimation = 1;
      if (settings.animation && settings.animateRotate) {
        rotateAnimation = animationDecimal; // count up between0~1
      }
      drawDoughnutText(animationDecimal, segmentTotal);
      $pathGroup.setAttributeNS(null, "opacity", animationDecimal);

      // draw each path
      if (segmentTotal) {
        for (let i = 0, len = data.length; i < len; i++) {
          const segmentAngle =
            rotateAnimation * (data[i].value / segmentTotal * (PI * 2));
          const endRadius = startRadius + segmentAngle;
          const largeArc = (endRadius - startRadius) % (PI * 2) > PI ? 1 : 0;
          const startX = centerX + cos(startRadius) * doughnutRadius;
          const startY = centerY + sin(startRadius) * doughnutRadius;
          const endX2 = centerX + cos(startRadius) * cutoutRadius;
          const endY2 = centerY + sin(startRadius) * cutoutRadius;
          const endX = centerX + cos(endRadius) * doughnutRadius;
          const endY = centerY + sin(endRadius) * doughnutRadius;
          const startX2 = centerX + cos(endRadius) * cutoutRadius;
          const startY2 = centerY + sin(endRadius) * cutoutRadius;
          const cmd = [
            "M",
            startX,
            startY, // Move pointer
            "A",
            doughnutRadius,
            doughnutRadius,
            0,
            largeArc,
            1,
            endX,
            endY, // Draw outer arc path
            "L",
            startX2,
            startY2, // Draw line path(this line connects outer and innner arc paths)
            "A",
            cutoutRadius,
            cutoutRadius,
            0,
            largeArc,
            0,
            endX2,
            endY2, // Draw inner arc path
            "Z", // Cloth path
          ];
          $paths[i].setAttributeNS(null, "d", cmd.join(" "));
          startRadius += segmentAngle;
        }
      }
    }

    function drawLedgend(data, elem, dc) {
      let $html = '<div class="ledgend cell large-5 md-mt4 md-ml3">';
      for (let i = data.length - 1; i >= 0; i--) {
        if (data[i].type === NON_EXPIRY && !options.enableSVPermanentValue) {
          continue;
        }

        $html += `<div class="each-ledgend mt2"><svg width="12" height="12" style="
        margin-top: 4px">
        <rect width="12" height="12" style="fill:${data[i]
          .color}"></rect></svg><div class="each-ledgend-details pl2 grid-x"><div class="large-12 small-4"><h3 data-locator=${data[
          i
        ]
          .dataLocatorExpiring} class="each-ledgend-details-text each-ledgend-heading-text mb0">${data[
          i
        ].title}</h3></div>`;

        $html += `<div class="large-12 small-8"><p class="each-ledgend-details-amt each-ledgend-details-text details-text">${data[
          i
        ].formatted}</p></div>`;

        $html += `</div></div>`;
      }
      $html += "</div>";

      const $ledgend = document.querySelectorAll(".ledgend")[0];
      if ($ledgend) {
        $ledgend.parentNode.removeChild($ledgend);
      }
      const html = createElementFromHTML($html);
      elem.parentNode.appendChild(html);
    }
    function drawDoughnutText(animationDecimal, segmentTotal) {
      document.getElementById("salNum").innerText = `$${(segmentTotal *
        animationDecimal
      ).toFixed(2)}`;

      document
        .getElementById("salNum")
        .setAttribute("style", "opacity: animationDecimal;");
      if (!segmentTotal) {
        document.querySelectorAll(".doughnutSummary")[0].className =
          "doughnutSummary zeroTotal";
      }
    }
    function animateFrame(cnt, drawData) {
      const easeAdjustedAnimationPercent = settings.animation
        ? CapValue(easingFunction(cnt), null, 0)
        : 1;
      drawData(easeAdjustedAnimationPercent);
    }
    function animationLoop(drawData) {
      const animFrameAmount = settings.animation
        ? 1 / CapValue(settings.animationSteps, Number.MAX_VALUE, 1)
        : 1;
      let cnt = settings.animation ? 0 : 1;
      requestAnimFrame(function sameFunction() {
        cnt += animFrameAmount;
        animateFrame(cnt, drawData);
        if (cnt <= 1) {
          requestAnimFrame(sameFunction);
        } else {
          settings.afterDrawed.call($this);
          document.querySelectorAll(".doughnutSummaryNumber")[0].innerText =
            settings.totalBal;
        }
      });
    }
    function Max(arr) {
      return Math.max.apply(null, arr);
    }
    function Min(arr) {
      return Math.min.apply(null, arr);
    }
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    function CapValue(valueToCap, maxValue, minValue) {
      if (isNumber(maxValue)) {
        if (valueToCap > maxValue) {
          return maxValue;
        }
      }
      if (isNumber(minValue)) {
        if (valueToCap < minValue) {
          return minValue;
        }
      }
      return valueToCap;
    }
  }
}

/*eslint-enable */
