import pick from 'lodash/fp/pick';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import { getHeaderOffsets } from '@bbb-app/utils/filterUtils';
import parseBoolean from '@bbb-app/utils/parseBoolean';
import {
  isBrowser,
  standardizeLTLFlag,
  unescape,
  capitalizeFirstCharacter,
} from '@bbb-app/utils/common';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import getCoords from '@bbb-app/utils/getCoords';

/**
 * Similar to Search/PLP, this is needed for converting the canonical product structure
 * returned from the Quick Picks Collection API into an object that matches
 * the `propTypes` shape of the `ProductTile` component.
 */
export const convertToProductProps = input => {
  const {
    ATTRIBUTES_JSON: attributesData = {},
    BADGE_s: badge = '',
    COLORS: colors = {},
    DISPLAY_NAME: title = '',
    INCART_FLAG: inCart,
    LOW_PRICE: lowPriceValue,
    HIGH_PRICE: highPriceValue,
    WAS_PRICE: wasPrice,
    IS_PRICE: isPrice,
    PRICE_RANGE_DESCRIP: priceRangeDescrip,
    PRODUCT_ID: productId,
    SCENE7_URL: image,
    SEO_URL: url,
    SWATCH_FLAG: swatchFlag,
    COLLECTION_FLAG: collectionFlag,
    ROLLUP_TYPE_CODE: rollupTypeCode,
    ALL_SIZES: sizes,
    SKU_FOR_SWATCH_ALL: variants = [],
    ELIGIBLE_CUSTOMIZATION_DESCRIP: eligibleCustomizationDescrip,
    CUSTOMIZATION_OFFERED_FLAG: customizationOfferedFlag,
    LTL_FLAG: ltlFlag,
    TBS_PRICE: tbsPrice,
  } = input;
  const attributes = (attributesData && attributesData.PLSR) || [];
  return {
    attributes: attributes
      .sort((a, b) => parseInt(a.PRIORITY, 10) - parseInt(b.PRIORITY, 10))
      .map(attr => ({
        skuAttributeId: attr.SKU_ATTRIBUTE_ID,
        text: unescape(attr.DISPLAY_DESCRIP),
        freeShippingLabel: attr.FREE_SHIPPING_LABEL,
      })),
    colors,
    badge,
    image: getConcatenatedScene7URLWithImageId(image),
    scene7imageID: image,
    isLTL: standardizeLTLFlag(ltlFlag),
    inCart: parseBoolean(inCart),
    qty: 1, // Default to one
    price: {
      normal: isPrice || '',
      normalValue: highPriceValue,
      lowValue: lowPriceValue,
      pricingLabelCode: '',
      priceRangeDescription: priceRangeDescrip,
      wasPrice,
      tbsPrice,
    },
    productId,
    title: unescape(title),
    url,
    swatchFlag,
    collectionFlag,
    rollupTypeCode,
    sizes,
    eligibleCustomizationDescrip,
    customizationOfferedFlag,
    variants:
      swatchFlag && variants /* istanbul ignore next */
        ? variants.map(
            /* istanbul ignore next */
            ({
              COLOR,
              MEDIUM_IMAGE_ID,
              SKU_TITLE,
              SWATCH_IMAGE_ID,
              SKU_ID,
              SKU_SIZE,
            }) => ({
              image: getConcatenatedScene7URLWithImageId(MEDIUM_IMAGE_ID),
              /* remove width parameter in url to get scene7ID as swatch scene7IDs
          are currently not in the JSON response */
              swatchScene7ID: MEDIUM_IMAGE_ID.substring(
                0,
                MEDIUM_IMAGE_ID.indexOf('?')
              ),
              label: capitalizeFirstCharacter(COLOR.toLowerCase()),
              swatchImage: getConcatenatedScene7URLWithImageId(
                SWATCH_IMAGE_ID,
                'swatch',
                32 // indicates the icon size
              ),
              title: SKU_TITLE,
              skuId: SKU_ID,
              size: SKU_SIZE,
            })
          )
        : [],
  };
};

/**
 * Picks specific fields from curried object.
 */
export const pickProductProps = pick([
  'price',
  'productId',
  'title',
  'variants',
  'defaultSkuCMS',
  'qty',
  'isLTL',
]);
export const internalScrollTo = final => window.scrollTo(0, final);
export const scrollSelectorUnderNavigation = selector => {
  if (isBrowser()) {
    const element = document.querySelector(selector);
    if (element) {
      /* istanbul ignore next */
      const {
        stickyHeaderHeight,
        marginTop,
        headerBanner,
      } = getHeaderOffsets();
      const final =
        getCoords(element).top -
        stickyHeaderHeight +
        // For Tricky Header
        /* istanbul ignore next */
        (marginTop === 0
          ? (headerBanner && headerBanner.offsetHeight) || 0
          : 0);
      setTimeoutCustom(internalScrollTo(final), 10);
    }
  }
};
