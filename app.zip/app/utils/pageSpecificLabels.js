import { merge } from 'lodash';
import pathOr from 'lodash/fp/pathOr';
import {
  pageNameToLabelsNodeMap,
  staticPageLabelIdentifierList,
} from '../constants/pageNameToLabelsNodeMap';

/* To get specific child label node in a parent label node e.g. myAccount.login*/
const fetchSpecificLabelNode = (node, labelData) => {
  const labelsIdentifiers = node.split('.');
  const mainNodeIdentifier = labelsIdentifiers[0];
  const specificNodeIdentifier = labelsIdentifiers[1];
  const mainNodeLabel = labelData && labelData[mainNodeIdentifier];
  /* istanbul ignore next */
  if (typeof mainNodeLabel === 'object') {
    return {
      [mainNodeIdentifier]: {
        [specificNodeIdentifier]: mainNodeLabel[specificNodeIdentifier],
      },
    };
  }
  return {};
};

/* To fetch all required labels for the specific page */
const pageSpecificLabelsResolver = (labelData, url, pageIdentifier) => {
  const staticPageLabelIdentifier = staticPageLabelIdentifierList.get(url);
  /* label Object's required  skeleton */
  let labels = {};

  /* Adding common labels required throughout application starts here */
  const commonLabels = [
    'Global',
    'header',
    'footer',
    'myAccount.header',
    'myAccount.myRegistries',
    'myAccount.registryPromotions',
    'Certona',
    'formMessages',
    'instantOffer',
    'Registry.navigation',
    'Registry.giftGiver',
    'ErrorPageLabels',
    'CountryCurrency',
    'ChangeStore',
    'InteractiveChecklist',
    'tbsInactivityModal',
    'ideaboard.modalHeading',
    'AssociateSignIn',
    'privacyPolicy',
    'SearchStores',
    'Registry.Bookingbug.findAppointmentText',
    'Registry.Bookingbug.findAppointmentNearYou',
  ];
  // Page specific required label nodes
  let labelsNodeArray = staticPageLabelIdentifier
    ? pageNameToLabelsNodeMap[staticPageLabelIdentifier] || []
    : pageNameToLabelsNodeMap[pageIdentifier] || [];

  /* holding unique values by removing duplicate values */
  labelsNodeArray = [...new Set([...labelsNodeArray, ...commonLabels])];
  /* ends here */
  /* istanbul ignore if */
  if (labelsNodeArray) {
    labelsNodeArray.forEach(node => {
      let nodeLabels = {};
      if (node && node.indexOf('.') > -1) {
        nodeLabels = fetchSpecificLabelNode(node, labelData);
      } else if (labelData) {
        nodeLabels = { [node]: labelData[node] };
      }
      if (pathOr(false, node, nodeLabels)) {
        labels = merge(labels, nodeLabels);
      }
    });
  }
  return labels;
};

export default pageSpecificLabelsResolver;
