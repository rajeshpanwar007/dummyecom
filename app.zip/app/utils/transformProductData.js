import { getStoreRef } from '@bbb-app/utils/storeRefUtils';
import { transformProductData } from '@bbb-app/utils/searchUtil';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { getCountryCurrencyValue } from '@bbb-app/utils/countryCurrencyUtils';

export const transformProductDataParameters = () => {
  const store = getStoreRef();
  const state = store.getState();

  return {
    country: getCountryCurrencyValue(),
    isInternational: isInternationalUser(),
    freeShippingQualifier: state.getIn(
      ['viewportConfig', 'pageConfig', 'Global', 'higherShippingThreshhold'],
      '0'
    ),
  };
};

export const transformSingleProduct = productData =>
  transformProductData(productData, transformProductDataParameters());
export const transformProductDataList = productDataList => {
  const dataParameters = transformProductDataParameters();
  return productDataList.map(productData =>
    transformProductData(productData, dataParameters)
  );
};
