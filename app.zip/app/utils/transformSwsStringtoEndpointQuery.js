import parseSanitizedSearchTerm from '@bbb-app/utils/parseSanitizedSearchTerm';
import { SWS_TERM_DELIM } from '../constants/search';
/**
 * parse the swsterm array into string for api call
 * @param {array} terms the search within search param from url
 * @return {string} array combined into a querystring
 */
export const transformSwsStringtoEndpointQuery = swsTerm =>
  swsTerm
    ? parseSanitizedSearchTerm(
        swsTerm.replace(new RegExp(SWS_TERM_DELIM, 'g'), ' ').trim()
      )
    : '';
