import { oneOfType, bool, number, string, shape, node } from 'prop-types';

/**
 * @prop {string} alt alt text for the image
 * @prop {string} className style classes
 * @prop {number} width width passed on to image
 * @prop {number} height height passed on to image
 * @prop {string} src image source to load
 * @prop {string} placeholder image element or component to show while image loads
 * @prop {bool} lazyLoad Toggle lazy load
 * @prop {object} lazyLoadOptions Options for the lazy load component, refer to https://github.com/vikash-bhardwaj/react-image-lazy-load
 * @prop {string} scene7imageID scene7ID of image
 * */
const propTypes = {
  alt: string,
  className: string,
  width: oneOfType([string, number]),
  height: oneOfType([string, number]),
  src: string,
  loader: node,
  lazyLoad: bool,
  lazyLoadOptions: shape({
    offset: number,
    placeholder: string,
  }),
  scene7imageID: string,
};

const defaultProps = {
  alt: '',
  lazyLoad: false,
  lazyLoadOptions: {
    offset: 0,
    placeholder: '',
  },
  isScene7UrlPrefix: true,
};

export { propTypes as default, defaultProps };
