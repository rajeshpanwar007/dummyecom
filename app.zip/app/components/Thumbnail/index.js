export { default } from './Thumbnail';
