import React from 'react';
import classnames from 'classnames';
import Picture from '@bbb-app/core-ui/picture';
import ImageSrcSet from '@bbb-app/core-ui/image-src-set';
import Img from '@bbb-app/core-ui/image/CoreImage';
import propTypes, { defaultProps } from './props';
import styles from './Thumbnail.css';

/**
 * Loads an image with options such as:
 * - lazy loaded with a placeholder
 * - preloader
 */
const Thumbnail = ({
  alt,
  breakpoints,
  className,
  height,
  width,
  src,
  loader,
  lazyLoad,
  lazyLoadOptions,
  scene7imageID,
  imgBeforeLoad,
  onImgLoad,
  onMouseEnter,
  onMouseLeave,
  isScene7UrlPrefix,
  imageSrcSet,
  scene7imageUrl,
  sizes,
  srcSet,
  imageSrc,
  dataLocator,
}) => {
  if (imageSrcSet) {
    return (
      <div className={styles.base}>
        <ImageSrcSet
          alt={alt}
          className={classnames(styles.image, className)}
          width={width}
          height={height}
          scene7imageID={scene7imageID}
          scene7imageUrl={scene7imageUrl}
          lazyLoad={lazyLoad}
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          lazyLoadOptions={lazyLoadOptions}
          onLoad={onImgLoad}
          isScene7UrlPrefix={isScene7UrlPrefix}
          loader={loader}
          sizes={sizes}
          srcSet={srcSet}
          imageSrc={imageSrc}
          data-locator={dataLocator}
        />
        {imgBeforeLoad}
      </div>
    );
  }
  return (
    <div className={styles.base}>
      <Picture
        category={breakpoints ? { breakpoints } : {}}
        lazyLoad={lazyLoad}
        lazyLoadOptions={lazyLoadOptions}
        onLoad={onImgLoad}
        isScene7UrlPrefix={isScene7UrlPrefix}
      >
        <Img
          alt={alt}
          className={classnames(styles.image, className)}
          height={height}
          loader={loader}
          src={src}
          width={width}
          scene7imageID={scene7imageID}
        />
      </Picture>
      {imgBeforeLoad}
    </div>
  );
};

Thumbnail.propTypes = propTypes;

Thumbnail.defaultProps = defaultProps;

export default Thumbnail;
