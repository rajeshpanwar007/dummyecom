import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import styles from './SeoExperience.css';

const MAX_RETRY_COUNT = 1;

const SeoExperience = ({ retry, fetchMetaTag, resetMetaTag, ...props }) => {
  const [retryApi, setRetryApi] = useState(0);

  const args = {
    pagePath: props.location.pathname,
    categoryId: props.match.params.id,
    siteId: props.siteId,
  };

  useEffect(
    () => {
      fetchMetaTag(args, 'SeoExperience', args.siteId, false);
    },
    [args, fetchMetaTag]
  );

  useEffect(
    () => {
      if (retry && retryApi < MAX_RETRY_COUNT) {
        fetchMetaTag(args, 'SeoExperience', args.siteId, false);
        setRetryApi(count => count + 1);
      } else if (retryApi >= MAX_RETRY_COUNT) {
        resetMetaTag();
      }
    },
    [args, fetchMetaTag, resetMetaTag, retry, retryApi]
  );

  return <h1 className={classnames(styles.container)}>Seo Experience Page</h1>;
};

SeoExperience.propTypes = {
  fetchMetaTag: PropTypes.func,
  retry: PropTypes.bool,
  resetMetaTag: PropTypes.func,
  siteId: PropTypes.number,
  location: PropTypes.any,
  match: PropTypes.any,
};

export default SeoExperience;
