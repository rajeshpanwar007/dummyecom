import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { ScriptInjector } from '@bbb-app/hoc/ThirdPartyLib';
import { isBrowser } from '@bbb-app/utils/common';
import styles from './Scene7Video.css';
const Secene7Video = props => {
  const {
    field_mute,
    field_loop,
    field_autoplay,
    field_playback,
    statusCode,
    video,
    image,
    alt,
    field_hide_controls: fieldHideControls,
  } = props;

  const [scriptInjected, setScriptInjected] = useState(false);
  let interval;

  useEffect(
    () => {
      if (!scriptInjected) {
        interval = setInterval(() => {
          toggleScriptStatus();
        }, 200);
      } else if (interval !== undefined) {
        clearInterval(interval);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const toggleScriptStatus = () => {
    if (isBrowser() && document.getElementById('S7VideoNode_container')) {
      setScriptInjected(true);
      if (interval !== undefined) {
        clearInterval(interval);
      }
    }
  };

  if (statusCode === 200) {
    let innerWidth = 0;
    if (isBrowser()) {
      innerWidth = window.innerWidth;
    }
    let videoId = '';
    let imageId = '';

    if (innerWidth >= 1024) {
      videoId = video.DSK.url;
      imageId = image.DSK.url;
    } else if (innerWidth >= 768 && innerWidth < 1024) {
      videoId = video.TAB.url;
      imageId = image.TAB.url;
    } else {
      videoId = video.MOB.url;
      imageId = image.MOB.url;
    }

    const S7VideoNode = 'S7VideoNode';
    const scriptPath =
      '/open-container-assets/opencontainerassets/common/scripts/scene7/';

    const scriptLoadedCallback = () => {
      const S7VideoViewer = isBrowser() && window.s7viewers;
      const S7VideView = new S7VideoViewer.VideoViewer({
        containerId: S7VideoNode,
        params: {
          asset: videoId,
          serverurl: 'https://b3h2.scene7.com/is/image/',
          contenturl: 'https://b3h2.scene7.com/skins/',
          config: 'Scene7SharedAssets/Universal_HTML5_Video',
          emailurl: 'https://b3h2.scene7.com/s7/emailFriend',
          mutevolume: field_mute,
          loop: field_loop,
          autoplay: field_autoplay,
          playback: field_playback,
          videoserverurl: 'https://b3h2.scene7.com/is/content/',
          posterimage: imageId,
        },
      });
      S7VideView.sdkBasePath = isBrowser() && window.location.origin; // it will only run on client
      S7VideView.utilsFilePath = `${scriptPath}util.js`;
      S7VideView.init();
    };

    /**
     * To Hide Video controls based on the flag from CMS
     * It will override Scene7 css
     */
    const HideControls =
      fieldHideControls && Number(fieldHideControls) ? (
        <style
        >{`#S7VideoNode_controls, #IconEffect_s7classic_20{display:none !important;} #S7VideoNode_videoPlayer{background-color: transparent !important} `}</style>
      ) : null;

    return (
      <React.Fragment>
        <span tabIndex="0" className="visuallyhidden">
          {alt}
        </span>
        {!scriptInjected &&
          isBrowser() && (
            <img
              src={`https://b3h2.scene7.com/is/image/${imageId}`}
              className={styles.fallbackImage}
              alt=""
            />
          )}
        <div id={S7VideoNode} className={styles.S7VideoNode} />
        {HideControls}
        <ScriptInjector
          loadedCallback={scriptLoadedCallback}
          callbackAfterUpdate={scriptLoadedCallback}
          scriptId="Secene7VideoViewer"
          isAsync
          isEnabled
          loadOnce
          parentSelector="body"
          src={`${scriptPath}videoViewer.js`}
        />
      </React.Fragment>
    );
  }
  return null;
};

Secene7Video.propTypes = {
  field_mute: PropTypes.string,
  field_loop: PropTypes.string,
  field_autoplay: PropTypes.string,
  field_playback: PropTypes.string,
  field_hide_controls: PropTypes.string,
  statusCode: PropTypes.number,
  video: PropTypes.object,
  image: PropTypes.object,
  alt: PropTypes.string,
};
export default Secene7Video;
