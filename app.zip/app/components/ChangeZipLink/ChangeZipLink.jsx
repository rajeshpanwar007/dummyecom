/* eslint-disable extra-rules/no-commented-out-code */
import React, { useState } from 'react';
import universal from 'react-universal-component';
import Button from '@bbb-app/core-ui/button';
import { options } from '@bbb-app/universal-component/options';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import { isBedBathCanada } from '@bbb-app/utils/common';

const ChangeZipFormAsync = universal(
  import(/* webpackChunkName: "change-zip-form" */ '../../containers/ChangeZipLink/ChangeZipForm'),
  options
);

const ChangeZipLink = props => {
  const [isModalOpen, toggleModal] = useState(false);
  const isCanada = isBedBathCanada();
  return (
    <React.Fragment>
      <Button
        id="changeZipLink"
        theme="link"
        variation="blueLink"
        onClick={() => toggleModal(!isModalOpen)}
      >
        {isCanada ? 'Change Postal Code' : 'Change Zip'}
      </Button>
      <ModalDialog
        mountedState={isModalOpen}
        toggleModalState={() => toggleModal(!isModalOpen)}
        titleAriaLabel="ChangeZipModal"
        closeIconLabel="Back"
        verticallyCenter
        variation="small"
        underlayClickNoExit
      >
        <ChangeZipFormAsync {...props} toggleModal={toggleModal} />
      </ModalDialog>
    </React.Fragment>
  );
};

export default ChangeZipLink;
