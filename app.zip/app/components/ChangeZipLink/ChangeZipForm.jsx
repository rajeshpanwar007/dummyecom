import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import { isUndefined } from 'lodash';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import ServiceUtil from '@bbb-app/utils/serviceUtil';
import { getCachedCookie, setCookie } from '@bbb-app/utils/universalCookie';
import { Redirect } from 'react-router';
import Heading from '@bbb-app/core-ui/heading/Heading';
import { isBedBathCanada } from '@bbb-app/utils/common';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Button from '@bbb-app/core-ui/button';
import Icon from '@bbb-app/core-ui/icon';
import getApiEndPointsFromStore from '@bbb-app/utils/getApiEndPointsFromStore';
import { FormWrapper } from '@bbb-app/forms/containers/FormWrapper/FormWrapper';
import FormInput from '@bbb-app/forms/containers/FormInput/FormInput';
import { SDD_CURRENT_ZIP_KEY } from '@bbb-app/redux/add-to-cart/constants';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import styles from '../Pages/PDP/ProductDetails/Components/DeliveryOptions/Components/ChangeZip/ChangeZip.css';

const DangerousHTMLWrapper = props => <span {...props} />;
const DangerousHTMLContainer = dangerousHTML(DangerousHTMLWrapper);

class ChangeZipForm extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      zipCode: getCachedCookie(SDD_CURRENT_ZIP_KEY),
      zipError: '',
      isFetching: false,
    };
    this.isBedBathCanada = isBedBathCanada();
    this.getLabel = LabelsUtil.getLabel;
  }

  onZipSubmit = obj => {
    const hasErrors = Object.keys(obj).length;
    if (!hasErrors) {
      const { edd_zipcode: { value } } = this.props.formWrapperData;
      this.triggerSDDEligibleAPICall(value);
    }
  };

  fireTealiumActionForShipT = (data, zip) => {
    const { fireTealiumAction } = this.props;
    const pageInfo = {};
    const actionDetails = {};
    if ((data && !data.sddFlag) || data === null) {
      actionDetails.pagename_breadcrumb = 'Same Day Delivery SearchModule';
      actionDetails.same_day_delivery_zip_not_eligible = zip;
      pageInfo.page_name = 'Same Day Delivery SearchModule';
    }
    fireTealiumAction(true, actionDetails, pageInfo);
  };
  async triggerSDDEligibleAPICall(zip) {
    const {
      toggleModal,
      viewType,
      marketEligibilitySuccess,
      onSuccessfulZipChange,
    } = this.props;
    this.setState({
      isFetching: true,
      data: undefined,
      errorMessages: undefined,
    });
    const zipCode = this.isBedBathCanada
      ? zip && typeof zip === 'string' && zip.split(' ')[0]
      : zip;
    const {
      body: { data, serviceStatus, errorMessages },
    } = await ServiceUtil.triggerServerRequest({
      url: getApiEndPointsFromStore('checkSddMarketEligibility').replace(
        ':zip',
        zipCode
      ),
      method: 'GET',
    });

    if (serviceStatus === 'SUCCESS' && data && data.sddFlag) {
      setCookie('SDDCZ', zip, {
        path: '/',
        expires: new Date(Date.now() + 3600 * 1000 * 24),
      });
      // To update SDDUZ cookie as well
      setCookie('SDDUZ', zip, {
        path: '/',
        expires: new Date(Date.now() + 3600 * 1000 * 24),
      });
      this.setState({ isFetching: false, zipCode: zip, data });
      if (window && window.location
        && window.location.href
        && window.location.href.includes('/store/same-day-delivery')
        && window.location.search && window.location.search.includes('zipcode')
      ) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set("zipcode", zip);
        history.replaceState(null, null, `?${urlParams.toString()}`);
      }
      marketEligibilitySuccess(data);
      if (viewType === 'sddPage') {
        onSuccessfulZipChange(true);
        // Call Action here to reload PLP on ZipCode Change
        toggleModal(false);
      }
    } else {
      let errorMsg = errorMessages;
      const isSddUnavailable = data && !data.sddFlag;
      if (isSddUnavailable) {
        errorMsg = [{ message: 'Same Day Delivery is unavailable' }];
      } else if (isSddUnavailable || data === null) {
        this.fireTealiumActionForShipT(data, zip);
      }
      this.setState({
        isFetching: false,
        zipCode: zip,
        errorMessages: errorMsg,
      });
    }
  }

  render() {
    const {
      labels,
      formWrapperData,
      clearIdentifierStateData,
      viewType,
      storePickupLink,
      isNoResults,
    } = this.props;
    const { data, errorMessages, isFetching } = this.state;

    // To redirect if user is on static page
    if (data && viewType === 'staticPage')
      return <Redirect to={'/store/same-day-delivery'} />;
    return (
      <div
        className={classnames({
          'large-8 small-12 pt1': isNoResults,
          pt2: !isNoResults,
        })}
      >
        <GridX>
          <Cell className={classnames('large-12')}>
            <Heading
              level={2}
              className={classnames({ [styles.noSddHeading]: isNoResults })}
            >
              {isNoResults ? (
                <DangerousHTMLContainer>
                  {this.getLabel(labels, 'nullSDDHeadingText')}
                </DangerousHTMLContainer>
              ) : (
                this.getLabel(labels, 'sddHeadingText')
              )}
            </Heading>
            <FormWrapper
              noValidate
              className={classnames('form-edd')}
              onSubmit={event => this.onZipSubmit(event)}
              id="changeZip"
              name="changeZip"
              identifier="changeZip"
              styles={styles}
              formWrapperData={formWrapperData}
              clearIdentifierStateData={clearIdentifierStateData}
            >
              <GridX className={classnames('mb3')}>
                {errorMessages && (
                  <section
                    className={classnames(styles.messageWrapper, 'small-12', {
                      'large-12 mt1 mb1 ': !isNoResults,
                      'large-10 mt0 mb15 large-offset-1 small-offset-0': isNoResults,
                    })}
                    data-locator="ChangeZip"
                  >
                    <Icon
                      className="mr2"
                      type="notificationAlert"
                      width="22px"
                      height="22px"
                    />
                    <Heading level={5}>
                      {LabelsUtil.getLabel(labels, 'sddUnavailable')}
                    </Heading>
                  </section>
                )}
                <Cell
                  className={classnames(
                    'large-6 small-12',
                    {
                      'large-offset-1 small-offset-0': isNoResults,
                      mt2: !isNoResults,
                    },
                    styles.changeZipForm
                  )}
                >
                  {' '}
                  <FormInput
                    id={'edd_zipcode'}
                    name={'edd_zipcode'}
                    type="text"
                    isRequired
                    label={this.getLabel(labels, 'zipCode')}
                    labelPosition="append"
                    value={
                      isUndefined(formWrapperData)
                        ? this.state.zipCode
                        : formWrapperData.edd_zipcode.value
                    }
                    edd_zipcodeError={
                      formWrapperData &&
                      formWrapperData.edd_zipcode.edd_zipcodeError
                    }
                    maxLength={this.isBedBathCanada ? '10' : '6'}
                    aria-label={this.getLabel(labels, 'zipCode')}
                    identifier="changeZip"
                    validation={this.isBedBathCanada ? 'postalCodeCA' : 'zip'}
                    pattern={this.isBedBathCanada ? '[a-zA-Z0-9-]*' : 'd*'}
                  />
                </Cell>
                <Cell
                  className={classnames(
                    'small-12',
                    {
                      'large-4': isNoResults,
                      'large-6 mt2': !isNoResults,
                    },
                    styles.changeZipButton,
                    { [styles.changeZipContainer]: isNoResults }
                  )}
                >
                  <Button
                    id="checkZipcode"
                    type="submit"
                    theme={isFetching ? 'deactivated' : 'primary'}
                    variation="fullWidth"
                    title={this.getLabel(labels, 'changeZipBtn')}
                  >
                    {this.getLabel(labels, 'changeZipBtn')}
                  </Button>
                  {storePickupLink && storePickupLink()}
                </Cell>
              </GridX>
            </FormWrapper>
          </Cell>
        </GridX>
      </div>
    );
  }
}

ChangeZipForm.propTypes = {
  labels: PropTypes.object,
  formWrapperData: PropTypes.object,
  clearIdentifierStateData: PropTypes.func,
  viewType: PropTypes.string,
  toggleModal: PropTypes.func,
  onSuccessfulZipChange: PropTypes.func,
  marketEligibilitySuccess: PropTypes.func,
  fireTealiumAction: PropTypes.func,
  storePickupLink: PropTypes.any,
  isNoResults: PropTypes.bool,
};

export default ChangeZipForm;
