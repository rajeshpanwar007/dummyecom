import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import kebabCase from 'lodash/fp/kebabCase';
import GridContainer from '@bbb-app/core-ui/grid-container';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { scrollToFiltersTop } from '@bbb-app/utils/scrollToFiltersTop';
import { isBrowser } from '@bbb-app/utils/common';
import {
  DEFAULT_SEARCH_SORT_BY,
  DEFAULT_SORT_BY,
} from '@bbb-app/constants/searchConstants';
import { CONFIG_MOBILE } from '@bbb-app/constants/appConstants';
import Styles from './ProductGridFooter.css';
// Created seperate util file for that
import Pagination from '../Pagination';
import Paging from '../Filters/Paging';
import PageSortOptions from '../Filters/PageSortOptions';
import { uiConfig } from '../Filters/uiConfig';
import { calculatePerPageOptions } from '../Filters/FiltersHelper';

/**
 * Wrapper component for rendering the footer of the product grid
 *
 * @param {object} params params for pagination
 * @param {function} onFilterUpdate function to handle filter update
 * @param {object} labels labels for components
 * @param {string} channelType mobile vs desktop prop
 */

const propTypes = {
  params: PropTypes.object,
  onFilterUpdate: PropTypes.func,
  labels: PropTypes.object,
  channelType: PropTypes.string,
  itemsPerPage: PropTypes.number,
  sort: PropTypes.string,
  paging: PropTypes.object,
  className: PropTypes.string,
  handlePaginationTealiumEvent: PropTypes.func,
  paginationTealiumData: PropTypes.object,
  pageId: PropTypes.string,
  isPartial: PropTypes.bool,
  isSearch: PropTypes.bool,
  boostedSearchEngine: PropTypes.string,
  filterConfiguration: PropTypes.object,
  searchTerm: PropTypes.string,
  categoryId: PropTypes.number,
  items: PropTypes.array,
  facetsData: PropTypes.object,
  selectedFilters: PropTypes.object,
  groupbySearchId: PropTypes.number,
  breadcrumbs: PropTypes.any,
  brandNameOriginal: PropTypes.string,
};

export const ProductGridFooter = ({
  sort,
  paging,
  itemsPerPage,
  params,
  onFilterUpdate,
  labels,
  channelType,
  className,
  handlePaginationTealiumEvent,
  paginationTealiumData,
  pageId,
  isPartial,
  isSearch,
  boostedSearchEngine,
  filterConfiguration,
  searchTerm,
  categoryId,
  items,
  facetsData,
  selectedFilters,
  groupbySearchId,
  breadcrumbs,
  brandNameOriginal,
}) => {
  const isMobile = channelType === CONFIG_MOBILE;
  const sortingOptions = isSearch
    ? filterConfiguration.sortingOptionsSrp
    : filterConfiguration.sortingOptions;
  const sortByFilterOptions = (sortingOptions || []).map(item => {
    return {
      label: item.displayName,
      props: {
        value: item.value,
      },
      key: kebabCase(item.displayName),
    };
  });

  const {
    filteredTotalPerPageFilterOptions,
    viewAllItemsPerPage,
  } = calculatePerPageOptions(
    filterConfiguration.perPageOptions,
    paging.count,
    itemsPerPage,
    labels
  );
  const sortBy = sort === DEFAULT_SORT_BY ? DEFAULT_SEARCH_SORT_BY : sort;

  const tealiumData = {
    searchTerm,
    categoryId,
    items,
    facetsData,
    selectedFilters,
    groupbySearchId,
    breadcrumbs,
    brandNameOriginal,
    paginationTealiumData,
    pageId,
    boostedSearchEngine,
  };
  return (
    <div className={classnames(Styles.color)}>
      <GridContainer>
        <div
          className={classnames(
            Styles.gridFooter,
            isPartial ? Styles.partial : 'mb3',
            className
          )}
        >
          {!isMobile &&
            !isPartial && (
              <div className={classnames(Styles.paging, Styles.footerDiv)}>
                <Paging
                  className={classnames(Styles.pagingHeader)}
                  paging={paging}
                  labels={labels}
                />
              </div>
            )}
          <Pagination
            className={classnames(Styles.pagination, Styles.footerDiv)}
            channelType={channelType}
            {...params}
            onPageClick={/* istanbul ignore next*/ (page, event) => {
              event.preventDefault();
              if (isBrowser()) {
                scrollToFiltersTop();
              }
              onFilterUpdate(page);
            }}
            buttonLabels={{
              back: LabelsUtil.getLabel(labels, 'pagination.backBtn'),
              next: LabelsUtil.getLabel(labels, 'pagination.nextBtn'),
              ariaNavLabel: LabelsUtil.getLabel(
                labels,
                'pagination.ariaNavLabel'
              ),
              ariaLinkLabel: LabelsUtil.getLabel(
                labels,
                'pagination.ariaLinkLabel'
              ),
              ariaCurrentLabel: LabelsUtil.getLabel(
                labels,
                'pagination.ariaCurrentLabel'
              ),
              pageNumberScreenReaderText: LabelsUtil.getLabel(
                labels,
                'pagination.pageNumberScreenReaderText'
              ),
            }}
            handlePaginationTealiumEvent={handlePaginationTealiumEvent}
            tealiumData={tealiumData}
          />
          {!isMobile &&
            !isPartial && (
              <PageSortOptions
                className={classnames(Styles.footerDiv, Styles.sort)}
                labels={labels}
                sort={sortBy}
                SortTypeOptionSet={sortByFilterOptions}
                defaultPerPage={uiConfig.defaultPerPage}
                itemsPerPage={viewAllItemsPerPage}
                PerPageOptionSet={filteredTotalPerPageFilterOptions}
                onFilterUpdate={onFilterUpdate}
                channelType={channelType}
                scrollToFiltersOnChange
              />
            )}
        </div>
      </GridContainer>
    </div>
  );
};

ProductGridFooter.propTypes = propTypes;
export default ProductGridFooter;
