export { default } from './ProductGridFooter';
