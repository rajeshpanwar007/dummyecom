export { default } from './ProductAttribute';
