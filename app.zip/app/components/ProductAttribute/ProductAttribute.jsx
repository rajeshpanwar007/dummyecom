import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';

import styles from './ProductAttribute.css';

const propTypes = {
  className: PropTypes.string,
  label: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  labelProps: PropTypes.object,
  valueProps: PropTypes.object,
  enableReviewOrderVariant: PropTypes.bool,
};

const AttributeValue = props => (
  <span className={classnames(styles.attributeValue)} {...props} />
);
const AttributeValueWithDangerousHTML = dangerousHTML(AttributeValue);

/**
 * ProductAttribute: Displays Product Attribute for a cart line item
 * @param {[string]}  className  [Additional Classes provided by the container]
 * @param {[string]}  label  [Attribute Key]
 * @param {[string]}  value  [Attribute value]
 * @param {[object]}  labelProps  [Additional Label Props]
 * @param {[object]}  valueProps  [Additional Value Props]
 * @return {[html]}  [Layout for Product Attribute]
 */

const ProductAttribute = ({
  className,
  label,
  value,
  labelProps,
  valueProps,
  enableReviewOrderVariant,
}) => {
  return (
    <div
      className={classnames(className, styles.info, {
        [styles.attributeSpacing]: !enableReviewOrderVariant,
      })}
    >
      <span {...labelProps} className={className}>
        {label && `${label}:`}{' '}
      </span>
      <AttributeValueWithDangerousHTML {...valueProps}>
        {value}
      </AttributeValueWithDangerousHTML>
    </div>
  );
};

ProductAttribute.propTypes = propTypes;

export default ProductAttribute;
