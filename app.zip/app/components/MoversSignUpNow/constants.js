export const SRC_SET = [
  {
    preset: 'content',
    width: '288',
    height: '196',
    sourceWidth: '288w',
  },
  {
    preset: 'content',
    width: '420',
    height: '288',
    sourceWidth: '420w',
  },
  {
    preset: 'content',
    width: '522',
    height: '355',
    sourceWidth: '522w',
  },
  {
    preset: 'content',
    width: '783',
    height: '533',
    sourceWidth: '783w',
  },
  {
    preset: 'content',
    width: '632',
    height: '430',
    sourceWidth: '632w',
  },
  {
    preset: 'content',
    width: '948',
    height: '645',
    sourceWidth: '948w',
  },
];

export const IMAGE_SRC = {
  preset: 'content',
  width: '632',
  height: '430',
};

export const SIZES = [
  {
    breakpoint: 'max-width: 768px',
    viewportWidth: '45vw',
  },
  {
    breakpoint: 'max-width: 1023px',
    viewportWidth: '60vw',
  },
  {
    breakpoint: 'min-width: 1024px',
    viewportWidth: '50vw',
  },
];
