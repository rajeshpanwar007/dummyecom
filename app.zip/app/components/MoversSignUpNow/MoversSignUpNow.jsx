import React from 'react';
import classnames from 'classnames';
import { isEmpty } from 'lodash/fp';
import { func, object, array } from 'prop-types';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import { noop } from '@bbb-app/utils/common';
import Button from '@bbb-app/core-ui/button';
import ImageSrcSet from '@bbb-app/core-ui/image-src-set';
import {
  extractScene7Id,
  checkIfURLIsScene7URL,
} from '@bbb-app/utils/getSceneImageData';
import TealiumHandler from '@bbb-app/tealium/TealiumHandler';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import styles from './MoversSignUpNow.css';
import { SIZES, SRC_SET, IMAGE_SRC } from './constants';
class MoversSignUpNow extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      modalMountedState: false,
    };
  }

  onClick = event => {
    event.preventDefault();
    this.setState({ modalMountedState: !this.state.modalMountedState });
  };

  toggleModalState = state => {
    this.setState({ modalMountedState: state });
  };

  renderReferredContent = (loadContent, contentData, referredContent, item) => {
    const { isFetching, content, error } = contentData;
    if (error) {
      return null;
    } else if (isEmpty(content) && !isFetching && !isEmpty(referredContent)) {
      loadContent(referredContent.map(v => v.id));
    } else if (contentData && !isEmpty(content)) {
      const itemId = referredContent.find(v => v.key === item);
      if (itemId && content[itemId.id] && content[itemId.id].body) {
        return (
          <div
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{
              __html: content[itemId.id].body,
            }}
          />
        );
      }
    }
    return null;
  };

  render() {
    const { loadContent, contentData, referredContent, labels } = this.props;
    const modalContentId = 'moversEmailSignUpCTA';
    const url = labels.emailSignUpImgSrc || null;
    const scene7imageID = checkIfURLIsScene7URL(url)
      ? extractScene7Id(url)
      : url;
    const lazyLoadOptions = {
      offset: 200,
      placeholder: '/static/product-image-placeholder.png',
    };
    const tealiumObject = {
      pagename_breadcrumb: 'New Mover',
      page_name: 'movers sign up modal',
      channel: 'New Mover',
      page_function: 'movers sign up modal',
      content_pagetype: '',
      product_pagetype: '',
      navigation_path: 'Main Level Page',
      subnavigation_path: 'Main Level Page',
    };
    return (
      <div
        className={classnames(
          styles.signUpNow,
          'small-12 flex center componentWrapper'
        )}
      >
        <div className={classnames('center', styles.text)}>
          <Heading level={2} className={styles.heading}>
            {LabelsUtil.getLabel(labels, 'moversEmailSignUpTitle')}
          </Heading>
          <p>{LabelsUtil.getLabel(labels, 'moversEmailSignUpCopy')}</p>
          <div className="center">
            <Button
              className={styles.cta}
              onClick={this.onClick}
              theme="secondaryTransparent"
            >
              {LabelsUtil.getLabel(labels, 'moversEmailSignUpNow')}
            </Button>
          </div>
        </div>

        <div className={styles.imgHolder}>
          <div className={styles.aspectRatio}>
            <div className={styles.wrapper}>
              <ImageSrcSet
                alt={''}
                srcSet={SRC_SET}
                sizes={SIZES}
                imageSrc={IMAGE_SRC}
                scene7imageID={scene7imageID}
                isScene7UrlPrefix
                className={styles.image}
                lazyLoadOptions={lazyLoadOptions}
                lazyLoad
              />
            </div>
          </div>
        </div>

        <ModalDialog
          mountedState={this.state.modalMountedState}
          toggleModalState={this.toggleModalState}
          titleAriaLabel="Movers Sign Up"
          verticallyCenter
          variation="medium"
          rclModalClass={styles.moversSignUpDialog}
        >
          {this.renderReferredContent(
            loadContent,
            contentData,
            referredContent,
            modalContentId
          )}
        </ModalDialog>
        {this.state.modalMountedState && (
          <ErrorBoundary>
            <TealiumHandler
              utagData={tealiumObject}
              identifier="Movers Sign Up Modal"
              isCLPFireTealium
              tealiumPageInfoNotAvailable
            />
          </ErrorBoundary>
        )}
      </div>
    );
  }
}

MoversSignUpNow.propTypes = {
  referredContent: array,
  contentData: object,
  loadContent: func,
  labels: object,
};

MoversSignUpNow.defaultProps = {
  referredContent: [],
  contentData: {
    isFetching: false,
  },
  loadContent: noop,
  labels: {},
};

export default MoversSignUpNow;
