import React from 'react';
import PropTypes from 'prop-types';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import SearchStores from '../../containers/SearchStores/SearchStores';
import { STORE_EVENTS_TITLE, STORE_SUB_HEADING, RSVP_TEXT } from './constants';

import styles from './StoreEventsModal.css';

const defaultProps = {};

const propTypes = {
  className: PropTypes.any,
  showEventModal: PropTypes.any,
  isForEventsPage: PropTypes.any,
  closeEventModal: PropTypes.any,
  zipSubmitted: PropTypes.any,
  eventName: PropTypes.any,
  contentId: PropTypes.any,
  isFetchingEventStores: PropTypes.any,
};
class StoreEventModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.renderZipModal = this.renderZipModal.bind(this);
    this.renderEventsHeading = this.renderEventsHeading.bind(this);
    this.toggleParentUnderlay = this.toggleParentUnderlay.bind(this);
    this.state = {
      modalMountedState: true,
      parentUnderlay: true,
    };
  }

  toggleParentUnderlay(value) {
    this.setState({ parentUnderlay: value });
  }

  renderEventsHeading() {
    const { zipSubmitted, eventName } = this.props;
    return (
      <div>
        <p className={styles.eventsTitleHeading}>{STORE_EVENTS_TITLE}</p>
        <div className={zipSubmitted ? styles.eventsBorder : ''}>
          <p className="m0">{zipSubmitted ? eventName : ''}</p>
          <p className={styles.eventsSubHeading}>
            {zipSubmitted ? RSVP_TEXT : STORE_SUB_HEADING}
          </p>
        </div>
      </div>
    );
  }

  renderZipModal() {
    const {
      isForEventsPage,
      showEventModal,
      closeEventModal,
      zipSubmitted,
      contentId,
      isFetchingEventStores,
    } = this.props;
    return (
      <ModalDialog
        mountedState={showEventModal}
        toggleModalState={closeEventModal}
        titleAriaLabel="aria-label"
        verticallyCenter
        underlayClickExits={this.state.parentUnderlay}
        variation={zipSubmitted ? 'medium' : 'small'}
      >
        {showEventModal && this.renderEventsHeading()}
        <SearchStores
          gridXClass="grid-container-fluid justify-center"
          cellClass="large-12"
          findStorePage={false}
          hideStoreNumber
          isFindAStore
          locator="findAStorePage-filtersDropdown"
          isForEventsPage={isForEventsPage}
          isEventsStyles={styles}
          contentId={contentId}
          toggleStoreEventModal={closeEventModal}
          toggleParentUnderlay={this.toggleParentUnderlay}
          isZipSubmitted={zipSubmitted}
          isFetchingEventStores={isFetchingEventStores}
          noPaddingTop
          noBorderTop
        />
      </ModalDialog>
    );
  }

  render() {
    const { className, showEventModal } = this.props;
    return (
      <div className={className}>{showEventModal && this.renderZipModal()}</div>
    );
  }
}

StoreEventModal.defaultProps = defaultProps;
StoreEventModal.propTypes = propTypes;

export default StoreEventModal;
