export const STORE_EVENTS_TITLE = 'In-store Events';
export const STORE_SUB_HEADING =
  'Please enter your Zip Code to find Store Events near you.';
export const RSVP_TEXT = 'Click on a store below to RSVP to your event';
