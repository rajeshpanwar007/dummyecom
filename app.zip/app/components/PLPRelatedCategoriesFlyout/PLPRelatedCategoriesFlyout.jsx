import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Button from '@bbb-app/core-ui/button';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import FlyoutClickOutside from '../../components/common/FlyoutClickOutside';
import styles from './PLPRelatedCategoriesFlyout.css';
import Ellipsis from './EllipsisIcon.async';

const propTypes = {
  flyoutProps: PropTypes.array, // Related Categories data
  track: PropTypes.func,
  displayName: PropTypes.string, // name of product for accessibility, try removing all accessibility code and make it more modular
  relatedCategoriesLabel: PropTypes.string,
};

class PLPRelatedCategoriesFlyout extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      showFlyout: false,
    };
    this.showFlyout = this.showFlyout.bind(this);
    this.hideFlyout = this.hideFlyout.bind(this);
    this.onClick = this.onClick.bind(this);
  }

  onClick() {
    this.toggleFlyout();
  }

  hideFlyout() {
    clearTimeout(this.hideFlyoutTimeout);
    this.setState({ showFlyout: false });
  }

  showFlyout() {
    clearTimeout(this.hideFlyoutTimeout);
    this.setState({ showFlyout: true });
  }

  toggleFlyout() {
    if (this.state.showFlyout) {
      clearTimeout(this.hideFlyoutTimeout);
    }
    this.setState({ showFlyout: !this.state.showFlyout });
  }

  render() {
    const {
      flyoutProps,
      displayName,
      track,
      relatedCategoriesLabel,
    } = this.props;
    const touchProps = {};
    touchProps.onClick = this.onClick;
    return (
      <div className={styles.categoryText} {...touchProps}>
        <Button
          className={classnames(styles.relatedCatFlyoutContainer, 'mt1')}
          aria-expanded={this.state.showFlyout}
          aria-label={`perform actions for ${displayName}`}
          theme="ghost"
          variation="noHorizontalPadding"
          aria-haspopup="true"
        >
          <Ellipsis />
          <span>{relatedCategoriesLabel}</span>
        </Button>
        <div className={classnames(this.state.showFlyout ? '' : styles.flyout)}>
          <FlyoutClickOutside
            showArrow={false}
            className={styles.flyOutBase}
            onClickOutside={this.hideFlyout}
          >
            <ul role="menu">
              {flyoutProps.map((item, index) => {
                return (
                  <PrimaryLink
                    href={item.CATEGORY_URL}
                    className={classnames(styles.flyoutLink)}
                    title={item.CATEGORY_DISP_NAME}
                    onClick={() => track('relatedCategories_SS')}
                    key={`PLPRelatedCategoriesFlyout-PrimaryLink-${index}`}
                  >
                    <li
                      className={classnames(styles.flyOutChild, 'px2 pb1')}
                      role="button"
                    >
                      <span>{item.CATEGORY_DISP_NAME}</span>
                    </li>
                  </PrimaryLink>
                );
              })}
            </ul>
          </FlyoutClickOutside>
        </div>
      </div>
    );
  }
}

PLPRelatedCategoriesFlyout.propTypes = propTypes;

export default PLPRelatedCategoriesFlyout;
