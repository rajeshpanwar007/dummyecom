import React from 'react';
import Icon from '@bbb-app/core-ui/icon/Icon';
import '../../assets/icons/ellipsis.svg';

const EllipsisIconComponent = () => (
  <Icon type={'ellipsis'} height="16px" width="16px" />
);

export default EllipsisIconComponent;
