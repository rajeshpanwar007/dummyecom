import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { getCurrentSiteIdAtBrowser } from '@bbb-app/utils/common';
import Button from '@bbb-app/core-ui/button';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import '@bbb-app/assets/icons/arrow.svg';
import RegistryQuickPicks from './RegistryQuickPicks';
import Skeleton from './Skeleton';
import style from './registryQuickPicks.css';
import PICKS from './PICKS';

const defaultProps = {
  data: PICKS[getCurrentSiteIdAtBrowser()],
};

const propTypes = {
  data: PropTypes.any,
  registryData: PropTypes.any,
};

export class QuickPickColumn extends React.PureComponent {
  constructor(props) {
    super(props);
    this.selectFeatured = this.selectFeatured.bind(this);
    this.selectPicks = this.selectPicks.bind(this);
  }
  selectFeatured(category) {
    if (this.props.data) {
      const data = this.props.data.filter(obj => {
        return obj.category === category;
      });

      return data.map(item => (
        <div
          className={classnames(
            style.postFeatured,
            `postFeatured large-12 medium-12 small-12 cell`
          )}
          key={item.id}
        >
          <img
            src={item.featured.img}
            className={classnames(`${style.qpLgImg} qpLgImg show-for-large`)}
            alt={item.featured.text}
            id="featureImg"
          />
          <div className={classnames(style.featuredContent, 'featuredContent')}>
            <h2 className={classnames(style.featuredTitle, 'featuredTitle')}>
              {item.featured.title}
            </h2>
            <p className={classnames(style.featuredText, 'featuredText')}>
              {item.featured.text}
            </p>

            <Button
              theme="ghost"
              href={item.featured.link}
              className={classnames(style.featuredLink, 'featuredLink')}
              variation="noPadding"
              isIconAfterContent="true"
              iconProps={{
                type: 'arrow',
                width: '20px',
                height: '20px',
              }}
              aria-label={`Go To ${item.featured.link_text}`}
            >
              {item.featured.link_text}
            </Button>
          </div>
        </div>
      ));
    }

    return null;
  }

  selectPicks(category) {
    if (this.props.data) {
      const data = this.props.data.filter(obj => {
        return obj.category === category;
      });

      return data.map(item => {
        return item.pick.map(smallPost => (
          <div
            className="post large-6 medium-6 small-12 cell"
            key={smallPost.id}
          >
            <PrimaryLink
              href={smallPost.link}
              alt={`Go to ${smallPost.text}`}
              className={classnames(style.primaryLinkQp)}
            >
              <img
                src={smallPost.img}
                className={classnames(style.qpSmImg, 'qpSmImg')}
                alt={smallPost.text}
              />
              <p className={classnames(style.postText, 'postText')}>
                {smallPost.text}
              </p>
            </PrimaryLink>
          </div>
        ));
      });
    }

    return null;
  }
  render() {
    if (
      !this.props.registryData ||
      !this.props.registryData.registryResVO ||
      !this.props.registryData.registryResVO.registrySummaryVO
    ) {
      return <Skeleton />;
    }
    return (
      <RegistryQuickPicks>
        <div
          className={classnames(
            style.featuredPostWrap,
            'small-12 medium-12 large-6 cell picksDisp grid-x grid-margin-x'
          )}
        >
          {this.selectFeatured(
            this.props.registryData.registryResVO.registrySummaryVO.eventType
          )}
        </div>
        <div
          className={classnames(
            style.postWrap,
            'postWrap small-12 medium-12 large-6 cell picksDisp grid-x grid-margin-x'
          )}
        >
          {this.selectPicks(
            this.props.registryData.registryResVO.registrySummaryVO.eventType
          )}
        </div>
      </RegistryQuickPicks>
    );
  }
}

QuickPickColumn.propTypes = propTypes;
QuickPickColumn.defaultProps = defaultProps;

export default QuickPickColumn;
