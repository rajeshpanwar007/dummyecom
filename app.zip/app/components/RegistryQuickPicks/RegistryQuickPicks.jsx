import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import compose from 'lodash/fp/compose';
import setDisplayName from '@bbb-app/hoc/setDisplayName';
import purify from '@bbb-app/hoc/purify';

const defaultProps = {
  className: null,
  children: null,
  data: null,
};

const propTypes = {
  className: PropTypes.any,
  children: PropTypes.node,
  data: PropTypes.object,
};

export const RegistryQuickPicks = ({ className, children, ...props }) => (
  <div
    className={classnames('grid-x regPicksWrapper grid-margin-x', className)}
    {...props}
  >
    {children}
  </div>
);

RegistryQuickPicks.propTypes = propTypes;
RegistryQuickPicks.defaultProps = defaultProps;

export default compose(purify, setDisplayName('Registry Quick Picks'))(
  RegistryQuickPicks
);
