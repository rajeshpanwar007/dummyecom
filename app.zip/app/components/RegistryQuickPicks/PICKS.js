const PICKS = {
  BuyBuyBaby: [
    {
      id: 0,
      category: 'Baby',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link:
            '/store/quickpicks/nursery-and-dcor/nursery-room-basics/dc1990123',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '/store/quickpicks/bath-and-potty/bathtime/dc1990118',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link:
            '/store/quickpicks/nursing-and-feeding/breastfeeding-essentials/dc1990119',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '/store/category/clothing-accessories/30007/',
        },
      ],
    },
    {
      id: 1,
      category: 'Birthday',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link:
            '/store/quickpicks/nursery-and-dcor/nursery-room-basics/dc1990123',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '/store/quickpicks/bath-and-potty/bathtime/dc1990118',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link:
            '/store/quickpicks/nursing-and-feeding/breastfeeding-essentials/dc1990119',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '/store/category/clothing-accessories/30007/',
        },
      ],
    },
    {
      id: 2,
      category: 'Other',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link:
            '/store/quickpicks/nursery-and-dcor/nursery-room-basics/dc1990123',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '/store/quickpicks/bath-and-potty/bathtime/dc1990118',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link:
            '/store/quickpicks/nursing-and-feeding/breastfeeding-essentials/dc1990119',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '/store/category/clothing-accessories/30007/',
        },
      ],
    },
  ],
  BedBathCanada: [
    {
      id: 0,
      category: 'Baby',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/baby/300003/all',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link:
            '/store/quickpicks/nursery-and-dcor/nursery-room-basics/dc1990123',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '/store/quickpicks/bath-and-potty/bathtime/dc1990118',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link:
            '/store/quickpicks/nursing-and-feeding/breastfeeding-essentials/dc1990119',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '/store/category/clothing-accessories/30007/',
        },
      ],
    },
    {
      id: 1,
      category: 'Wedding',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/wedding%5Ffeo%5FFeatured2%5FRegistry%5FQuickPicks%5F10%5F15%5F18?$other$',
        text:
          'Start building your registry together. Discover the best brands and products perfect for your new home.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/wedding/300001/newborn-essentials',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FAnAfternoonOfBaking%5F612x360%5F10%5F15%5F18?$other$',
          text: 'An Afternoon of Baking',
          link: '/store/quickpicks/kitchen/an-afternoon-of-baking/dc1990007',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FDinnerEntertainmentMadeEasy%5F612x360%5F10%5F15%5F18?$other$',
          text: 'Dinner Entertainment Made Easy',
          link:
            '/store/quickpicks/dining-room/dinner-entertainment-made-easy/dc1990140',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FSleepingInLuxuryNeverLookedSoGood%5F612x360%5F10%5F15%5F18?$other$',
          text: 'Sleeping In Luxury Never Looked So Good',
          link:
            '/store/quickpicks/bedroom/sleeping-in-luxury-never-looked-so-good/dc1990046',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FTheRightTowelForBothOfYou%5F612x360%5F10%5F15%5F18?$other$',
          text: 'The Right Towel For Both Of You',
          link:
            '/store/quickpicks/bathroom/the-right-towel-for-both-of-you/dc1990053',
        },
      ],
    },
    {
      id: 2,
      category: 'College',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'BBBYUS COLLEGE REGISTRY  Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks BBBYUS',
        link: '/store/kickstarters/university/300006/extras',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link: '#',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '#',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link: '#',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '#',
        },
      ],
    },
    {
      id: 3,
      category: 'Retirement',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'BBBYUS Retirement REGISTRY  Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks BBBYUS',
        link: '#',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link: '#',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '#',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link: '#',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '#',
        },
      ],
    },
    {
      id: 4,
      category: 'Housewarming',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5F08%5F16%5F18%5FfeaturedPost?$other$',
        text: 'Register for these first',
        title: 'Mover Starter Packs',
        link: '/store/kickstarters/housewarming/300004/extras',
        link_text: 'See All',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18?$other$',
          text: 'Starter Kit',
          link: '/store/quickpicks/extras/ready-for-adventure/dc1990001',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot2?$other$',
          text: 'Unpack First',
          link:
            '/store/quickpicks/laundry/make-the-most-of-your-closet/dc1990035',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot3?$other$',
          text: 'Power Up Set',
          link: '/store/quickpicks/extras/your-smart-home-your-way/dc1990059',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot4?$other$',
          text: 'Bathroom 101',
          link: '/store/quickpicks/bathroom/elevate-the-bathroom/dc1990024',
        },
      ],
    },
  ],
  BedBathUS: [
    {
      id: 0,
      category: 'Baby',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link:
            '/store/quickpicks/nursery-and-dcor/nursery-room-basics/dc1990123',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '/store/quickpicks/bath-and-potty/bathtime/dc1990118',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link:
            '/store/quickpicks/nursing-and-feeding/breastfeeding-essentials/dc1990119',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '/store/category/clothing-accessories/30007/',
        },
      ],
    },
    {
      id: 1,
      category: 'Wedding',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/wedding%5Ffeo%5FFeatured2%5FRegistry%5FQuickPicks%5F10%5F15%5F18?$other$',
        text:
          'Start building your registry together. Discover the best brands and products perfect for your new home.',
        title: 'Registry Quick Picks',
        link: '/store/kickstarters/wedding/200001',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FAnAfternoonOfBaking%5F612x360%5F10%5F15%5F18?$other$',
          text: 'An Afternoon of Baking',
          link: '/store/quickpicks/kitchen/an-afternoon-of-baking/dc1990007',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FDinnerEntertainmentMadeEasy%5F612x360%5F10%5F15%5F18?$other$',
          text: 'Dinner Entertainment Made Easy',
          link:
            '/store/quickpicks/dining-room/dinner-entertainment-made-easy/dc1990140',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FSleepingInLuxuryNeverLookedSoGood%5F612x360%5F10%5F15%5F18?$other$',
          text: 'Sleeping In Luxury Never Looked So Good',
          link:
            '/store/quickpicks/bedroom/sleeping-in-luxury-never-looked-so-good/dc1990046',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/QP%5FTheRightTowelForBothOfYou%5F612x360%5F10%5F15%5F18?$other$',
          text: 'The Right Towel For Both Of You',
          link:
            '/store/quickpicks/bathroom/the-right-towel-for-both-of-you/dc1990053',
        },
      ],
    },
    {
      id: 2,
      category: 'College',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'BBBYUS COLLEGE REGISTRY  Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks BBBYUS',
        link: '#',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link: '#',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '#',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link: '#',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '#',
        },
      ],
    },
    {
      id: 3,
      category: 'Retirement',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FRegistryDashboard%5FModule4A%5FQuickPicksHero1260x964?$other$',
        text:
          'BBBYUS Retirement REGISTRY  Choose from our curated lists of products to get your registry started quickly and easily.',
        title: 'Registry Quick Picks BBBYUS',
        link: '#',
        link_text: 'See All Quick Picks',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FNursery%5FBasics%5FQuickPicks%5F612x360?$other$',
          text: 'Nursery Room Basics',
          link: '#',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBathtime%5FQuickPicks%5F612x360?$other$',
          text: 'Bathtime',
          link: '#',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%5FDASH%5FBreastfeeding%5FQuickPicks%5F612x360?$other$',
          text: 'Breastfeeding Essentials',
          link: '#',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/05%5F18%5Ffeo%5FREG%20%5FDASH%5FFirst%20Wardrobe%5FQuickPicks%5F612x360?$other$',
          text: 'First Wardrobe',
          link: '#',
        },
      ],
    },
    {
      id: 4,
      category: 'Housewarming',
      featured: {
        id: 0,
        img:
          '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5F08%5F16%5F18%5FfeaturedPost?$other$',
        text: 'Register for these first',
        title: 'Mover Starter Packs',
        link: '#',
        link_text: 'See All',
      },
      pick: [
        {
          id: 0,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18?$other$',
          text: 'Starter Kit',
          link: '#',
        },
        {
          id: 1,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot2?$other$',
          text: 'Unpack First',
          link: '#',
        },
        {
          id: 2,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot3?$other$',
          text: 'Power Up Set',
          link: '#',
        },
        {
          id: 3,
          img:
            '//s7d9.scene7.com/is/image/BedBathandBeyond/feo%5Fmover%5FRegistry%5Fsmall%5Ffeatured%5F08%5F16%5F18%5Fslot4?$other$',
          text: 'Bathroom 101',
          link: '#',
        },
      ],
    },
  ],
};

export default PICKS;
