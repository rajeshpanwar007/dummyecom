export { default } from './SDD';
