import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import getOr from 'lodash/fp/getOr';
import { isUndefined } from 'lodash';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import { getCookie, setCookie } from '@bbb-app/utils/universalCookie';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Paragraph from '@bbb-app/core-ui/paragraph';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper/SkeletonWrapper';
import FormWrapper from '@bbb-app/forms/containers/FormWrapper/FormWrapper';
import FormInput from '@bbb-app/forms/containers/FormInput/FormInput';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import ErrorMessage from '@bbb-app/core-ui/focusable-error-message/ErrorMessage';
import { isBedBathCanada } from '@bbb-app/utils/common';
import '@bbb-app/assets/icons/arrow.svg';
import { SDD_ERR_CODE_ZIP_NOT_FOUND } from '@bbb-app/constants/pdpConstants';
import getSddMarketEligibilityAxios from '@bbb-app/redux/market-eligibility/axios';
import { updateMarketCookies } from '@bbb-app/utils/sddUtils';

import styles from './SDD.css';
import {
  PAGE_NAME,
  PAGE_TYPE,
  COOKIE_PATH,
} from '../../containers/SDD/SDDModal/constants';
import {
  LINK_INFO_ZIP_CODE,
  PAGE_NAME_BREADCRUMEB,
} from '../../containers/SDD/SDDModal/SDDModalConstants';
import BopisAlert from '../Bopis/BopisAlert/BopisAlert.async';

const propTypes = {
  labels: PropTypes.object,
  sddMarketEligibility: PropTypes.func,
  sddMarketEligibilitySuccess: PropTypes.func,
  sddMarketData: PropTypes.object,
  closeModal: PropTypes.func,
  isSDDLandingPage: PropTypes.bool,
  formWrapperData: PropTypes.object,
  clearSDDError: PropTypes.func,
  handleTealiumEvent: PropTypes.func,
  pageName: PropTypes.string,
  isBopisFilter: PropTypes.bool,
  OnZipChange: PropTypes.any,
  clientZip: PropTypes.string,
  setError: PropTypes.func,
  eddFacetCount: PropTypes.object,
  fetchSddButtonStatus: PropTypes.func,
  isSddCheckbox: PropTypes.bool,
  sameDayCount: PropTypes.any,
  fetchingSddRadioButtonStatus: PropTypes.any,
  toggleModal: PropTypes.func,
};

export class SDD extends React.PureComponent {
  constructor(props) {
    super(props);
    const sddZip = getCookie('SDDCZ');
    this.state = {
      sddZip,
      sddZipError: '',
      marketDataError: getOr([], 'error', props.sddMarketData),
      submitClicked: false,
      searchAgainClicked: false,
      bopisZip: sddZip,
    };
    this.isBedBathCanada = isBedBathCanada();
    this.handleSubmit = this.handleSubmit.bind(this);
    this.searchAgain = this.searchAgain.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleZipOnChange = this.handleZipOnChange.bind(this);
  }

  componentDidMount() {
    if (
      this.props.isBopisFilter &&
      this.state.bopisZip &&
      this.state.bopisZip.length !== 0 &&
      !this.props.isSddCheckbox
    ) {
      this.handleZipOnChange();
    }
  }

  componentWillReceiveProps(nextProps) {
    const sddZip = getCookie('SDDCZ');
    const {
      isSddCheckbox,
      sameDayCount,
      fetchingSddRadioButtonStatus,
      toggleModal,
      sddMarketData,
    } = nextProps;
    const sddFlag = getOr('', 'marketData.sddFlag', sddMarketData);
    const sddError = this.state.marketDataError;
    /* istanbul ignore next */
    if (
      sddZip &&
      !nextProps.sddMarketData.isFetching &&
      !nextProps.sddMarketData.error &&
      !this.state.sddZipError
    ) {
      /* istanbul ignore next */
      this.setState({ sddZip }, () => {
        if (this.props.isBopisFilter) {
          this.props.OnZipChange(sddZip);
        }
      });
    }
    if (nextProps.clientZip && nextProps.clientZip !== this.props.clientZip) {
      this.setState({ bopisZip: nextProps.clientZip });
    }
    if (
      this.props.fetchingSddRadioButtonStatus !==
        fetchingSddRadioButtonStatus &&
      sddFlag &&
      (!sddError || !sddError.length) &&
      this.state.searchAgainClicked &&
      isSddCheckbox &&
      sameDayCount &&
      !fetchingSddRadioButtonStatus &&
      this.state.bopisZip.length === 5
    ) {
      toggleModal();
      this.setState({ searchAgainClicked: false });
      this.props.OnZipChange(this.state.bopisZip);
    }
  }

  getSDDClasses(isSDDLandingPage) {
    let confirmZipBtnClass = classnames(styles.confirmZip);
    let deliveryTextClass = classnames(styles.deliveryText, 'mb3 mt0');
    let zipcodeAvailClass = classnames(styles.deliveryText, 'sm-mb3 mb25');
    let startShoppingBtnClass = classnames('large-6 mr1 sm-mb2');
    let deliverySuccessClass = classnames(styles.deliveryText, 'mb1');
    let sddNoteClass = classnames(styles.sddNote, 'sm-mt3 mt25 mb0');

    if (isSDDLandingPage) {
      confirmZipBtnClass = '';
      deliveryTextClass = classnames(styles.sddHeading, 'mb2 mt0');
      zipcodeAvailClass = classnames(styles.deliveryText, 'mb2');
      startShoppingBtnClass = classnames('large-8 mr1 sm-mb2');
      deliverySuccessClass = classnames(styles.sddHeading, 'mb1');
      sddNoteClass = classnames(styles.sddNote, 'mt3');
    }

    return {
      confirmZipBtnClass,
      deliveryTextClass,
      zipcodeAvailClass,
      startShoppingBtnClass,
      deliverySuccessClass,
      sddNoteClass,
    };
  }

  // eslint-disable-next-line complexity
  async handleSubmit(obj) {
    const { isSddCheckbox, toggleModal } = this.props;
    const sddZipinCookie = getCookie('SDDCZ');
    if (sddZipinCookie === this.state.bopisZip && isSddCheckbox) {
      toggleModal();
      return;
    }
    if (this.props.isBopisFilter) {
      this.props.setError(false);
      const el = document.getElementById('sddZip');
      el.blur();
    }
    const { sddZip } = this.props.formWrapperData;
    const hasErrors = Object.keys(obj).length;
    const inputValue = this.isBedBathCanada
      ? sddZip.value &&
        typeof sddZip.value === 'string' &&
        sddZip.value.split(' ')[0]
      : sddZip.value;
    this.setState({
      submitClicked: false,
    });

    if (
      !hasErrors &&
      !this.props.isBopisFilter &&
      this.state.bopisZip.length === 5
    ) {
      this.setState({ submitClicked: true });
      if (typeof this.props.fetchSddButtonStatus !== 'undefined') {
        this.props.fetchSddButtonStatus(true);
      }
      this.props.sddMarketEligibility(inputValue);
    }
    if (!hasErrors && this.props.isBopisFilter) {
      this.setState({ submitClicked: true, marketDataError: [] });
      if (typeof this.props.fetchSddButtonStatus !== 'undefined') {
        this.props.fetchSddButtonStatus(true);
      }
      const response = await getSddMarketEligibilityAxios(inputValue);
      const data = getOr(null, 'data.data', response);
      const errors = getOr([], 'data.errorMessages', response);
      if (data) {
        const { sddFlag = false, promoAttId } = data;
        if (this.state.bopisZip)
          updateMarketCookies(this.state.bopisZip, sddFlag, promoAttId);
        this.props.sddMarketEligibilitySuccess(data);
      } else if (errors.length > 0) {
        this.setState({ marketDataError: errors });
      }
    }
  }

  handleZipOnChange() {
    this.setState({ submitClicked: true });
    this.props.sddMarketEligibility(this.state.bopisZip);
  }

  searchAgain() {
    this.setState({
      submitClicked: false,
      searchAgainClicked: true,
    });
  }

  sddError() {
    const { marketData } = this.props.sddMarketData;
    const error = this.state.marketDataError;
    const errorCode =
      pathOr('', '[0].code', error) ||
      pathOr('', 'body.response.data.errorMessages[0].code', error);
    return (
      errorCode === SDD_ERR_CODE_ZIP_NOT_FOUND ||
      (marketData && (!marketData.sddFlag || marketData.atgResponse === null))
    );
  }

  triggerTealium() {
    if (this.props.handleTealiumEvent) {
      const tealiumConstants = {
        pagename_breadcrumb: PAGE_NAME_BREADCRUMEB,
        linkinfo_zipcode: LINK_INFO_ZIP_CODE,
        page_type: PAGE_TYPE,
        page_name: PAGE_NAME,
      };
      if (this.props.handleTealiumEvent) {
        this.props.handleTealiumEvent(
          'same_day_confirm_zip',
          tealiumConstants,
          'Same_day_confirm_zip'
        );
      }
    }
  }

  formError() {
    const { formWrapperData } = this.props;
    if (
      this.state.submitClicked &&
      formWrapperData &&
      !formWrapperData.sddZip.sddZipError
    ) {
      return true;
    }
    return false;
  }

  handleChange(event) {
    const value = event.target.value;
    if (value.length <= 5 || this.isBedBathCanada)
      this.setState({ bopisZip: value });
  }

  deliveryOptionsSkeleton = () => {
    return (
      <SkeletonWrapper width={130} height={12}>
        <rect width="100" height="10" y="2" ry="2" />
      </SkeletonWrapper>
    );
  };

  renderZipForm(labels, marketData, isSDDLandingPage) {
    const { formWrapperData } = this.props;
    const SDDStyle = this.getSDDClasses(isSDDLandingPage);

    return (
      <GridX className={styles.formWrapper}>
        <Cell className={classnames('large-12 mx-auto small-12')}>
          <Paragraph className={SDDStyle.deliveryTextClass}>
            {marketData && marketData.atgResponse !== null
              ? LabelsUtil.getLabel(labels, 'orderByText', [
                  marketData.displayCutOffTime,
                  marketData.displayGetByTime,
                  marketData.minShipFee,
                ])
              : LabelsUtil.getLabel(labels, 'orderByDefault')}
          </Paragraph>
          <Paragraph className={SDDStyle.zipcodeAvailClass}>
            {LabelsUtil.getLabel(labels, 'checkZipAvailability')}
          </Paragraph>
          <FormWrapper
            noValidate
            onSubmit={this.handleSubmit}
            id="sddModal"
            name="sddModal"
            identifier="sddModal"
            styles={styles}
            formWrapperData={formWrapperData}
          >
            <FormInput
              type="text"
              id="sddZip"
              name="sddZip"
              value={
                isUndefined(formWrapperData)
                  ? this.state.sddZip
                  : formWrapperData.sddZip.value
              }
              isRequired
              sddZipError={
                formWrapperData && formWrapperData.sddZip.sddZipError
              }
              label={this.isBedBathCanada ? 'Postal Code' : 'Zip Code'}
              labelPosition="append"
              autoComplete="off"
              // Need to see what aria label to be added
              aria-label={LabelsUtil.getLabel(labels, 'confirmZip')}
              identifier="sddModal"
              validation={this.isBedBathCanada ? 'postalCodeCA' : 'zip'}
              pattern={this.isBedBathCanada ? '[a-zA-Z0-9-]*' : 'd*'}
              maxLength={this.isBedBathCanada ? '10' : '6'}
            />
            <div className="mb2">
              {this.formError() &&
                this.sddError() &&
                !this.props.sddMarketData.isFetching && (
                  <ErrorMessage className="mt1">
                    {LabelsUtil.getLabel(labels, 'sddNotAvailable')}
                  </ErrorMessage>
                )}
              {this.formError() &&
              this.state.marketDataError &&
              !this.sddError() &&
              !this.state.sddZipError ? (
                <ErrorMessage className="mt1">
                  {LabelsUtil.getLabel(labels, 'apiError')}
                </ErrorMessage>
              ) : null}
            </div>
            <div className="sm-mt3 mt25">
              <Button
                theme="primary"
                type="submit"
                variation="fullWidth"
                onClick={() => this.triggerTealium()}
                className={SDDStyle.confirmZipBtnClass}
              >
                {LabelsUtil.getLabel(labels, 'confirmZip')}
              </Button>
            </div>
          </FormWrapper>
        </Cell>
      </GridX>
    );
  }

  renderCongratulationsMessage(labels, isSDDLandingPage, pageName) {
    const SDDStyle = this.getSDDClasses(isSDDLandingPage);
    if (pageName === 'SDDPage') {
      setCookie('sddModal', true, {
        path: COOKIE_PATH,
      });
    }
    return (
      <div>
        <Paragraph className={SDDStyle.deliverySuccessClass}>
          {LabelsUtil.getLabel(labels, 'sddAvailable', [this.state.sddZip])}
        </Paragraph>
        <Paragraph className={classnames(styles.deliveryText, 'mb3 mt0')}>
          {LabelsUtil.getLabel(labels, 'goShopping')}
        </Paragraph>
        <GridX className="grid-margin-x">
          <Cell className={SDDStyle.startShoppingBtnClass}>
            {isSDDLandingPage !== true ? (
              <Button
                theme="primary"
                variation="fullWidth"
                onClick={this.props.closeModal}
              >
                {LabelsUtil.getLabel(labels, 'startShopping')}
              </Button>
            ) : (
              <Button theme="primary" variation="fullWidth" href="/">
                {LabelsUtil.getLabel(labels, 'startShopping')}
              </Button>
            )}
          </Cell>
          {isSDDLandingPage !== true ? (
            <Cell className="large-6">
              <Button
                theme="secondary"
                variation="fullWidth"
                onClick={this.searchAgain}
              >
                {LabelsUtil.getLabel(labels, 'searchAgain')}
              </Button>
            </Cell>
          ) : null}
        </GridX>
        {isSDDLandingPage ? (
          <GridX className={classnames('grid-margin-x mt3')}>
            <Cell className="sm-center">
              <PrimaryLink
                href="#"
                type="bold"
                className={classnames(styles.searchAgain, 'mb2')}
                iconProps={{ type: 'arrow', className: 'ml3' }}
                isIconAfterContent
                onClick={this.searchAgain}
              >
                {LabelsUtil.getLabel(labels, 'searchAgain')}
              </PrimaryLink>
            </Cell>
          </GridX>
        ) : null}
      </div>
    );
  }

  renderBopusFilter(labels) {
    const { formWrapperData, eddFacetCount } = this.props;
    const formError = this.formError();
    const sddError = this.sddError();
    return (
      <GridX className={styles.formWrapper}>
        <Cell className={classnames('large-12 mx-auto small-12')}>
          <FormWrapper
            noValidate
            onSubmit={this.handleSubmit}
            id="sddModal"
            name="sddModal"
            identifier="sddModal"
            styles={styles}
            formWrapperData={formWrapperData}
          >
            <div className={styles.inputBtnGroup}>
              <FormInput
                type="text"
                id="sddZip"
                name="sddZip"
                value={this.state.bopisZip}
                onChange={this.handleChange}
                isRequired
                sddZipError={
                  formWrapperData && formWrapperData.sddZip.sddZipError
                }
                label={this.isBedBathCanada ? 'Postal Code' : 'Zip Code'}
                labelPosition="append"
                autoComplete="off"
                // Need to see what aria label to be added
                aria-label={LabelsUtil.getLabel(labels, 'confirmZip')}
                identifier="sddModal"
                validation={this.isBedBathCanada ? 'postalCodeCA' : 'zip'}
                pattern={this.isBedBathCanada ? '[a-zA-Z0-9-]*' : 'd*'}
                maxLength={this.isBedBathCanada ? '10' : '6'}
              />
              <Button
                theme="secondary"
                type="submit"
                variation="fullWidth"
                onClick={() => {
                  this.triggerTealium();
                  this.searchAgain();
                }}
                className={'inline-btn'}
              >
                Submit
              </Button>
            </div>
            <div id={'sddErrorMsg'}>
              {this.props.sddMarketData.isFetching &&
                this.deliveryOptionsSkeleton()}
              {eddFacetCount &&
                eddFacetCount.oneDay === 0 &&
                eddFacetCount.twoDay === 0 &&
                sddError &&
                !this.props.sddMarketData.isFetching && (
                  <ErrorMessage className="mt1">
                    Try another zipcode
                  </ErrorMessage>
                )}
              {formError && sddError && !this.state.sddZipError ? (
                <ErrorMessage className="mt1">
                  <BopisAlert
                    label={LabelsUtil.getLabel(labels, 'apiError')}
                    isAvailable={false}
                    status={'ghost'}
                    isSdd
                    hasStatusIcon={false}
                  />
                </ErrorMessage>
              ) : null}
            </div>
          </FormWrapper>
        </Cell>
      </GridX>
    );
  }

  render() {
    const { marketData } = this.props.sddMarketData;
    const {
      labels,
      isSDDLandingPage,
      clearSDDError,
      formWrapperData,
      pageName,
      isBopisFilter,
    } = this.props;
    const displayCongratulationMsg =
      !this.props.sddMarketData.isFetching &&
      this.state.submitClicked &&
      !this.state.marketDataError &&
      marketData &&
      marketData.sddFlag;

    const displayNoteText =
      (!displayCongratulationMsg && isSDDLandingPage) || !isSDDLandingPage;

    const SDDStyle = this.getSDDClasses(isSDDLandingPage);

    if (
      formWrapperData &&
      formWrapperData.sddZip.sddZipError &&
      clearSDDError
    ) {
      clearSDDError();
    }

    if (isBopisFilter) {
      return <ErrorBoundary>{this.renderBopusFilter(labels)}</ErrorBoundary>;
    }

    return (
      <ErrorBoundary>
        {isSDDLandingPage !== true ? (
          <Heading level={1} className={classnames(styles.sddHeading, 'mb15')}>
            {LabelsUtil.getLabel(labels, 'sddHeading')}
          </Heading>
        ) : null}
        <div className="mb2">
          {displayCongratulationMsg
            ? this.renderCongratulationsMessage(
                this.props.labels,
                isSDDLandingPage,
                pageName
              )
            : this.renderZipForm(labels, marketData, isSDDLandingPage)}
        </div>
        {displayNoteText ? (
          <Paragraph className={SDDStyle.sddNoteClass}>
            {LabelsUtil.getLabel(labels, 'sddNote')}
          </Paragraph>
        ) : null}
      </ErrorBoundary>
    );
  }
}

SDD.propTypes = propTypes;

export default SDD;
