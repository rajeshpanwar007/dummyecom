import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import classedWrapper from '@bbb-app/hoc/classedWrapper';
import wrapper from '@bbb-app/hoc/wrapper';
export const ParagraphComponent = props => <p {...props} />;

const WrappedMessageWithClassName = classedWrapper({
  wrapperName: 'Message',
  wrapperClassName: 'callout small',
});

const defaultProps = {
  className: null,
  type: 'alert',
};

const propTypes = {
  className: PropTypes.any,
  type: PropTypes.string,
};

export const Message = props => {
  const { className, type, ...others } = props;

  const wrappedProps = {
    ...others,
    Component: ParagraphComponent,
    className: classnames(type, className),
  };

  return wrapper(WrappedMessageWithClassName, wrappedProps);
};

Message.propTypes = propTypes;
Message.defaultProps = defaultProps;

export default Message;
