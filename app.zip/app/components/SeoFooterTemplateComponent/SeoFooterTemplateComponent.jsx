/**
* @Description
    This file contains the component for the Seo Footer Template component

    @return {Object} - Returns a Seo Footer Template component html
*
*/
import React from 'react';
import { pathOr } from 'lodash/fp';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import Heading from '@bbb-app/core-ui/heading';
import { decodeHtmlEntities } from '@bbb-app/utils/common';
import Paragraph from '@bbb-app/core-ui/paragraph';
import ShowMore from '@bbb-app/core-ui/show-more/ShowMore';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import Image from '@bbb-app/core-ui/image';
import styles from './SeoFooterTemplateComponent.css';

const propTypes = {
  componentData: PropTypes.object,
  labels: PropTypes.object,
  isLazyLoad: PropTypes.bool,
  seoTitle: PropTypes.string,
  filterRatings: PropTypes.object,
  pageName: PropTypes.string,
};

const renderTitle = title => (
  <Heading level={2} className={classnames('center mb2', styles.seoTitle)}>
    {title}
  </Heading>
);

const renderText = text => (
  <div
    className={classnames(styles.seoHeaderText, 'center mt0 mb15')}
    // eslint-disable-next-line react/no-danger
    dangerouslySetInnerHTML={{
      __html: text,
    }}
  />
);

export const SeoFooterTemplateComponent = ({
  componentData,
  labels,
  seoTitle,
  isLazyLoad,
  filterRatings,
  pageName,
}) => {
  const selectedRatingFilters = pathOr('', 'RATINGS', filterRatings);
  const ratingsApplied =
    selectedRatingFilters &&
    (selectedRatingFilters.includes('4-0') &&
      selectedRatingFilters.includes('5-0'));
  const title = decodeHtmlEntities(seoTitle) || componentData.headerTitle;
  let topRatedTitle = ratingsApplied ? `Top Rated ${title}` : title;
  const storeIndex = topRatedTitle && topRatedTitle.indexOf(' at ');
  if (pageName === 'PLP' && storeIndex > -1) {
    topRatedTitle =
      topRatedTitle && topRatedTitle.substring(0, storeIndex).trim();
  }
  const DangerousText = dangerousHTML(DangerousText);
  return (
    <div className={classnames(styles.seoFooterTemplateWrapper)}>
      <div>
        <ShowMore
          containerHeight={300}
          buttonProps={{
            isIconAfterContent: true,
            theme: 'ghostPrimary',
            variation: 'noPadding',
          }}
          labels={labels && labels.categoryCopy}
        >
          {componentData.headerTitle && renderTitle(topRatedTitle)}
          {componentData.headerText && renderText(componentData.headerText)}
          {componentData.basicInfo &&
            componentData.basicInfo.map((item, index) => (
              <div
                className={classnames(
                  'flex',
                  'mb3',
                  styles.seoBasicInfoWrapper
                )}
                key={index}
              >
                <Image
                  src={item.basicinfoImgurl}
                  className={classnames(
                    styles.thumbnail,
                    'lg-pr2',
                    'md-pr2',
                    'sm-pr2'
                  )}
                  reactImage={false}
                  lazyLoad={isLazyLoad}
                />
                <Paragraph className={classnames(styles.seoBasicInfoText)}>
                  <DangerousText>{item.basicInfoText}</DangerousText>
                </Paragraph>
              </div>
            ))}
          <div className={classnames(styles.seoFooterText)}>
            {componentData.footerTitle &&
              renderTitle(componentData.footerTitle)}
            {componentData.footerText && renderText(componentData.footerText)}
          </div>
        </ShowMore>
      </div>
    </div>
  );
};

SeoFooterTemplateComponent.propTypes = propTypes;

export default SeoFooterTemplateComponent;
