export { default } from './SeoFooterTemplateComponent';
