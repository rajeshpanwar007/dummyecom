import React from 'react';
import PropTypes from 'prop-types';
const ClientMetrics = ({ clientMetrics }) => {
  return (
    <ul>
      {clientMetrics.gbi_view_product_rate !== undefined &&
        clientMetrics.gbi_view_product_rate !== null && (
          <li>
            <span className="bold">Product View Rate: </span>
            {clientMetrics.gbi_view_product_rate}
          </li>
        )}
      {clientMetrics.gbi_add_to_cart_rate !== undefined &&
        clientMetrics.gbi_add_to_cart_rate !== null && (
          <li>
            <span className="bold">Add to Cart Rate: </span>
            {clientMetrics.gbi_add_to_cart_rate}
          </li>
        )}
      {clientMetrics.gbi_add_to_reg_rate !== undefined &&
        clientMetrics.gbi_add_to_reg_rate !== null && (
          <li>
            <span className="bold">Add to Registry Rate: </span>
            {clientMetrics.gbi_add_to_reg_rate}
          </li>
        )}
      {clientMetrics.gbi_order_rate !== undefined &&
        clientMetrics.gbi_order_rate !== null && (
          <li>
            <span className="bold">Conversion Rate: </span>
            {clientMetrics.gbi_order_rate}
          </li>
        )}
    </ul>
  );
};

ClientMetrics.propTypes = {
  clientMetrics: PropTypes.object,
};

export default ClientMetrics;
