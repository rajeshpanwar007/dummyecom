export const API_VERSION = 5.4;
export const PASS_KEY = 'cakNFkt6u07atVEBzYdpqWxrF9LG5UNjTnKVyIT0RG8tQ';
export const REVIEWS_COUNT_ON_PDP = 5;
export const REVIEWS_COUNT_ON_MODAL = 10;
export const QNA_COUNT_ON_PDP = 5;
export const QNA_COUNT_ON_MODAL = 10;
export const QNA_CAMPAIGNID = 'BV_QUESTION_DISPLAY';
export const locale = 'en_US';
export const localeCA = 'en_CA';
export const reviewCharCount = 255;
export const commonParams = {
  apiversion: API_VERSION,
};

export const feedbackParams = {
  feedbackType: 'helpfulness',
};
export const USER_ID = 'usertoken';
export const BV_ENDPOINTS = {
  submitReview: 'https://stg.api.bazaarvoice.com/data/submitreview.json',
  uploadPhoto: 'https://stg.api.bazaarvoice.com/data/uploadphoto.json',
  submitQuestion: 'https://stg.api.bazaarvoice.com/data/submitquestion.json',
  submitAnswer: 'https://stg.api.bazaarvoice.com/data/submitanswer.json',
  fetchReviews: '/api/apps/conversations/query/reviews',
  fetchQnA: '/api/apps/conversations/query/qa',
  submitFeedback: 'https://stg.api.bazaarvoice.com/data/submitfeedback.json',
  getProductReviewToken: '/apis/v1.0/bazaarvoice/productReviewToken',
  fetchReviewsOS: '/apis/services/conversations/review',
  fetchQnAOS: '/apis/services/conversations/qa',
  getProductBVReviewToken: '/apis/v1.0/bazaarvoice/productBVReviewToken',
  getPurchaseStatus:
    '/apis/stateful/v1.0/customers/*/productreviews/getPurchaseStatus',
};

export const ERROR_CODE_MAPPING = {
  ERROR_FORM_IMAGE_TOO_LARGE: 'File size exceeds 5MB limit.',
  ERROR_FORM_IMAGE_HEIGHT_TOO_SMALL:
    'It must be at least 100 pixels tall, but was 93 pixels.',
  ERROR_FORM_IMAGE_WIDTH_TOO_SMALL:
    'It must be at least 100 pixels wide, but was 46 pixels.',
  ERROR_FORM_IMAGE_PARSE:
    'Please ensure that the image is a valid BMP, PNG, GIF or JPEG file.',
};

export const filtersLabels = {
  gridFilters: {
    allFiltersTitle: 'Filter',
    viewResultsCountBtn: 'View Results',
    viewResultsBtn: 'View Results',
  },
};

/* Mindful changing any value will impact read reviews sorting functionality */
export const reviewsSortOptions = [
  {
    key: 'Most Recent',
    label: 'Most Recent',
    props: {
      value: 'Most Recent',
    },
    sortValue: 'SubmissionTime desc',
  },
  {
    key: 'Most Helpful',
    label: 'Most Helpful',
    props: {
      value: 'Most Helpful',
    },
    sortValue: 'HelpfulVoteCount desc',
  },
  {
    key: 'Highest to Lowest',
    label: 'Highest to Lowest',
    props: {
      value: 'Highest to Lowest',
    },
    sortValue: 'Rating desc',
  },
  {
    key: 'Lowest to Highest',
    label: 'Lowest to Highest',
    props: {
      value: 'Lowest to Highest',
    },
    sortValue: 'Rating asc',
  },
  {
    key: 'Most Relevant',
    label: 'Most Relevant',
    props: {
      value: 'Most Relevant',
    },
    sortValue: 'HelpfulVoteCount desc,Rating desc,SubmissionTime desc',
  },
];

/* Mindful changing any value will impact read QNA sorting functionality */
export const qnaSortOptions = [
  {
    key: 'Most Recent',
    label: 'Most Recent',
    props: {
      value: 'Most Recent',
    },
    sortValue: 'SubmissionTime desc',
  },
  {
    key: 'MostHelpfulAnswer',
    label: 'Most Helpful Answers',
    props: {
      value: 'MostHelpfulAnswer',
    },
    sortValue: '1',
  },
  {
    key: 'Least Recent',
    label: 'Least Recent',
    props: {
      value: 'Least Recent',
    },
    sortValue: 'SubmissionTime asc',
  },
  {
    key: 'AnswerNeeded',
    label: 'Answers Needed',
    props: {
      value: 'AnswerNeeded',
    },
    sortValue: '1',
  },
];

export const backToTop = {
  title: 'Back to top',
  ariaLabel: 'Click to scroll at top',
  'navigate back': 'navigatetoback',
  TOP: 'TOP',
  referredContent: [
    {
      id: '7728',
      key: 'Redeem_In_Store_Template',
    },
    {
      id: '5534',
      key: 'txt_coupon_cashier_instruction',
    },
    {
      id: '4868',
      key: 'myOffers',
    },
  ],
};
