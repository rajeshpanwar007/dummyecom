import React from 'react';
import PropTypes from 'prop-types';

const defaultProps = {
  name: '',
  children: {},
  fields: [],
};
const childContextTypes = {
  fieldState: PropTypes.object,
};
const propTypes = {
  // name: PropTypes.string,
  children: PropTypes.object,
  fields: PropTypes.array,
};
class Form extends React.PureComponent {
  constructor(props) {
    super(props);
    this.componentDidMount = this.componentDidMount.bind(this);
  }

  getChildContext() {
    return { fieldState: this.state };
  }
  componentDidMount() {
    const fields = this.props.fields;
    const fieldState = {};
    for (let i = 0; i < fields.length; i += 1) {
      const field = fields[i];
      const fieldError = `${field}Error`;
      fieldState[field] = '';
      fieldState[fieldError] = '';
    }
  }
  render() {
    return React.Children.only(this.props.children);
  }
}
Form.propTypes = propTypes;
Form.childContextTypes = childContextTypes;
Form.defaultProps = defaultProps;
export default Form;
