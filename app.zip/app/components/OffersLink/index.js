export { default } from './OffersLink.jsx';
