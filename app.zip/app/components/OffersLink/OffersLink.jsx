import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ConditionalLink from '@bbb-app/conditional-link/ConditionalLink';
import CountIndicator from '@bbb-app/core-ui/count-indicator';
import '@bbb-app/assets/icons/inline/myOffers.svg';

const OffersLink = ({
  text,
  linkProps,
  isLoggedIn,
  offersCount,
  className = '',
}) => {
  return (
    <ConditionalLink
      iconProps={{
        type: 'myOffers',
        attr: {
          className: classnames('block', 'mx-auto mb1'),
        },
      }}
      type="noUnderline"
      data-loctor={`topNav-${linkProps.attr.href}`}
      {...linkProps.attr}
      className={className}
    >
      <span>{text}</span>
      {isLoggedIn && <CountIndicator count={offersCount} />}
    </ConditionalLink>
  );
};

OffersLink.propTypes = {
  text: PropTypes.string,
  linkProps: PropTypes.object,
  offersCount: PropTypes.number,
  isLoggedIn: PropTypes.bool,
  className: PropTypes.string,
};

export default OffersLink;
