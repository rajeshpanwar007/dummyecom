const lastCardLink = '/store/s/';
const lastItem = [
  {
    BRAND_ID: 1001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
  {
    BRAND_ID: 2001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
  {
    BRAND_ID: 3001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
  {
    BRAND_ID: 4001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
  {
    BRAND_ID: 5001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
  {
    BRAND_ID: 6001010109988,
    SCENE7_URL: false,
    IS_PRICE: null,
    DISPLAY_NAME: 'We have so much more to explore!',
    button: lastCardLink,
    button_text: 'Shop All',
    prodId: null,
  },
];

export default lastItem;
