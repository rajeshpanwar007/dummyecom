import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash/fp/isEmpty';
import pathOr from 'lodash/fp/pathOr';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import Cell from '@bbb-app/core-ui/cell';
import Heading from '@bbb-app/core-ui/heading';
import Accordion from '@bbb-app/core-ui/accordion/Accordion';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Icon from '@bbb-app/core-ui/icon';
import '@bbb-app/assets/icons/minus.svg';
import '@bbb-app/assets/icons/plus.svg';
import { PNH_LIST_OWNER_SHOP } from '@bbb-app/constants/route/route';
import { SLOT_CONTENT_KEY } from '@bbb-app/constants/appConstants';
import SlotMachineDetails from '../../containers/SlotMachineDetails/SlotMachineDetails';
import getReferredContentId from '../../utils/getReferredContentId';
import { MOB_INITIAL_LIMIT } from './constants';
import style from './SlotMachine.css';

const defaultProps = {};

const propTypes = {
  data: PropTypes.any,
  dispatchGetProdIds: PropTypes.func,
  dispatchGetProdIdsReferredContent: PropTypes.func,
  prodIds: PropTypes.any,
  regState: PropTypes.any,
  registryType: PropTypes.any,
  nodeId: PropTypes.any,
  savedRegistryState: PropTypes.string,
  savedRegistryType: PropTypes.string,
  extraData: PropTypes.object,
  pageIdentifier: PropTypes.string,
  children: PropTypes.any,
};

class SlotMachineWrapper extends React.PureComponent {
  constructor() {
    super();

    this.state = {
      showMoreText: 'Show Less',
      clicked: false,
    };

    this.updateExpand = this.updateExpand.bind(this);
    this.delayProcess = undefined;
  }

  componentDidMount() {
    const {
      dispatchGetProdIds,
      dispatchGetProdIdsReferredContent,
      nodeId,
      prodIds,
      regState,
      registryType,
      extraData,
      pageIdentifier,
    } = this.props;
    if (pageIdentifier === PNH_LIST_OWNER_SHOP && extraData) {
      // we need to make a call using referral content id
      const referredContent = pathOr([], 'referredContent', extraData);
      if (referredContent.length > 0) {
        const contentId = getReferredContentId(
          referredContent,
          SLOT_CONTENT_KEY
        );
        if (contentId) dispatchGetProdIdsReferredContent(contentId);
      }
    } else if (
      // only initiate call if registry type changes or the the data is empty
      this.isRegistryTypeDifferent() ||
      isEmpty(prodIds)
    ) {
      /* istanbul ignore next */
      dispatchGetProdIds(regState, registryType, nodeId);
    }
  }

  componentWillUnmount() {
    clearTimeout(this.delayProcess);
  }

  /**
   * to check if the registry type or state are different
   * so that a new set of data will be needed,
   * not picking registryId as the state-type combo could be similar for registries
   */
  isRegistryTypeDifferent() {
    const {
      regState,
      registryType,
      savedRegistryState,
      savedRegistryType,
    } = this.props;

    return (
      registryType !== savedRegistryType || regState !== savedRegistryState
    );
  }

  updateExpand() {
    if (this.delayProcess !== undefined) {
      clearTimeout(this.delayProcess);
    }
    /* istanbul ignore next */
    if (this.state.showMoreText === 'Show Less') {
      /* istanbul ignore next */
      this.delayProcess = setTimeoutCustom(() => {
        /* istanbul ignore next */
        this.setState({
          showMoreText: 'Show More',
        });
      }, 200);
    } else {
      /* istanbul ignore next */
      this.delayProcess = setTimeoutCustom(() => {
        /* istanbul ignore next */
        this.setState({
          showMoreText: 'Show Less',
        });
      }, 200);
    }
  }

  renderSlotMachineItem(slotItem, idx) {
    /**
     * Commented out below as it is causing RegistryHomeTab to render as blank for all the registries which are in 'post' state.
     */
    // if (registryState === 'post') return <div />;

    const categoryName = pathOr('', 'field_featured_products.[0]', slotItem);
    const sanitizeCategoryName = categoryName
      .toLowerCase()
      .replace(/\s+/g, '-');

    return (
      <SlotMachineDetails
        key={`${idx}-${sanitizeCategoryName}`}
        select={'baby'}
        slot={idx}
        registryData={this.props.data}
        categoryKey={`${idx}-${sanitizeCategoryName}`}
        categoryName={categoryName}
        categoryProductIds={slotItem.field_secondary_products}
        sanitizeCategoryName={sanitizeCategoryName}
        isRegistryTypeDifferent={this.isRegistryTypeDifferent()}
        {...this.props}
      />
    );
  }

  renderTitle() {
    /**
     * Commented out below as it is causing RegistryHomeTab to render as blank for all the registries which are in 'post' state.
     */
    // if (registryState === 'post') {
    //   return <div />;
    // }
    const titleLegendLbl = pathOr(null, 'extraData.titleLegendLbl', this.props);
    const dataLocators = pathOr({}, 'extraData.dataLocator', this.props);
    const title = pathOr(
      'And Now, The Fun Stuff',
      'extraData.title',
      this.props
    );
    // will call when legend is available and this piece of code is used for Pack and hold items
    if (titleLegendLbl) {
      return (
        <Cell>
          <Heading
            level={2}
            className={classnames('slot-container-title-1 sm-mb2')}
            data-locator={dataLocators.title}
            styleVariation="h4-sans"
          >
            {title}
          </Heading>
          <Paragraph
            theme="largeLight"
            className={classnames('mt0 pb2 center sm-mb1')}
            data-locator={dataLocators.legend}
          >
            {titleLegendLbl}
          </Paragraph>
        </Cell>
      );
    }
    return <h1 className="cell large-12 slot-container-title H1">{title}</h1>;
  }

  render() {
    if (!this.props.prodIds) return <div />;

    const prodIds = pathOr([], 'prodIds.components', this.props);
    const { children } = this.props;
    return (
      <Fragment>
        <div className="grid-x grid-margin-x slot-container slot-dsk slotmobile">
          {this.renderTitle()}
          {children && (
            <Cell className={classnames(style.tipsModulePanel)}>
              {children}
            </Cell>
          )}
          {prodIds.slice(0, MOB_INITIAL_LIMIT).map((slotItem, idx) => {
            return this.renderSlotMachineItem(slotItem, idx);
          })}
        </div>
        <Accordion
          /* istanbul ignore next */
          onChange={() => this.updateExpand()}
          className={'small-10 large-12 medium-12 inline-styling'}
          expandAll
          accordion={false}
          showExpandCollapseIcon
          expandCollapseIconPos="right"
          expandCollapseIcons={{
            expand: <Icon type="plus" width="12px" height="12px" />,
            collapse: <Icon type="minus" width="12px" height="12px" />,
          }}
          data={[
            {
              title: (
                <div className={'show-more-slots'}>
                  {this.state.showMoreText}
                </div>
              ),
              body: (
                <div className="grid-x grid-margin-x slot-container slot-dsk slotmobile">
                  {prodIds.slice(MOB_INITIAL_LIMIT).map((slotItem, idx) => {
                    // start index after the initial limit is reached
                    const index = idx + MOB_INITIAL_LIMIT;
                    return this.renderSlotMachineItem(slotItem, index);
                  })}
                </div>
              ),
            },
          ]}
        />
      </Fragment>
    );
  }
}

SlotMachineWrapper.propTypes = propTypes;
SlotMachineWrapper.defaultProps = defaultProps;

export default SlotMachineWrapper;
