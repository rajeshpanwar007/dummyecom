const registryTypeData = {
  baby: [
    {
      title: 'Items Loved Most',
      id: 0,
      featuredProducts: [
        17110357,
        46992574,
        42324256,
        15150270,
        42757009,
        42789857,
      ],
    },
    {
      title: 'Bathtime Essentials',
      id: 1,
      featuredProducts: [
        44983758,
        43451661,
        60141583,
        44660468,
        42349990,
        20437596,
        45876011,
      ],
    },
    {
      title: 'Nursery Trends',
      id: 2,
      featuredProducts: [43478569, 60058737, 60058775],
    },
    {
      title: 'Newborn Must-Haves',
      id: 3,
      featuredProducts: [15909129, 61167544, 18223120, 61203228, 43200726],
    },
    {
      title: 'Top Toys and Activities',
      id: 4,
      featuredProducts: [
        60430359,
        15002212,
        15053917,
        43033560,
        15122129,
        15948205,
        45838668,
        18724081,
        44321666,
        43136162,
        60111968,
        61419414,
      ],
    },
    {
      title: 'Most Comfy',
      id: 5,
      featuredProducts: [
        60683717,
        46921802,
        61488250,
        40247670,
        17173928,
        18738422,
        61786912,
        45317033,
      ],
    },
    {
      featuredProducts: [
        1017392190,
        1041831502,
        1045630903,
        1045042942,
        1013345430,
        1017392190,
        1041831502,
        1045630903,
        1045042942,
        1013345430,
      ],
    },
  ],
  birthday: [],
  other: [],
};

export default registryTypeData;
