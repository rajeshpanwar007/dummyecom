import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { pathOr } from 'lodash/fp';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Card from '@bbb-app/core-ui/card';
import { getCurrentSiteIdAtBrowser } from '@bbb-app/utils/common';
import Button from '@bbb-app/core-ui/button';
import ImageSrcSet from '@bbb-app/core-ui/image-src-set';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import { PRODUCT_IMAGE_PLACEHOLDER } from '@bbb-app/constants/appConstants';
import '@bbb-app/assets/icons/check.svg';
import { PNH_LIST_OWNER_SHOP } from '@bbb-app/constants/route/route';

import AddToRegistry from '../../containers/AddToRegistry/SlotAddToRegistry';
import AddToPNH from '../../containers/AddToPNH/AddToPNH.async';
import { HYPERLINK } from '../AddToRegistry/constants';
import {
  ALREADY_ADDED_PNH_ITEM,
  ADDED_REGISTRY_ITEM,
  ALREADY_ADDED_REGISTRY_ITEM,
  ADD_TO_REG_BUTTON_CLASS,
  PDP,
  COLLEGE_URL_PARAM,
} from './constants';

import style from './SlotMachine.css';

const defaultProps = {
  name: null,
  price: null,
  button: null,
  buttonText: null,
  image: null,
  addedToReg: false,
  itemIndex: 0,
  currentSite: getCurrentSiteIdAtBrowser(),
  intlRestricted: false,
};

export const IMAGE_SRC = {
  preset: 'content',
  width: '200',
  height: '200',
};

export const SRC_SET = [
  {
    preset: 'content',
    width: '200',
    height: '200',
    sourceWidth: '1x',
  },
  {
    preset: 'content',
    width: '400',
    height: '400',
    sourceWidth: '2x',
  },
];

const lazyLoadOptions = {
  offset: 200,
  placeholder: PRODUCT_IMAGE_PLACEHOLDER,
  alt: 'image not found',
};

const propTypes = {
  name: PropTypes.string,
  buttonProp: PropTypes.any,
  price: PropTypes.any,
  button: PropTypes.any,
  buttonText: PropTypes.string,
  image: PropTypes.any,
  addedToReg: PropTypes.bool,
  registryData: PropTypes.any,
  prodId: PropTypes.any,
  skuId: PropTypes.any,
  modalImage: PropTypes.any,
  itemIndex: PropTypes.any,
  containerTitle: PropTypes.string,
  currentSite: PropTypes.any,
  categorySearch: PropTypes.any,
  intlRestricted: PropTypes.bool,
  cardHeadingTitle: PropTypes.string,
  pageIdentifier: PropTypes.string,
  addedItemLbl: PropTypes.string,
  itemStores: PropTypes.array,
  categoryUrlMappedData: PropTypes.object,
  pickUpStoreId: PropTypes.string,
  pdpURL: PropTypes.string,
};

export const SlotMachineCard = props => {
  const {
    name,
    buttonProp,
    image,
    button,
    price,
    addedToReg,
    buttonText,
    registryData,
    prodId,
    skuId,
    modalImage,
    itemIndex,
    containerTitle,
    currentSite,
    categorySearch,
    intlRestricted,
    cardHeadingTitle,
    pageIdentifier,
    itemStores,
    addedItemLbl,
    categoryUrlMappedData,
    pickUpStoreId,
    pdpURL,
  } = props;
  const funStuffTealiumParams = {
    fromFunStuff: true,
    containerTitle,
    cardHeadingTitle,
  };

  const registryId = pathOr(
    '',
    'registryResVO.registryVO.registryId',
    registryData
  );

  // it will fetch url from siteconfig api
  const getCategoryUrl = (categoryName, urlParam) => {
    if (categoryUrlMappedData) {
      return `${categoryUrlMappedData[
        categoryName
      ]}store-${pickUpStoreId}?${urlParam}`;
    }
    // fallback if categoryUrlMappedData not exists in sitconfig api
    return `${button}${categoryName}?ta=typeahead`;
  };

  const getRedirectUrl = () => {
    switch (pageIdentifier) {
      case PNH_LIST_OWNER_SHOP:
        return getCategoryUrl(categorySearch, COLLEGE_URL_PARAM);
      default:
        return `${button}${categorySearch}?ta=typeahead`;
    }
  };

  const getSubmittedButton = () => {
    switch (pageIdentifier) {
      case PNH_LIST_OWNER_SHOP:
        return (
          <Button
            variation="primary"
            theme="control"
            iconProps={{ type: 'check' }}
            isIconAfterContent={false}
            className={classnames(
              style.addToRegButton,
              ADD_TO_REG_BUTTON_CLASS,
              `overlayButton-${currentSite}`
            )}
            alt={LabelsUtil.replacePlaceholderValues(
              ALREADY_ADDED_PNH_ITEM,
              name
            )}
          >
            {addedItemLbl}
          </Button>
        );
      default:
        return (
          <Button
            variation="primary"
            theme="control"
            iconProps={{ type: 'check' }}
            isIconAfterContent={false}
            className={classnames(
              style.addToRegButton,
              ADD_TO_REG_BUTTON_CLASS,
              `overlayButton-${currentSite}`
            )}
            alt={LabelsUtil.replacePlaceholderValues(
              ALREADY_ADDED_REGISTRY_ITEM,
              name
            )}
          >
            {ADDED_REGISTRY_ITEM}
          </Button>
        );
    }
  };

  const addCTAComponent = () => {
    switch (pageIdentifier) {
      case PNH_LIST_OWNER_SHOP:
        return (
          <AddToPNH
            viewType={PDP}
            skuId={skuId.toString()}
            prodId={prodId ? prodId.toString() : ''}
            qty={parseInt(1, 10)}
            selectedProduct={{
              SKU_SCENE7_URL: modalImage,
              SKU_DISPLAY_NAME: name,
              STORES: itemStores,
            }}
            onSuccess={() => {
              buttonProp(skuId.toString());
            }}
            price={price}
            registryId={registryId}
          />
        );
      default:
        return (
          <AddToRegistry
            ltlFlag="false"
            registryId={registryId}
            skuId={skuId.toString()}
            prodId={prodId ? prodId.toString() : ''}
            addToRegistryState={{ data: '', error: '', productId: '' }}
            qty={parseInt(1, 10)}
            price={price}
            disabled={intlRestricted}
            disableAddToRegistryDropdown={intlRestricted}
            ctaType={HYPERLINK}
            funStuffTealiumParams={funStuffTealiumParams}
            selectedProduct={{
              SKU_SCENE7_URL: modalImage,
              SKU_DISPLAY_NAME: name,
            }}
            itemIndex={itemIndex + 1}
            buttonProps={{
              attr: {
                theme: intlRestricted ? 'deactivated' : 'control',
                variation: '',
                className: classnames(
                  `slotButton atrButtonDsh themeButton-${currentSite}`,
                  {
                    slotButtonDisabled: intlRestricted,
                  }
                ),
                'data-locator': 'regdash-addtoregistrybutton',
                onClick: buttonProp,
                alt: `Click to add ${name} to this registry`,
                disabled: intlRestricted,
              },
              children: 'Add To Registry',
              disabled: intlRestricted,
            }}
          />
        );
    }
  };

  /**
   * This function will generate PDP link
   * @param {HTMLElement} htmlNode HTML node which will wrap by pdp hyper link
   * @param {string} className Classname for HTML node element
   */
  const generatePDPLink = (htmlNode, className = null) => {
    let html = null;
    if (pdpURL !== 'empty') {
      html = (
        <PrimaryLink target="_blank" className={className} href={pdpURL}>
          {htmlNode}
        </PrimaryLink>
      );
    } else {
      html = className ? <div className={className}>{htmlNode}</div> : htmlNode;
    }
    return html;
  };

  return (
    <Card
      ariaAttributes={{
        role: 'region',
        'aria-describedby': 'Slot Machine',
      }}
      style={{ postition: 'relative' }}
      className={classnames(style.cardHeight, 'cardHeight')}
    >
      {generatePDPLink(
        <ImageSrcSet
          alt={name}
          className={'fullWidth slotProdImg'}
          srcSet={SRC_SET}
          imageSrc={IMAGE_SRC}
          scene7imageID={
            image
              ? `//s7d2.scene7.com/is/image/BedBathandBeyond/${image}`
              : `//s7d9.scene7.com/is/image/BedBathandBeyond/07%5F11%5F18%5Ffeo%5Fslot%5Fend%5Fcard?$other$`
          }
          lazyLoadOptions={lazyLoadOptions}
          lazyLoad
        />
      )}

      <div
        className={classnames(
          style.slotMeta,
          'slotMeta',
          !prodId && style.noProdIdSlotMeta
        )}
      >
        <p>
          {generatePDPLink(price, classnames(style.slotPrice, 'slotPrice'))}
        </p>
        <p>
          {generatePDPLink(
            <span
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{ __html: name }}
            />,
            classnames(style.slotName, 'slotName', `${buttonText}-text-style`)
          )}
        </p>
      </div>
      {!prodId ? (
        <Button
          variation="none"
          theme="control"
          alt={buttonText}
          href={getRedirectUrl()}
          className={classnames(
            style.slotButton,
            'slotButton fol',
            `${buttonText}-style`,
            `lastButton-${currentSite}`,
            'showNone'
          )}
        >
          {buttonText}
        </Button>
      ) : (
        addCTAComponent()
      )}

      <div
        className={classnames(style.addToRegOverlay, 'addToRegOverlay')}
        style={addedToReg ? { display: 'flex' } : { display: 'none' }}
      >
        {getSubmittedButton()}
      </div>
    </Card>
  );
};

SlotMachineCard.propTypes = propTypes;
SlotMachineCard.defaultProps = defaultProps;

export default SlotMachineCard;
