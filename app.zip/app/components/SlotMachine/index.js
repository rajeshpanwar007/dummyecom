export { default } from './SlotMachineWrapper';
