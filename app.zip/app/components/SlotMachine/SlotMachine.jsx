import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import _ from 'lodash';
import Array from 'lodash/fp';
import pathOr from 'lodash/fp/pathOr';
import isEmpty from 'lodash/fp/isEmpty';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { isBrowser, getPreviousLocation } from '@bbb-app/utils/common';
import CustomCarousel from '@bbb-app/carousel/CustomCarousel';
import { PNH_LIST_OWNER_SHOP } from '@bbb-app/constants/route/route';

import Skeleton from '../../components/SlotMachine/Skeleton';
import SlotMachineCard from './SlotMachineCard';
import style from './SlotMachine.css';
import lastItem from './lastItem';

const defaultProps = {
  title: null,
};
const propTypes = {
  categoryKey: PropTypes.string,
  categoryName: PropTypes.string,
  categoryProductIds: PropTypes.array,
  categoryUrlMappedData: PropTypes.object,
  registryData: PropTypes.any,
  title: PropTypes.string,
  dispatchFetchProds: PropTypes.func,
  slot: PropTypes.any,
  registryOwnerFirstCategoryList: PropTypes.any,
  sanitizeCategoryName: PropTypes.string,
  isRegistryTypeDifferent: PropTypes.bool,
  isRemainingItemFetching: PropTypes.bool,
  isFirstItemsFetching: PropTypes.bool,
  pageIdentifier: PropTypes.string,
  sortedBy: PropTypes.string,
  contextPath: PropTypes.string,
};

export class SlotMachine extends React.PureComponent {
  constructor(props) {
    super(props);
    let registryId = '';
    if (isBrowser()) {
      const pathnameArr = window.location.pathname.split('/');
      registryId = pathnameArr && pathnameArr[pathnameArr.length - 1];
    }
    this.state = {
      skuList: [],
      currentIndex: 1,
      productsList: null,
      itemsFetching: false,
      registryId,
    };

    // carousel settings
    this.settings = {
      dots: false,
      infinite: false,
      speed: 600,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      lazyLoad: false,
    };

    this.isInternationalUser = isInternationalUser();
    this.handleDisabled = this.handleDisabled.bind(this);
    this.createRegList = this.createRegList.bind(this);
  }

  componentDidMount() {
    const {
      categoryKey,
      categoryProductIds,
      dispatchFetchProds,
      isRegistryTypeDifferent,
      pageIdentifier,
    } = this.props;
    const slotProducts = pathOr([], 'slotResults.data', this.props);

    /*
     * initiate call only if data is empty in corresponding slotResults
     *
     * isRegistryTypeDifferent checks if the registry is of different type
     * else in case of some sku api fail, it will try to initiate call even when
     * registry is switched
     */
    if (isEmpty(slotProducts) && !isRegistryTypeDifferent) {
      dispatchFetchProds(categoryKey, categoryProductIds);
    } else if (
      // In case of Pack and Hold there is no registry type
      isEmpty(slotProducts) &&
      pageIdentifier === PNH_LIST_OWNER_SHOP
    ) {
      dispatchFetchProds(categoryKey, categoryProductIds);
    }
    this.createRegList();
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.props.isRemainingItemFetching !== nextProps.isRemainingItemFetching
    ) {
      this.setState({ itemsFetching: nextProps.isRemainingItemFetching });
    }
  }

  shouldComponentUpdate(nextProps) {
    let currentUrl = '';
    const prevUrl = getPreviousLocation();
    if (isBrowser()) {
      currentUrl = window.location.pathname;
    }

    const slotProducts = pathOr({}, 'slotResults', this.props);
    if (
      isEmpty(slotProducts.data) ||
      nextProps.pageIdentifier === 'PNHChecklist'
    ) {
      return true;
    }

    if (
      currentUrl !== prevUrl &&
      !this.props.isFirstItemsFetching &&
      !nextProps.isRemainingItemFetching
    ) {
      return true;
    }
    return false;
  }

  componentDidUpdate(prevProps) {
    if (
      this.props.registryOwnerFirstCategoryList !==
        prevProps.registryOwnerFirstCategoryList &&
      !this.props.isRemainingItemFetching &&
      !this.state.itemsFetching
    ) {
      this.createRegList();
    }
  }

  getPDPURL(tileData, registryId) {
    const { contextPath } = this.props;
    const { SEO_URL, SKU_ID } = tileData;
    const queryDelimiter = '?';
    let PDP_URL = 'empty';
    if (SEO_URL) {
      PDP_URL = `${contextPath}${SEO_URL}`;

      if (SKU_ID) PDP_URL += `${queryDelimiter}skuId=${SKU_ID}`;
      else PDP_URL += `${queryDelimiter}`;

      if (registryId !== '') PDP_URL += `&registryId=${registryId}`;
    }
    return PDP_URL;
  }

  createRegList() {
    const tempArr = [];
    const { registryOwnerFirstCategoryList, sortedBy } = this.props;
    if (
      sortedBy === 'priceView' &&
      registryOwnerFirstCategoryList &&
      registryOwnerFirstCategoryList.categoryBuckets
    ) {
      registryOwnerFirstCategoryList.categoryBuckets.map(skuItem => {
        if (skuItem.items && skuItem.items.length > 0) {
          skuItem.items.map(product => {
            if (!product.deletedItem) {
              return tempArr.push(product.sku);
            }
            return null;
          });
        }
        return this.setState({
          skuList: tempArr,
        });
      });
    } else if (Array.isArray(registryOwnerFirstCategoryList)) {
      registryOwnerFirstCategoryList.map(skuItem => {
        if (skuItem.registryItemList.length > 0) {
          skuItem.registryItemList.map(product => {
            if (!product.deletedItem) {
              return tempArr.push(product.sku);
            }
            return null;
          });
        }
        return this.setState({
          skuList: tempArr,
        });
      });
    }
  }

  updateSkuList(skuId) {
    /* istanbul ignore next */
    this.setState({
      skuList: [...this.state.skuList, parseInt(skuId, 10)],
    });
  }

  selectProductArray(slotProducts) {
    const data = slotProducts.data;
    const haveLastObj = data.find(obj => {
      return obj.BRAND_ID === 1001010109988;
    });

    if (!haveLastObj) {
      return [...data, lastItem[0]];
    }
    return data;
  }

  handleDisabled(item) {
    let exist = null;
    const existItem = _.intersectionWith(
      [parseInt(item, 10)],
      this.state.skuList,
      _.isEqual
    );
    if (existItem.length > 0) {
      /* istanbul ignore next */
      exist = true;
    } else if (existItem.length === 0) {
      exist = false;
    }

    return exist;
  }

  renderCards(products) {
    // below label will show when item will be added into checklist
    const addedItemLbl = pathOr('', 'extraData.addedItemLbl', this.props);
    const pickUpStoreId = pathOr('', 'extraData.pickUpStoreId', this.props);

    return products.map(item => {
      return (
        <div
          key={`${item.PRODUCT_ID}${item.BRAND_ID}`}
          style={{ padding: '2px', width: '350px' }}
          className={`slotContainerId-${this.props.slot} slotPrintStyle`}
        >
          <SlotMachineCard
            name={item.DISPLAY_NAME ? item.DISPLAY_NAME.substring(0, 55) : null}
            price={item.IS_PRICE}
            image={item.SCENE7_URL}
            modalImage={item.SCENE7_URL}
            button={item.button}
            buttonText={item.button_text ? 'Shop All' : 'Add To Registry'}
            addedToReg={this.handleDisabled(item.SKU_ID)}
            registryData={this.props.registryData}
            prodId={item.PRODUCT_ID}
            skuId={item.SKU_ID || ''}
            itemStores={item.STORES}
            containerTitle={this.props.title}
            buttonProp={() => this.updateSkuList(item.SKU_ID)}
            categorySearch={this.props.sanitizeCategoryName}
            intlRestricted={this.isInternationalUser}
            cardHeadingTitle={this.props.categoryName}
            pageIdentifier={this.props.pageIdentifier}
            addedItemLbl={addedItemLbl}
            categoryUrlMappedData={this.props.categoryUrlMappedData}
            pickUpStoreId={pickUpStoreId}
            pdpURL={this.getPDPURL(item, this.state.registryId)}
          />
        </div>
      );
    });
  }

  render() {
    const slotProducts = pathOr({}, 'slotResults', this.props);

    // hide the skeleton when the sku api call fails
    if (slotProducts.error) {
      return null;
    }

    // show skeleton if not in error and data is empty
    if (isEmpty(slotProducts.data)) {
      return <Skeleton />;
    }

    return (
      <div
        className={classnames(
          style.slotMachineWrapper,
          'slotMachineWrapper cell large-4 medium-6 small-10 grid-x'
        )}
      >
        <div className="large-12 medium-12 small-12 ">
          <h3 className={classnames(style.slotCardTitle, 'slotCardTitle')}>
            {this.props.categoryName}
          </h3>
          <CustomCarousel
            ref={slider => (this.slider = slider)}
            {...this.settings}
          >
            {this.renderCards(this.selectProductArray(slotProducts))}
          </CustomCarousel>
        </div>
      </div>
    );
  }
}

SlotMachine.propTypes = propTypes;
SlotMachine.defaultProps = defaultProps;

export default SlotMachine;
