import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import { RegistryOwnerPath } from '@bbb-app/constants/route/registryRoute';
import { LOCATORS } from './dataLocators';

/**
 * @static
 * @memberof LTLAltNumberModal
 */
const propTypes = {
  labels: PropTypes.object,
  poBoxModalMountedState: PropTypes.bool,
  togglePoBoxModalState: PropTypes.func,
  redirectTo: PropTypes.func,
  registryId: PropTypes.string,
  editRegistryQueryParam: PropTypes.string,
  modalDescriptionClass: PropTypes.string,
};
/**
 * @memberof LTLModal
 */
const renderModalHeading = labels => {
  return (
    <Cell>
      <Heading data-locator={LOCATORS.PO_BOX_MODAL_HEADING} level={3}>
        {LabelsUtil.getLabel(labels, 'poBoxModalTitle')}
      </Heading>
    </Cell>
  );
};
/**
 * @memberof LTLModal
 */
const renderModalDescription = (labels, modalDescriptionClass) => {
  return (
    <Cell className={classnames('mb2')}>
      <Paragraph
        data-locator={LOCATORS.PO_BOX_MODAL_DESCRIPTION}
        className={classnames(`${modalDescriptionClass}`)}
      >
        {LabelsUtil.getLabel(labels, 'poBoxModalDescription')}
      </Paragraph>
    </Cell>
  );
};
/**
 * @returns
 * @memberof LTLModal
 */
const renderUpdateButton = (
  labels,
  registryId,
  redirectTo,
  editRegistryQueryParam
) => {
  const queryDelimiter = '?';
  return (
    <GridX className={classnames('small-12')}>
      <Cell className={classnames('large-6 small-8')}>
        <Button
          data-locator={LOCATORS.PO_BOX_UPDATE_ADDRESS}
          onClick={() => {
            redirectTo(
              `${RegistryOwnerPath}${registryId}${queryDelimiter}${editRegistryQueryParam}`
            );
          }}
        >
          {LabelsUtil.getLabel(labels, 'updateAddress')}
        </Button>
      </Cell>
    </GridX>
  );
};
/**
 * @class LTLAltNumberModal
 * @extends {PureComponent}
 */
export const POBoxAddressModal = props => {
  const {
    labels,
    poBoxModalMountedState,
    togglePoBoxModalState,
    redirectTo,
    registryId,
    editRegistryQueryParam,
    modalDescriptionClass,
  } = props;
  return (
    <ErrorBoundary>
      <ModalDialog
        verticallyCenter
        mountedState={poBoxModalMountedState}
        toggleModalState={togglePoBoxModalState}
        titleAriaLabel={LabelsUtil.getLabel(labels, 'poBoxModalAriaTitle')}
        variation={'small'}
        scrollDisabled={false}
        initialFocus=".rclModalContent"
      >
        <GridX className={classnames('large-12 small-12')}>
          {renderModalHeading(labels)}
          {renderModalDescription(labels, modalDescriptionClass)}
          {renderUpdateButton(
            labels,
            registryId,
            redirectTo,
            editRegistryQueryParam
          )}
        </GridX>
      </ModalDialog>
    </ErrorBoundary>
  );
};

// propTypes
POBoxAddressModal.propTypes = propTypes;
// export
export default POBoxAddressModal;
