import React from 'react';
import PropTypes from 'prop-types';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Button from '@bbb-app/core-ui/button';
import ViewRegistryButton from '../common/ATCATRModalCTAs/ViewRegistryButton';

export const ATRDefaultModal = ({
  quantity,
  content,
  closeTxt,
  onClose,
  endpoints,
  registryId,
  labels,
  isListType,
}) => {
  const messageToDisplay =
    content.status === 'success'
      ? `${quantity} items ${content.content}`
      : content.content;
  return (
    <GridX>
      <Cell className="mb3">
        <span>{messageToDisplay}</span>
      </Cell>
      {content.status === 'success' ? (
        <Cell className="mb1">
          <ViewRegistryButton
            endpoints={endpoints}
            registryId={registryId}
            labels={labels}
            isListType={isListType}
          />
        </Cell>
      ) : null}
      <Cell className="mb2">
        <Button theme="link" onClick={onClose}>
          {closeTxt}
        </Button>
      </Cell>
    </GridX>
  );
};

ATRDefaultModal.propTypes = {
  quantity: PropTypes.number,
  content: PropTypes.string,
  closeTxt: PropTypes.string,
  onClose: PropTypes.func,
  endpoints: PropTypes.any,
  registryId: PropTypes.any,
  labels: PropTypes.any,
  isListType: PropTypes.bool,
};

export default ATRDefaultModal;
