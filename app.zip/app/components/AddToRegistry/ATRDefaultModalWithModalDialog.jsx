import React from 'react';
import PropTypes from 'prop-types';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import ATRDefaultModal from './ATRDefaultModal';
const ATRWithModalDialog = props => {
  return (
    <ModalDialog
      mountedState={props.mountedState}
      toggleModalState={props.toggleModalState}
      dialogClass={props.dialogClass}
      titleAriaLabel={props.titleAriaLabel}
      verticallyCenter={props.verticallyCenter}
      rclModalClass={props.rclModalClass}
      variation={props.variation}
      scrollDisabled={props.scrollDisabled}
    >
      <ATRDefaultModal
        quantity={props.quantity}
        content={props.content}
        closeTxt={props.closeTxt}
        labels={props.labels}
        onClose={props.onClose}
        endpoints={props.endpoints}
        registryId={props.registryId}
        isListType={props.isListType}
      />
    </ModalDialog>
  );
};

const propTypes = {
  mountedState: PropTypes.any,
  toggleModalState: PropTypes.any,
  dialogClass: PropTypes.any,
  titleAriaLabel: PropTypes.any,
  verticallyCenter: PropTypes.any,
  rclModalClass: PropTypes.any,
  variation: PropTypes.any,
  scrollDisabled: PropTypes.any,
  quantity: PropTypes.any,
  content: PropTypes.any,
  closeTxt: PropTypes.any,
  labels: PropTypes.any,
  onClose: PropTypes.any,
  endpoints: PropTypes.any,
  registryId: PropTypes.any,
  isListType: PropTypes.any,
};

ATRWithModalDialog.propTypes = propTypes;

export default ATRWithModalDialog;
