export const LOCATORS = {
  LTL_DSL_MODAL_HEADING: 'atr_ltldsl_modalheading',
  LTL_DSL_MODAL_DESCRIPTION: 'atr_ltldsl_modaldescription',
  LTL_DSL_ALT_PHONE_NUMBER: 'atr_ltldsl_alt_phone_number',
  PO_BOX_MODAL_HEADING: 'atr_pobox_modalheading',
  PO_BOX_MODAL_DESCRIPTION: 'atr_pobox_modaldescription',
  PO_BOX_UPDATE_ADDRESS: 'atr_pobox_updateaddress_button',
  UPDATE_ADDRESS: 'ltldsl_update_button',
};
