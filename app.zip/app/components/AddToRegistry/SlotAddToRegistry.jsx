/* eslint-disable max-lines */
import React, { PureComponent, Fragment } from 'react';
import { withRouter } from 'react-router';
import classnames from 'classnames';
import { parse } from 'qs';
import pathOr from 'lodash/fp/pathOr';
import { isEmpty, isEqual } from 'lodash';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import isUserRecognized from '@bbb-app/utils/isUserRecognized';
import uniqueKeys from '@bbb-app/utils/uniqueKeys';
import Button from '@bbb-app/core-ui/button';
import AuthValidator from '@bbb-app/hoc/AuthValidator';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import RegistryTypeModalWrapper from '@bbb-app/registry-type/containers/registry-type-modal/RegistryTypeModalWrapper';
import CustomSelect from '@bbb-app/custom-select/CustomSelect';
import {
  QUERY_STRING,
  CREATE_REGISTRY_FORM_URL,
} from '@bbb-app/constants/registryConstants';
import styles from './AddToRegistry.css';
import {
  NO_QTY,
  NO_SIZE,
  NO_SWATCH,
  NO_LTL,
  ACTION_REGISTRY,
} from '../../constants/CallToAction';
import AsyncModalDialogWithATCModal from '../../containers/common/ATCATRModal/ATCATRModalWithModalDialog.async';
import AsyncATRDefaultModal from './ATRDefaultModal.async';
import atcStyles from '../AddToCart/AddToCart.css';
import POBoxAddressModal from './POBoxAddressModal.async';
import { BUTTON, HYPERLINK } from './constants';
import {
  getDefaultProps,
  getPropTypes,
  autoAddItemRevoked,
  getRegistryDropDownOptions,
  disableCtaForLTL,
  getRegistryById,
  addToRegistryStarted,
  validateLtlDslModalOptions,
  getSelectedProductProps,
} from './AddToRegistryUtil';
import LTLAltDslModal from './../../containers/LTLAltDslModal/LTLAltDslModal.async';
import { moveToRegistryTealiumInfo } from './moveToRegistryTealiumInfo';
/**
 * @class AddToRegistry
 * @extends {React.PureComponent}
 * AddToRegistry is a component that renders button or select element and handles the user action on it
 */
class AddToRegistry extends PureComponent {
  /**
   * @static defaultProps
   * @memberof AddToRegistry
   */
  static defaultProps = getDefaultProps();
  /**
   * @static propTypes
   * @memberof AddToRegistry
   */
  static propTypes = getPropTypes();
  /**
   * Creates an instance of AddToRegistry.
   * @param {any} props
   * @memberof AddToRegistry
   */
  constructor(props) {
    super(props);
    this.uid =
      this.props.uniqueKey || uniqueKeys.getStatelessUniqueKey('AddToRegistry');
    this.setDefaultErrorState();
    this.autoAddItem = false; // this flag determines whether to trigger the AddToRegistry action post logon on PDP without user action
    this.selectedRegistryId = ''; // registry id cached for selected registry from dropdown
    this.ltlAltDslRegistryName = '';
    this.regGuestAltNumber = ''; // altphone number handled from gift giver view.
    this.state = {
      selectedRegistryId: 0, // id of registry that corresponds to the selected state of dropdown
      selectedRegistryName: '',
      atrModalMountedState: false,
      ltlModalMountedState: false,
      poBoxModalMountedState: false,
      isATREventFired: false, // this state property indicates that the user has initiated ATR action and determines to render the AuthValidator component
      createRegistryModalState: false,
      contextTheme: 'regular', // whether add to registry is initiated from LtlAltDslModal or regular PDP/ QV/ Child, possible values ['regular', 'ltlAltDsl']
    };
    this.handleAddToRegistryClick = this.handleAddToRegistryClick.bind(this);
    // CustomSelect callback
    this.handleSelectedRegistry = this.handleSelectedRegistry.bind(this);
    // AuthValidator loginStateValidCallback
    this.addItemToRegistryCallback = this.addItemToRegistryCallback.bind(this);
    // registry type modal registry select
    this.onModalSelectionChange = this.onModalSelectionChange.bind(this);
    // registry type modal
    this.toggleRegistryModalState = this.toggleRegistryModalState.bind(this);
  }
  /**
   * @memberof AddToRegistry
   */
  componentDidMount() {
    const query = parse(location.search, { ignoreQueryPrefix: true });
    /* istanbul ignore if : this condition depends on browser location object */
    if (isEqual('true', query.addToRegistry)) {
      this.toggleATREventFiredState();
    }
  }
  /**
   * @param {any} newProps
   * @memberof AddToRegistry
   */
  componentWillReceiveProps(newProps) {
    const { genericError, onError, ltlFlag } = this.props;
    const { data, error, productId, skuId } = this.props.addToRegistryState;
    const isLTL = isEqual('true', ltlFlag) || isEqual(true, ltlFlag);
    const isSelectedSku =
      newProps.prodId === productId &&
      newProps.skuId === skuId &&
      newProps.addToRegistryState.uid === this.uid &&
      (isLTL ? !isEmpty(newProps.ltlShipMethod) : true);
    /* istanbul ignore else  */
    if (isSelectedSku) {
      /* istanbul ignore else  */
      if (
        this.autoAddItem &&
        newProps.registries &&
        newProps.registries.profileRegistryList
      ) {
        const customerRegistries = newProps.registries.profileRegistryList;
        /* istanbul ignore else  */
        if (customerRegistries.length === 0) {
          this.toggleRegistryModalState(true);
          this.emptyStoreForGuestUser();
        } else if (
          customerRegistries.length === 1 &&
          !isEmpty(newProps.registryId)
        ) {
          this.addItemToGiftRegistry(newProps);
          this.autoAddItem = false;
          autoAddItemRevoked();
        } else if (customerRegistries.length > 1) {
          this.emptyStoreForGuestUser();
        }
      }
      // Add To Registry action has been fired
      this.setMountedState(newProps, data, error, isLTL);
    }
    /* istanbul ignore else  */
    if (error) {
      onError(error || genericError);
    }
  }
  onModalSelectionChange(type) {
    const eventType = type.registryCode;
    const { redirectTo } = this.props;
    this.toggleRegistryModalState(false);
    redirectTo(`${CREATE_REGISTRY_FORM_URL}${QUERY_STRING}${eventType}`);
  }
  /**
   * @param {any} newProps
   * @param {any} data
   * @param {any} error
   * @memberof AddToRegistry
   */
  setMountedState(newProps, inData, inError, isLTL) {
    const { addToRegistryState } = newProps;
    const { data, error, qty } = addToRegistryState;
    if ((data && data !== inData) || (error && error !== inError)) {
      const qtyOrig = isEmpty(error) ? 1 : qty;
      /* istanbul ignore else  */
      if (this.props.onModalHide) this.props.onModalHide();
      /* istanbul ignore else  */
      if (isLTL) {
        this.setState({ ltlModalMountedState: false }, () => {
          this.openAtrModal(qtyOrig);
        });
      } else {
        this.openAtrModal(qtyOrig);
      }
    }
  }
  /**
   * @memberof AddToRegistry
   */
  setDefaultErrorState() {
    this.error = {};
  }
  /**
   * @returns the CustomSelect Component
   * @memberof AddToRegistry
   */
  getRegistryDropDown() {
    const {
      useLabelClass,
      disableAddToRegistryDropdown,
      wrapperClassName,
      dropDownPosition,
      maxNumberOfElementsToShow,
    } = this.props;
    const optionSet = getRegistryDropDownOptions(this.props);
    return (
      <Fragment>
        <CustomSelect
          optionSet={optionSet}
          variationName="selectPrimary"
          defaultValue={this.state.selectedRegistryId}
          selectOption={this.handleSelectedRegistry}
          wrapperClassName={classnames(wrapperClassName)}
          disabled={
            disableAddToRegistryDropdown ||
            this.isFetching ||
            disableCtaForLTL(this.props)
          }
          labelClassName={useLabelClass ? classnames(styles.labelClass) : ''}
          position={dropDownPosition}
          maxNumberOfElementsToShow={maxNumberOfElementsToShow}
          {...this.props.dropdownProps}
        />
        {this.getPOBoxAddressModal()}
        {this.isLTL && this.getLTLAltDslModal()}
        {this.getATRModal()}
      </Fragment>
    );
  }
  /* returns Hyperlink component
   * @memberof AddToRegistry*/
  getRegistryHyperlink() {
    const { buttonProps } = this.props;
    return (
      <Fragment>
        <PrimaryLink
          href="#"
          onClick={e => {
            e.preventDefault();
            this.handleAddToRegistryClick();
            buttonProps.attr.onClick();
          }}
          alt={buttonProps.attr.alt}
          variation={buttonProps.attr.variation}
          className={classnames(buttonProps.attr.className)}
          iconProps={buttonProps.attr.iconProps}
          disabledLink={
            buttonProps.attr.disabled ||
            this.isFetching ||
            disableCtaForLTL(this.props)
          }
        >
          {buttonProps.children}
        </PrimaryLink>
      </Fragment>
    );
  }
  /* @returns Button Component
   * @param {string} theme
   * @returns
   * @memberof AddToRegistry
   */
  getRegistryButton(theme) {
    const { buttonProps } = this.props;
    const btnTheme = theme || pathOr('', 'attr.theme', buttonProps);
    return (
      <Fragment>
        <Button
          onClick={this.handleAddToRegistryClick}
          disabled={
            buttonProps.disabled ||
            this.isFetching ||
            disableCtaForLTL(this.props)
          }
          {...buttonProps.attr}
          theme={btnTheme}
        >
          {buttonProps.children}
        </Button>
        {this.getRegistryTypeModal()}
        {this.getPOBoxAddressModal()}
        {this.isLTL && this.getLTLAltDslModal()}
        {this.getATRModal()}
      </Fragment>
    );
  }
  getRegistryTypeModal() {
    const { registryLabels } = this.props;
    return (
      this.state.createRegistryModalState && (
        <RegistryTypeModalWrapper
          isRegistryTypeOpen={this.state.createRegistryModalState}
          toggleRegistryModalState={this.toggleRegistryModalState}
          labels={registryLabels.createRegistry}
          location={this.props.location}
          changeRegistryType={this.onModalSelectionChange}
          registryNotFound
        />
      )
    );
  }
  /**
   * @returns LTL Modal
   * @memberof AddToRegistry
   */
  getLTLAltDslModal() {
    return (
      <LTLAltDslModal
        {...this.props}
        toggleLTLModalState={this.toggleLTLModalState}
        ltlModalMountedState={this.state.ltlModalMountedState}
        showPhoneNumberInput={!this.regGuestAltNumber}
        altPhoneNumber={this.regGuestAltNumber}
        ltlAltDslRegistryId={this.selectedRegistryId}
        ltlAltDslRegistryName={this.ltlAltDslRegistryName}
        modalDescriptionClass={styles.modalDescription}
        uniqueKey={this.uid}
      />
    );
  }
  /**
   * @returns POBoxAddress Modal
   * @memberof AddToRegistry
   */
  getPOBoxAddressModal() {
    const { registryLabels, redirectTo } = this.props;
    return (
      <POBoxAddressModal
        labels={registryLabels}
        redirectTo={redirectTo}
        registryId={this.selectedRegistryId}
        togglePoBoxModalState={this.togglePoBoxModalState}
        poBoxModalMountedState={this.state.poBoxModalMountedState}
        editRegistryQueryParam={this.props.editRegistryQueryParam}
        modalDescriptionClass={styles.modalDescription}
      />
    );
  }
  /**
   * @returns  ATR Modal
   * @memberof AddToRegistry
   */
  getATRModal() {
    const {
      labels,
      enabledGlobalSwitches,
      endpoints,
      validationLabels,
      scene7UrlConfig,
      genericError,
      viewType,
      addToRegistryState,
      calledFromRegistry,
      resetVendorPriceDetails,
    } = this.props;
    const {
      data,
      error,
      isFetching,
      skuId,
      productId,
      addedSkuAttrs,
      registryId,
      registryName,
      parentProductId,
      qty,
      categoryId,
    } = addToRegistryState;
    const itemDetailsVO = pathOr([], 'component.itemDetailsVO', data);
    const modalVariation = 'medium';
    const content =
      error || (itemDetailsVO && !itemDetailsVO.length) // whether ATR API response is successful
        ? {
            status: 'error',
            content: genericError,
          }
        : {
            status: 'success',
            content: LabelsUtil.getLabel(labels, 'ATRsuccessMessage').replace(
              ':registryName',
              registryName
            ),
          };
    const enabledATRModal = pathOr('', 'enableATRModal', enabledGlobalSwitches);
    const enableATCRelatedCategories = pathOr(
      '',
      'enableATCRelatedCategories',
      enabledGlobalSwitches
    );
    if (!isFetching && this.state.atrModalMountedState) {
      return enabledATRModal ? (
        <AsyncModalDialogWithATCModal
          mountedState={this.state.atrModalMountedState}
          dialogClass={atcStyles.atcModal}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'cartStatusModal')}
          verticallyCenter
          rclModalClass={classnames(atcStyles.addedTocartModal)}
          variation={modalVariation}
          scrollDisabled={false}
          data={data}
          error={error}
          isFetching={isFetching}
          toggleModalState={() => {
            this.toggleATRModalState(false);
          }}
          skuId={skuId}
          itemQty={qty}
          scene7UrlConfig={scene7UrlConfig}
          labels={labels}
          validationLabels={validationLabels}
          endpoints={endpoints}
          parentProductId={parentProductId}
          calledFromRegistry={calledFromRegistry}
          enableCertonaContainerATCATRModal={pathOr(
            '',
            'enableCertonaContainerATCATRModal',
            enabledGlobalSwitches
          )}
          enableCertona={pathOr('', 'enableCertona', enabledGlobalSwitches)}
          prodId={productId}
          categoryId={categoryId}
          enableATCRelatedCategories={enableATCRelatedCategories}
          registryId={registryId}
          messageContent={content}
          selectedProduct={addedSkuAttrs}
          viewType={viewType}
          resetVendorPriceDetails={resetVendorPriceDetails}
        />
      ) : (
        <AsyncATRDefaultModal
          quantity={qty}
          content={content}
          closeTxt={LabelsUtil.getLabel(labels, 'closeBtnText')}
          labels={labels}
          onClose={() => {
            this.toggleATRModalState(false);
          }}
          endpoints={endpoints}
          registryId={registryId}
        />
      );
    }
    return '';
  }
  emptyStoreForGuestUser() {
    this.props.modalATRDidClose();
    this.autoAddItem = false;
    autoAddItemRevoked();
  }
  /**
   * @param {*} qtyAdded
   * @param {*} qtySelected
   * @memberof AddToRegistry
   */
  openAtrModal(qtyOrig) {
    const { onSuccess } = this.props;
    this.setState(
      {
        atrModalMountedState: true,
      },
      () => {
        this.resetRegistryDropDown();
        onSuccess(qtyOrig);
      }
    );
  }
  /**
   * Gets the fetching or busy state of the component
   * @returns {bool}
   */
  get isFetching() {
    return this.props.addToRegistryState.isFetching;
  }
  /**
   * @param {any} value : toggles the state of the registry type selection modal
   * @memberof AddToRegistry
   */
  toggleRegistryModalState(value) {
    this.setState({ createRegistryModalState: !!value });
  }
  /**
   * toggles the state of LTL Modal
   * @memberof AddToRegistry
   */
  toggleLTLModalState = value => {
    this.setState({ ltlModalMountedState: value }, () => {
      /* istanbul ignore else  */
      if (value) {
        this.resetRegistryDropDown();
      }
    });
  };
  /**
   * toggles the state of LTL Modal
   * @memberof AddToRegistry
   */
  togglePoBoxModalState = value => {
    this.setState({ poBoxModalMountedState: value }, () => {
      /* istanbul ignore else  */
      if (value) {
        this.resetRegistryDropDown();
      }
    });
  };
  /**
   * toggles the state of ATR Modal
   * @memberof AddToRegistry
    */
  toggleATRModalState = value => {
    this.setState({ atrModalMountedState: value }, () => {
      /* istanbul ignore else  */
      if (!value) {
        this.props.modalATRDidClose();
        if (this.props.resetVendorPriceDetails) {
          this.props.resetVendorPriceDetails();
        }
      }
    });
    /* istanbul ignore else  */
    if (this.props.closeQuickViewModal) this.props.closeQuickViewModal();
  };
  /**
   * @memberof AddToRegistry
   */
  resetRegistryDropDown() {
    this.setState({
      selectedRegistryId: 0,
    });
  }
  /**
   * @param {boolean} addItemToGiftRegistry controls whether to initiate the `add item`
   * it is written in callback because it depends on AuthValidator HOC, which gets rendered based on isATREventFired and controls the flow for guest or logged on user
   * @memberof AddToRegistry
   */
  toggleATREventFiredState(addItemToGiftRegistry) {
    this.setState(
      {
        isATREventFired: !this.state.isATREventFired,
      },
      () => {
        /* istanbul ignore else  */
        if (addItemToGiftRegistry) {
          this.addItemToGiftRegistry();
        }
      }
    );
  }
  /**
   * @param {any} selectedRegistryId
   * @memberof AddToRegistry
   */
  handleSelectedRegistry(selectedRegistryId) {
    const { registries } = this.props;
    if (selectedRegistryId) {
      this.selectedRegistryId = selectedRegistryId;
      const selectedRegistry = getRegistryById(selectedRegistryId, registries);
      const selectedRegistryName = pathOr('', 'eventType', selectedRegistry);
      const alternatePhoneNumber = pathOr(
        '',
        'alternatePhone',
        selectedRegistry
      );
      addToRegistryStarted(this.props, this.uid);
      /* istanbul ignore else  */
      if (isEqual('CART', this.props.pageType)) {
        this.moveItemToRegistryFromSFL(selectedRegistryId);
      } else {
        this.setState({
          selectedRegistryId,
          selectedRegistryName,
          alternatePhoneNumber,
        });
        // check SKU validations
        /* istanbul ignore else  */
        if (!this.checkSkuValidations()) return;
        this.addItemToGiftRegistry(
          undefined,
          selectedRegistryId,
          selectedRegistryName,
          selectedRegistry
        );
      }
    }
  }
  /**
   * Moves an Item to registry from Saved Line items on cart page
   * @param {number} selectedRegistryId Selected Registry ID
   * @returns
   * @memberof AddToRegistry
   */
  moveItemToRegistryFromSFL(selectedRegistryId) {
    const {
      skuId,
      wishListItemId,
      moveToRegistry,
      itemIndex,
      registryId,
      ltlFlag,
      registries,
      validateAltPhoneNum,
      altPhoneNumModal,
      referenceNumber,
      isCustomizationRequired,
      personalizationType,
    } = this.props;
    // activeRegistryId belongs to the registry selected by user to add the item
    const activeRegistryId = selectedRegistryId || registryId;
    const selectedRegistry = getRegistryById(activeRegistryId, registries);
    const tealiumMTRData = moveToRegistryTealiumInfo(
      this.props.tealiumData,
      selectedRegistry
    );
    const item = {
      skuId,
      wishListItemId,
      moveItemFromSaveForLater: true,
      registryId: activeRegistryId,
      movedItemIndex: itemIndex,
      referenceNumber: referenceNumber || '',
      isCustomizationRequired,
      personalizationType,
      tealiumMTRData,
    };
    // args to perform LTL validations: alternate no and po box registry address
    const argsForLTLValidations = {
      ltlFlag,
      activeRegistryId,
      selectedRegistry,
      validateAltPhoneNum,
      altPhoneNumModal,
      registries,
    };
    // evaluate the LTL conditions
    const canBeAdded = this.checkLTLConditions(argsForLTLValidations);
    /* istanbul ignore else  */
    if (canBeAdded) {
      moveToRegistry(item);
    }
  }
  /**
   * @memberof AddToRegistry
   */
  handleAddToRegistryClick() {
    addToRegistryStarted(this.props, this.uid);
    if (isEqual('CART', this.props.pageType)) {
      this.moveItemToRegistryFromSFL();
    } else {
      const { selectDslOnModal, validateLtlDslOnModal } = this.props;
      // check SKU validations but skip from registry guest view
      if (
        !(selectDslOnModal || validateLtlDslOnModal) &&
        !this.checkSkuValidations()
      )
        return;
      this.toggleATREventFiredState(true);
    }
  }
  /**
   * @returns
   * @memberof AddToRegistry
   */
  checkSkuValidations() {
    let canBeAdded = true;
    const {
      skuId,
      qty,
      addToRegistryState,
      ltlFlag,
      ltlShipMethod,
      size,
      swatch,
      onClientError,
      updateCallToAction,
    } = this.props;
    const quantity = addToRegistryState.qty ? addToRegistryState.qty : qty;
    // args for sku, inline dsl validations
    const argsForSKUValidations = {
      qty: quantity,
      ltlFlag,
      ltlShipMethod,
      skuId,
      size,
      swatch,
    };
    // check if color/finish/size/dsl selected
    this.checkValidations(argsForSKUValidations);
    // if no SKU available, show error
    if (!isEmpty(this.error)) {
      canBeAdded = false;
      onClientError(this.error);
      updateCallToAction(ACTION_REGISTRY);
      this.resetRegistryDropDown();
      this.setDefaultErrorState();
    }
    return canBeAdded;
  }
  /**
   * @param {any} activeRegistryId
   * @param {any} selectedRegistry
   * @returns {boolean} if LTL can be added
   * opens po box modal or alternate LTL number modal
   * @memberof AddToRegistry
   */
  checkLTLConditions(argsForLTLValidations) {
    const {
      ltlFlag,
      activeRegistryId,
      selectedRegistry,
      registries,
      selectDslOnModal,
      altPhoneNumModal,
    } = argsForLTLValidations;
    let registrySelected = selectedRegistry;
    let canBeAdded = true;
    /* istanbul ignore else */
    if (isEqual('true', ltlFlag) || isEqual(true, ltlFlag)) {
      /* istanbul ignore else */
      if (!registrySelected && activeRegistryId) {
        registrySelected = getRegistryById(activeRegistryId, registries);
      }
      // check poBoxAddress
      const hasPoBoxAddress = pathOr('', 'poBoxAddress', registrySelected);
      if (hasPoBoxAddress) {
        canBeAdded = false;
        this.selectedRegistryId = pathOr('', 'registryId', registrySelected);
        this.togglePoBoxModalState(true);
      } else {
        canBeAdded = validateLtlDslModalOptions(argsForLTLValidations);
        /* istanbul ignore else */
        if (canBeAdded) {
          const alternatePhone =
            pathOr('', 'alternatePhone', registrySelected) || altPhoneNumModal;
          /* istanbul ignore else  */
          if (selectDslOnModal) {
            this.regGuestAltNumber = alternatePhone;
          }
          /* istanbul ignore else  */
          if (selectDslOnModal || isEmpty(alternatePhone)) {
            canBeAdded = false;
            this.selectedRegistryId = pathOr(
              '',
              'registryId',
              registrySelected
            );
            this.ltlAltDslRegistryName = pathOr(
              '',
              'eventType',
              registrySelected
            );
            this.toggleLTLModalState(true);
          }
        }
      }
    }
    return canBeAdded;
  }
  /**
   * @param {any} argsForValidations
   * @memberof AddToRegistry
   */
  checkValidations(argsForValidations) {
    const { qty, ltlShipMethod, skuId, size, swatch } = argsForValidations;
    /* istanbul ignore else  */
    if (qty <= 0) {
      this.error[NO_QTY] = NO_QTY;
    }
    /* istanbul ignore else  */
    if (skuId && this.isLTL && !ltlShipMethod) {
      this.error[NO_LTL] = NO_LTL;
    }
    /*
     * no SKU selected, DO NOT USE isEmpty for null check in case of skuId
     * as isEmpty has a bug for Numeric values and this component is used on different pages
     * and skuId is getting consumed as Number and String both from different parent components
     */

    if (!skuId) {
      // no size
      /* istanbul ignore else  */
      if (isEmpty(size)) this.error[NO_SIZE] = NO_SIZE;
      // no color
      /* istanbul ignore else  */
      if (isEmpty(swatch)) this.error[NO_SWATCH] = NO_SWATCH;
    }
  }
  /**
   * @param {any} newProps
   * @param {any} selectedRegistryId in case of dropdown
   * @param {any} selectedRegistryName in case of dropdown
   * @param {any} selectedRegistry in case of dropdown
   * @returns
   * @memberof AddToRegistry
   */
  addItemToGiftRegistry(
    newProps,
    selectedRegistryId,
    selectedRegistryName,
    selectedRegistry
  ) {
    const {
      skuId,
      prodId,
      addToRegistryState,
      qty,
      registryId,
      registryName,
      isCustomizationRequired,
      personalizationType,
      refNum,
      ltlFlag,
      ltlShipMethod,
      porchPayLoadJson,
      isList,
      fromComparisonPage,
      returnURL,
      addToRegistry,
      ltlAltRegistryId,
      ltlAltRegistryName,
      altPhoneNumModal,
      validateAltPhoneNum,
      validateLtlDslOption,
      registries,
      selectDslOnModal,
      price,
      validateLtlDslOnModal,
      giftGiverTealiumData,
      favStoreId,
      ltlData,
      location,
      parentProductId,
      funStuffTealiumParams,
      quickViewTealiumInfo,
      quickViewTags,
    } =
      newProps || this.props;
    // activeRegistryId belongs to the registry selected by user to add the item
    const activeRegistryId =
      ltlAltRegistryId || selectedRegistryId || registryId;
    const activeRegistryName =
      ltlAltRegistryName || selectedRegistryName || registryName;
    const quantity = addToRegistryState.qty ? addToRegistryState.qty : qty;
    // no registry: open registry type selection modal
    /* istanbul ignore else  */
    if (isEmpty(activeRegistryId)) {
      this.toggleRegistryModalState(true);
      return;
    }
    const atrPDPTealiumData = {
      ltlData,
      personalizationType,
      ltlFlag,
      location,
    };
    const { skuName, scene7URL } = getSelectedProductProps(
      this.props.selectedProduct
    );
    // args to perform LTL validations: alternate no and po box registry address
    const argsForLTLValidations = {
      ltlFlag,
      activeRegistryId,
      selectedRegistry,
      validateAltPhoneNum,
      validateLtlDslOption,
      altPhoneNumModal,
      selectDslOnModal,
      registries,
      validateLtlDslOnModal,
    };
    // evaluate the LTL conditions
    const canBeAdded = this.checkLTLConditions(argsForLTLValidations);
    // all pre-conditions fulfilled : SKU available, LTL pristine, registry available, call the API
    if (canBeAdded) {
      addToRegistry({
        skuId,
        skuName,
        prodId,
        scene7URL,
        activeRegistryId,
        qty: quantity,
        activeRegistryName,
        isCustomizationRequired,
        personalizationType,
        refNum,
        ltlFlag,
        ltlShipMethod,
        porchPayLoadJson,
        isList,
        fromComparisonPage,
        returnURL,
        price,
        altNumber: altPhoneNumModal,
        giftGiverTealiumData,
        favStoreId,
        atrPDPTealiumData,
        location,
        parentProductId,
        funStuffTealiumParams,
        quickViewTealiumInfo,
        quickViewTags,
      });
    }
  }
  /**
   * checkIfLoggedOn redirects to the sign in page if user is not signed in else to the PDP page
   * @param (object) location
   * @param {object} route
   */
  checkIfLoggedOn() {
    let queryDelimiter;
    const { isATREventFired } = this.state;
    const {
      location,
      addToRegistryQueryParam,
      skuId,
      productType,
      PDP_URL,
      ltlShipMethod,
    } = this.props;
    let href = PDP_URL;
    if (!isATREventFired || !skuId) {
      return null;
    }
    /* istanbul ignore else  */
    if (!isEmpty(addToRegistryQueryParam)) {
      queryDelimiter = '?';
      /* istanbul ignore else  */
      if (isEqual('MSWP', productType)) {
        href += this.isLtlFlag
          ? `${queryDelimiter}skuId=${skuId}&sopt=${ltlShipMethod}&${addToRegistryQueryParam}`
          : `${queryDelimiter}skuId=${skuId}&${addToRegistryQueryParam}`;
      } else {
        href += this.isLtlFlag
          ? `${queryDelimiter}sopt=${ltlShipMethod}&${addToRegistryQueryParam}`
          : `${queryDelimiter}${addToRegistryQueryParam}`;
      }
    }
    const toLocation = href.split(queryDelimiter);
    const pathName = toLocation[0];
    const search = `${queryDelimiter}${toLocation[1]}`;
    const isRecognized = isUserRecognized();
    return (
      !isRecognized && (
        <AuthValidator
          location={location}
          route={`${pathName}${search}`}
          loginStateValidCallback={this.addItemToRegistryCallback}
          pathName={pathName}
          search={search}
        />
      )
    );
  }
  /**
   * @memberof AddToRegistry
   */
  addItemToRegistryCallback() {
    /* istanbul ignore if : this condition depends on browser location object */
    /* istanbul ignore next */
    const query = parse(location.search, { ignoreQueryPrefix: true });
    /* istanbul ignore next */
    if (isEqual('true', query.addToRegistry)) {
      this.autoAddItem = true;
      // replace the unique stateless key identifier to represent the same instance of anonymous AddToRegistry
      this.uid = this.props.addToRegistryState.uid;
    }
  }
  /**
   * @returns
   * @memberof AddToRegistry
   */
  renderAddToRegistryLayout() {
    let addToRegistryLayout;
    const {
      registries,
      ltlAltBtnTheme,
      ctaType,
      altDslCtaType,
      ltlFlag,
    } = this.props;
    const ownedRegistries = pathOr([], 'profileRegistryList', registries);
    const recommendedRegistries = pathOr(
      [],
      'recommendedRegistryList',
      registries
    );
    this.isLtlFlag = isEqual('true', ltlFlag) || isEqual(true, ltlFlag);
    /* istanbul ignore else  */
    if (isEqual(BUTTON, altDslCtaType))
      return this.getRegistryButton(ltlAltBtnTheme);

    /* istanbul ignore else  */
    if (isEqual(HYPERLINK, ctaType)) return this.getRegistryHyperlink();

    if (recommendedRegistries.length > 0 || ownedRegistries.length > 1) {
      addToRegistryLayout = this.getRegistryDropDown();
    } else {
      addToRegistryLayout = this.getRegistryButton();
    }
    return addToRegistryLayout;
  }
  /* @returns
   * @memberof AddToRegistry
   */
  render() {
    return (
      <ErrorBoundary>
        {this.checkIfLoggedOn()} {this.renderAddToRegistryLayout()}
      </ErrorBoundary>
    );
  }
}
/* Wrap with  WithRouter for AuthValidator and export the AddToRegistry Component*/
export default withRouter(AddToRegistry);

/* eslint-enable max-lines */
