/* eslint max-lines: ["error", 1550]*/
import React, { Component, Fragment } from 'react';
import { withRouter, Redirect } from 'react-router';
import { compose } from 'redux';
import classnames from 'classnames';
import { parse } from 'qs';
import { compile } from 'path-to-regexp';
import { pathOr } from 'lodash/fp';
import { toast } from 'react-toastify';
import { isEmpty, isEqual } from 'lodash';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import truncate from '@bbb-app/utils/truncate';
import {
  isGuestUser,
  isTouchDevice,
  noop,
  decodeHtmlEntities,
  isBrowser,
  getQueryString,
} from '@bbb-app/utils/common';
import isUserRecognized from '@bbb-app/utils/isUserRecognized';
import uniqueKeys from '@bbb-app/utils/uniqueKeys';
import Button from '@bbb-app/core-ui/button';
import '@bbb-app/styles/thirdparty/toast.css';
import { withSiteSpectTracker } from '@bbb-app/site-spect/Experiment';
import isTbs from '@bbb-app/utils/isTbs';
import toJS from '@bbb-app/hoc/toJS';
import { SessionStorageUtil } from '@bbb-app/utils/sessionStorage';
import AuthValidator from '@bbb-app/hoc/AuthValidator';
import Icon from '@bbb-app/core-ui/icon/Icon';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import RegistryTypeModalWrapper from '@bbb-app/registry-type/containers/registry-type-modal/RegistryTypeModalWrapper';
import CustomSelect from '@bbb-app/custom-select/CustomSelect';
import CustomTooltip from '@bbb-app/core-ui/custom-tooltip/CustomTooltip';
import { ROUTE_BEYOND_PLUS_REDIRECT } from '@bbb-app/constants/route/checkoutRoute';
import '../../assets/icons/gift.svg';
import styles from './AddToRegistry.css';
import {
  NO_QTY,
  NO_SIZE,
  NO_SWATCH,
  NO_LTL,
  ACTION_REGISTRY,
} from '../../constants/CallToAction';
import AsyncModalDialogWithATCModal from '../../containers/common/ATCATRModal/ATCATRModalWithModalDialog.async';
import AsyncATRDefaultModal from './ATRDefaultModal.async';
import atcStyles from '../AddToCart/AddToCart.css';
import POBoxAddressModal from './POBoxAddressModal.async';
import RecommendToFriendModal from '../../containers/RecommendToFriendModal/RecommendToFriendModal.async';
import {
  STATE,
  ADD_TO_REGISTRY_LOGIN_RULE,
  BUTTON,
  HYPERLINK,
  DROPDOWN,
  FLIP_FLOP_PAGE_IDENTIFIER,
} from './constants';
import {
  setSFLNandDModalState,
  autoAddItemRevoked,
  toggleNandDmodalMountedState,
  getRegistryDropDownOptions,
  getListAndRegistryLayout,
  disableCta,
  setParentProductID,
  getRegistryById,
  addToRegistryStarted,
  isFriendRegistry as isFriendRegistryFn,
  moveItemToRegistryFromSFL,
  createRegRedirectPrams,
  guestUserTealiumATREvent,
  isListItem,
  validateLtlDslModalOptions,
  addToRegistryUtility,
  getListType,
} from './AddToRegistryUtil';
import LTLAltDslModal from '../../containers/LTLAltDslModal/LTLAltDslModal.async';
import NandDModal from './NandDModal.async';
import { ADD_TO_REGISTRY_QUERY_PARAM } from '../../containers/AddToRegistry/constants';
import CtaSkeleton from './CtaSkeleton/CtaSkeleton';
import { openAtrModalStateChange } from './AddToRegistryModalUtility';
import AddToRegistryPropTypes from './AddToRegistryPropTypes';
/**
 * @param {object} registries, contain the customer profile owned and recommended registried
 * @param {function} addToRegistry inherited from the AddToRegistry container component
 * @param {function} moveToRegistry inherited from the SavedLineItem component
 * @param {string} pageType pageType to handle defferent actions for different page type
 * @param {function} onClientError inherited from the AddToRegistry container component
 * @param {function} onSuccess inherited from the AddToRegistry container component
 * @param {function} onError inherited from the AddToRegistry container component
 * @param {bool} hideAtrModalState pass this props as true if you want to hide ATR Success Modal
 */
const QUERY_STRING = '?regType=';
const CREATE_REGISTRY_FORM_URL = '/store/giftregistry/createRegistryForm';
const getDefaultProps = () => {
  return {
    registries: {},
    addToRegistry: noop,
    moveToRegistry: noop,
    onClientError: noop,
    onSuccess: noop,
    onError: noop,
    pageType: '',
    altPhoneNumModal: '',
    wrapperClassName: 'pb1',
    hideAtrModalState: false,
    isFlipFLopATR: false,
    clickedFromPB: false,
  };
};
const EMPTY_OBJ = {};
let isSimulateRegLink = false;
/**
 * @class AddToRegistry | @extends {React.Component} |  AddToRegistry is a component that renders button or select element and handles the user action on it
 */
class AddToRegistry extends Component {
  /**
   * @static defaultProps \ @memberof AddToRegistry
   */
  static defaultProps = getDefaultProps();
  static propTypes = AddToRegistryPropTypes;
  /**
   * Creates an instance of AddToRegistry.
   * @param {any} props
   * @memberof AddToRegistry
   */
  constructor(props) {
    super(props);
    this.state = {
      regType: '',
      redirectToCreateRegistry: false,
      modalMinimizeState: false,
      PDPRedirectPath: '',
      NandModalMountedState: false,
      isDropDown: false,
    };
    this.isShow = false;
    this.uid =
      this.props.uniqueKey || uniqueKeys.getStatelessUniqueKey('AddToRegistry');
    this.setDefaultErrorState();
    this.skipNandD = 'false';
    this.isCartPage = isEqual('CART', this.props.pageType);
    this.autoAddItem = false; // this flag determines whether to trigger the AddToRegistry action post logon on PDP without user action
    this.selectedRegistryId = ''; // registry id cached for selected registry from dropdown
    this.ltlAltDslRegistryName = '';
    this.regGuestAltNumber = ''; // altphone number handled from gift giver view.
    this.state = { ...STATE, firstRender: true }; // firstRender state is added to avoid reconciliation issue of ATR button
    this.state.recommendModalMountedState =
      this.props.recommendModalMountedState || false;
    this.isListAndRegistryLayoutResolved = false;
    this.handleAddToRegistryClick = this.handleAddToRegistryClick.bind(this);
    this.handleAddToRegistry = this.handleAddToRegistry.bind(this);
    this.handleSelectedRegistry = this.handleSelectedRegistry.bind(this); // CustomSelect callback
    this.addItemToRegistryCallback = this.addItemToRegistryCallback.bind(this); // AuthValidator loginStateValidCallback
    this.onModalSelectionChange = this.onModalSelectionChange.bind(this); // registry type modal registry select
    this.toggleRegistryModalState = this.toggleRegistryModalState.bind(this); // registry type modal
    this.addItemToGiftRegistry = this.addItemToGiftRegistry.bind(this);
    this.moveItemToRegistryFromSFL = this.moveItemToRegistryFromSFL.bind(this);
    this.resetRegistryDropDown = this.resetRegistryDropDown.bind(this);
    this.getToastNotification = this.getToastNotification.bind(this);
    this.renderToastNotifcation = this.renderToastNotifcation.bind(this);
  }
  /**
   * @memberof AddToRegistry
   */
  componentDidMount() {
    const query = parse(location.search, { ignoreQueryPrefix: true });
    /* istanbul ignore if : this condition depends on browser location object */
    if (isEqual('true', query.addToRegistry)) {
      this.toggleATREventFiredState();
    }
    /* istanbul ignore else */
    if (this.isCartPage) {
      setSFLNandDModalState(this.props, this);
    }
    if (this.state.firstRender) this.toggleFirstRender();
  }

  /* eslint complexity: ["error", 18]*/
  componentWillReceiveProps(newProps) {
    const {
      data,
      error,
      productId,
      skuId,
      NandDFlag,
    } = this.props.addToRegistryState;
    const isSelectedSku =
      newProps.prodId === productId &&
      newProps.skuId === skuId &&
      newProps.addToRegistryState.uid === this.uid &&
      (this.isLTL
        ? newProps.ltlShipMethod === '' || !isEmpty(newProps.ltlShipMethod)
        : true);
    if (isSelectedSku) {
      /* istanbul ignore else  */
      if (
        this.autoAddItem &&
        newProps.registries &&
        newProps.registries.profileRegistryList && // check for ownandrecommended call to finish
        newProps.registryListFetched // check for all-registrty call to finish
      ) {
        const customerRegistries = newProps.registries.profileRegistryList;
        if (customerRegistries.length === 0) {
          this.toggleRegistryModalState(true);
        } else if (
          customerRegistries.length === 1 &&
          !isEmpty(newProps.registryId)
        ) {
          const wasGuestUser = true;
          this.addItemToGiftRegistry(newProps, wasGuestUser);
          this.autoAddItem = false;
          autoAddItemRevoked();
        } else {
          this.emptyStoreForGuestUser();
        }
      }
      if (
        newProps.addToRegistryState.NandDFlag &&
        newProps.addToRegistryState.NandDFlag !== NandDFlag &&
        this.skipNandD === 'false'
      ) {
        if (this.props.onModalHide) this.props.onModalHide();
        toggleNandDmodalMountedState(true, this);
      } else {
        this.setMountedState(newProps, data, error, this.isLTL); // Add To Registry action has been fired
      }
    }
    if (
      this.isCartPage &&
      this.props.cartSavedItemsIsFetching &&
      !newProps.cartSavedItemsIsFetching
    ) {
      setSFLNandDModalState(newProps, this);
    }
    if (
      newProps.closeLtlModalMountedState !==
        this.props.closeLtlModalMountedState &&
      newProps.closeLtlModalMountedState
    ) {
      this.setState({
        ltlModalMountedState: false,
      });
    }

    if (
      isBrowser() &&
      this.props.skuId !== null &&
      newProps.registries &&
      newProps.registries.profileRegistryList && // check for ownandrecommended call to finish
      newProps.registryListFetched // check for all-registrty call to finish
    ) {
      const type = getQueryString('type');
      if (type === 'addToRegistry' && isSimulateRegLink === false) {
        const totalRegistry = newProps.registries.profileRegistryList.length;
        let buttonRef = null;
        if (totalRegistry === 0 || totalRegistry === 1) {
          buttonRef = document.getElementById('addToRegistryLink');
          if (buttonRef === null) {
            buttonRef = document.getElementById('addToRegistryBtn');
          }
        } else {
          const registryId = getQueryString('registryId');
          buttonRef = document.querySelector(`[value='${registryId}']`);
        }
        if (buttonRef !== null) {
          buttonRef.click();
          isSimulateRegLink = true;
        }
      }
    }
  }
  shouldComponentUpdate(nextProps, nextState) {
    if (!isEqual(this.props, nextProps) || !isEqual(this.state, nextState)) {
      return true;
    }
    return false;
  }

  onModalSelectionChange(type) {
    const { pathName, search } = createRegRedirectPrams(this.props);
    this.setState({
      regType: type.registryCode,
      PDPRedirectPath: `${pathName}${search}`,
      redirectToCreateRegistry: true,
    });
    this.toggleRegistryModalState(false);
  }
  /**
   * @param {any} newProps | @param {any} data |  @param {any} error | @memberof AddToRegistry
   */

  setMountedState(newProps, inData, inError, isLTL) {
    const { addToRegistryState } = newProps;
    const { data, error, qty } = addToRegistryState;
    if ((data && data !== inData) || (error && error !== inError)) {
      const qtyOrig = isEmpty(error) ? 1 : qty;
      if (this.props.onModalHide) this.props.onModalHide();
      if (isLTL) {
        this.setState({ ltlModalMountedState: false }, () => {
          this.openAtrModal(qtyOrig);
        });
      } else if (this.state.NandDmodalMountedState) {
        this.setState({ NandDmodalMountedState: false }, () => {
          this.openAtrModal(qtyOrig);
        });
      } else {
        this.openAtrModal(qtyOrig);
      }
    }
  }
  /** @memberof AddToRegistry  */
  setDefaultErrorState() {
    this.error = {};
  }
  /**
   * @returns the CustomSelect Component |  @memberof AddToRegistry
   */
  getRegistryDropDown() {
    const {
      useLabelClass,
      disableAddToRegistryDropdown,
      wrapperClassName,
      dropDownPosition,
      maxNumberOfElementsToShow,
      labelClassName,
      enableCollegeList,
      swatchError,
      registryLabels,
      buttonProps,
      atrWrapperClass,
      preventLabelOverride,
    } = this.props;
    this.setState({ isDropDown: true });
    const optionSet = getRegistryDropDownOptions(this.props);
    let defaultDropdownHeading = null;
    if (!this.isCartPage && enableCollegeList === true) {
      const addToListRegistry = getListAndRegistryLayout(this.props);
      defaultDropdownHeading =
        preventLabelOverride && buttonProps.children
          ? buttonProps.children
          : LabelsUtil.getLabel(registryLabels, addToListRegistry.Label);
    }
    const isDisabled =
      disableAddToRegistryDropdown || this.isFetching || disableCta(this.props);
    return (
      <div
        className={classnames(
          styles.addtoRegistryBtn,
          atrWrapperClass,
          this.props.isFromPLP && 'setHeightATRPLP',
          'folDeep'
        )}
        id="atr-cta"
      >
        <CustomSelect
          optionSet={optionSet}
          variationName={
            this.props.isPrimaryATR ? 'selectATRPrimary' : 'selectPrimary'
          }
          defaultValue={this.state.selectedRegistryId}
          selectOption={this.handleSelectedRegistry}
          wrapperClassName={classnames(wrapperClassName)}
          labelClassName={classnames('inlineBlock', labelClassName, {
            [styles.labelClass]: useLabelClass,
          })}
          position={dropDownPosition}
          maxNumberOfElementsToShow={maxNumberOfElementsToShow}
          defaultDropdownHeading={defaultDropdownHeading}
          {...this.props.dropdownProps}
          isPrimaryATR={this.props.isPrimaryATR}
          disabled={isDisabled}
          ulClassName={this.props.isFromPLP && 'PLPATRdropdown'}
        />
        {!isTouchDevice() &&
          !isDisabled &&
          swatchError && (
            <CustomTooltip
              className={styles.errorToolTip}
              swatchError={swatchError}
              id={buttonProps.attr['aria-describedby']}
            />
          )}
        {enableCollegeList && this.getRegistryTypeModal()}
        {this.getPOBoxAddressModal()}
        {!this.state.ltlModalMountedState && this.getNandDModal()}
        {this.isLTL && this.getLTLAltDslModal()}
        {this.getATRModal()}
        {this.isCartPage && this.addSflModal()}
        {this.getRecommendModal()}
      </div>
    );
  }
  // returns Hyperlink component @memberof AddToRegistry
  getRegistryHyperlink() {
    const { buttonProps } = this.props;
    return (
      <Fragment>
        <PrimaryLink
          href="#"
          onClick={this.handleAddToRegistry}
          variation={buttonProps.attr.variation}
          className={classnames(buttonProps.attr.className)}
          iconProps={buttonProps.attr.iconProps}
          disabledLink={
            buttonProps.attr.disabled ||
            this.isFetching ||
            disableCta(this.props)
          }
          id="addToRegistryLink"
        >
          {buttonProps.children}
        </PrimaryLink>
        {this.getPOBoxAddressModal()}
        {this.isLTL && this.getLTLAltDslModal()}
        {this.getATRModal()}
        {this.isCartPage && this.addSflModal()}
        {this.getNandDModal()}
      </Fragment>
    );
  }
  /* return data-locator respective of Registry and List in ATR */
  getDataLocator(loadHyperlink, addToListRegistry) {
    const { buttonProps, registryLabels, registryId, registries } = this.props;
    if (!loadHyperlink) {
      if (addToListRegistry && addToListRegistry.Label === 'AddToList') {
        const registryData = getRegistryById(registryId, registries);
        const listType = getListType(registryData, registries, registryLabels);
        return `atr_addTo${listType}_button`;
      }
    }
    return pathOr('', 'attr.data-locator', buttonProps);
  }
  /**
   * @returns Button Component | @param {string} theme | @returns |  @memberof AddToRegistry
   */
  getRegistryButton(theme) {
    const {
      buttonProps,
      enableCollegeList,
      registryLabels,
      swatchError,
      atrWrapperClass,
      preventLabelOverride,
      isRecommendations,
      isFlipFLopATR,
      quickAddToRegistry,
      isInitLoadATR,
    } = this.props;
    let buttonLabel = buttonProps.children;
    let addToListRegistry;
    if (!this.isCartPage && enableCollegeList === true && !isRecommendations) {
      addToListRegistry = getListAndRegistryLayout(this.props, isFlipFLopATR);
      if (!preventLabelOverride) {
        buttonLabel = pathOr(
          'Add To Registry',
          addToListRegistry.Label,
          registryLabels
        );
      }
    }
    const isDisabled =
      buttonProps.disabled || quickAddToRegistry
        ? false
        : this.isFetching || disableCta(this.props);
    let btnTheme =
      (isInitLoadATR && !this.listAndRegistryLayoutResolved()) ||
      (isInitLoadATR && this.state.firstRender)
        ? 'deactivated'
        : theme || pathOr('', 'attr.theme', buttonProps);
    btnTheme =
      (btnTheme === 'secondaryWhite' ||
        btnTheme === 'deactivated' ||
        btnTheme === 'secondary') &&
      isDisabled
        ? 'secondaryWhiteDeactivated'
        : btnTheme;

    const loadHyperlink = pathOr(false, 'attr.loadHyperlink', buttonProps);

    return (
      <div
        className={classnames(
          styles.addtoRegistryBtn,
          atrWrapperClass,
          'folDeep'
        )}
        id="atr-cta"
      >
        {loadHyperlink ? (
          this.getRegistryHyperlink()
        ) : (
          <Button
            onClick={this.handleAddToRegistry}
            {...buttonProps.attr}
            disabled={isDisabled}
            theme={btnTheme}
            data-locator={this.getDataLocator(loadHyperlink, addToListRegistry)}
            id="addToRegistryBtn"
          >
            {buttonLabel}
          </Button>
        )}
        {!isTouchDevice() &&
          !isDisabled &&
          swatchError && (
            <CustomTooltip
              className={styles.errorToolTip}
              swatchError={swatchError}
              id={buttonProps.attr['aria-describedby']}
            />
          )}
        {this.getRegistryTypeModal()}
        {this.getPOBoxAddressModal()}
        {!this.state.ltlModalMountedState && this.getNandDModal()}
        {this.isLTL && !loadHyperlink && this.getLTLAltDslModal()}
        {!loadHyperlink && this.getATRModal()}
        {this.isCartPage && this.addSflModal()}
      </div>
    );
  }
  getRegistryTypeModal() {
    const { registryLabels } = this.props;
    const createRegistryLabels = registryLabels
      ? registryLabels.createRegistry
      : EMPTY_OBJ;
    return (
      this.state.createRegistryModalState && (
        <RegistryTypeModalWrapper
          isRegistryTypeOpen={this.state.createRegistryModalState}
          toggleRegistryModalState={this.toggleRegistryModalState}
          labels={createRegistryLabels}
          location={this.props.location}
          changeRegistryType={this.onModalSelectionChange}
          registryNotFound
          closeRegistryModal={this.closeRegistryTypeModal}
        />
      )
    );
  }
  getLTLAltDslModal() {
    return (
      <LTLAltDslModal
        {...this.props}
        toggleLTLModalState={this.toggleLTLModalState}
        ltlModalMountedState={this.state.ltlModalMountedState}
        showPhoneNumberInput={!this.regGuestAltNumber}
        altPhoneNumber={this.regGuestAltNumber}
        ltlAltDslRegistryId={this.selectedRegistryId}
        ltlAltDslRegistryName={this.ltlAltDslRegistryName}
        modalDescriptionClass={styles.modalDescription}
        uniqueKey={this.uid}
      />
    );
  }
  /**
   * @returns POBoxAddress Modal
   * @memberof AddToRegistry
   */
  getPOBoxAddressModal() {
    const { registryLabels, redirectTo } = this.props;
    return (
      <POBoxAddressModal
        labels={registryLabels}
        redirectTo={redirectTo}
        registryId={this.selectedRegistryId}
        togglePoBoxModalState={this.togglePoBoxModalState}
        poBoxModalMountedState={this.state.poBoxModalMountedState}
        editRegistryQueryParam={this.props.editRegistryQueryParam}
        modalDescriptionClass={styles.modalDescription}
      />
    );
  }
  getRecommendModal() {
    const { registryLabels, skuId } = this.props;
    return (
      <RecommendToFriendModal
        labels={registryLabels}
        toggleRecommendModalState={this.toggleRecommendModalState}
        recommendModalMountedState={this.state.recommendModalMountedState}
        registryId={this.selectedRegistryId}
        skuId={skuId}
      />
    );
  }
  getATRSuccessMessage(labels, registryName, checklistName, isListType) {
    return LabelsUtil.getLabel(
      labels,
      isListType ? 'ATLsuccessMessage' : 'ATRsuccessMessage'
    ).replace(':registryName', isListType ? checklistName : registryName);
  }
  // @returns  ATR Modal@memberof AddToRegistry
  getATRModal() {
    const {
      labels,
      enabledGlobalSwitches,
      endpoints,
      validationLabels,
      scene7UrlConfig,
      genericError,
      viewType,
      addToRegistryState,
      calledFromRegistry,
      resetVendorPriceDetails,
      porchPayLoadJson,
      disableATRModal,
      fireTealiumAction,
      selectedPlanDetails,
      pageIdentifier,
      quickViewTags,
      isATRModalHide,
    } = this.props;
    const {
      data,
      error,
      isFetching,
      skuId,
      productId,
      addedSkuAttrs,
      registryId,
      registryName,
      checklistName,
      qty,
      categoryId,
    } = addToRegistryState;
    const itemDetailsVO = pathOr([], 'component.itemDetailsVO', data);
    const isListType = pathOr(false, 'component.isListType', data);
    const itemSku = pathOr('', 'component.itemDetailsVO[0].skuId', data);
    const modalVariation = 'medium';
    const content =
      error || (itemDetailsVO && !itemDetailsVO.length) // whether ATR API response is successful
        ? {
            status: 'error',
            content: genericError,
          }
        : {
            status: 'success',
            content: this.getATRSuccessMessage(
              labels,
              registryName,
              checklistName,
              isListType
            ),
          };
    const enabledATRModal = pathOr('', 'enableATRModal', enabledGlobalSwitches);
    const enableATCRelatedCategories = pathOr(
      '',
      'enableATCRelatedCategories',
      enabledGlobalSwitches
    );

    if (
      isATRModalHide &&
      itemSku.toString() === this.props.skuId &&
      (pageIdentifier === 'PLP' ||
        pageIdentifier === 'SearchResults' ||
        pageIdentifier === 'BrandLanding') &&
      !isListType &&
      !isFetching &&
      !quickViewTags.isQuickViewOpen &&
      !isTbs()
    ) {
      return this.getToastNotification();
    } else if (
      !this.isShow &&
      !isFetching &&
      !disableATRModal &&
      this.state.atrModalMountedState &&
      !this.disableATRonQuickAdd
    ) {
      return enabledATRModal ? (
        <AsyncModalDialogWithATCModal
          mountedState={this.state.atrModalMountedState}
          dialogClass={atcStyles.atcModal}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'addedToRegistry')}
          verticallyCenter
          rclModalClass={classnames(atcStyles.addedTocartModal)}
          variation={modalVariation}
          hideParent={this.state.modalMinimizeState}
          scrollDisabled={false}
          data={data}
          isFetching={isFetching}
          toggleModalState={() => {
            this.toggleATRModalState(false);
          }}
          skuId={skuId}
          itemQty={qty}
          scene7UrlConfig={scene7UrlConfig}
          labels={labels}
          validationLabels={validationLabels}
          endpoints={endpoints}
          parentProductId={setParentProductID(this.props)}
          calledFromRegistry={calledFromRegistry}
          enableCertonaContainerATCATRModal={pathOr(
            '',
            'enableCertonaContainerATCATRModal',
            enabledGlobalSwitches
          )}
          enableCertona={pathOr('', 'enableCertona', enabledGlobalSwitches)}
          prodId={productId}
          categoryId={categoryId}
          enableATCRelatedCategories={enableATCRelatedCategories}
          registryId={registryId}
          messageContent={content}
          selectedProduct={addedSkuAttrs}
          viewType={viewType}
          resetVendorPriceDetails={resetVendorPriceDetails}
          pageIdentifier={this.props.pageIdentifier}
          closeNandDModal={() => {}}
          minimizeATCHandler={this.toggleMinimizeModal}
          isListType={isListType}
          registrySiteConfig={this.props.registrySiteConfig}
          favBadgePDPSiteSpect={this.props.favBadgePDPSiteSpect}
          setFavBadgePDPSiteSpect={this.props.setFavBadgePDPSiteSpect}
          isPorchPayloadAvailable={!!porchPayLoadJson}
          addToRegistryState={addToRegistryState}
          enabledGlobalSwitches={enabledGlobalSwitches}
          fireTealiumAction={fireTealiumAction}
          selectedPlanDetails={selectedPlanDetails}
        />
      ) : (
        <AsyncATRDefaultModal
          mountedState={this.state.atrModalMountedState}
          toggleModalState={this.toggleATRModalState}
          dialogClass={atcStyles.atcModal}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'addedToRegistry')}
          verticallyCenter
          rclModalClass={classnames(atcStyles.addedTocartModal)}
          variation={modalVariation}
          scrollDisabled={false}
          quantity={qty}
          content={content}
          closeTxt={LabelsUtil.getLabel(labels, 'closeBtnText')}
          labels={labels}
          onClose={() => {
            this.toggleATRModalState(false);
          }}
          endpoints={endpoints}
          registryId={registryId}
          isListType={isListType}
          selectedPlanDetails={selectedPlanDetails}
        />
      );
    }
    return '';
  }
  getToastNotification() {
    const showToast = pathOr('', 'toastNotification.show', this.props);
    if (showToast) {
      toast(this.renderToastNotifcation, { autoClose: 5000 });
      this.isShow = !this.isShow;
    }
  }

  getNandDModal() {
    const { addToRegistryState, NandDFlag } = this.props;
    const { isFetching } = addToRegistryState;
    if (!isFetching && NandDFlag === true) {
      return (
        <NandDModal
          selectedRegistryId={this.state.selectedRegistryId}
          selectedRegistryName={this.state.selectedRegistryName}
          NandDFlag={NandDFlag}
          NandDmodalMountedState={this.state.NandDmodalMountedState}
          toggleLTLModalState={this.toggleLTLModalState}
          addItemToGiftRegistry={this.addItemToGiftRegistry}
          quantity={this.state.cartItemQty}
          toggleNandDmodalMountedState={state =>
            toggleNandDmodalMountedState(state, this)}
          parentProductId={setParentProductID(this.props)}
          minimizeATCHandler={this.toggleMinimizeModal}
          toggleModalState={() => {
            this.toggleATRModalState(false);
          }}
          {...this.props}
        />
      );
    }
    return '';
  }
  toggleMinimizeModal = state => {
    this.setState({ modalMinimizeState: state });
  };
  addSflModal() {
    if (this.state.NandDmodalMountedState) {
      return (
        <NandDModal
          moveItemToRegistryFromSFL={this.moveItemToRegistryFromSFL}
          NandDmodalMountedState={this.state.NandDmodalMountedState}
          toggleNandDmodalMountedState={state =>
            toggleNandDmodalMountedState(state, this)}
          quantity={this.props.qty}
          addToCartFromSfl={this.props.addToCartFromSfl}
          IsSfl
          parentProductId={setParentProductID(this.props)}
          minimizeATCHandler={this.toggleMinimizeModal}
          toggleModalState={() => {
            this.toggleATRModalState(false);
          }}
          {...this.props}
        />
      );
    }
    return '';
  }
  closeRegistryTypeModal = () => {
    if (this.autoAddItem) {
      this.emptyStoreForGuestUser();
    }
  };
  emptyStoreForGuestUser() {
    this.props.modalATRDidClose();
    this.autoAddItem = false;
    autoAddItemRevoked();
  }
  /**
   * @param {*} qtyAdded | @param {*} qtySelected | @memberof AddToRegistry
   */
  openAtrModal(qtyOrig) {
    const { pageIdentifier, hideAtrModalState } = this.props;
    this.setState(
      {
        atrModalMountedState:
          pageIdentifier !== FLIP_FLOP_PAGE_IDENTIFIER && !hideAtrModalState, // please do not use this props unless you want to hide ATR success Modal
      },
      () => {
        openAtrModalStateChange(
          this.props,
          this.targetName,
          qtyOrig,
          this.resetRegistryDropDown
        );
      }
    );
  }
  //* Gets the fetching or busy state of the component @returns {bool}
  get isFetching() {
    return this.props.addToRegistryState.isFetching;
  }
  /**
   * @param {any} value : toggles the state of the registry type selection modal
   * @memberof AddToRegistry
   */
  toggleRegistryModalState(value) {
    this.setState({ createRegistryModalState: !!value }, () => {
      if (value && this.props.onModalHide) {
        this.props.onModalHide();
      } else if (value === false && this.props.closeQuickViewModal) {
        this.props.closeQuickViewModal();
      }
    });
  }
  /**
   * toggles the state of LTL Modal
   * @memberof AddToRegistry
   */
  toggleLTLModalState = value => {
    this.setState({ ltlModalMountedState: value }, () => {
      if (value) {
        this.resetRegistryDropDown();
        // Hide parent modal (QV) to prevent underlay clicks closing everything
        if (this.props.onModalHide) this.props.onModalHide();
      } else if (value === false && this.props.closeQuickViewModal) {
        // Close parent modal (QV) to remove from DOM
        this.props.closeQuickViewModal();
      }
    });
  };
  toggleRecommendModalState = (value = false) => {
    this.setState({ recommendModalMountedState: value }, () => {
      if (value) {
        if (this.props.onModalHide) this.props.onModalHide();
      } else {
        this.resetRegistryDropDown();
        if (this.props.closeQuickViewModal) this.props.closeQuickViewModal();
      }
    });
  };
  /**
   * toggles the state of LTL Modal
   * @memberof AddToRegistry
   */
  togglePoBoxModalState = value => {
    this.setState({ poBoxModalMountedState: value }, () => {
      if (value) {
        this.resetRegistryDropDown();
        // Hide parent modal (QV) to prevent underlay clicks closing everything
        if (this.props.onModalHide) this.props.onModalHide();
      } else if (value === false && this.props.closeQuickViewModal) {
        // Close parent modal (QV) to remove from DOM
        this.props.closeQuickViewModal();
      }
    });
  };
  /**
   * toggles the state of ATR Modal
   * @memberof AddToRegistry
   */
  toggleATRModalState = value => {
    this.setState({ atrModalMountedState: value }, () => {
      if (!value) {
        this.props.modalATRDidClose();
        if (this.props.resetVendorPriceDetails) {
          this.props.resetVendorPriceDetails();
        }
      }
    });
    if (this.props.closeQuickViewModal) this.props.closeQuickViewModal();
    if (pathOr(null, 'replaceProps.closeReplaceModal', this.props))
      this.props.replaceProps.closeReplaceModal();
    if (pathOr(null, 'quickAddProps.toggleChooseOptionState', this.props))
      this.props.quickAddProps.toggleChooseOptionState();
  };
  /**
   * @memberof AddToRegistry
   */
  resetRegistryDropDown() {
    this.setState({
      selectedRegistryId: 0,
    });
  }
  /**
   * @param {boolean} addItemToGiftRegistry controls whether to initiate the `add item` | it is written in callback because it depends on AuthValidator HOC |which gets rendered based on isATREventFired | and controls the flow for guest or logged on user
   * @memberof AddToRegistry
   */
  toggleATREventFiredState(addItemToGiftRegistry) {
    this.setState(
      {
        isATREventFired: !this.state.isATREventFired,
      },
      () => {
        if (addItemToGiftRegistry) {
          this.addItemToGiftRegistry();
        }
      }
    );
  }

  /** *
   * Check if the sku being added is bp sku , if yes then redirect to bp landing page
   * @returns {Boolean}
   */
  redirectIfBeyondPlusSKU() {
    const { skuId, pageConfigGlobal, redirectTo } = this.props;
    const beyondPlusSKUList = pathOr(
      null,
      'Global.beyondPlusSKUList',
      pageConfigGlobal
    );
    // convert beyondPlusSKUList string to list
    const bpSKUList = beyondPlusSKUList ? beyondPlusSKUList.split(',') : [];
    // redirect if beyondPlusSKUList is not empty and have a valid Beyond Plus skuId
    if (!isEmpty(bpSKUList) && bpSKUList.indexOf(skuId) !== -1) {
      return redirectTo(
        pathOr(
          ROUTE_BEYOND_PLUS_REDIRECT,
          'Global.beyondPlusUrl',
          pageConfigGlobal
        )
      );
    }
    return null;
  }

  replaceItem(selectedRegistryId) {
    const { replaceProps } = this.props;
    const { getReplacedItemData, replaceProductFromRegistry } = replaceProps;
    const productData = {
      replacedProductDetails: {
        skuId: this.props.skuId,
        registryName: pathOr('', 'nandDProps.eventType', replaceProps),
        qty: pathOr('', 'nandDProps.qtyRemaining', replaceProps),
        prodId: this.props.prodId,
        price: this.props.price,
        parentProductId: this.props.parentProductId,
        registryId:
          selectedRegistryId ||
          pathOr('', 'nandDProps.registryId', replaceProps),
      },
      discontinuedProductDetails: pathOr({}, 'nandDProps', replaceProps),
    };
    getReplacedItemData(
      this.props.selectedProduct.SCENE7_URL,
      this.props.selectedProduct.DISPLAY_NAME,
      this.props.skuId
    );
    replaceProductFromRegistry(productData);
    this.props.closeQuickViewModal();
  }
  /**
   * @param {any} selectedRegistryId |  @memberof AddToRegistry
   */
  handleSelectedRegistry(selectedRegistryId) {
    const { quickViewTags, isEnableATRRecommend } = this.props;
    if (this.props.isPLPLTL && !quickViewTags.isQuickViewOpen) {
      this.props.openLtlAtrMOdal();
    } else {
      const { registries, pageIdentifier, certonaIdentifier } = this.props;
      if (certonaIdentifier === 'AddToCart_rr' && isEnableATRRecommend) {
        this.props.track('RecommATRCount');
      }
      if (pageIdentifier === FLIP_FLOP_PAGE_IDENTIFIER) {
        this.props.track('flipFlopAddToRegFromMSWP_SS');
      }
      if (this.props.clickedFromPB && this.props.track) {
        this.props.track('click_AddToRegisryProdBundle');
      }
      if (this.redirectIfBeyondPlusSKU()) {
        return; // Redirect to beyond plus if bp sku
      }
      if (
        this.props.replaceProps &&
        selectedRegistryId ===
          pathOr('', 'replaceProps.nandDProps.registryId', this.props)
      ) {
        this.replaceItem(selectedRegistryId);
        return;
      }
      if (pathOr(false, 'quickAddProps.fromQuickAdd', this.props)) {
        if (this.props.quickAddProps.ovRegistryId === selectedRegistryId)
          this.disableATRonQuickAdd = true;
        else this.disableATRonQuickAdd = false;
      }
      /* istanbul ignore else */
      if (selectedRegistryId) {
        this.selectedRegistryId = selectedRegistryId;
        const selectedRegistry = getRegistryById(
          selectedRegistryId,
          registries
        );
        this.isShow = false;
        const selectedRegistryName = pathOr('', 'eventType', selectedRegistry);
        const alternatePhoneNumber = pathOr(
          '',
          'alternatePhone',
          selectedRegistry
        );
        // If provided, fire the SiteSpect tracking function now
        if (this.props.fireSSTrack) this.props.fireSSTrack();
        addToRegistryStarted(this.props, this.uid, !this.disableATRonQuickAdd);
        if (this.isCartPage) {
          this.moveItemToRegistryFromSFL(selectedRegistryId);
          this.setState({
            selectedRegistryId,
          });
        } else {
          this.setState({
            selectedRegistryId,
            selectedRegistryName,
            alternatePhoneNumber,
          });
          const isFriendRegistry = isFriendRegistryFn(
            selectedRegistryId,
            registries
          );
          // check SKU validations
          if (!this.checkSkuValidations(isFriendRegistry)) return;
          if (!isFriendRegistry) {
            this.addItemToGiftRegistry(
              undefined,
              false, // guest user can only be true in case of single registry
              selectedRegistryId,
              selectedRegistryName,
              selectedRegistry
            );
          } else {
            this.toggleRecommendModalState(true);
          }
        }
      } else if (isEmpty(selectedRegistryId)) {
        this.toggleRegistryModalState(true);
      }
    }
  }
  /**
   * Moves an Item to registry from Saved Line items on cart page | @param {number} selectedRegistryId Selected Registry ID | @memberof AddToRegistry
   */
  moveItemToRegistryFromSFL(selectedRegistryId, skipNotifyFlag = 'false') {
    moveItemToRegistryFromSFL(selectedRegistryId, skipNotifyFlag, this);
  }
  /**
   * Redirect to BeyondPlus Page for BeyondPlus SkuId, else add to normal cart. @memberof AddToRegistry
  */
  handleAddToRegistry(evt) {
    const { quickViewTags, isEnableATRRecommend } = this.props;
    if (this.props.isPLPLTL && !quickViewTags.isQuickViewOpen) {
      this.props.openLtlAtrMOdal();
    } else {
      evt.preventDefault();
      const { pageIdentifier, certonaIdentifier } = this.props;
      if (certonaIdentifier === 'AddToCart_rr' && isEnableATRRecommend) {
        this.props.track('RecommATRCount');
      }
      if (pageIdentifier === FLIP_FLOP_PAGE_IDENTIFIER) {
        this.props.track('flipFlopAddToRegFromMSWP_SS');
      }
      if (this.props.replaceProps) {
        this.replaceItem();
        return;
      }
      if (pathOr(false, 'quickAddProps.fromQuickAdd', this.props)) {
        this.disableATRonQuickAdd = true;
      }
      const { clickedFromPB, track } = this.props;
      if (clickedFromPB && track) {
        track('click_AddToRegisryProdBundle');
      }
      this.isShow = false;
      if (!this.redirectIfBeyondPlusSKU()) {
        // redirect to beyond plus if bp sku
        this.handleAddToRegistryClick(evt);
      }
    }
  }
  handleAddToRegistryClick(evt) {
    this.targetName = pathOr('', 'target.name', evt);
    // If provided, fire the SiteSpect tracking function now
    if (this.props.fireSSTrack) this.props.fireSSTrack();
    addToRegistryStarted(this.props, this.uid);
    if (this.isCartPage) {
      this.moveItemToRegistryFromSFL();
    } else {
      const { selectDslOnModal, validateLtlDslOnModal } = this.props;
      // check SKU validations but skip from registry guest view
      if (
        !(selectDslOnModal || validateLtlDslOnModal) &&
        !this.checkSkuValidations()
      )
        return;
      this.toggleATREventFiredState(true);
    }
    if (isGuestUser()) {
      guestUserTealiumATREvent(this.props);
    }
  }
  // @returns @memberof AddToRegistry
  checkSkuValidations(isFriendRegistry) {
    let canBeAdded = true;
    const {
      skuId,
      qty,
      ltlFlag,
      ltlShipMethod,
      size,
      swatch,
      onClientError,
      updateCallToAction,
      products,
    } = this.props;
    const argsForSKUValidations = products || {
      qty,
      ltlFlag,
      ltlShipMethod,
      skuId,
      size,
      swatch,
      isFriendRegistry,
    };
    // check if color/finish/size/dsl selected
    if (Array.isArray(argsForSKUValidations)) {
      argsForSKUValidations.forEach(args => {
        this.checkValidations(args);
      });
    } else {
      this.checkValidations(argsForSKUValidations);
    }
    // if no SKU available, show error
    if (!isEmpty(this.error)) {
      canBeAdded = false;
      onClientError(this.error);
      if (updateCallToAction) {
        updateCallToAction(ACTION_REGISTRY);
      }
      if (isFriendRegistry) {
        if (this.error[NO_QTY] || this.error[NO_SIZE] || this.error[NO_SWATCH])
          this.resetRegistryDropDown();
        else canBeAdded = true;
      } else {
        this.resetRegistryDropDown();
      }
      this.setDefaultErrorState();
    }
    return canBeAdded;
  }
  checkIfListItem(selectedRegistry, registries, registryLabels) {
    const { isCollegeList, isMoversList } = isListItem(
      selectedRegistry,
      registries,
      registryLabels
    );
    const isList = isCollegeList || isMoversList;
    return isList;
  }
  /**
   * @param {any} activeRegistryId | @param {any} selectedRegistry |  @returns {boolean} if LTL can be added | opens po box modal or alternate LTL number modal | @memberof AddToRegistry
   */
  checkLTLConditions(argsForLTLValidations) {
    const {
      activeRegistryId,
      selectedRegistry,
      registries,
      selectDslOnModal,
      altPhoneNumModal,
      registryLabels,
    } = argsForLTLValidations;
    let registrySelected = selectedRegistry;
    let canBeAdded = true;
    const isList = this.checkIfListItem(
      selectedRegistry,
      registries,
      registryLabels
    );
    /* istanbul ignore else */
    if (this.isLTL) {
      /* istanbul ignore else */
      if (!registrySelected && activeRegistryId) {
        registrySelected = getRegistryById(activeRegistryId, registries);
      }
      // check poBoxAddress
      const hasPoBoxAddress = pathOr('', 'poBoxAddress', registrySelected);
      if (hasPoBoxAddress && !isList) {
        canBeAdded = false;
        this.selectedRegistryId = pathOr('', 'registryId', registrySelected);
        this.togglePoBoxModalState(true);
      } else {
        canBeAdded = validateLtlDslModalOptions(argsForLTLValidations);
        /* istanbul ignore else */
        if (canBeAdded) {
          const alternatePhone =
            pathOr('', 'alternatePhone', registrySelected) || altPhoneNumModal;
          if (selectDslOnModal) {
            this.regGuestAltNumber = alternatePhone;
          }
          /* istanbul ignore else  */
          if (selectDslOnModal || (isEmpty(alternatePhone) && !isList)) {
            canBeAdded = false;
            this.selectedRegistryId = pathOr(
              '',
              'registryId',
              registrySelected
            );
            this.ltlAltDslRegistryName = pathOr(
              '',
              'eventType',
              registrySelected
            );
            this.toggleLTLModalState(true);
          }
        }
      }
    }
    return canBeAdded;
  }
  // * @param {any} argsForValidations * @memberof AddToRegistry
  checkValidations(argsForValidations) {
    const {
      qty,
      ltlShipMethod,
      skuId,
      size,
      swatch,
      isFriendRegistry,
    } = argsForValidations;
    if (qty <= 0) {
      this.error[NO_QTY] = NO_QTY;
    }
    if (skuId && this.isLTL && (ltlShipMethod !== '' && !ltlShipMethod)) {
      this.error[NO_LTL] = NO_LTL;
    }
    if (isFriendRegistry) {
      this.error[NO_LTL] = '';
    }
    /*
     * no SKU selected | DO NOT USE isEmpty for null check in case of skuId |as isEmpty has a bug for Numeric values | and this component is used on different pages
     * and skuId is getting consumed as Number and String both from different parent components
     */
    if (!skuId) {
      if (isEmpty(size)) this.error[NO_SIZE] = NO_SIZE; // no size
      if (isEmpty(swatch)) this.error[NO_SWATCH] = NO_SWATCH; // no color
    }
  }
  /**
   * @param {any} newProps | @param {any} selectedRegistryId in case of dropdown|@param {any} selectedRegistryName in case of dropdown |@param {any} selectedRegistry in case of dropdown
   * @memberof AddToRegistry
   */
  addItemToGiftRegistry(
    newProps,
    wasGuestUser = false,
    selectedRegistryId,
    selectedRegistryName,
    selectedRegistry,
    skipNotifyFlagVal = this.props.plpATRskipNotifyFlag || 'false'
  ) {
    const {
      ltlAltRegistryId,
      registryId,
      ltlFlag,
      validateAltPhoneNum,
      validateLtlDslOption,
      altPhoneNumModal,
      selectDslOnModal,
      registries,
      validateLtlDslOnModal,
      registryLabels,
    } =
      newProps || this.props;
    if (altPhoneNumModal && registryId) {
      const sessionUtil = new SessionStorageUtil(isBrowser());
      sessionUtil.saveItem('altNumber', altPhoneNumModal);
    }
    this.skipNandD = skipNotifyFlagVal;
    // activeRegistryId belongs to the registry selected by user to add the item
    const activeRegistryId =
      ltlAltRegistryId || selectedRegistryId || registryId;
    // no registry: open registry type selection modal
    if (isEmpty(activeRegistryId)) {
      this.toggleRegistryModalState(true);
      return;
    }
    // args to perform LTL validations: alternate no and po box registry address
    const argsForLTLValidations = {
      ltlFlag,
      activeRegistryId,
      selectedRegistry,
      validateAltPhoneNum,
      validateLtlDslOption,
      altPhoneNumModal,
      selectDslOnModal,
      registries,
      validateLtlDslOnModal,
      registryLabels,
    };
    // evaluate the LTL conditions
    const canBeAdded = !JSON.parse(skipNotifyFlagVal)
      ? this.checkLTLConditions(argsForLTLValidations)
      : true;
    const props = this.props;
    addToRegistryUtility({
      newProps,
      wasGuestUser,
      selectedRegistryId,
      selectedRegistryName,
      skipNotifyFlagVal,
      props,
      canBeAdded,
      selectedRegistry,
      registries,
      shouldFireRegApi: this.disableATRonQuickAdd,
    });
  }
  /**
   * checkIfLoggedOn redirects to the sign in page if user is not signed in else to the PDP page | @param (object) location | @param {object} route
   */
  checkIfLoggedOn() {
    const { isATREventFired } = this.state;
    const { location, skuId, products, verificationType } = this.props;
    if (!isATREventFired || (!skuId && !products)) {
      return null;
    }
    const isRecognized = isUserRecognized();
    const isPendingDeviceVerificationFlow =
      !isEmpty(verificationType) && isRecognized;
    if (!isRecognized || isPendingDeviceVerificationFlow) {
      const { pathName, search } = createRegRedirectPrams(this.props);
      return (
        <AuthValidator
          location={location}
          route={`${pathName}${search}`}
          loginStateValidCallback={this.addItemToRegistryCallback}
          pathName={pathName}
          search={search}
          loginRule={ADD_TO_REGISTRY_LOGIN_RULE}
          noReplaceState
          allowRecognizedWithCallback={isPendingDeviceVerificationFlow}
        />
      );
    }
    return false;
  }
  toggleFirstRender = () => {
    this.setState({ firstRender: false });
  };
  // @memberof AddToRegistry
  addItemToRegistryCallback() {
    /* istanbul ignore next */
    const query = parse(location.search, { ignoreQueryPrefix: true });
    /* istanbul ignore if : this condition depends on browser location object */
    if (isEqual('true', query.addToRegistry)) {
      this.autoAddItem = true;
      // replace the unique stateless key identifier to represent the same instance of anonymous AddToRegistry
      this.uid = this.props.addToRegistryState.uid;
    }
  }
  /**
   * This function will check if layout of Add to registry is resolved (whether it will add to registry, add to list or dropdown)
   * This is done by checking if own-recommended registry API call is completed or if user is guest
   */
  listAndRegistryLayoutResolved() {
    const { ownRecommendedRegistriesFetched } = this.props;
    if (!this.isListAndRegistryLayoutResolved) {
      const isGuest = isGuestUser();
      this.isListAndRegistryLayoutResolved =
        ownRecommendedRegistriesFetched || isGuest;
    }
    return this.isListAndRegistryLayoutResolved;
  }
  renderToastNotifcation() {
    const {
      toastNotification: { content },
      selectedProduct,
      addToRegistryState,
    } = this.props;

    let renderableContent = null;
    if (!isEmpty(content)) {
      const id = addToRegistryState.registryId;
      const toRegistryPath = compile(
        '/store/giftRegistry/viewRegistryOwner/myItems/:id?'
      );
      let skuAdded = '';
      skuAdded = addToRegistryState && `?skuAdded=${addToRegistryState.skuId}`;
      const viewlink = toRegistryPath({ id });
      const displayName = decodeHtmlEntities(selectedProduct.DISPLAY_NAME);
      renderableContent = (
        <div className={styles.toastContentWrapper}>
          <div>
            <PrimaryLink
              variation="secondaryWhite"
              className={styles.toastItemsLink}
              href={`${viewlink}${skuAdded}`}
            >
              {truncate(displayName, '30')}
            </PrimaryLink>
            <span> {' has been added to your registry'} </span>
          </div>
          <div className={styles.toastViewRegistryLinkWrapper}>
            <PrimaryLink
              variation="secondaryWhite"
              className={styles.toastItemsLink}
              href={`${viewlink}${skuAdded}`}
            >
              {'View Registry'}
            </PrimaryLink>
          </div>
        </div>
      );
    }
    return renderableContent;
  }

  renderAddToRegistryLayout() {
    let addToRegistryLayout;
    const {
      registries,
      ltlAltBtnTheme,
      ctaType,
      altDslCtaType,
      isFlipFLopATR,
      isInitLoadATR,
      ltlFlag,
      isRegistryButton,
    } = this.props;
    const ownedRegistries = pathOr([], 'profileRegistryList', registries);
    const recommendedRegistries = pathOr(
      [],
      'recommendedRegistryList',
      registries
    );
    this.isLTL = isEqual('true', ltlFlag) || isEqual(true, ltlFlag);
    if (isEqual(BUTTON, altDslCtaType) || isEqual(BUTTON, ctaType))
      return this.getRegistryButton(ltlAltBtnTheme);
    if (isEqual(HYPERLINK, ctaType)) return this.getRegistryHyperlink();
    const addToListRegistry = getListAndRegistryLayout(
      this.props,
      isFlipFLopATR
    );
    if (isRegistryButton) return this.getRegistryButton();
    if (!this.isCartPage && this.props.enableCollegeList === true) {
      if (isInitLoadATR && !this.listAndRegistryLayoutResolved()) {
        return this.getRegistryButton();
      } else if (!this.listAndRegistryLayoutResolved()) {
        return <CtaSkeleton />;
      }
      if (addToListRegistry.Layout === BUTTON) {
        return this.getRegistryButton();
      } else if (addToListRegistry.Layout === DROPDOWN) {
        return this.getRegistryDropDown();
      }
    }
    if (
      (recommendedRegistries.length > 0 || ownedRegistries.length > 1) &&
      addToListRegistry.Layout === DROPDOWN
    ) {
      addToRegistryLayout = this.getRegistryDropDown();
    } else {
      addToRegistryLayout = this.getRegistryButton();
    }
    return addToRegistryLayout;
  }
  render() {
    const {
      redirectToCreateRegistry,
      regType,
      PDPRedirectPath,
      isDropDown,
    } = this.state;
    const loadHyperlink = pathOr(
      false,
      'attr.loadHyperlink',
      this.props.buttonProps
    );
    return (
      <ErrorBoundary>
        {loadHyperlink && !isDropDown && <Icon type={'gift'} />}
        {this.checkIfLoggedOn()} {this.renderAddToRegistryLayout()}
        {redirectToCreateRegistry && (
          <Redirect
            push
            to={{
              pathname: CREATE_REGISTRY_FORM_URL,
              search: `${QUERY_STRING}${regType}&${ADD_TO_REGISTRY_QUERY_PARAM}`,
              params: {
                redirect: PDPRedirectPath,
              },
            }}
          />
        )}
      </ErrorBoundary>
    );
  }
}
export const AddToRegistryTest = withRouter(AddToRegistry);
export default compose(withRouter, withSiteSpectTracker)(toJS(AddToRegistry));
