/**
 * Add to registry CTA type,
 * It could be combination of Button or Dropdown based on number of Registries available or single registry
 * Hyper link is used where dropdown is not needed, and product will be added directly to Active registry if available.
 */
export const BUTTON = 'button';
export const DROPDOWN = 'dropdown';
export const HYPERLINK = 'hyperlink';
export const SELECT = 'select';

export const ADD_TO_REGISTRY_LOGIN_RULE = 'addToRegistry';
export const ADD_TO_REGISTRY_TEALIUM_ACTION = 'add_item_to_registry';
export const ACCESSORY_PRODUCT = 'ACCESSORY';
export const COLLECTION_PRODUCT = 'COLLECTION';
export const STATE = {
  selectedRegistryId: 0, // id of registry that corresponds to the selected state of dropdown
  selectedRegistryName: '',
  atrModalMountedState: false,
  ltlModalMountedState: false,
  poBoxModalMountedState: false,
  isATREventFired: false, // this state property indicates that the user has initiated ATR action and determines to render the AuthValidator component
  createRegistryModalState: false,
  NandDmodalMountedState: false,
};
export const ND_MODAL_PAGE_TYPE = 'product';
export const ND_MODAL_PAGNAME_BREADCRUMB = 'N&D modal';
export const ND_MODAL_PAGE_NAME = 'nd modal';
export const FLIP_FLOP_PAGE_IDENTIFIER = 'RegistryFlipFlops';
export const COLLEGE_CHECKLIST = 'CollegeChecklist';
export const MOVERS_CHECKLIST = 'MoversChecklist';
export const PNH_CHECKLIST = 'PNHChecklist'; // Used for Tealium
export const MOVER_LIST_PAGE = 'moverListPage'; // for identify mover list
export const TEALIUM_RGG_INFO = {
  page_type: 'Registry',
  page_name: 'add to registry',
};
export const TEALIUM_PA_INFO = {
  page_type: 'Product Details Page',
  page_name: 'add to registry',
};
