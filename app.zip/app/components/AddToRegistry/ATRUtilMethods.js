import pathOr from 'lodash/fp/pathOr';

export function deleteTealiumTagsByLocation(location, registryTags) {
  const tealiumTags = registryTags;
  const search = pathOr('', 'search', location);
  const pathname = pathOr('', 'pathname', location);
  if (search.includes('?keyword=') || pathname.includes('/store/s')) {
    tealiumTags.category_id = '';
    tealiumTags.brand_id = '';
  } else if (
    search.includes('?brandId=') ||
    pathname.includes('/store/brand')
  ) {
    tealiumTags.search_words_applied = '';
    tealiumTags.category_id = '';
  } else if (
    search.includes('?categoryId=') ||
    pathname.includes('/store/category')
  ) {
    tealiumTags.search_words_applied = '';
    tealiumTags.brand_id = '';
  }
  return tealiumTags;
}
