/* eslint max-lines: ["error", {"max": 1070}] */
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import qs, { stringify, parse } from 'qs';
import { isEqual, isEmpty } from 'lodash';
import { fromJS } from 'immutable';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { noop } from '@bbb-app/utils/common';
import { PDP_PAGENAME_BREADCRUMB } from '@bbb-app/tealium/constants';
import { getPersonalizationTypeForTealium } from '@bbb-app/tealium/tagSelectors/utils';
import {
  ACCESSORY_PRODUCT,
  BUTTON,
  DROPDOWN,
  COLLECTION_PRODUCT,
  COLLEGE_CHECKLIST,
  MOVERS_CHECKLIST,
  PNH_CHECKLIST,
  MOVER_LIST_PAGE,
  TEALIUM_RGG_INFO,
  TEALIUM_PA_INFO,
} from './constants';
import { moveToRegistryTealiumInfo } from './moveToRegistryTealiumInfo';
import getParentProductData from '../Pages/PDP/ProductDetails/Utils/getParentProductData';
import atrTealiumInfo from '../../containers/AddToRegistry/atrTealiumInfo';
import { deleteTealiumTagsByLocation } from './ATRUtilMethods';

/**
 * @param{object} registries, contain the customer profile owned and recommended registried
 * @param {function} addToRegistry inherited from the AddToRegistry container component
 * @param {function} moveToRegistry inherited from the SavedLineItem component
 * @param {string} pageType pageType to handle defferent actions for different page type
 * @param {function} onClientError inherited from the AddToRegistry container component
 * @param {function} onSuccess inherited from the AddToRegistry container component
 * @param {function} onError inherited from the AddToRegistry container component
 */
export const getDefaultProps = () => {
  return {
    registries: {},
    addToRegistry: noop,
    moveToRegistry: noop,
    onClientError: noop,
    onSuccess: noop,
    onError: noop,
    pageType: '',
    altPhoneNumModal: '',
    wrapperClassName: 'pb1',
  };
};
/**
 * PropTypes
 * @param {string} skuId Sku ID of the Product to be added in the registry
 * @param {string} prodId product Id of the Product to be added in the registry
 * @param {string} wishListItemId wishListItemId of the Product to be added in the registry
 * @param {object} registries contain the customer profile owned and recommended registried
 * @param {object} buttonProps Additional Props to passed to select button
 * @param {object} dropdownProps Additional Props to passed to select Secect
 * @param {function} onSuccess Method to call on sucess of add to registry
 * @param {function} onError Method to call on error of add to registry
 * @param {number} qty qty of the Product to be added in the registry
 * @param {string} registryName Name of the registry Name
 * @param {object} addToRegistryState Current state of the registry
 * @param {string} addToRegistryQueryParam Query Params to send with add to Registry call
 * @param {object} location Current Location of the page
 * @param {object} history History
 * @param {error} genericError genericError
 * @param {object} registryLabels lables to be passed by the parent component
 * @param {string} pageType To handle different actions for different page type
 * @param {function} moveToRegistry Handler for move to registry action on cart page
 * @param {number} itemIndex Item index to be passed if necassary to add to registry
 * @param {string} PDP_URL url of the product details page
 * @param {function} addToRegistryInitiated sets the prodId, skuId in the store of the SKU selected
 * @param {function} modalATRDidClose clears the prodId, skuId in the store of the SKU selected
 * @param {string} ctaType type of the ATR component to be rendered, [button | hyperlink]
 * @param {string} viewType view type to be passed to add to registry CTA in certona
 * @param {string} ltlAltBtnTheme theme of the ATR button on the alt no. modal
 * @param {string} useLabelClass class applied to the dropdown in case of child cgrid view pdp
 * @param {string} disableAddToRegistryDropdown disbales dropdown
 * @param {string} redirectTo function that pushes location to the browser history
 * @param {string} ltlFlag whther ltl SKU
 */
export const getPropTypes = () => {
  return {
    skuId: PropTypes.string,
    wishListItemId: PropTypes.string,
    registries: PropTypes.object,
    buttonProps: PropTypes.object,
    dropdownProps: PropTypes.object,
    onSuccess: PropTypes.func,
    onError: PropTypes.func,
    qty: PropTypes.number,
    registryName: PropTypes.string,
    addToRegistryState: PropTypes.object,
    addToRegistryQueryParam: PropTypes.string,
    editRegistryQueryParam: PropTypes.string,
    location: PropTypes.object.isRequired,
    history: PropTypes.object,
    genericError: PropTypes.string,
    registryLabels: PropTypes.object,
    enabledGlobalSwitches: PropTypes.object,
    labels: PropTypes.object,
    validationLabels: PropTypes.object,
    endpoints: PropTypes.object,
    scene7UrlConfig: PropTypes.object,
    registryId: PropTypes.string,
    selectedProduct: PropTypes.object,
    pageType: PropTypes.string,
    moveToRegistry: PropTypes.func,
    itemIndex: PropTypes.number,
    prodId: PropTypes.string,
    productType: PropTypes.string,
    PDP_URL: PropTypes.string,
    addToRegistryInitiated: PropTypes.func,
    modalATRDidClose: PropTypes.func,
    ctaType: PropTypes.string,
    viewType: PropTypes.string,
    ltlAltBtnTheme: PropTypes.string,
    useLabelClass: PropTypes.bool,
    disableAddToRegistryDropdown: PropTypes.bool,
    redirectTo: PropTypes.func,
    ltlFlag: PropTypes.string,
    tealiumData: PropTypes.object,
    ltlData: PropTypes.object,
    closeQuickViewModal: PropTypes.func,
    onModalHide: PropTypes.func,
    parentProductId: PropTypes.string,
    calledFromRegistry: PropTypes.bool,
    pageIdentifier: PropTypes.string,
    skipNotifyFlag: PropTypes.string,
    productDetails: PropTypes.object,
  };
};
/**
 * @param {any} registryId
 * @param {any} registries
 * @returns the registry with the passed registryId
 */
export const getRegistryById = (registryId, registries) => {
  let selectedRegistry;
  const ownedRegistries = pathOr([], 'profileRegistryList', registries);
  const recommendedRegistries = pathOr(
    [],
    'recommendedRegistryList',
    registries
  );
  const listTypeRegistries = pathOr([], 'profilelistTypeRegList', registries);
  const pnhListRegistries = pathOr([], 'profilePackAndHoldList', registries);

  selectedRegistry = ownedRegistries.find(
    item => registryId === item.registryId
  );

  if (typeof selectedRegistry === 'undefined' && recommendedRegistries.length) {
    selectedRegistry = recommendedRegistries.find(
      item => registryId === item.registryId
    );
  }
  if (typeof selectedRegistry === 'undefined' && listTypeRegistries.length) {
    selectedRegistry = listTypeRegistries.find(
      item => registryId === item.registryId
    );
  }
  if (typeof selectedRegistry === 'undefined' && pnhListRegistries.length) {
    selectedRegistry = pnhListRegistries.find(
      item => registryId === item.registryId
    );
  }
  return selectedRegistry;
};
export const isFriendRegistry = (registryId, registries) => {
  const recommendedRegistries = pathOr(
    [],
    'recommendedRegistryList',
    registries
  );
  if (!recommendedRegistries.length) return false;
  const selectedFriendRegistry = recommendedRegistries.find(
    item => registryId === item.registryId
  );
  if (!isEmpty(selectedFriendRegistry)) return true;
  return false;
};
const getCreateRegistryLink = (
  optionsSet,
  registryLabels,
  addToRegistryHeading
) => {
  const createRegLink = {
    key: null,
    label: LabelsUtil.getLabel(registryLabels, 'createRegistryLbl'),
    props: {
      value: null,
      class: 'noIndentation createRegistryButton',
    },
  };
  optionsSet.push(addToRegistryHeading, createRegLink);
  return optionsSet;
};
export const getFriendsRegistries = (
  optionsSet,
  registryLabels,
  friendsRegistries,
  refNum
) => {
  const registryReccomendedList = friendsRegistries.map(item => {
    const coRegistrantFirstName = item.coRegistrantFirstName;
    return {
      key: item.registryId,
      label: coRegistrantFirstName
        ? `${item.primaryRegistrantFirstName} & ${coRegistrantFirstName}'s ${item.eventType} ${item.eventDate}`
        : `${item.primaryRegistrantFirstName}'s ${item.eventType} ${item.eventDate}`,
      props: {
        value: item.registryId,
        class: 'noIndentation',
        disableOption: !!refNum,
      },
    };
  });
  /* istanbul ignore else  */
  if (registryReccomendedList.length) {
    registryReccomendedList.splice(0, 0, {
      label: LabelsUtil.getLabel(registryLabels, 'FriendRegistry'),
      isHeading: true,
      classToAdd: 'addToRegListHeading',
      props: {
        value: '0',
      },
    });
    optionsSet.push(...registryReccomendedList);
  }
  return optionsSet;
};
/**
 * @param {any} props
 * @returns Options array for CustomSelect component
 * @memberof AddToRegistry
 */
export const getRegistryDropDownOptions = args => {
  const {
    registryLabels,
    registries,
    enableCollegeList,
    pageType,
    refNum,
    isEnableMoverListPDP,
    enableRegistryRecommendations,
  } = args;
  const addToRegistryLabel = getAddToRegistryLabel(args);
  const ownedRegistries = pathOr([], 'profileRegistryList', registries);
  const isCartPage = isEqual('CART', pageType);
  const recommendedRegistries = pathOr(
    [],
    'recommendedRegistryList',
    registries
  );
  const registryOwnedList = ownedRegistries.map(item => {
    return {
      key: item.registryId,
      label: `${item.eventType} Registry ${item.eventDate}`,
      props: {
        value: item.registryId,
        class: 'noIndentation',
      },
    };
  });
  const addToRegistryHeading = {
    label: addToRegistryLabel,
    isHeading: true,
    classToAdd: 'addToRegListHeading',
    props: {
      value: '0',
    },
  };
  let optionsSet = [addToRegistryHeading, ...registryOwnedList];
  if (!isCartPage) {
    if (enableCollegeList) {
      if (registryOwnedList.length === 0) {
        optionsSet.shift();
      }
      if (enableRegistryRecommendations && recommendedRegistries.length) {
        // social recommendation flow
        optionsSet = getFriendsRegistries(
          optionsSet,
          registryLabels,
          recommendedRegistries,
          refNum
        );
      }
      const listTypeRegistries = pathOr(
        [],
        'profilelistTypeRegList',
        registries
      );
      let collegeListTypeRegistries = listTypeRegistries.map(item => {
        const fromPage = item.fromPage;
        if (
          fromPage !== MOVER_LIST_PAGE ||
          (isEnableMoverListPDP && fromPage === MOVER_LIST_PAGE)
        ) {
          return {
            key: item.registryId,
            label: `${item.checklistname}`,
            props: {
              value: item.registryId,
              class: 'noIndentation',
            },
          };
        }
        return false;
      });
      /* istanbul ignore else  */
      collegeListTypeRegistries = collegeListTypeRegistries.filter(Boolean);
      if (collegeListTypeRegistries.length) {
        collegeListTypeRegistries.splice(0, 0, {
          label: LabelsUtil.getLabel(registryLabels, 'AddToList'),
          isHeading: true,
          classToAdd: 'addToRegListHeading',
          props: {
            value: '0',
          },
        });
        optionsSet.push(...collegeListTypeRegistries);
      }
      if (registryOwnedList.length === 0) {
        optionsSet = getCreateRegistryLink(
          optionsSet,
          registryLabels,
          addToRegistryHeading
        );
      }
    } else if (enableRegistryRecommendations && recommendedRegistries.length) {
      if (registryOwnedList.length === 0) {
        optionsSet.shift();
      }
      // social recommendation flow
      optionsSet = getFriendsRegistries(
        optionsSet,
        registryLabels,
        recommendedRegistries,
        refNum
      );
      if (registryOwnedList.length === 0) {
        optionsSet = getCreateRegistryLink(
          optionsSet,
          registryLabels,
          addToRegistryHeading
        );
      }
    }
  }
  return optionsSet;
};
export const getSelectedProductProps = prod => {
  if (prod) {
    return {
      skuName: prod.DISPLAY_NAME || prod.SKU_DISPLAY_NAME,
      scene7URL: prod.SKU_SCENE7_URL,
    };
  }
  return {};
};
/**
 * @returns boolean
 * @memberof AddToRegistry
 */
export const disableCtaForLTL = args => {
  const { ltlFlag, enabledRegistryOwner } = args;
  const atrLtlConfig = pathOr(
    false,
    'enableLTLRegForSite',
    enabledRegistryOwner
  );
  return (isEqual('true', ltlFlag) || isEqual(true, ltlFlag)) && !atrLtlConfig;
};
/**
 * @returns boolean check for inter
 * @memberof AddToRegistry
 */
export const disableCtaForInternationalUser = () => {
  return isInternationalUser();
};
export const disableCta = args => {
  return disableCtaForLTL(args) || disableCtaForInternationalUser();
};
/*
 * validates alternate phone no. or dsl from alternate dsl modal on click of atr modal
 */
export const validateLtlDslModalOptions = argsForLTLValidations => {
  let canBeAddedLTL = true;
  let canBeAddedALTPhone = true;
  const {
    validateAltPhoneNum,
    validateLtlDslOption,
    validateLtlDslOnModal,
  } = argsForLTLValidations;
  if (validateLtlDslOnModal && typeof validateLtlDslOption === 'function') {
    canBeAddedLTL = validateLtlDslOption();
  }
  /* istanbul ignore else */
  if (typeof validateAltPhoneNum === 'function') {
    canBeAddedALTPhone = validateAltPhoneNum();
  }
  return canBeAddedLTL && canBeAddedALTPhone;
};
/**
 * @memberof AddToRegistry
 * remove addToRegistry=true from search in location and do not maintain history
 * window.history.replaceState is intentional below
 */
export const autoAddItemRevoked = () => {
  let toLocation;
  const { search, pathname, hash } = location;
  const queryParams = parse(search, {
    ignoreQueryPrefix: true,
  });
  /* istanbul ignore if : this condition depends on browser location object */
  if (isEqual('true', queryParams.addToRegistry)) {
    delete queryParams.addToRegistry;
    toLocation = isEmpty(queryParams)
      ? `${pathname}${hash}`
      : `${pathname}?${stringify(queryParams)}${hash}`;
    window.history.replaceState(null, null, toLocation);
  }
};
export const filterCategoryId = selectedProduct => {
  const L1_ID = pathOr(null, 'L1_ID.[0]', selectedProduct);
  const L2_ID = pathOr(null, 'L2_ID.[0]', selectedProduct);
  const L3_ID = pathOr(null, 'L3_ID.[0]', selectedProduct);
  const PRIMARY_CATEGORY = pathOr('', 'PRIMARY_CATEGORY', selectedProduct);
  return PRIMARY_CATEGORY || L3_ID || L2_ID || L1_ID;
};
export const getCategoryId = (selectedProduct, location) => {
  const locationSearch = pathOr('', 'search', location);
  const query = qs.parse(locationSearch, { ignoreQueryPrefix: true });
  if (query.categoryId) {
    return query.categoryId;
  }
  let categoryId = null;
  if (selectedProduct) {
    categoryId = filterCategoryId(selectedProduct);
    if (!categoryId) {
      // Get category id from PARENT_PROD_INFO if not available for product
      categoryId = filterCategoryId(
        getParentProductData(selectedProduct, location)[0]
      );
    }
  }
  return categoryId;
};
export const addToRegistryStarted = (args, uid, quickAddATRState) => {
  const {
    skuId,
    prodId,
    addToRegistryInitiated,
    selectedProduct,
    qty,
    location,
    refNum,
    personalisedImageList,
    moderationStatus,
    parentProductId,
    ltlFlag,
    ltlShipMethod,
    products,
  } = args;
  const {
    SCENE7_URL,
    SKU_SCENE7_URL,
    DISPLAY_NAME,
    PRODUCT_VARIATION,
  } = selectedProduct || {
    SCENE7_URL: '',
    SKU_SCENE7_URL: '',
    DISPLAY_NAME: '',
    PRODUCT_VARIATION: '',
  };
  let PERSONALISED_IMAGE_URL = '';
  let itemType = '';
  let ltlDeliveryServices = '';
  const isLtlFlag = isEqual('true', ltlFlag) || isEqual(true, ltlFlag);
  if (refNum) {
    const imgObj = personalisedImageList.filter(obj => {
      return obj.size === 'x-small';
    })[0];
    PERSONALISED_IMAGE_URL =
      moderationStatus === 'pending' ? imgObj['moderated-url'] : imgObj.url;
    itemType = 'PER';
  } else if (isLtlFlag) {
    itemType = 'LTL';
    ltlDeliveryServices = ltlShipMethod;
  }
  const addedSkuAttrs = {
    SCENE7_URL,
    SKU_SCENE7_URL,
    DISPLAY_NAME,
    PERSONALISED_IMAGE_URL,
    PRODUCT_VARIATION,
  };
  const primaryCategoryId = getCategoryId(selectedProduct, location);
  addToRegistryInitiated({
    skuId,
    prodId,
    addedSkuAttrs,
    qty,
    uid,
    parentProductId,
    categoryId: primaryCategoryId,
    refNum,
    itemType,
    ltlDeliveryServices,
    products,
    quickAddATRState,
  });
};
export const createRegRedirectPrams = propsData => {
  const {
    addToRegistryQueryParam,
    skuId,
    productType,
    PDP_URL,
    ltlFlag,
    ltlShipMethod,
    location,
  } = propsData;
  const params = parse(location.search, { ignoreQueryPrefix: true });
  let search = '';
  delete params.personalize;
  /* istanbul ignore else  */
  if (!isEmpty(addToRegistryQueryParam)) {
    search = '?';
    const isLtlFlag = isEqual('true', ltlFlag) || isEqual(true, ltlFlag);
    if (isEqual('MSWP', productType)) {
      params.skuId = skuId;
    }
    if (isLtlFlag) {
      params.sopt = ltlShipMethod;
    }
    const [key, value] = addToRegistryQueryParam.split('=');
    params[key] = value;
  }
  const searchArr = Object.keys(params);
  // Construct param string
  searchArr.forEach((key, index) => {
    search += `${key}=${params[key]}`;
    search += index === searchArr.length - 1 ? '' : '&';
  });
  const uri = PDP_URL || location.pathname;
  const toLocation = uri.split('?');
  const pathName = toLocation[0];
  return {
    pathName,
    search: search.trim(),
  };
};
/**
 * Detrmines the parentProductId to be sent to display the correct certona suggestions.
 * @returns parentProductId
 */
export const setParentProductID = args => {
  const variation = pathOr(
    '',
    'addToRegistryState.addedSkuAttrs.PRODUCT_VARIATION',
    args
  );
  const isAccesoryOrCollection =
    variation === ACCESSORY_PRODUCT || variation === COLLECTION_PRODUCT;
  return isAccesoryOrCollection
    ? args.addToRegistryState.productId
    : args.addToRegistryState.parentProductId;
};
/**
 * Moves an Item to registry from Saved Line items on cart page | @param {number} selectedRegistryId Selected Registry ID |
 * @returns
 * @memberof AddToRegistry */
export const moveItemToRegistryFromSFL = (
  selectedRegistryId,
  skipNotifyFlag,
  context
) => {
  const { props } = context;
  const {
    skuId,
    wishListItemId,
    moveToRegistry,
    itemIndex,
    registryId,
    ltlAltRegistryId,
    ltlFlag,
    registries,
    validateAltPhoneNum,
    altPhoneNumModal,
    referenceNumber,
    isCustomizationRequired,
    personalizationType,
  } = props;
  // activeRegistryId belongs to the registry selected by user to add the item
  const activeRegistryId = selectedRegistryId || ltlAltRegistryId || registryId;
  context.skipNandD = skipNotifyFlag; // eslint-disable-line no-param-reassign
  const selectedRegistry = getRegistryById(activeRegistryId, registries);
  const tealiumMTRData = moveToRegistryTealiumInfo(
    props.tealiumData,
    selectedRegistry
  );
  const item = {
    skuId,
    wishListItemId,
    isCustomizationRequired,
    personalizationType,
    tealiumMTRData,
    moveItemFromSaveForLater: true,
    registryId: activeRegistryId,
    movedItemIndex: itemIndex,
    referenceNumber: referenceNumber || '',
    alternateNumber: altPhoneNumModal,
    skipNotifyFlag: skipNotifyFlag || false,
  };
  // args to perform LTL validations: alternate no and po box registry address
  const argsForLTLValidations = {
    ltlFlag,
    activeRegistryId,
    selectedRegistry,
    validateAltPhoneNum,
    altPhoneNumModal,
    registries,
  };
  // evaluate the LTL conditions
  const canBeAdded = context.checkLTLConditions(argsForLTLValidations);
  if (canBeAdded) {
    moveToRegistry(item);
  }
};
export const toggleNandDmodalMountedState = (state, context) => {
  context.setState({
    NandDmodalMountedState: state,
  });
};
export const setSFLNandDModalState = (propData, context) => {
  const displayMessage = pathOr(null, 'displayMessage', propData);
  const sflNandDFlag = pathOr(false, 'sflNandDFlag', propData);
  if (displayMessage && sflNandDFlag && context.skipNandD === 'false') {
    toggleNandDmodalMountedState(true, context);
  } else {
    toggleNandDmodalMountedState(false, context);
  }
};
/** Get Customization/Personalization attribute for Tealium  **/
export const getCustomizeDescription = productDetails => {
  const customizeDesc = productDetails
    ? productDetails.ELIGIBLE_CUSTOMIZATION_DESCRIP
    : '';
  return getPersonalizationTypeForTealium(customizeDesc);
};
const getButtonLayout = (listCount, registryCount, isFlipFLopATR) => {
  const addToListRegistry = {};
  if (isFlipFLopATR || (listCount === 0 && registryCount <= 1)) {
    addToListRegistry.Layout = BUTTON;
    addToListRegistry.Label = 'AddToRegistry';
  } else if (listCount === 1 && registryCount === 0) {
    addToListRegistry.Layout = BUTTON;
    addToListRegistry.Label = 'AddToList';
  }
  return addToListRegistry;
};
export const getDropDownLayout = (listCount, registryCount) => {
  const addToListRegistry = {};
  if (listCount >= 1 && registryCount >= 1) {
    addToListRegistry.Layout = DROPDOWN;
    addToListRegistry.Label = 'AddToRegistryList';
  } else if (listCount === 0 && registryCount > 1) {
    addToListRegistry.Layout = DROPDOWN;
    addToListRegistry.Label = 'AddToRegistry';
  } else if (listCount > 1 && registryCount === 0) {
    addToListRegistry.Layout = DROPDOWN;
    addToListRegistry.Label = 'AddToList';
  }
  return addToListRegistry;
};
// Function to Decide whether to render ATR/L Button or a dropdown
export const getListAndRegistryLayout = (propData, isFlipFLopATR = false) => {
  const { registries } = propData;
  const ownedRegistries = pathOr([], 'profileRegistryList', registries);
  const listTypeRegistries = pathOr([], 'profilelistTypeRegList', registries);

  const recommendedRegistries = pathOr(
    [],
    'recommendedRegistryList',
    registries
  );
  if (
    !isFlipFLopATR &&
    recommendedRegistries.length &&
    listTypeRegistries.length === 0
  ) {
    return {
      Layout: DROPDOWN,
      Label: 'AddToRegistry',
    };
  }
  const ownedRegistriesLength = ownedRegistries && ownedRegistries.length;
  const listTypeRegistriesLength = listTypeRegistries.length;
  let layoutObject = getButtonLayout(
    listTypeRegistriesLength,
    ownedRegistriesLength,
    isFlipFLopATR
  );
  if (!Object.keys(layoutObject).length) {
    layoutObject = getDropDownLayout(
      listTypeRegistriesLength,
      ownedRegistriesLength
    );
  }
  return layoutObject;
};
export const getTealiumDataForAtr = (newProps, props) => {
  const { productDetails, ltlData, ltlFlag, location } = newProps || props;
  const tealiumPersonalizationType = getCustomizeDescription(productDetails);
  const atrPDPTealiumData = {
    ltlData,
    tealiumPersonalizationType,
    ltlFlag,
    location,
  };
  return atrPDPTealiumData;
};
export const getSelectedChecklistName = (selectedRegistry, registries) => {
  let checklistName = pathOr('', 'checklistname', selectedRegistry);

  if (checklistName === '') {
    const listTypeRegistries = pathOr([], 'profilelistTypeRegList', registries);
    checklistName = listTypeRegistries[0]
      ? listTypeRegistries[0].checklistname
      : '';
  }
  return checklistName;
};
// Function to determine the type of checklist (College/Movers)
export const checkListItemType = (selectedRegistry, registries, eventCode) => {
  let isSingleListInAccount = false;
  let isList = false;
  const ownedRegistries = pathOr([], 'profileRegistryList', registries);
  const listTypeRegistries = pathOr([], 'profilelistTypeRegList', registries);
  const pnhListRegistries = pathOr([], 'profilePackAndHoldList', registries);

  const listEventCode = eventCode.split(',').map(item => item.trim());
  const listRegistries = listTypeRegistries.filter(
    item => listEventCode.indexOf(item.eventCode) > -1
  );
  const pnhRegistries = pnhListRegistries.filter(
    item => listEventCode.indexOf(item.eventCode) > -1
  );

  if (
    ownedRegistries.length === 0 &&
    (listRegistries.length === 1 || pnhRegistries.length === 1)
  ) {
    isSingleListInAccount = true;
  }
  if (
    (typeof selectedRegistry !== 'undefined' &&
      selectedRegistry.checklistname !== null &&
      typeof selectedRegistry.checklistname === 'string') ||
    (isSingleListInAccount && listRegistries.length > 0)
  ) {
    isList =
      typeof selectedRegistry === 'undefined'
        ? listEventCode.indexOf(listRegistries[0].eventCode) > -1
        : listEventCode.indexOf(selectedRegistry.eventCode) > -1;
  } else if (
    (typeof selectedRegistry !== 'undefined' && pnhRegistries.length > 0) ||
    isSingleListInAccount
  ) {
    isList =
      typeof selectedRegistry === 'undefined'
        ? listEventCode.indexOf(pnhRegistries[0].eventCode) > -1
        : listEventCode.indexOf(selectedRegistry.eventCode) > -1;
  }
  return isList;
};
export const isListItem = (selectedRegistry, registries, registryLabels) => {
  const collegeCode = LabelsUtil.getLabel(registryLabels, 'collegeEventCodes');
  const moversCode = LabelsUtil.getLabel(registryLabels, 'moverEventCodes');
  const pnhCode = LabelsUtil.getLabel(registryLabels, 'pnhEventCodes');
  const isCollegeList = checkListItemType(
    selectedRegistry,
    registries,
    collegeCode
  );
  const isMoversList = checkListItemType(
    selectedRegistry,
    registries,
    moversCode
  );
  const isPNHList = checkListItemType(selectedRegistry, registries, pnhCode);

  return { isCollegeList, isMoversList, isPNHList };
};
export const addToRegistryAction = (
  payLoad,
  addToRegistry,
  isList,
  selectedRegistry,
  registries,
  registryLabels
) => {
  let payLoadData;
  const listType = getListType(selectedRegistry, registries, registryLabels);
  if (listType) {
    const selectedChecklistName = getSelectedChecklistName(
      selectedRegistry,
      registries
    );
    payLoadData = Object.assign(
      {
        isList: true,
        checklistName: selectedChecklistName,
        listType,
      },
      payLoad
    );
  } else {
    payLoadData = Object.assign({ isList }, payLoad);
  }
  addToRegistry(payLoadData);
};

export const getListType = (selectedRegistry, registries, registryLabels) => {
  const { isCollegeList, isMoversList, isPNHList } = isListItem(
    selectedRegistry,
    registries,
    registryLabels
  );
  let listType = null;
  if (isCollegeList) {
    listType = COLLEGE_CHECKLIST;
  } else if (isMoversList) {
    listType = MOVERS_CHECKLIST;
  } else if (isPNHList) {
    listType = PNH_CHECKLIST;
  }
  return listType;
};

/* eslint complexity: ["error", 14]*/
export const addToRegistryUtility = addRegUtilData => {
  const {
    newProps,
    wasGuestUser,
    selectedRegistryId,
    selectedRegistryName,
    skipNotifyFlagVal,
    props,
    canBeAdded,
    selectedRegistry,
    registries,
    shouldFireRegApi,
  } = addRegUtilData;
  const {
    skuId,
    prodId,
    addToRegistryState,
    qty,
    registryId,
    registryName,
    isCustomizationRequired,
    personalizationType,
    refNum,
    ltlFlag,
    ltlShipMethod,
    porchPayLoadJson,
    fromComparisonPage,
    returnURL,
    addToRegistry,
    ltlAltRegistryId,
    ltlAltRegistryName,
    altPhoneNumModal,
    price,
    giftGiverTealiumData,
    favStoreId,
    location,
    isFromPendingTab,
    isFromDeclinedTab,
    isDeclined,
    repositoryId,
    funStuffTealiumParams,
    quickViewTealiumInfo,
    isATRRM,
    imageUrl,
    quickViewTags,
    certonaIdentifier,
    tealiumATCCertonaLabel,
    isList,
    registryLabels,
    products,
    removeIsFromPendingTab,
    hideLoader,
    clickedFromPB,
    replaceProps,
    quickAddProps,
    closeQuickViewModal,
  } =
    newProps || props;
  const activeRegistryId = ltlAltRegistryId || selectedRegistryId || registryId;
  const activeRegistryName =
    ltlAltRegistryName || selectedRegistryName || registryName;
  const quantity = wasGuestUser ? addToRegistryState.qty : qty;
  const atrPDPTealiumData = getTealiumDataForAtr(newProps, props);
  const selectedProductProps = getSelectedProductProps(props.selectedProduct);
  const { skuName, scene7URL } = selectedProductProps;
  const listType = getListType(selectedRegistry, registries, registryLabels);
  const altNoInRegistry = pathOr('', 'alternatePhone', selectedRegistry);
  // all pre-conditions fulfilled : SKU available, LTL pristine, registry available, call the API
  if (canBeAdded) {
    const payLoad = {
      skuId,
      skuName,
      prodId,
      scene7URL,
      activeRegistryId,
      qty: quantity,
      activeRegistryName,
      isCustomizationRequired,
      personalizationType,
      refNum,
      ltlFlag,
      ltlShipMethod: ltlFlag ? ltlShipMethod : null,
      porchPayLoadJson,
      fromComparisonPage,
      returnURL,
      price,
      isATRRM,
      imageUrl,
      giftGiverTealiumData,
      favStoreId,
      atrPDPTealiumData,
      location,
      isFromPendingTab,
      isFromDeclinedTab,
      isDeclined,
      repositoryId,
      funStuffTealiumParams,
      quickViewTealiumInfo,
      isProductOfTypeCollection:
        props.productDetails && typeof props.productDetails !== 'undefined'
          ? props.productDetails.COLLECTION_FLAG
          : '',
      listType,
      quickViewTags,
      certonaIdentifier,
      tealiumATCCertonaLabel,
      altNumber: altPhoneNumModal,
      skipNotifyFlag: skipNotifyFlagVal,
      products,
      hideLoader,
      altNoInRegistry,
      clickedFromPB,
      fromReplace: pathOr(false, 'fromReplace', replaceProps),
      shouldFireRegApi,
      toggleChooseOptionState: pathOr(
        null,
        'toggleChooseOptionState',
        quickAddProps
      ),
      closeQuickViewModal,
    };
    if (removeIsFromPendingTab) {
      delete payLoad.isFromPendingTab;
    }
    addToRegistryAction(
      payLoad,
      addToRegistry,
      isList,
      selectedRegistry,
      registries,
      registryLabels
    );
  }
};
export const guestUserTealiumATREvent = props => {
  const {
    selectedProduct,
    pageIdentifier,
    miniCartData,
    interactiveCheckListData,
    snowplowTags,
    qty,
    personalizationType,
    price,
    ltlFlag,
    fireTealiumAction,
    location,
    isChooseOption,
  } = props;
  let ATR_PAGE_PARM;
  if (typeof pageIdentifier !== 'undefined') {
    ATR_PAGE_PARM =
      pageIdentifier === 'Registry_Gift_Giver'
        ? TEALIUM_RGG_INFO
        : TEALIUM_PA_INFO;
  }

  const {
    DISPLAY_NAME,
    IS_PRICE,
    BRAND_ID,
    BRAND_NAME,
    BRAND,
    PRIMARY_CATEGORY,
    SEO_URL,
    PRODUCT_ID,
    SKU_ID,
  } = selectedProduct;

  const brandName = BRAND_NAME || BRAND;

  const defaultVal = '';
  const productName = DISPLAY_NAME || defaultVal;
  const tealiumAtrData = {
    brand_id: BRAND_ID || defaultVal,
    brand_name: brandName || defaultVal,
    category_id: PRIMARY_CATEGORY || defaultVal,
    product_name: productName,
    product_url: SEO_URL || defaultVal,
    product_price: IS_PRICE || price,
    product_has_personalization: personalizationType === 'N' ? 'false' : 'true',
    pagename_breadcrumb: `${PDP_PAGENAME_BREADCRUMB}${productName}`,
    isChooseOption,
  };
  const regData = {
    pageId: pageIdentifier,
    atrPDPTealiumData: {
      ltlFlag,
    },
    prodId: PRODUCT_ID || defaultVal,
    skuId: SKU_ID || defaultVal,
    qty,
  };
  const registryTealiumPayload = atrTealiumInfo(
    tealiumAtrData,
    fromJS({ miniCartData }),
    pageIdentifier,
    regData,
    null,
    interactiveCheckListData,
    {},
    snowplowTags
  );
  const modifiedTags = deleteTealiumTagsByLocation(
    location,
    registryTealiumPayload
  );
  fireTealiumAction('add to registry', modifiedTags, ATR_PAGE_PARM);
};
const getAddToRegistryLabel = ({
  registryLabels,
  preventLabelOverride,
  buttonProps,
}) => {
  return preventLabelOverride && buttonProps.children
    ? buttonProps.children
    : LabelsUtil.getLabel(registryLabels, 'AddToRegistry');
};
