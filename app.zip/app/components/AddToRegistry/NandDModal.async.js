/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';
import { options } from '@bbb-app/universal-component/options';

const NandDModal = universal(
  import(/* webpackChunkName: "NandDModal-chunk" */ './ATRNandDModal'),
  options
);

export default NandDModal;
/* eslint-enable extra-rules/no-commented-out-code */
