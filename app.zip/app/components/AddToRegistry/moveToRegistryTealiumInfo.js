import { OUT_OF_STOCK, IN_STOCK } from '@bbb-app/tealium/constants';
import { getPersonalizationFromCustCodes } from '@bbb-app/tealium/tagSelectors/utils';

import { getStaticTealiumTags } from '../Pages/Registry/ProductGridTile/staticTealiumTags';

const PAGE_NAME = 'move to registry';
const PAGE_NAME_BREADCRUMB = 'Check Out>Full Cart';
const FINDING_METHOD = 'Wish List';
const REGISTRY_ADD_LOCATION = 'Wish List';

export const getProductTealiumTags = (productData, customizationCodes) => {
  let productTags;
  let skuTags;
  /* istanbul ignore else  */
  if (productData) {
    /* istanbul ignore else  */
    if (productData.productVO) {
      const productVO = productData.productVO;
      productTags = {
        product_id: [`${productVO.productId}`],
        product_name: [`${productVO.name}`],
        product_url: [`${productData.productHrefUrl}`],
        product_sub_sub_category: [],
        product_subcategory: [],
        product_category: [],
        product_price: [`${productData.price}`],
        product_quantity: [`${productData.quantity}`],
        registry_product_name_count_purchased: [`${productData.qtyPurchased}`],
        registry_product_name_count_requested: [`${productData.qtyRequested}`],
      };
    }
    /* istanbul ignore else  */
    if (productData.skuVO) {
      const skuVO = productData.skuVO;
      const isPersonalized = !!(
        skuVO.customizationOffered && skuVO.personalizationType !== 'N'
      );
      const personalizationType = getPersonalizationFromCustCodes(
        productData.personalizationOptions,
        customizationCodes,
        isPersonalized
      );
      skuTags = {
        product_sku_id: [`${skuVO.skuId}`],
        product_sku_name: [`${skuVO.displayName}`],
        is_ltl_item: skuVO.ltlItem,
        personalization_type: personalizationType,
        inventory_status: skuVO.skuInStock ? IN_STOCK : OUT_OF_STOCK,
        product_has_personalization: isPersonalized,
        level_of_service: productData.ltlShipMethodDesc
          ? productData.ltlShipMethodDesc
          : '',
      };
    }
    return Object.assign({}, skuTags, productTags);
  }
  return null;
};

export const getEventSpecificTags = () => {
  const eventSpecificTags = {
    page_name: PAGE_NAME,
    pagename_breadcrumb: PAGE_NAME_BREADCRUMB,
    product_added_outside_reg: '',
    product_finding_method: FINDING_METHOD,
    registry_add_location: REGISTRY_ADD_LOCATION,
  };
  return eventSpecificTags;
};

export const getRegistryTealiumTags = registryData => {
  /* istanbul ignore else  */
  if (registryData) {
    const registrantName = registryData.primaryRegistrantLastName
      ? `${registryData.primaryRegistrantFirstName} ${registryData.primaryRegistrantLastName}`
      : registryData.primaryRegistrantFirstName;
    const registryTealiumTags = {
      registry_event_date: registryData.eventDate,
      registry_favorite_categories_id: [],
      registry_favorite_categories_name: [],
      registry_id: registryData.registryId,
      registry_purchased: registryData.eventType,
      registry_total_items: '',
      registry_total_value: '',
      registry_type: registryData.eventType,
      shower_celebration_date: registryData.showerDate
        ? registryData.showerDate
        : '',
      registrants_name: registrantName,
    };
    return registryTealiumTags;
  }
  return null;
};

export const getCartCheckListTags = (interactiveChecklistData, cartData) => {
  const cartCheckListTags = {
    registry_checklist_completion: interactiveChecklistData
      ? interactiveChecklistData.averageC1Percentage
      : '',
  };
  return Object.assign({}, cartData, cartCheckListTags);
};

export const moveToRegistryTealiumInfo = (tealiumData, registryData) => {
  if (tealiumData && registryData) {
    const productTealiumTags = getProductTealiumTags(
      tealiumData.productData,
      tealiumData.customizationCodes
    );
    const registryTealiumTags = getRegistryTealiumTags(registryData);
    const cartCheckListTags = getCartCheckListTags(
      tealiumData.interactiveChecklistData,
      tealiumData.cartData
    );
    const staticTags = getStaticTealiumTags();
    const eventSpecificTags = getEventSpecificTags();
    return Object.assign(
      {},
      productTealiumTags,
      registryTealiumTags,
      staticTags,
      eventSpecificTags,
      cartCheckListTags
    );
  }
  return null;
};

export default moveToRegistryTealiumInfo;
