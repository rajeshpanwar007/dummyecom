import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { isEmpty } from 'lodash';
import { pathOr } from 'lodash/fp';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import getTransformedLtlOptions from '@bbb-app/utils/getTransformedLtlOptions';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import FormInput from '@bbb-app/forms/components/FormInput';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import {
  validateChange,
  validateAll,
} from '@bbb-app/forms/validations/validator';
import '@bbb-app/assets/icons/helpIcon.svg';
import { LOCATORS } from './dataLocators';
import AddToRegistry from '../AddToRegistry/AddToRegistry';
import { Skeleton } from './Skeleton/Skeleton';

/**
 * @class LTLAltDslModal
 * @extends {PureComponent}
 */
class LTLAltDslModal extends PureComponent {
  /**
   * @static
   * @memberof LTLAltDslModal
   */
  static propTypes = {
    registryLabels: PropTypes.object,
    ltlDetails: PropTypes.object,
    ltlModalMountedState: PropTypes.bool,
    toggleLTLModalState: PropTypes.func,
    getLTLDetails: PropTypes.func,
    skuId: PropTypes.string,
    ltlAltDslRegistryId: PropTypes.string,
    ltlAltDslRegistryName: PropTypes.string,
    modalDescriptionClass: PropTypes.string,
    altPhoneNumber: PropTypes.string,
    selectDslOnModal: PropTypes.bool,
    showPhoneNumberInput: PropTypes.bool,
    ltlShipMethod: PropTypes.string,
    updateDslOnModal: PropTypes.bool,
    updateRegistryItemDsl: PropTypes.func,
    shipMethodUnsupported: PropTypes.bool,
    ltlDeliveryServices: PropTypes.string,
    onModalClose: PropTypes.func,
    fromRegistryOwner: PropTypes.bool,
  };
  /**
   * Creates an instance of LTLModal.
   * @param {any} props
   * @memberof LTLModal
   */
  constructor(props) {
    super(props);
    this.state = this.getDefaultState();
  }

  /**
   * @param {*} newProps
   */
  componentWillReceiveProps(newProps) {
    if (
      newProps.ltlModalMountedState !== this.props.ltlModalMountedState &&
      newProps.ltlModalMountedState &&
      newProps.selectDslOnModal
    ) {
      this.props.getLTLDetails({ skuId: this.props.skuId });
    }
  }
  /**
   * @returns
   * @memberof LTLAltDslModal
   */
  getDefaultState() {
    return {
      altPhoneNum: this.props.altPhoneNumber || '',
      altPhoneNumError: '',
      ltlDetailsSelected: '',
      ltlDetailsError: '',
    };
  }
  /**
   * @param {any} errorClass
   * @memberof LTLAltNumberModal
   */
  setFocusOnErrorField(errorClass) {
    const errorField = document.getElementsByClassName(errorClass)[0];
    if (errorField) errorField.focus();
  }
  /**
   *
   * @param {*} value
   * @param {*} index
   */
  getDeliveryMethodAndCost(value) {
    const { ltlDetails } = this.props.ltlDetails;
    if (value) {
      const selectedDslDetails = ltlDetails.find(
        item => value === item.shipMethodId
      );
      this.setState({
        ltlDetailsError: '',
        ltlDetailsSelected: value,
        ltlShipMethodDesc: selectedDslDetails.shipMethodDescription,
        deliverySurcharge: selectedDslDetails.deliverySurcharge,
      });
    }
  }
  /**
   * @memberof LTLModal
   */
  modalLTLDidClose = () => {
    this.setState(this.getDefaultState());
  };
  /**
   * @param {event} prop
   * This is called on 'change' event on input fileds. This function updates the state with the form values.
   * @memberof LTLModal
   */
  handleInputChange = event => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
  };
  /**
   * @param {rule, event} prop
   * This is called on 'blur' event on input fileds. This function validates the values on form fields
   * and validates it with the REGEX, populates the error fields if the validation fails.
   */
  handleInputBlur = (rule, event) => {
    const { name, value } = event.target;
    const validation = validateChange(name, value, rule);
    /* istanbul ignore else  */
    if (validation)
      this.setState(validation, () => {
        this.setFocusOnErrorField('altPhoneNumError');
      });
  };

  /**
   * @memberof LTLModal
   */
  validateAltPhoneNum = () => {
    const fieldName = 'altPhoneNum';
    const constraint = 'phoneRequired';
    let isValid = true;
    const fieldValue = this.state[fieldName].trim();
    const errors = validateAll({
      altPhoneNum: {
        rule: constraint,
        value: fieldValue,
      },
    });
    if (Object.keys(errors).length) {
      isValid = false;
      this.setState(errors, () => {
        this.setFocusOnErrorField('altPhoneNumError');
      });
    }
    return isValid;
  };
  /**
   * @memberof LTLModal
   */
  validateLtlDslOption = () => {
    const constraint = 'required';
    let isValid = true;
    const fieldValue = this.state.ltlDetailsSelected.trim();
    const errors = validateAll({
      ltlDetails: {
        rule: constraint,
        value: fieldValue,
      },
    });
    if (Object.keys(errors).length) {
      isValid = false;
      this.setState(errors, () => {
        this.setFocusOnErrorField('ltlDetailsError');
      });
    }
    return isValid;
  };
  /**
   * @memberof LTLModal
   */
  renderModalHeading() {
    const { registryLabels, selectDslOnModal } = this.props;
    const labelKey = selectDslOnModal
      ? 'dslModalTitle'
      : 'altPhoneNumModalTitle';
    return (
      <Cell>
        <Heading data-locator={LOCATORS.LTL_DSL_MODAL_HEADING} level={3}>
          {LabelsUtil.getLabel(registryLabels, labelKey)}
          {selectDslOnModal && (
            <React.Fragment>
              <Button
                data-tooltip={LabelsUtil.getLabel(
                  registryLabels,
                  'dslModalToolTip'
                )}
                theme="ghost"
                variation="noPadding"
                title={LabelsUtil.getLabel(registryLabels, 'dslModalToolTip')}
                iconProps={{
                  type: 'helpIcon',
                  height: '12px',
                  width: '12px',
                }}
                className={classnames('ml1', 'tooltip-bottom')}
              />
            </React.Fragment>
          )}
        </Heading>
      </Cell>
    );
  }
  /**
   * @memberof LTLModal
   */
  renderModalDescription() {
    const {
      registryLabels,
      modalDescriptionClass,
      selectDslOnModal,
      showPhoneNumberInput,
    } = this.props;
    const labelKey =
      selectDslOnModal && !showPhoneNumberInput
        ? 'dslModalDescription'
        : 'altPhoneNumModalDescription';
    return (
      <Cell className={classnames('mb2')}>
        <Paragraph
          data-locator={LOCATORS.LTL_DSL_MODAL_DESCRIPTION}
          className={classnames(`${modalDescriptionClass}`)}
        >
          {LabelsUtil.getLabel(registryLabels, labelKey)}
        </Paragraph>
      </Cell>
    );
  }
  /**
   * @returns
   * @memberof LTLAltDslModal
   */
  renderUpdateButton() {
    const {
      registryLabels,
      updateRegistryItemDsl,
      shipMethodUnsupported,
      ltlDeliveryServices,
    } = this.props;
    const {
      ltlDetailsSelected,
      ltlShipMethodDesc,
      deliverySurcharge,
    } = this.state;
    const ltlDslNotSupported = isEmpty(ltlDeliveryServices)
      ? shipMethodUnsupported
      : false;

    const args = {
      ltlDeliveryServices: ltlDetailsSelected,
      shipMethodUnsupported: ltlDslNotSupported,
      ltlShipMethodDesc,
      deliverySurcharge,
    };
    return (
      <GridX className={classnames('small-12')}>
        <Cell className={classnames('large-4 small-8')}>
          <Button
            onClick={() => {
              if (this.validateLtlDslOption()) {
                updateRegistryItemDsl(args);
              }
            }}
            data-locator={LOCATORS.UPDATE_ADDRESS}
          >
            {LabelsUtil.getLabel(registryLabels, 'ltlDslUpdateLink')}
          </Button>
        </Cell>
      </GridX>
    );
  }
  /**
   * Reset icon props and class to blank because from registry gift giver view it overrides the button properties
   * @returns
   * @memberof LTLModal
   */
  renderATRButton() {
    const { registryLabels } = this.props;
    const btnName = pathOr('', 'buttonProps.attr.name', this.props);
    return (
      <GridX className={classnames('small-12')}>
        <Cell className={classnames('large-6 small-8')}>
          <AddToRegistry
            {...this.props}
            altDslCtaType={'button'}
            altPhoneNumModal={this.state.altPhoneNum}
            selectDslOnModal={false}
            validateLtlDslOnModal={this.props.selectDslOnModal}
            ltlAltRegistryId={this.props.ltlAltDslRegistryId}
            ltlAltRegistryName={this.props.ltlAltDslRegistryName}
            buttonProps={{
              attr: {
                name: btnName,
                className: '',
                iconProps: null,
              },
              children: LabelsUtil.getLabel(registryLabels, 'AddToRegistry'),
              disabled: false,
            }}
            ltlAltBtnTheme="primary"
            validateAltPhoneNum={
              this.props.showPhoneNumberInput && this.validateAltPhoneNum
            }
            validateLtlDslOption={this.validateLtlDslOption}
            ltlShipMethod={
              this.props.selectDslOnModal
                ? this.state.ltlDetailsSelected
                : this.props.ltlShipMethod
            }
            preventLabelOverride
          />
        </Cell>
      </GridX>
    );
  }
  /**
   * @returns
   * @memberof LTLModal
   */
  renderInputAltPhoneNum() {
    const fieldName = 'altPhoneNum';
    const fieldError = `${fieldName}Error`;
    const errorClass = this.state[fieldError] ? 'errorField' : '';
    const constraint = 'phoneRequired';
    const { registryLabels } = this.props;
    return (
      <GridX className={classnames('small-12 mb2')}>
        <Cell className={classnames('large-8 small-12')}>
          <FormInput
            type="tel"
            id="altPhoneNum"
            name="altPhoneNum"
            data-locator={LOCATORS.LTL_DSL_ALT_PHONE_NUMBER}
            className={classnames(errorClass)}
            label={LabelsUtil.getLabel(registryLabels, 'altPhoneNumModalTitle')}
            labelPosition="append"
            value={this.state.altPhoneNum}
            maxLength="10"
            onChange={this.handleInputChange}
            onBlur={event => {
              this.handleInputBlur(constraint, event);
            }}
          />
          {errorClass && (
            <Paragraph
              className={classnames(
                {
                  validationErrorMessage: errorClass,
                },
                'altPhoneNumError'
              )}
            >
              {this.state[fieldError]}
            </Paragraph>
          )}
        </Cell>
      </GridX>
    );
  }
  /**
   * @returns
   * @memberof LTLModal
   */
  renderLTLDropdown() {
    const fieldName = 'ltlDetails';
    const { registryLabels } = this.props;
    const { ltlDetails } = this.props.ltlDetails;
    const fieldError = `${fieldName}Error`;
    const errorClass = this.state[fieldError] ? 'errorField' : '';
    if (!ltlDetails) return null;
    const LTLdropdown = [
      {
        label: LabelsUtil.getLabel(registryLabels, 'chooseOption'),
        props: { value: '' },
      },
      ...getTransformedLtlOptions(ltlDetails),
    ];

    return (
      <GridX className={classnames('small-12 mb2')}>
        <Cell className={classnames('large-8 small-12')}>
          <FormInput
            className={classnames(errorClass)}
            id={`ltlDetails`}
            type="select"
            name={`ltlDetails`}
            labelStyle="inlineLabel"
            label={LabelsUtil.getLabel(registryLabels, 'LTLDropdown')}
            optionSet={LTLdropdown}
            selectOption={value => this.getDeliveryMethodAndCost(value)}
            defaultValue={this.state.ltlDetailsSelected}
          />
          {errorClass && (
            <Paragraph
              className={classnames(
                {
                  validationErrorMessage: errorClass,
                },
                'ltlDetailsError'
              )}
            >
              {this.state[fieldError]}
            </Paragraph>
          )}
        </Cell>
      </GridX>
    );
  }

  renderForm() {
    const { selectDslOnModal, ltlDetails } = this.props;
    if (selectDslOnModal && ltlDetails && ltlDetails.isFetching === true)
      return null;

    return [
      this.renderModalHeading(),
      this.renderModalDescription(),
      selectDslOnModal && this.renderLTLDropdown(),
      this.props.showPhoneNumberInput && this.renderInputAltPhoneNum(),
      this.props.updateDslOnModal
        ? this.renderUpdateButton()
        : this.renderATRButton(),
    ];
  }

  /**
   * @returns
   * @memberof LTLModal
   */
  render() {
    const {
      registryLabels,
      ltlModalMountedState,
      toggleLTLModalState,
      ltlDetails,
      fromRegistryOwner,
    } = this.props;
    return (
      <ErrorBoundary>
        <ModalDialog
          verticallyCenter
          mountedState={ltlModalMountedState}
          toggleModalState={toggleLTLModalState}
          onModalDidClose={this.modalLTLDidClose}
          titleAriaLabel={LabelsUtil.getLabel(
            registryLabels,
            'altPhoneNumModalAriaTitle'
          )}
          initialFocus=".rclModalContent"
          variation={'small'}
          scrollDisabled={false}
          customZIndex={fromRegistryOwner && '100999'}
          onModalClose={fromRegistryOwner && this.props.onModalClose}
        >
          <GridX className={classnames('large-12 small-12')}>
            {this.props.selectDslOnModal &&
              ltlDetails &&
              ltlDetails.isFetching && <Skeleton />}
            {this.renderForm()}
          </GridX>
        </ModalDialog>
      </ErrorBoundary>
    );
  }
}

export default LTLAltDslModal;
