import { isEqual } from 'lodash';
import { FLIP_FLOP_PAGE_IDENTIFIER } from './constants';

/**
 * @param{object} registries, contain the customer profile owned and recommended registried
 * @param {function} addToRegistry inherited from the AddToRegistry container component
 * @param {function} moveToRegistry inherited from the SavedLineItem component
 * @param {string} pageType pageType to handle defferent actions for different page type
 * @param {function} onClientError inherited from the AddToRegistry container component
 * @param {function} onSuccess inherited from the AddToRegistry container component
 * @param {function} onError inherited from the AddToRegistry container component
 */
export const openAtrModalStateChange = (
  props,
  targetName,
  qtyOrig,
  resetRegistryDropDown
) => {
  const { pageIdentifier, onSuccess, closeQuickViewModal, pageType } = props;
  if (pageIdentifier !== FLIP_FLOP_PAGE_IDENTIFIER) {
    resetRegistryDropDown();
    if (isEqual('REGISTRY_RECOMMENDATIONS', pageType)) {
      onSuccess(targetName);
    } else {
      onSuccess(qtyOrig);
    }
  } else if (closeQuickViewModal) {
    closeQuickViewModal();
  }
};
