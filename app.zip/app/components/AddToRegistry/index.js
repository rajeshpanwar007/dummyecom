export { default } from './AddToRegistry';
