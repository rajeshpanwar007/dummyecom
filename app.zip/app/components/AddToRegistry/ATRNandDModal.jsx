import React from 'react';
import PropTypes from 'prop-types';
import { pathOr } from 'lodash/fp';
import { isEmpty } from 'lodash';
import classnames from 'classnames';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Button from '@bbb-app/core-ui/button';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import TealiumHandler from '@bbb-app/tealium/TealiumHandler';
import AddToCart from '../../containers/AddToCart/AddToCart.async';
import styles from './AddToRegistry.css';
import {
  ND_MODAL_PAGNAME_BREADCRUMB,
  ND_MODAL_PAGE_TYPE,
  ND_MODAL_PAGE_NAME,
} from './constants';
import ATCModalRecommendation from '../../containers/ATCModalRecommendation/ATCModalRecommendation';
class NandDModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      NandDModalState: this.props.NandDmodalMountedState || false,
    };
  }

  hideModalHandler = () => {
    this.setState({
      NandDModalState: false,
    });
    this.props.toggleLTLModalState();
    this.props.nandDModalClose();
    this.props.toggleNandDmodalMountedState(false);
    if (this.props.closeQuickViewModal) this.props.closeQuickViewModal();
  };
  renderTxt = () => {
    const isMobileScreen = this.props.isMobile.isMobileScreen;
    return (
      <div className={!isMobileScreen ? 'pb03' : 'pb25'}>
        <span
          className={
            !isMobileScreen
              ? classnames(styles.modalHeadDsk, 'mb3')
              : classnames(styles.modalHeadMob, 'mb15')
          }
        >
          {LabelsUtil.getLabel(this.props.registryLabels, 'nandDHeading')}
        </span>
        <span className={styles.nandModalBody}>
          {`${LabelsUtil.getLabel(this.props.registryLabels, 'nandDBody')}`}
        </span>
        <span className={styles.nandModalConfirm}>
          {LabelsUtil.getLabel(this.props.registryLabels, 'nandDConfirm')}
        </span>
      </div>
    );
  };

  renderAddToCartBtn = () => {
    const isMobileScreen = this.props.isMobile.isMobileScreen;
    const { registryLabels, refNum, prodId, skuId, qty } = this.props;
    return (
      <AddToCart
        prodId={prodId}
        skuId={skuId}
        qty={qty}
        refnum={refNum}
        ignoreEmptyStoreDataOnUnmount
        viewType={'PDP'}
        registryId={this.props.registryId}
        className={
          !isMobileScreen
            ? classnames('ml15', styles.button, styles.addtocart)
            : classnames('fullwidth', styles.modalBtn)
        }
        buttonProps={{
          attr: {
            theme: 'primary',
            className: 'fullWidth',
            'data-locator': 'addtocartbutton',
          },
          children: LabelsUtil.getLabel(registryLabels, 'addToCart'),
        }}
        onModalClose={() => {
          /* istanbul ignore next */
          this.hideModalHandler();
        }}
        closeNandDModal={this.hideModalHandler}
        isfromNandDModal
      />
    );
  };

  renderAddToCartSFLBtn = () => {
    const {
      addToCartFromSfl,
      registryLabels,
      sflCart,
      itemIndexCart,
      isMobile,
    } = this.props;
    const isMobileScreen = isMobile.isMobileScreen;
    return (
      <div
        className={
          !isMobileScreen
            ? classnames('ml15', styles.button)
            : classnames('fullwidth', styles.modalBtn)
        }
      >
        <Button
          className={'fullWidth'}
          data-locator="saveditems_movetocartSfl"
          onClick={() => {
            /* istanbul ignore next */
            addToCartFromSfl(sflCart, itemIndexCart, null);
          }}
          theme="secondary"
        >
          {LabelsUtil.getLabel(registryLabels, 'addToCart')}
        </Button>
      </div>
    );
  };

  renderATCModalRecommendation = () => {
    const {
      isShiptSdd,
      showSDDResults,
      parentProductId,
      calledFromRegistry,
      showATCSuggestions,
      viewType,
      isList,
      minimizeATCHandler,
      toggleModalState,
      onAddToCartFromCertona,
      enabledGlobalSwitches,
      selectedProduct,
      isPdpPersonalizeProduct,
      track,
      storeIdNumber,
      buttonIdentifier,
      clickedOnPickItUp,
      addToRegistryState,
      prodId,
      registryId,
      NandDFlag,
    } = this.props;

    const { data } = addToRegistryState;

    const enableCertonaContainerATCATRModal = pathOr(
      '',
      'enableCertonaContainerATCATRModal',
      enabledGlobalSwitches
    );
    const enableCertona = pathOr('', 'enableCertona', enabledGlobalSwitches);
    const isRegistryItem = !isEmpty(registryId) && !showATCSuggestions;
    const enableWarrantyPlan = pathOr(
      false,
      'enableWarrantyPlan',
      enabledGlobalSwitches
    );
    const warrantyMinPrice = pathOr(
      false,
      'MIN_WARRANTY_PRICE',
      selectedProduct
    );
    const isWarrantyEnabled = enableWarrantyPlan && warrantyMinPrice;
    return (
      enableCertonaContainerATCATRModal &&
      enableCertona &&
      data &&
      !isShiptSdd &&
      !showSDDResults && (
        <ATCModalRecommendation
          prodId={prodId}
          parentProductId={parentProductId}
          calledFromRegistry={calledFromRegistry}
          isRegistry={isRegistryItem}
          showATRCTA={isRegistryItem}
          viewType={viewType}
          registryId={registryId}
          isList={isList}
          minimizeATCHandler={minimizeATCHandler}
          toggleATCHandler={toggleModalState}
          onAddToCartFromCertona={onAddToCartFromCertona}
          isWarrantyEnabled={isWarrantyEnabled}
          isPdpPersonalizeProduct={isPdpPersonalizeProduct}
          track={track}
          storeIdNumber={storeIdNumber}
          buttonIdentifier={buttonIdentifier}
          clickedOnPickItUp={clickedOnPickItUp}
          NandDFlag={NandDFlag}
        />
      )
    );
  };
  render() {
    const {
      IsSfl,
      moveItemToRegistryFromSFL,
      registryLabels,
      addItemToGiftRegistry,
      registryId,
      selectedRegistryId,
      isMobile,
      prodId,
      selectedRegistryName,
      NandDFlag,
    } = this.props;
    const isMobileScreen = isMobile.isMobileScreen;
    const utag = {
      product_id: [prodId] || [],
      pagename_breadcrumb: ND_MODAL_PAGNAME_BREADCRUMB,
      call_to_actiontype: ND_MODAL_PAGE_NAME,
      page_function: ND_MODAL_PAGE_NAME,
      page_name: ND_MODAL_PAGE_NAME,
      page_type: ND_MODAL_PAGE_TYPE,
    };
    return (
      <React.Fragment>
        {
          <ModalDialog
            mountedState={this.state.NandDModalState}
            toggleModalState={this.hideModalHandler}
            titleAriaLabel={LabelsUtil.getLabel(registryLabels, 'nandDModal')}
            variation="medium"
            verticallyCenter
            scrollDisabled={false}
            onModalClose={this.hideModalHandler}
            className={'p03'}
          >
            {this.renderTxt()}
            <div
              className={
                !isMobileScreen ? styles.button : ('fullwidth', styles.modalBtn)
              }
            >
              <Button
                className={'fullWidth'}
                onClick={() => {
                  /* istanbul ignore next */
                  if (IsSfl) {
                    moveItemToRegistryFromSFL(registryId, IsSfl);
                    /* istanbul ignore next */
                  } else {
                    addItemToGiftRegistry(
                      '',
                      false,
                      selectedRegistryId,
                      selectedRegistryName,
                      '',
                      'true'
                    );
                  }
                }}
                theme="secondary"
              >
                {LabelsUtil.getLabel(registryLabels, 'AddToRegistry')}
              </Button>
            </div>
            {IsSfl ? this.renderAddToCartSFLBtn() : this.renderAddToCartBtn()}
            {NandDFlag && (
              <div className="mt3">{this.renderATCModalRecommendation()}</div>
            )}
          </ModalDialog>
        }
        <ErrorBoundary>
          <TealiumHandler
            utagData={utag}
            identifier="Ndmodal"
            tealiumPageInfoNotAvailable
          />
        </ErrorBoundary>
      </React.Fragment>
    );
  }
}

NandDModal.propTypes = {
  addItemToGiftRegistry: PropTypes.func,
  registryLabels: PropTypes.object,
  qty: PropTypes.number,
  refNum: PropTypes.string,
  prodId: PropTypes.string,
  skuId: PropTypes.string,
  registryId: PropTypes.string,
  isMobile: PropTypes.object,
  closeQuickViewModal: PropTypes.func,
  nandDModalClose: PropTypes.func,
  moveItemToRegistryFromSFL: PropTypes.func,
  IsSfl: PropTypes.bool,
  addToCartFromSfl: PropTypes.func,
  sflCart: PropTypes.object,
  itemIndexCart: PropTypes.number,
  NandDmodalMountedState: PropTypes.bool,
  toggleNandDmodalMountedState: PropTypes.func,
  toggleLTLModalState: PropTypes.func,
  selectedRegistryId: PropTypes.number,
  selectedRegistryName: PropTypes.string,
  isShiptSdd: PropTypes.bool,
  showSDDResults: PropTypes.bool,
  parentProductId: PropTypes.number,
  calledFromRegistry: PropTypes.bool,
  showATCSuggestions: PropTypes.string,
  viewType: PropTypes.string,
  isList: PropTypes.string,
  minimizeATCHandler: PropTypes.func,
  toggleModalState: PropTypes.bool,
  onAddToCartFromCertona: PropTypes.func,
  enabledGlobalSwitches: PropTypes.object,
  selectedProduct: PropTypes.object,
  isPdpPersonalizeProduct: PropTypes.bool,
  track: PropTypes.bool,
  storeIdNumber: PropTypes.string,
  buttonIdentifier: PropTypes.string,
  clickedOnPickItUp: PropTypes.bool,
  addToRegistryState: PropTypes.object,
  NandDFlag: PropTypes.bool,
};

export default NandDModal;
