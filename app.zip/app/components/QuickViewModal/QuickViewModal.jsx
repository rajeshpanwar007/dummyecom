import React from 'react';
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Notification from '@bbb-app/core-ui/notification/Notification';
import { withSiteSpectTracker } from '@bbb-app/site-spect/Experiment';
import ProductDetails from '../Pages/PDP/ProductDetails/ProductDetails';
import { ProductItemListAsync } from '../Pages/PDP/ProductItemList/ProductItemList.async';
import QuickViewCertona from '../../containers/QuickViewCertona/QuickViewCertona.async';
import PLPQuickViewTealiumHandler from '../../containers/ThirdParty/Tealium/PLPQuickViewTealiumHandler/PLPQuickViewTealiumHandler';
import isRBYRRegistry from '../../components/Pages/Registry/utils/isRBYRRegistry';
import MiniQuickViewModal from './MiniQuickViewModal';
import {
  REGISTRY_QUICK_VIEW,
  LIST_QUICK_VIEW,
} from '../../containers/QuickViewModal/QuickViewModalWrapper/constants';
import { checkItemNeedToExcluded } from '../Pages/Registry/excludeNeededItem';

const propTypes = {
  selectedProduct: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  onModalClose: PropTypes.func,
  isQuickViewOpen: PropTypes.bool,
  getLTLDetails: PropTypes.func,
  productVariation: PropTypes.string,
  productUrl: PropTypes.string,
  deviceConfig: PropTypes.object,
  selectedSkuId: PropTypes.string,
  isQuickViewHidden: PropTypes.bool,
  onModalHide: PropTypes.func,
  onPickupInStoreButtonClick: PropTypes.func,
  isPickupInStoreModalOpen: PropTypes.string,
  switchConfigGlobal: PropTypes.object,
  ProductBadgingConfig: PropTypes.object,
  variation: PropTypes.string,
  pageIdentifier: PropTypes.string,
  guestViewerLabels: PropTypes.string,
  bopisSaving: PropTypes.string,
  resgistryListItems: PropTypes.array,
  giftGiver: PropTypes.bool,
  registryProductInfo: PropTypes.object,
  pageType: PropTypes.string,
  isCompare: PropTypes.bool,
  productCompareData: PropTypes.object,
  miniQuickViewMode: PropTypes.bool,
  preLoadImage: PropTypes.bool,
  profileHasRegistries: PropTypes.bool,
  quickViewError: PropTypes.string,
  registryData: PropTypes.object,
  itemType: PropTypes.object,
  jdaCatName: PropTypes.object,
  sKUDetailVO: PropTypes.object,
  track: PropTypes.func,
  isShowBadge: PropTypes.bool,
};

const defaultProps = {
  selectedProduct: {},
  switchConfigGlobal: {},
  closeModalOnBackDrop: false,
};

function showError(msg) {
  // Todo: needs to be implemented
  return msg;
}

export const getDisableNavToPDP = (
  isRegistryPersonalisedItem,
  personalizationType,
  giftGiver,
  isLtlItem
) => {
  if (!giftGiver) {
    // for owner view
    return false;
  } else if (isRegistryPersonalisedItem || isLtlItem) {
    // for giftgiver PY non personalised and LTL
    return true;
  }
  return false; // For all normal SKUs
};

export const QuickViewModal = ({
  selectedProduct,
  onModalClose,
  isQuickViewOpen,
  productVariation,
  productUrl,
  onModalHide,
  selectedSkuId,
  switchConfigGlobal,
  ProductBadgingConfig,
  variation,
  pageIdentifier,
  giftGiver,
  registryProductInfo,
  isCompare,
  productCompareData,
  miniQuickViewMode,
  preLoadImage,
  profileHasRegistries,
  quickViewError,
  registryData,
  bopisSaving,
  onPickupInStoreButtonClick,
  ...props
}) => {
  const parentProductData = {
    PRODUCT_VARIATION: productVariation,
  };
  const personalizationType = pathOr(
    '',
    'personalizationType',
    registryProductInfo
  );
  const isRegistryPersonalisedItem = pathOr(
    false,
    'isPersonalised',
    registryProductInfo
  );
  const itemType = pathOr('', 'itemType', registryProductInfo);
  const jdaCatName = pathOr('', 'jdaCatName', registryProductInfo);

  const sKUDetailVO = pathOr({}, 'sKUDetailVO', registryProductInfo);

  const isRBYR = pathOr(
    false,
    'registryResVO.registrySummaryVO.storedValueOptIn',
    registryData
  );
  const isRBYRRegistryEnabled = isRBYRRegistry(
    props.guestViewerLabels,
    pathOr(
      '',
      'registryResVO.registrySummaryVO.registryType.registryTypeName',
      registryData
    )
  );
  const isLtlItem = pathOr(false, 'isLtlItem', registryProductInfo);
  const isIntlRestricted = JSON.parse(
    pathOr('false', 'INTL_RESTRICTED', selectedProduct)
  );
  const disableNavToPDP = getDisableNavToPDP(
    isRegistryPersonalisedItem,
    personalizationType,
    giftGiver,
    isLtlItem
  );
  const enableMiniQuickViewModal = pathOr(
    false,
    'enableMiniQuickViewModal',
    switchConfigGlobal
  );
  const productAttributes = pathOr(
    null,
    'quickViewSwatchDetails.data.ATTRIBUTES_JSON',
    props
  );
  let fireTealium = false;
  const productType = pathOr(null, 'TYPE', selectedProduct);
  /* istanbul ignore else */
  if (
    !(parentProductData.PRODUCT_VARIATION === 'NORMAL') ||
    (parentProductData.PRODUCT_VARIATION === 'NORMAL' && productType)
  ) {
    fireTealium = true;
  }
  const globalBopusSavingFlag = pathOr(
    false,
    'enableBopusSavingEvent',
    switchConfigGlobal
  );
  const BopusExclusionFlag =
    pathOr('0', 'BOPUS_EXCLUSION_FLAG', selectedProduct) === '1';
  const bopisSavingMsg =
    globalBopusSavingFlag &&
    !BopusExclusionFlag &&
    bopisSaving &&
    bopisSaving.bopisSavingsMsg
      ? bopisSaving.bopisSavingsMsg
      : '';

  return (
    <ErrorBoundary>
      {enableMiniQuickViewModal &&
      parentProductData.PRODUCT_VARIATION === 'NORMAL' &&
      miniQuickViewMode ? (
        <React.Fragment>
          <MiniQuickViewModal
            profileHasRegistries={profileHasRegistries}
            selectedProduct={selectedProduct}
            quickViewMode={isQuickViewOpen}
            closeModal={onModalClose}
            hideModal={onModalHide}
            showError={showError}
            selectedSkuId={selectedSkuId}
            switchConfigGlobal={switchConfigGlobal}
            variation={variation}
            disableNavToPDP={disableNavToPDP}
            registryProductInfo={registryProductInfo}
            hideIdeaboardIcon={pageIdentifier === 'IdeaboardDetail'}
            isIntlRestricted={isIntlRestricted}
            isCompare={isCompare}
            productCompareData={productCompareData}
            miniQuickViewModal={enableMiniQuickViewModal}
            pageIdentifier={pageIdentifier}
            onPickupInStoreButtonClick={onPickupInStoreButtonClick}
            miniQuickViewMode={miniQuickViewMode}
            {...props}
          />
          {pageIdentifier === 'IdeaboardDetail' && (
            <PLPQuickViewTealiumHandler
              pageType={props.pageType}
              variation={variation}
              pageIdentifier={pageIdentifier}
              switchConfigGlobal={switchConfigGlobal}
              productVariation={productVariation}
            />
          )}
        </React.Fragment>
      ) : (
        <React.Fragment>
          {!isLtlItem &&
            disableNavToPDP &&
            giftGiver && (
              <div>
                <Notification
                  status={'error'}
                  wrapperClass={'mb3 small-mb3'}
                  content={LabelsUtil.getLabel(
                    props.guestViewerLabels,
                    'quickViewPYNotification'
                  )}
                />
              </div>
            )}
          {parentProductData.PRODUCT_VARIATION === 'COLLECTION' ? (
            <ProductItemListAsync
              profileHasRegistries={profileHasRegistries}
              childProducts={selectedProduct}
              parentProductData={parentProductData}
              isCompare={isCompare}
              quickViewMode={isQuickViewOpen}
              productUrl={productUrl}
              view="list"
              bopisSavingMsg={bopisSavingMsg}
              closeModal={onModalClose}
              hideModal={onModalHide}
              switchConfigGlobal={switchConfigGlobal}
              ProductBadgingConfig={ProductBadgingConfig}
              hideIdeaboardIcon={pageIdentifier === 'IdeaboardDetail'}
              pageIdentifier={pageIdentifier}
              productAttributes={productAttributes}
              productCompareData={productCompareData}
              itemListError={quickViewError}
              onPickupInStoreButtonClick={onPickupInStoreButtonClick}
              {...props}
            />
          ) : (
            <div>
              <ProductDetails
                isNeedToExcluded={checkItemNeedToExcluded(
                  itemType,
                  jdaCatName,
                  sKUDetailVO
                )}
                isRBYRItem={isRBYR}
                isRBYRRegistryEnabled={isRBYRRegistryEnabled}
                profileHasRegistries={profileHasRegistries}
                selectedProduct={selectedProduct}
                view="twoColumnLayout"
                quickViewMode={isQuickViewOpen}
                bopisSavingMsg={bopisSavingMsg}
                closeModal={onModalClose}
                hideModal={onModalHide}
                showError={showError}
                selectedSkuId={selectedSkuId}
                switchConfigGlobal={switchConfigGlobal}
                variation={variation}
                disableNavToPDP={disableNavToPDP}
                registryProductInfo={registryProductInfo}
                hideIdeaboardIcon={pageIdentifier === 'IdeaboardDetail'}
                isIntlRestricted={isIntlRestricted}
                isCompare={isCompare}
                productAttributes={productAttributes}
                productCompareData={productCompareData}
                preLoadImage={preLoadImage}
                onPickupInStoreButtonClick={onPickupInStoreButtonClick}
                giftGiver={giftGiver}
                {...props}
              />
              {variation !== REGISTRY_QUICK_VIEW &&
                variation !== LIST_QUICK_VIEW &&
                switchConfigGlobal.enableCertona &&
                switchConfigGlobal.enableQVCertona &&
                pageIdentifier !== 'IdeaboardDetail' && (
                  <QuickViewCertona
                    {...props}
                    quickViewMode={isQuickViewOpen}
                    track={props.track}
                    isShowBadge={props.isShowBadge}
                  />
                )}
            </div>
          )}
          {isQuickViewOpen && fireTealium ? (
            <PLPQuickViewTealiumHandler
              pageType={props.pageType}
              variation={variation}
              pageIdentifier={pageIdentifier}
              switchConfigGlobal={switchConfigGlobal}
              productVariation={productVariation}
            />
          ) : (
            ''
          )}
        </React.Fragment>
      )}
    </ErrorBoundary>
  );
};

QuickViewModal.propTypes = propTypes;
QuickViewModal.defaultProps = defaultProps;

export default withSiteSpectTracker(QuickViewModal);
