/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';

import { options } from '@bbb-app/universal-component/options';

export const MiniQuickViewModal = universal(
  import(/* webpackChunkName: "MiniQuickViewModal" */ './MiniQuickViewModal'),
  options
);

export default MiniQuickViewModal;
