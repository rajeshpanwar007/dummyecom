export { default } from './QuickViewModal';
