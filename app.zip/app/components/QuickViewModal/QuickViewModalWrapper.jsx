import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import QuickViewModal from '../../containers/QuickViewModal/QuickViewModal.async';
import styles from './QuickViewModal.css';

class QuickViewModalWrapper extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      isDesktop: typeof window !== 'undefined' && window.innerWidth >= 1024,
    };
  }

  renderQuickView = () => {
    const {
      selectedProduct,
      productId,
      isQuickViewOpen,
      variation,
      registryId,
      noModeration,
      pageName,
      giftGiver,
      guestViewerLabels,
      isIdeaboardOwner,
      pageType,
      registryData,
      modalComponent,
      selectedCheckboxFilter,
      hideParent,
    } = this.props;

    return (
      <QuickViewModal
        registryData={registryData}
        transitionDataSkeleton={selectedProduct}
        productIdSkeleton={productId}
        isQuickViewOpenSkeleton={isQuickViewOpen}
        variation={variation}
        registryId={registryId}
        noModeration={noModeration}
        pageName={pageName}
        giftGiver={giftGiver}
        guestViewerLabels={guestViewerLabels}
        isIdeaboardOwner={isIdeaboardOwner}
        pageType={pageType}
        modalComponent={modalComponent}
        selectedCheckboxFilter={selectedCheckboxFilter}
        hideParent={hideParent}
        replaceProps={this.props.replaceProps}
        quickAddProps={this.props.quickAddProps}
      />
    );
  };

  render() {
    const {
      isPickupInStoreModalOpen,
      isQuickViewOpen,
      getRecommendedItemModalClose,
      isQuickViewHidden,
      switchConfigGlobal,
      productVariation,
      miniQuickViewMode,
      hideParentModal,
      isBopisFeatureEnable,
      selectedProduct,
    } = this.props;
    const quickViewClass =
      isPickupInStoreModalOpen || hideParentModal ? 'hide' : '';
    const enableMiniQuickViewModal = pathOr(
      false,
      'enableMiniQuickViewModal',
      switchConfigGlobal
    );
    const { isDesktop } = this.state;
    return (
      <ErrorBoundary>
        {enableMiniQuickViewModal &&
        productVariation === 'NORMAL' &&
        miniQuickViewMode ? (
          <ModalDialog
            mountedState={isQuickViewOpen}
            toggleModalState={getRecommendedItemModalClose}
            rclModalClass={styles.rclMiniQuickViewModalContainer}
            titleAriaLabel={pathOr(
              'Quick View Modal',
              'DISPLAY_NAME',
              selectedProduct
            )}
            variation={isDesktop ? `small` : `large`}
            verticallyCenter
            underlayClickNoExit
            scrollDisabled={false}
            hideParent={isQuickViewHidden}
            onModalClose={
              pathOr(null, 'replaceProps.closeReplaceModal', this.props) ||
              pathOr(null, 'quickAddProps.toggleChooseOptionState', this.props)
            }
            dialogClass={classnames(
              quickViewClass,
              'QuickViewModal',
              /* istanbul ignore next: condition will always return true, no point of adding below condition. */
              miniQuickViewMode ? styles.mswpModal : styles.qvModal
            )}
          >
            {isQuickViewOpen && this.renderQuickView()}
          </ModalDialog>
        ) : (
          <ModalDialog
            mountedState={isQuickViewOpen}
            toggleModalState={getRecommendedItemModalClose}
            rclModalClass={styles.rclModalContainer}
            titleAriaLabel={pathOr(
              'Quick View Modal',
              'DISPLAY_NAME',
              selectedProduct
            )}
            variation="medium"
            verticallyCenter
            underlayClickNoExit
            scrollDisabled={false}
            hideParent={isQuickViewHidden}
            dialogClass={classnames(
              quickViewClass,
              'QuickViewModal',
              styles.qvModal
            )}
            isBopisFeatureEnable={isBopisFeatureEnable}
          >
            {isQuickViewOpen && this.renderQuickView()}
          </ModalDialog>
        )}
      </ErrorBoundary>
    );
  }
}

QuickViewModalWrapper.propTypes = {
  isPickupInStoreModalOpen: PropTypes.bool,
  isQuickViewOpen: PropTypes.bool,
  getRecommendedItemModalClose: PropTypes.func,
  isQuickViewHidden: PropTypes.bool,
  selectedProduct: PropTypes.bool,
  productId: PropTypes.string,
  switchConfigGlobal: PropTypes.object,
  productVariation: PropTypes.string,
  miniQuickViewMode: PropTypes.bool,
  variation: PropTypes.string,
  registryId: PropTypes.string,
  noModeration: PropTypes.bool,
  pageName: PropTypes.string,
  giftGiver: PropTypes.bool,
  guestViewerLabels: PropTypes.object,
  isIdeaboardOwner: PropTypes.bool,
  pageType: PropTypes.string,
  registryData: PropTypes.object,
  modalComponent: PropTypes.any,
  selectedCheckboxFilter: PropTypes.string,
  hideParentModal: PropTypes.bool,
  hideParent: PropTypes.func,
  isBopisFeatureEnable: PropTypes.bool,
  replaceProps: PropTypes.object,
  quickAddProps: PropTypes.object,
};

export default QuickViewModalWrapper;
