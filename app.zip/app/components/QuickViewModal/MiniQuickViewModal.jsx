import React from 'react';
import qs from 'qs';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import { isEmpty, isArray, isEqual } from 'lodash';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import { isNull } from '@bbb-app/utils/common';
import ShiptSddUtil from '@bbb-app/utils/ShiptSddUtil';
import Button from '@bbb-app/core-ui/button';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import Paragraph from '@bbb-app/core-ui/paragraph';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import isTbs from '@bbb-app/utils/isTbs';
import shopInStoreUtilFn from '@bbb-app/utils/shopInStoreUtil';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import PrimaryLinkContainer from '@bbb-app/plp-primary-link/containers/PrimaryLink';
import removeRefNumForVendorPrice from '../Pages/PDP/ProductDetails/Utils/removeRefNumForVendorPrice';
import PDPPrice from '../Pages/PDP/ProductDetails/Components/PDPPrice';
import { NO_SIZE, NO_SWATCH } from '../../constants/CallToAction';
import MultiSKUComponent from '../common/MultiSKU/MultiSKU';
import AddToCart from '../../containers/AddToCart/AddToCart.async';
import AddToRegistry from '../../containers/AddToRegistry/AddToRegistry';
import { TBSProductDetailsUtil } from '../Pages/PDP/ProductDetails/TBSProductDetailsUtil';
import {
  getIsIntlRestricted,
  addToRegistryExperiment,
  getMinimumQtyMessage,
  checkIfProductIsAvailable,
} from '../Pages/PDP/ProductDetails/ExtendedProductDetailsUtil';
import styles from './MiniQuickViewModal.css';
import { ProductDetailsUtil } from '../Pages/PDP/ProductDetails/ProductDetailsUtil';
import Skeleton from './Skeleton/Skeleton';
import CompareCta from '../../containers/Pages/Compare/ComparePage/CompareCta/CompareCta.async';
import QuickViewStoreInfo from '../../containers/Pages/PDP/TBS/StoreInventoryStatus/QuickViewStoreStatus/QuickViewStoreInfo';
import PDPPickItUp from '../../containers/PDPPickItUp/PDPPickItUp.async';
import PDPShipIt from '../PDPShipIt/PDPShipIt';
import Personalization from '../../containers/Pages/PDP/Personalization/Personalization.async';
const defaultState = {
  isFetching: true,
  hasError: false,
  swatchError: '',
  callToAction: {
    error: {
      NO_SWATCH: '',
      NO_SIZE: '',
      NO_LTL: '',
    },
  },
  callToActionValue: '',
  quantity: 1,
  isSubscriptionSelected: false,
};

const defaultProps = {
  selectedProduct: null,
  isFetching: false,
  error: null,
  productId: null,
  isFlipFLopATR: false,
};

const propTypes = {
  selectedProduct: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  labels: PropTypes.string,
  switchConfigGlobal: PropTypes.object,
  selectedSKU: PropTypes.object,
  deviceConfig: PropTypes.object.isRequired,
  config: PropTypes.object.isRequired,
  skuSelectionAction: PropTypes.func,
  quickViewMode: PropTypes.bool,
  formWrapperData: PropTypes.object,
  skuDetail: PropTypes.array,
  fireTealiumAction: PropTypes.func,
  productId: PropTypes.string,
  closeModal: PropTypes.func,
  hideModal: PropTypes.func,
  contextPath: PropTypes.string,
  tbsSkuInventoryData: PropTypes.object,
  viewType: PropTypes.string,
  miniQuickViewModal: PropTypes.bool,
  selectedSkuId: PropTypes.string,
  getLTLDetails: PropTypes.func,
  isFetching: PropTypes.bool,
  skuError: PropTypes.object,
  isMobile: PropTypes.bool,
  ltlData: PropTypes.object,
  pdpTealiumData: PropTypes.object,
  skuId: PropTypes.any,
  price: PropTypes.any,
  isCompare: PropTypes.bool,
  isFlipFLopATR: PropTypes.bool,
  profileHasRegistries: PropTypes.bool,
  allRegistryExpirationStatus: PropTypes.bool,
  onPickupInStoreButtonClick: PropTypes.func,
  isLoggedIn: PropTypes.bool,
  quantity: PropTypes.number,
  location: PropTypes.object,
  subscriptionSelection: PropTypes.object,
  vendorPriceDetails: PropTypes.array,
  showError: PropTypes.func,
  changeQuantity: PropTypes.func,
  miniQuickViewMode: PropTypes.bool,
  eventType: PropTypes.string,
  registriesList: PropTypes.object,
  nearestStoreAvailabilty: PropTypes.string,
  clickFromPLPTile: PropTypes.bool,
  showSDDResults: PropTypes.bool,
  sddMarketData: PropTypes.object,
  switchConfig: PropTypes.object,
  replaceProps: PropTypes.object,
  quickAddProps: PropTypes.object,
};

class MiniQuickViewModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = defaultState;
    this.productUrl = '';
    this.validateCallToAction = this.validateCallToAction.bind(this);
    this.updateCallToAction = this.updateCallToAction.bind(this);
    this.isInternationalUser = isInternationalUser();
    this.isOutOfStock = this.isOutOfStock.bind(this);
    this.displayFindInStoreLink = this.displayFindInStoreLink.bind(this);
    this.getRegistryId = this.getRegistryId.bind(this);
    this.isPlpMobileExperiment = false;
    this.isShipTSdd = ShiptSddUtil(props.location) || props.showSDDResults;
    this.isShopInStore = shopInStoreUtilFn(props.location);
    this.getPersonalizationByType = this.getPersonalizationByType.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    const { selectedProduct, selectedSkuId } = this.props;
    if (
      selectedProduct !== nextProps.selectedProduct &&
      this.state.callToActionValue
    ) {
      const interimState = this.getUpdatedErrorState(nextProps);
      this.setState(interimState);
    }
    if (
      nextProps.selectedProduct &&
      nextProps.selectedSkuId &&
      nextProps.selectedProduct.LTL_FLAG === 'true' &&
      selectedSkuId !== nextProps.selectedSkuId
    ) {
      this.props.getLTLDetails(nextProps.selectedSkuId);
    }
  }

  getProductPrice() {
    const { selectedProduct, labels, miniQuickViewModal, ltlData } = this.props;
    const { enableDynamicPricing } = this.props.switchConfigGlobal;
    return (
      <PDPPrice
        selectedProduct={selectedProduct}
        labels={labels}
        enableDynamicPricing={enableDynamicPricing}
        miniQuickViewModal={miniQuickViewModal}
        ltlData={ltlData}
        isBeyondPriceHidden
      />
    );
  }
  getCouponMsg = couponInEligibleMsg => {
    const { labels } = this.props;
    return (
      <p className={classnames(styles.couponFont, 'fol', 'my0')} tabIndex={0}>
        {LabelsUtil.getLabel(labels, 'excludedFromCoupons')}
        <Button
          data-tooltip={couponInEligibleMsg}
          theme="ghost"
          variation="noPadding"
          iconProps={{
            type: 'helpIcon',
            height: '12px',
            width: '12px',
          }}
          className={classnames('ml1', 'tooltip-top', styles.tooltip)}
        />
      </p>
    );
  };

  getProductHeading(DISPLAY_NAME) {
    /* istanbul ignore next */
    const LinkWithDangerousHTML = dangerousHTML(props => (
      <PrimaryLink {...props} href={this.productUrl} title={DISPLAY_NAME} />
    ));
    return (
      <Heading level={3} className={classnames('mb1')}>
        <LinkWithDangerousHTML>{DISPLAY_NAME}</LinkWithDangerousHTML>
      </Heading>
    );
  }

  getClassForATRATC() {
    const divClass = 'renderfullWidthATR';
    return divClass;
  }

  getProductSwatches() {
    const pdpState = this.state;
    const callToActionValue = pathOr('', 'callToActionValue', pdpState);
    const isSizeEmpty = isEqual(
      NO_SIZE,
      pathOr('', 'callToAction.error.NO_SIZE', pdpState)
    );
    const mPulseEnabled = ProductDetailsUtil.isMpulseEnabled(this.props);

    const isSwatchEmpty = isEqual(
      NO_SWATCH,
      pathOr('', 'callToAction.error.NO_SWATCH', pdpState)
    );
    const ensemblesCount = pathOr(
      0,
      'ensemblesCount.ensembles_count',
      this.props
    );
    const productId = pathOr('', 'selectedProduct.PRODUCT_ID', this.props);
    return (
      <div className={classnames('lg-mb15 md-mb15 sm-mb0')}>
        <MultiSKUComponent
          productId={productId}
          productDisplayName={
            (isArray(this.props.selectedProduct.SKU_DISPLAY_NAME)
              ? this.props.selectedProduct.DISPLAY_NAME
              : this.props.selectedProduct.SKU_DISPLAY_NAME) ||
            this.props.selectedProduct.DISPLAY_NAME
          }
          isSizeEmpty={isSizeEmpty}
          isSwatchEmpty={isSwatchEmpty}
          callToActionValue={callToActionValue}
          selectedProduct={this.props.selectedProduct}
          selectedSKU={this.props.selectedSKU}
          deviceConfig={this.props.deviceConfig}
          config={this.props.config}
          skuSelectionAction={this.props.skuSelectionAction}
          labels={this.props.labels}
          handleSwatchChange={this.handleSwatchChange}
          ensemblesCount={ensemblesCount}
          quickViewMode={this.props.quickViewMode}
          formWrapperData={this.props.formWrapperData}
          mPulseEnabled={mPulseEnabled}
          fireTealiumAction={this.props.fireTealiumAction}
          skuDetail={this.props.skuDetail}
          isMobile={this.props.isMobile}
          miniQuickViewModal={this.props.miniQuickViewModal}
          pdpData={this.props.pdpTealiumData}
          clickFromPLPTile={this.props.clickFromPLPTile}
          showAllOptions
          isChooseOption
        />
      </div>
    );
  }

  getUpdatedErrorState(nextProps) {
    const interimState = Object.assign({}, this.state);
    /* istanbul ignore else */
    if (!isEmpty(nextProps.selectedSKU.colorVariation)) {
      interimState.callToAction.error[NO_SWATCH] = '';
    }
    /* istanbul ignore else */
    if (nextProps.selectedSKU.sizeVariation) {
      interimState.callToAction.error[NO_SIZE] = '';
    }
    return interimState;
  }

  /**
	 * Get Product Url base on ProductId, skuId & add swatch query params(if any)
	 * @returns {string} : Product Url
	 */
  getProductUrl = () => {
    const { contextPath, productId, selectedSKU } = this.props;
    const { SEO_URL } = this.props.selectedProduct;
    let url = `${contextPath}${SEO_URL}?poc=${productId}`;
    let query = '';
    if (this.isShipTSdd) query = 'sdd=true';
    if (this.isShopInStore) query = 'pickup=true';
    if (selectedSKU && selectedSKU.skuId) {
      url += `${'&'}skuId=${selectedSKU.skuId}`;
    } else if (selectedSKU && !isEmpty(selectedSKU.colorVariation)) {
      url += `${'&'}color=${selectedSKU.colorVariation.label}`;
    } else if (selectedSKU && !isEmpty(selectedSKU.sizeVariation)) {
      url += `${'&'}size=${selectedSKU.sizeVariation}`;
    }
    if (query) url += `&${query}`;
    return url;
  };
  getProductNotAvailableMsg() {
    const NotAvailMessage = dangerousHTML(Paragraph);
    const { labels } = this.props;
    return (
      <NotAvailMessage className={styles.notAvailableOnline}>
        {LabelsUtil.getLabel(labels, 'productNotAvailableOnline')}
      </NotAvailMessage>
    );
  }

  setSubscriptionSelection(value) {
    this.setState({
      isSubscriptionSelected: value,
    });
  }
  getRegistryId() {
    return ProductDetailsUtil.getRegistryId(this.props);
  }

  getPersonalizationByType(type, vendorProps, disableNavToPDP, isShipIt) {
    const { vendorPriceDetails } = vendorProps;
    return !vendorPriceDetails ? (
      <ErrorBoundary>
        <Personalization
          type={type}
          {...vendorProps}
          disableNavToPDP={disableNavToPDP}
          switchConfig={this.props.switchConfig}
          switchConfigGlobal={this.props.switchConfigGlobal}
          isShipIt={isShipIt}
        />{' '}
      </ErrorBoundary>
    ) : (
      ''
    );
  }

  isOutOfStock(isOutOfStock, showNotifyFlag, props, labels, isShipIt) {
    return ProductDetailsUtil.isOutOfStock(
      isOutOfStock,
      showNotifyFlag,
      props,
      labels,
      isShipIt,
      this.props.onPickupInStoreButtonClick
    );
  }

  displayFindInStoreLink(props, isPickItUp) {
    return ProductDetailsUtil.handleDisplayFindInStoreLink(
      props,
      isPickItUp,
      this.validateCallToAction,
      this.updateCallToAction,
      this.state.isSubscriptionSelected,
      this.props.onPickupInStoreButtonClick
    );
  }
  updateCallToAction(value) {
    return this.setState({
      callToActionValue: value,
    });
  }

  validateCallToAction(error) {
    return this.setState({
      callToAction: {
        error: {
          NO_SIZE: error.NO_SIZE,
          NO_SWATCH: error.NO_SWATCH,
          NO_LTL: error.NO_LTL,
        },
      },
    });
  }

  returnPrimaryATRValue = profileHasRegistries => {
    return profileHasRegistries && addToRegistryExperiment(this.props.config);
  };

  /**
	 * Render Pick it up button
	 * @param {object} labels
	 * @param {bool} isPrimaryATR
	 * @param {string} siteId
	 */
  renderPickItUp(isPrimaryATR, labels, viewType) {
    const siteId = pathOr('', 'siteId', this.props.config);
    const pdpProps = {
      vdcCaseMsg: ProductDetailsUtil.getVendorShippingMessage(this.props),
      ...this.props,
    };
    const mPulseEnabled = ProductDetailsUtil.isMpulseEnabled(this.props);
    const isPnHEvent =
      this.props.eventType === 'PACK_HOLD' ||
      this.props.eventType === 'PACK_HOLD_MOVING';
    const LTLItem =
      pathOr('false', 'LTL_FLAG', this.props.selectedProduct) === 'true';
    const storeOnlyAvailable = this.props.selectedProduct.storeOnly && !isTbs();
    return (
      !LTLItem && (
        <PDPPickItUp
          selectedSkuId={this.props.selectedSKU.skuId}
          findInStoreHandler={this.props.onPickupInStoreButtonClick}
          onClientError={this.validateCallToAction}
          updateCallToAction={this.updateCallToAction}
          displayFindInStoreLink={this.displayFindInStoreLink}
          selectedProduct={this.props.selectedProduct}
          pdpProps={pdpProps}
          labels={labels}
          swatchError={this.state.swatchError}
          siteId={siteId}
          mPulseEnabled={mPulseEnabled}
          isSubscriptionSelected={this.state.isSubscriptionSelected}
          isPrimary={
            !(
              (!this.state.isSubscriptionSelected && isPrimaryATR) ||
              (this.props.isLoggedIn && isPnHEvent)
            )
          }
          miniQuickViewMode={this.props.miniQuickViewMode}
          isPdpTrue
          storeOnlyAvailable={storeOnlyAvailable}
          nearestStoreAvailabilty={this.props.nearestStoreAvailabilty}
          viewType={viewType}
          replaceProps={this.props.replaceProps}
          quickAddProps={this.props.quickAddProps}
        />
      )
    );
  }

  /**
	 * Render Ship it up button
	 * @param {object} labels
	 * @param {bool} isOutOfStock
	 * @param {string} viewType
	 * @param {bool} intlRestrictedItem
	 */
  /* eslint complexity: ["error", 16]*/
  renderShipItUp(
    isOutOfStock,
    isPrimaryATR,
    viewType,
    labels,
    intlRestrictedItem
  ) {
    let checkOOS = false;
    const otherArgs = { viewType, labels };
    const locationSearch = pathOr('', 'search', this.props.location);
    const query = qs.parse(locationSearch, { ignoreQueryPrefix: true });
    const isRBYR = pathOr(false, 'isRBYRItem', query);
    const isRBYRRegistryEnabled = pathOr(false, 'isRBYRRegistryEnabled', query);
    const pdpProps = {
      vdcCaseMsg: ProductDetailsUtil.getVendorShippingMessage(this.props),
      ...this.props,
    };
    const tbsSkuInventoryData = this.props.tbsSkuInventoryData;
    const selectedSkuInventory = pathOr(
      null,
      'tbsMultiSkuInventory',
      tbsSkuInventoryData
    );
    const isIntlRestricted = pathOr(
      null,
      'INTL_RESTRICTED',
      this.props.selectedProduct
    );
    const vendorPriceDetails = this.props.vendorPriceDetails;

    const zipProps = {
      pdpProps,
      isPdpTrue: true,
      findInStoreHandler: this.props.onPickupInStoreButtonClick,
      onClientError: this.validateCallToAction,
      updateCallToAction: this.updateCallToAction,
      attribJSON: pathOr({}, 'ATTRIBUTES_JSON', this.props.selectedProduct),
      mPulseEnabled: ProductDetailsUtil.isMpulseEnabled(this.props),
      isIntlRestricted,
      swatchError: this.state.swatchError,
      switchConfigGlobal: this.props.switchConfigGlobal,
      vdcOffSetDate: pathOr(
        null,
        'VDC_OFFSET_DATE',
        this.props.selectedProduct
      ),
      selectedSkuInventory,
      isSubscriptionSelected: this.state.isSubscriptionSelected,
    };
    const { subscriptionSelection } = this.props;
    const itemExcludedReason = TBSProductDetailsUtil.getTbsItemExcludedReason(
      this.props.selectedProduct,
      true
    );
    /* istanbul ignore next */
    const disableFlag = isTbs()
      ? pathOr(0, 'DISABLE_FLAG', this.props.selectedProduct) === 1
      : false;
    const itemDisabled = disableFlag || !!itemExcludedReason;

    const isProductAvailable = checkIfProductIsAvailable(
      intlRestrictedItem,
      isOutOfStock,
      itemDisabled
    );
    const {
      type,
      showPersonalization,
    } = ProductDetailsUtil.validatePersonalizationByCriteria(this.props);

    const quantity = ProductDetailsUtil.validateQuantity(this.props.quantity);
    const eventType = pathOr(
      null,
      'makeSelectActiveRegistry.eventType',
      this.props
    );

    const isPnHEvent =
      eventType === 'PACK_HOLD' || eventType === 'PACK_HOLD_MOVING';
    const isPrimaryPnH = this.props.isLoggedIn && isPnHEvent;

    const themeATC = isPrimaryATR || isPrimaryPnH ? 'secondary' : 'primary';

    const EMAIL_OUT_OF_STOCK =
      pathOr('false', 'EMAIL_OUT_OF_STOCK', this.props.selectedProduct) ===
      'true';
    const showNotifyFlag = isOutOfStock ? EMAIL_OUT_OF_STOCK === true : false;
    checkOOS = isOutOfStock;
    const parentProductValue = query.poc
      ? query.poc
      : pathOr('', 'PARENT_PRODUCT', this.props.selectedProduct)[0];
    let atcLabel = '';
    if (!isOutOfStock) {
      if (this.state.isSubscriptionSelected) {
        atcLabel = 'subscriptionAtc';
      } else {
        atcLabel = 'cart';
      }
    } else {
      atcLabel = 'outOfStock';

      otherArgs.refNum = '';
      /* istanbul ignore else */
      if (
        typeof vendorPriceDetails !== 'undefined' &&
        !isEmpty(vendorPriceDetails)
      ) {
        otherArgs.refNum = pathOr('', 'refnum', vendorPriceDetails);
      }
    }
    const sddOnly = this.isShipTSdd;

    return (
      <PDPShipIt
        AddToCart={AddToCart}
        atcProps={this.props}
        labels={labels}
        query={query}
        zipProps={zipProps}
        subscriptionSelection={subscriptionSelection}
        isRBYR={JSON.parse(isRBYR)}
        isRBYRRegistryEnabled={isRBYRRegistryEnabled}
        isProductAvailable={isProductAvailable}
        subscriptionItem={this.state.isSubscriptionSelected}
        isOutOfStock={checkOOS}
        showNotifyFlag={showNotifyFlag}
        quantity={quantity}
        swatchError={this.state.swatchError}
        viewType={this.props.viewType || 'PDP'}
        themeATC={themeATC}
        refNum={otherArgs.refNum}
        parentProductValue={parentProductValue}
        atcLabel={atcLabel}
        type={type}
        showPersonalization={showPersonalization}
        getPersonalizationByType={this.getPersonalizationByType}
        vendorPriceDetails={vendorPriceDetails}
        validateCallToAction={this.validateCallToAction}
        updateCallToAction={this.updateCallToAction}
        changeQuantity={this.props.changeQuantity}
        removeRefNumForVendorPrice={removeRefNumForVendorPrice}
        showError={this.props.showError}
        getRegistryId={this.getRegistryId}
        getIsOutOfStock={this.isOutOfStock}
        sddOnly={sddOnly}
        sddMarketData={sddOnly && this.props.sddMarketData}
        isChooseOption
      />
    );
  }
  /**
	* Render add to Registry CTA
	* @param {object} labels
	* @param {bool} isOutOfStock
	* @param {bool} quickViewMode
	* @param {string} viewType
	* @param {string} ltlFlag
	*/
  // eslint-disable-next-line max-params
  renderAddToRegistry(
    isFetching,
    labels,
    price,
    quickViewMode,
    viewType,
    ltlFlag,
    intlRestrictedItem,
    isPrimaryATR
  ) {
    const themeATR = isPrimaryATR ? 'primary' : 'secondary';
    const btnClassName = [
      isPrimaryATR ? styles.primaryCTAPDP : styles.lightLink,
      isPrimaryATR ? '' : styles.ctaButtonPDP,
    ];
    const loadHyperlink = !isPrimaryATR;
    return (
      <React.Fragment>
        <AddToRegistry
          isLazyLoad={false}
          isFetching={isFetching}
          quickViewMode={quickViewMode}
          skuId={this.props.selectedSKU.skuId}
          prodId={this.props.selectedProduct.PRODUCT_ID}
          qty={1}
          swatchError={this.state.swatchError}
          productVariation={this.props.selectedProduct.PRODUCT_VARIATION}
          size={this.props.selectedSKU.sizeVariation}
          swatch={this.props.selectedSKU.colorVariation}
          viewType={viewType}
          buttonProps={{
            attr: {
              theme: intlRestrictedItem ? 'deactivated' : themeATR,
              className: classnames(
                btnClassName,
                {
                  fullWidth: !loadHyperlink,
                },
                'mb1'
              ),
              'data-locator': 'miniquickview-addtoregistrybutton',
              'aria-describedby': 'atrErrorTooltip',
              loadHyperlink,
              href: '#',
            },
            children: LabelsUtil.getLabel(labels, 'addToRegistry'),
          }}
          onClientError={this.validateCallToAction}
          updateCallToAction={this.updateCallToAction}
          onSuccess={() => {
            this.setState({
              quantity: 1,
            });
          }}
          parentProductId={this.props.productId ? this.props.productId : ''}
          atrWrapperClass={loadHyperlink ? 'inline' : ''}
          plpATRskipNotifyFlag={'true'}
          price={price}
          isCustomizationRequired={false}
          closeQuickViewModal={this.props.closeModal}
          onModalHide={this.props.hideModal}
          ltlFlag={ltlFlag}
          selectedProduct={this.props.selectedProduct}
          refNum={''}
          isFlipFLopATR={this.props.isFlipFLopATR}
          isPrimaryATR={isPrimaryATR}
          isInitLoadATR
          isChooseOption
          replaceProps={this.props.replaceProps}
          quickAddProps={this.props.quickAddProps}
        />
      </React.Fragment>
    );
  }

  /**
	 * Render ATC, ATR and Compare Now button based on isCompare Prop
	 * @param {bool} ltlFlag
	 * @param {bool} isOutOfStock
	 * @param {object} intlRestrictedItem
	 */
  renderCTAs = (ltlFlag, isOutOfStock, intlRestrictedItem) => {
    const {
      labels,
      viewType,
      isCompare,
      isFlipFLopATR,
      profileHasRegistries,
      selectedProduct,
      allRegistryExpirationStatus,
      isFetching,
      price,
      quickViewMode,
      registriesList,
    } = this.props;
    const profilelistTypeRegList =
      !isEmpty(registriesList.profilelistTypeRegList) &&
      registriesList.profilelistTypeRegList.length > 0;
    const isPrimaryATR =
      isFlipFLopATR ||
      profilelistTypeRegList ||
      (this.returnPrimaryATRValue(profileHasRegistries) &&
        allRegistryExpirationStatus);
    if (isCompare) {
      return <CompareCta pdpProps={this.props} />;
    }
    const storeOnlyAvailable = this.props.selectedProduct.storeOnly && !isTbs();
    const isEverliving =
      pathOr('', 'IS_EVERLIVING', selectedProduct) === 'true';
    const sddEligible = pathOr(
      false,
      'sddEligibleFlag',
      this.props.selectedProduct
    );
    return isEverliving ? (
      this.getProductNotAvailableMsg()
    ) : (
      <React.Fragment>
        {isPrimaryATR &&
          this.renderAddToRegistry(
            isFetching,
            labels,
            price,
            quickViewMode,
            viewType,
            ltlFlag,
            intlRestrictedItem,
            isPrimaryATR
          )}
        {this.isShipTSdd &&
          !storeOnlyAvailable &&
          sddEligible &&
          this.renderShipItUp(
            isOutOfStock,
            isPrimaryATR,
            viewType,
            labels,
            intlRestrictedItem
          )}

        {this.renderPickItUp(isPrimaryATR, labels, viewType)}
        {!this.isShipTSdd &&
          !storeOnlyAvailable &&
          this.renderShipItUp(
            isOutOfStock,
            isPrimaryATR,
            viewType,
            labels,
            intlRestrictedItem
          )}
        {!isPrimaryATR &&
          this.renderAddToRegistry(
            isFetching,
            labels,
            price,
            quickViewMode,
            viewType,
            ltlFlag,
            intlRestrictedItem,
            isPrimaryATR
          )}
      </React.Fragment>
    );
  };

  render() {
    const {
      labels,
      isFetching,
      skuDetail,
      selectedSkuId,
      switchConfigGlobal,
      clickFromPLPTile,
    } = this.props;
    let isOutOfStock = false;
    const selectedProduct = this.props.selectedProduct;
    const {
      SCENE7_URL,
      DISPLAY_NAME,
      TYPE,
      COUPON_INELIGIBILITY_FLAG,
      COUPON_INELIGIBILITY_MESSAGE,
    } = this.props.selectedProduct;
    const isCouponExcluded =
      pathOr(false, 'enableCouponExclusion', switchConfigGlobal) &&
      (COUPON_INELIGIBILITY_FLAG === true ||
        COUPON_INELIGIBILITY_FLAG === 'true');
    const finalSrc = getConcatenatedScene7URLWithImageId(SCENE7_URL);
    this.productUrl = this.getProductUrl();
    const tbsSkuInventoryData = this.props.tbsSkuInventoryData;
    const selectedSkuInventory = pathOr(
      null,
      'tbsMultiSkuInventory',
      tbsSkuInventoryData
    );
    const shipTimeFrame = pathOr(false, 'shipTimeFrame', selectedSkuInventory);
    /* istanbul ignore next */
    isOutOfStock = isTbs()
      ? TBSProductDetailsUtil.isTbsOutOfStock(selectedSkuInventory)
      : ProductDetailsUtil.getIsOutOFStock(
          TYPE,
          this.props.selectedSKU,
          this.props.skuDetail,
          this.props.selectedProduct
        );
    const ltlFlag = selectedProduct && selectedProduct.LTL_FLAG;
    const intlRestrictedItem = getIsIntlRestricted(
      this.props,
      this.isInternationalUser
    );
    const isSkeleton =
      !(skuDetail && skuDetail.length) && isNull(this.props.skuError);
    if (
      isFetching ||
      isSkeleton ||
      isNull(selectedProduct) ||
      isEmpty(selectedProduct)
    ) {
      return <Skeleton />;
    }
    /* istanbul ignore if: Code is not reacable, same code is avalible above */
    if (isNull(selectedProduct) || isEmpty(selectedProduct)) {
      return null;
    }
    const renderAttributes = product => {
      if (
        product &&
        product.selectedProduct &&
        typeof product.selectedProduct.PROD_ATTRIBUTES === 'object'
      ) {
        return product.selectedProduct.PROD_ATTRIBUTES.map(attribute => {
          return (
            <p
              key={attribute}
              className={classnames(styles.attribute, 'my0')}
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{
                __html: attribute,
              }}
              tabIndex={0}
            />
          );
        });
      }
      return null;
    };

    return (
      <ErrorBoundary>
        <React.Fragment>
          <div className={classnames('flex', 'mb2')}>
            <PrimaryLinkContainer
              href={this.productUrl}
              variation="primary"
              type="small"
              elementClicked={'Image'}
            >
              <img
                className={classnames(styles.imageContainer)}
                alt={DISPLAY_NAME}
                src={finalSrc}
                data-locator="chooseOptionModal_productImage"
              />
            </PrimaryLinkContainer>
            <div className={classnames('ml2')}>
              {this.getProductPrice()}
              {isCouponExcluded
                ? this.getCouponMsg(COUPON_INELIGIBILITY_MESSAGE)
                : ''}
              {this.getProductHeading(DISPLAY_NAME)}
            </div>
          </div>
          {this.isPlpMobileExperiment &&
            this.props.isMobile && (
              <div className={'mb2'}>{renderAttributes(this.props)}</div>
            )}
          {this.getProductSwatches()}
          {!clickFromPLPTile &&
            getMinimumQtyMessage(
              switchConfigGlobal,
              selectedSkuId,
              skuDetail,
              selectedProduct,
              labels
            )}
          {!clickFromPLPTile && (
            <div id={this.getClassForATRATC()}>
              {this.renderCTAs(ltlFlag, isOutOfStock, intlRestrictedItem)}
            </div>
          )}

          {this.isShipTSdd && (
            <PrimaryLink
              href={this.productUrl}
              variation="primary"
              className={styles.weCanShip}
            >
              {LabelsUtil.getLabel(labels, 'weCanShip')}
            </PrimaryLink>
          )}

          {!clickFromPLPTile && (
            <QuickViewStoreInfo
              labels={this.props.labels}
              productDetails={this.props}
              shipTimeFrame={shipTimeFrame}
            />
          )}
        </React.Fragment>
      </ErrorBoundary>
    );
  }
}
MiniQuickViewModal.propTypes = propTypes;
MiniQuickViewModal.defaultProps = defaultProps;

export default MiniQuickViewModal;
