export const YES = 'yes';
export const NO = 'no';
export const BLANK = '_blank';
export const FEEDBACK = 'feedback';
export const SEARCH = 'Search';
export const YESPARAM = 'Yes';
export const NOPARAM = 'No';
export const LOCATOR_YESNOFEEDBACK_NO_DROPDOWN =
  'yesnofeedback-dropdown-menu-for-no';
export const DROPDOWN_OPTIONS = [
  {
    label: '- Select -',
    props: {
      value: '',
    },
  },
  {
    label: 'Results are not relevant',
    props: {
      value: '00',
    },
  },
  {
    label: 'Results loaded too slowly',
    props: {
      value: '01',
    },
  },
  {
    label: 'Filter/sort was not helpful',
    props: {
      value: '10',
    },
  },
  {
    label: "Can't find specific item I am looking for",
    props: {
      value: '11',
    },
  },
];
