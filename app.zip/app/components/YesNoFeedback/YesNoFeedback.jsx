import React from 'react';
import PropTypes from 'prop-types';
import Cookies from 'universal-cookie';
import classnames from 'classnames';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Heading from '@bbb-app/core-ui/heading';
import HyperLink from '@bbb-app/core-ui/hyper-link';
import { isBrowser } from '@bbb-app/utils/filterUtils';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import getEncodedValue from '@bbb-app/utils/getEncodedValue';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import { getSearchWithinSearchInfo } from '@bbb-app/tealium/tagSelectors/searchWithinSearchWords';
import CustomSelect from '@bbb-app/custom-select/CustomSelect';
import styles from './YesNoFeedback.css';
import {
  YES,
  NO,
  BLANK,
  FEEDBACK,
  SEARCH,
  YESPARAM,
  NOPARAM,
  DROPDOWN_OPTIONS,
  LOCATOR_YESNOFEEDBACK_NO_DROPDOWN,
} from './constants';

const propTypes = {
  searchHeaderLabels: PropTypes.object,
  yesNoLinks: PropTypes.object,
  itemsPerPage: PropTypes.number,
  paging: PropTypes.object,
  facetInfo: PropTypes.object,
  boostedEngine: PropTypes.object,
  fireTealiumAction: PropTypes.func,
  sortValue: PropTypes.object,
};

export const customerSurveyURL = (customerSurveyLink, noResponseCode) => {
  const feedbackType = { '00': '00', '01': '01', '10': '02', '11': '03' };

  const queryStringObj = {
    QM: new Cookies().get('QuantumMetricSessionID'),
    Full_URL: isBrowser() && window.location.href,
    Yes_No_Response: noResponseCode ? 'No' : 'Yes',
    No_Response: noResponseCode ? feedbackType[noResponseCode] : undefined,
  };

  let customVars = JSON.stringify(queryStringObj);
  customVars = getEncodedValue(customVars);

  return `${customerSurveyLink}&customVars=${customVars}`;
};

const yesThankYouPageUI = (searchHeaderLabels, yesNoLinks, noResponseCode) => {
  const { yesNoCommonMsg, customerSurveyText, yesTextMsg } = searchHeaderLabels;
  const { customerSurveyLink } = yesNoLinks;

  return (
    <React.Fragment>
      <Paragraph className={classnames(styles.pText, 'mt0')}>
        {yesTextMsg}
      </Paragraph>
      <Paragraph className={classnames(styles.pText, 'mb0')}>
        {yesNoCommonMsg}{' '}
        <HyperLink
          href={`${customerSurveyURL(customerSurveyLink, noResponseCode)}`}
          className={styles.linkText}
          target={BLANK}
        >
          {customerSurveyText}
        </HyperLink>
      </Paragraph>
    </React.Fragment>
  );
};
const noThankYouPageUI = (searchHeaderLabels, yesNoLinks, noResponseCode) => {
  const {
    yesNoCommonMsg,
    customerSurveyText,
    noTextMsg,
    chatWithUsText,
    orYouCan,
  } = searchHeaderLabels;
  const { customerSurveyLink, chatWithUsLinkUs } = yesNoLinks;

  return (
    <React.Fragment>
      <Paragraph className={classnames(styles.pText, 'mt0')}>
        {noTextMsg}
      </Paragraph>
      <Paragraph className={classnames(styles.pText, 'mb0')}>
        {yesNoCommonMsg}{' '}
        <HyperLink
          href={`${customerSurveyURL(customerSurveyLink, noResponseCode)}`}
          className={styles.linkText}
          target={BLANK}
        >
          {customerSurveyText}
        </HyperLink>{' '}
        {orYouCan}{' '}
        <PrimaryLink
          href={chatWithUsLinkUs}
          className={styles.linkText}
          target={BLANK}
        >
          {chatWithUsText}
        </PrimaryLink>
      </Paragraph>
    </React.Fragment>
  );
};

class YesNoFeedback extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      yesNoPage: true,
      yesThankYouPage: false,
      noPage: false,
      noThankYouPage: false,
      noResponseCode: false,
    };
    this.navigateToYesOrNoPage = this.navigateToYesOrNoPage.bind(this);
    this.submitNoFeedback = this.submitNoFeedback.bind(this);
  }

  triggerTealiumAction(param) {
    const {
      itemsPerPage,
      paging,
      facetInfo,
      boostedEngine,
      fireTealiumAction,
      sortValue,
    } = this.props;

    if (fireTealiumAction) {
      let feedbackType = '';
      const pageNumber =
        paging && itemsPerPage > 0 ? Math.ceil(paging.end / itemsPerPage) : 1;
      if (param === '10') {
        feedbackType = '02';
      } else if (param === '11') {
        feedbackType = '03';
      } else {
        feedbackType = param;
      }
      const tealiumObj = {
        call_to_actiontype: FEEDBACK,
        page_type: SEARCH,
        feedback_subtype: feedbackType,
        search_within_search: getSearchWithinSearchInfo(),
        facets_applied: facetInfo && facetInfo.all_facets_applied,
        facet_order: facetInfo && facetInfo.facet_order,
        sort_value: sortValue && sortValue.sort_order,
        boosted_search_engine:
          boostedEngine && boostedEngine.boosted_search_engine,
        page_number: pageNumber,
      };

      this.props.fireTealiumAction('', tealiumObj, '');
    }
  }

  navigateToYesOrNoPage(yesNoParam) {
    if (yesNoParam === YES) {
      this.setState({
        yesNoPage: false,
        yesThankYouPage: true,
      });
      this.triggerTealiumAction(YESPARAM);
    } else if (yesNoParam === NO) {
      this.setState({
        yesNoPage: false,
        noPage: true,
      });
      this.triggerTealiumAction(NOPARAM);
    }
  }

  yesNoFeedbackButtons() {
    const { yesNoPage } = this.state;
    if (yesNoPage) {
      const { searchHeaderLabels } = this.props;
      const { yesNoHeadingText, yesText, noText } = searchHeaderLabels;
      return (
        <React.Fragment>
          <Heading level={4} className={classnames(styles.h4, 'mb2')}>
            {yesNoHeadingText}
          </Heading>
          <Button
            onClick={() => this.navigateToYesOrNoPage(YES)}
            theme="secondaryStrokeBasic"
            className={classnames(styles.buttonYesNoStyle, 'mr2')}
          >
            {yesText}
          </Button>
          <Button
            onClick={() => this.navigateToYesOrNoPage(NO)}
            theme="secondaryStrokeBasic"
            className={classnames(styles.buttonYesNoStyle, 'mr2')}
          >
            {noText}
          </Button>
        </React.Fragment>
      );
    }
    return null;
  }

  submitNoFeedback(index) {
    this.setState({
      noPage: false,
      noThankYouPage: true,
      noResponseCode: index,
    });
    this.triggerTealiumAction(index);
  }
  noPageUI() {
    const { searchHeaderLabels } = this.props;
    const { noDropTextMsg } = searchHeaderLabels;

    return (
      <React.Fragment>
        <Paragraph className={classnames(styles.pHeading, 'mt0 mb2')}>
          {noDropTextMsg}
        </Paragraph>
        <CustomSelect
          optionSet={DROPDOWN_OPTIONS}
          selectOption={this.submitNoFeedback}
          maxNumberOfElementsToShow={4}
          dataLocator={LOCATOR_YESNOFEEDBACK_NO_DROPDOWN}
          variationName="selectPrimary"
          wrapperClassName={classnames(
            'large-2 small-4 medium-offset-0 small-offset-1'
          )}
        />
      </React.Fragment>
    );
  }
  yesNoLanding() {
    const {
      yesThankYouPage,
      noThankYouPage,
      noPage,
      noResponseCode,
    } = this.state;
    const { searchHeaderLabels, yesNoLinks } = this.props;
    if (yesThankYouPage) {
      return yesThankYouPageUI(searchHeaderLabels, yesNoLinks, noResponseCode);
    } else if (noThankYouPage) {
      return noThankYouPageUI(searchHeaderLabels, yesNoLinks, noResponseCode);
    } else if (noPage) {
      return this.noPageUI();
    }
    return null;
  }
  render() {
    return (
      <GridContainer className="mt2 mb3">
        <GridX>
          <Cell className="large-5 center mx-auto ">
            {this.yesNoFeedbackButtons()}
            {this.yesNoLanding()}
          </Cell>
        </GridX>
      </GridContainer>
    );
  }
}

YesNoFeedback.propTypes = propTypes;

export default YesNoFeedback;
