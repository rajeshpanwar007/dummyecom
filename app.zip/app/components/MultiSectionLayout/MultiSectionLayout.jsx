import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import styles from './MultiSectionLayout.css';

const propTypes = {
  className: PropTypes.string,
  asideAttrs: PropTypes.object,
  asideContent: PropTypes.any.isRequired,
  mainContent: PropTypes.any.isRequired,
  mainContentProps: PropTypes.object,
  headingContent: PropTypes.any.isRequired,
  headingContentProps: PropTypes.object,
  labels: PropTypes.object,
  isAsideContent: PropTypes.bool,
};

const defaultProps = {
  className: null,
  asideAttrs: null,
  mainContentAttrs: null,
  addAddress: PropTypes.func,
  headingContent: null,
};

const MultiSectionLayout = ({
  isAsideContent,
  className,
  asideAttrs,
  asideContent: AsideContent,
  mainContent: MainContent,
  mainContentProps,
  headingContentProps,
  headingContent,
  ...props
}) => {
  const renderAsideContent = () => {
    return (
      <Cell className="large-3 sm-hide xs-hide">
        <div className="large-12">
          <aside
            className={classnames('pl3 pr3 pt2 pb3', styles.asideContainer)}
          >
            <AsideContent {...asideAttrs} />
          </aside>
        </div>
      </Cell>
    );
  };
  return (
    <div className={classnames(styles[className], styles.mainContainerWrapper)}>
      <GridContainer className={classnames(styles.accountWrapper)}>
        <GridX
          className={classnames('grid-margin-x', className, styles.pageWrapper)}
        >
          {headingContentProps.contain &&
            headingContentProps.contain === 'no-contain' && (
              <Cell
                className={classnames('large-11 large-offset-1 small-12 pb3')}
              >
                <PrimaryLink
                  className={classnames(
                    headingContentProps.alignment,
                    styles.rowWrapper
                  )}
                  variation="myPrefrences"
                  href="/"
                >
                  {headingContent}
                </PrimaryLink>
              </Cell>
            )}

          {isAsideContent && renderAsideContent()}

          <Cell
            className={classnames(
              'large-9 small-12 relative',
              isAsideContent
                ? [styles.myOfferAsideContentShow]
                : [styles.myOfferAsideContentHide]
            )}
          >
            <GridX>
              <Cell className={classnames('large-12 small-12 mb3')}>
                {headingContentProps.contain &&
                  headingContentProps.contain === 'contain' && (
                    <Heading level={1} className={styles.pageHeading}>
                      {headingContent}
                    </Heading>
                  )}
                <MainContent {...mainContentProps} {...props} />
              </Cell>
            </GridX>
          </Cell>
        </GridX>
      </GridContainer>
    </div>
  );
};

MultiSectionLayout.propTypes = propTypes;
MultiSectionLayout.defaultProps = defaultProps;

export default MultiSectionLayout;
