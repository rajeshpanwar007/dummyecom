import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';

import GridX from '@bbb-app/core-ui/grid-x';
import TeaserTile from '../../components/PureContent/TeaserTile';
import Pagination from '../../components/Pagination';
import Skeleton from './Skeleton/Skeleton';
import styles from './CuratedCategories.css';

class CuratedCategories extends React.PureComponent {
  static propTypes = {
    data: PropTypes.object,
    isFetching: PropTypes.bool,
    error: PropTypes.object,
    channelType: PropTypes.string,
    pageNumber: PropTypes.number,
    labels: PropTypes.object,
    updatePageNumber: PropTypes.number,
    curatedCategoriesConfig: PropTypes.object,
  };

  constructor(props) {
    super(props);

    this.onPageClick = this.onPageClick.bind(this);
  }

  onPageClick(page, event) {
    event.preventDefault();
    const { updatePageNumber, curatedCategoriesConfig } = this.props;
    const tilesPerPage = pathOr(9, 'tilesPerPage', curatedCategoriesConfig);
    const pageNumber = page.start > 0 ? page.start / tilesPerPage + 1 : 1;
    updatePageNumber(pageNumber);
  }

  renderTeaserCol3 = () => {
    const { data } = this.props;
    return (
      <GridX className={classnames('grid-margin-x')}>
        {data &&
          data.categories &&
          data.categories.map((categoryProductDetails, index) => {
            return (
              <TeaserTile
                key={index}
                data={categoryProductDetails}
                tileArragement="center small-12 medium-4"
                tileVariation="roundImgFullTheme"
              />
            );
          })}
      </GridX>
    );
  };

  render() {
    const {
      isFetching,
      error,
      channelType,
      data,
      pageNumber,
      labels,
      curatedCategoriesConfig,
    } = this.props;

    if (error) {
      return null;
    }

    if (isFetching) {
      return <Skeleton />;
    }

    const tilesPerPage = pathOr(9, 'tilesPerPage', curatedCategoriesConfig);
    const start = (pageNumber - 1) * tilesPerPage;
    return (
      <div
        className={classnames(
          styles.curatedCategories,
          'grid-fullbleed-container'
        )}
      >
        <div className="grid-container">{this.renderTeaserCol3()}</div>
        <Pagination
          className="pb3"
          channelType={channelType}
          numFound={pathOr(0, 'totalCuratedCategories', data)}
          perPage={tilesPerPage}
          start={start}
          onPageClick={this.onPageClick}
          buttonLabels={{
            back: LabelsUtil.getLabel(labels, 'paginationBack'),
            next: LabelsUtil.getLabel(labels, 'paginationNext'),
            ariaNavLabel: LabelsUtil.getLabel(labels, 'paginationAriaNav'),
            ariaLinkLabel: LabelsUtil.getLabel(labels, 'paginationAriaLink'),
            ariaCurrentLabel: LabelsUtil.getLabel(
              labels,
              'paginationAriaCurrent'
            ),
          }}
        />
      </div>
    );
  }
}

export default CuratedCategories;
