import React from 'react';
import PropTypes, { func } from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import { withRouter } from 'react-router';
import { compose } from 'redux';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { windowScroll, triggerOpenAppModalEvent } from '@bbb-app/utils/common';
import toJS from '@bbb-app/hoc/toJS';
import { withSiteSpectTracker } from '@bbb-app/site-spect/Experiment';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import allRegTypes from '@bbb-app/registry-type/registryTypes';

import styles from './RegistryFooter.css';
import TabButton from './TabButton';
import TabPanel from './TabPanel';
import ListRegistries from '../InteractiveChecklist/ICLayOut/OtherList/ListRegistries';
import InteractiveChecklist from '../../containers/InteractiveChecklist/InteractiveChecklist.async';

import {
  MORE_KEY,
  CHECKLIST_KEY,
  REGISTRY_KEY,
  LISTS_KEY,
  APPOINTMENTS,
  BROWSE_AND_GIFTS_KEY,
  STORE_PATH,
  NEW_LISTS_KEY,
  NEW_REGISTRY_KEY,
  FLIP_FLOP,
  ANALYZER,
  BUILD,
} from './constants';
import { FLIP_FLOP_BANNER_TEXT } from '../../containers/Pages/Registry/RegistryOwner/FlipFlop/constants';
/**
 * @param {array} routes [list of routes for interactive checklist]
 * @param {bool} locationChange [used to close drawer on page change]
 * @param {object} data [data for footer links and more panel links]
 * @param {func} selectActiveRegistry [function to update registry]
 * @param {array} activeRegistryID [current active registry. appears selected in registry tab]
 * @param {bool} endpoints [list of endpoints from siteconfig used to map to feo urls ]
 * @param {object} stickyLinksCount [number of tabs that appear before more tab in footer]
 * @param {func} registryList [list of user's registries]
 *
*/
const propTypes = {
  routes: PropTypes.array,
  locationChange: PropTypes.bool,
  data: PropTypes.object,
  selectActiveRegistry: PropTypes.func,
  setRegistryFooterRenderedStatus: PropTypes.func,
  activeRegistry: PropTypes.object,
  activeRegistryID: PropTypes.string,
  registryLabel: PropTypes.object,
  endpoints: PropTypes.object,
  stickyLinksCount: PropTypes.number,
  registryList: PropTypes.array,
  switchConfig: PropTypes.object,
  pageIdentifier: PropTypes.string,
  interactiveCheckListFlag: PropTypes.bool,
  location: PropTypes.object,
  onClickOtherList: PropTypes.func,
  ownRecomendedList: PropTypes.array,
  fireTealiumAction: PropTypes.func,
  registrySiteConfig: PropTypes.object,
  track: func,
  isMoverListEnable: PropTypes.bool,
  isPNHChecklistEnabledIC: PropTypes.bool,
  isPNHChecklistEnabledSFooter: PropTypes.bool,
  deviceBreakpoints: PropTypes.object,
  siteId: PropTypes.string,
  staticPageIdentifier: PropTypes.string,
};

const defaultProps = {
  ownRecomendedList: [],
};

export class RegistryFooter extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      openDrawer: '',
      isPanelActive: false,
      lastPanelSelected: '',
      keyPanel: '',
    };
    this.clearLastPanelSelected = false;
    this.isInternationalUser = isInternationalUser();
  }

  componentDidMount() {
    this.props.setRegistryFooterRenderedStatus();
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.props.locationChange !== nextProps.locationChange &&
      this.props.location.pathname !== nextProps.location.pathname
    ) {
      this.setState({
        isPanelActive: false,
        activeDrawer: '',
        openDrawer: '',
        keyPanel: '',
      });
    }
  }

  onClickLink = (itmId, closeIcOnESC, banerText) => {
    this.togglePanel(itmId, closeIcOnESC, banerText);
  };
  onClickFlipFlopLink = itmId => {
    setTimeoutCustom(() => {
      this.props.track('tinderTapIcon_SS');
    }, 0);

    this.togglePanel(itmId);
  };

  getUpdatedStickyLinksData = (
    stickyLinksData,
    collegeListsLength,
    registriesLength
  ) => {
    const enableCollegeCheckList = pathOr(
      false,
      'CollegeChecklist.enableCollegeCheckList',
      this.props.switchConfig
    );
    if (!enableCollegeCheckList) {
      return stickyLinksData;
    }
    let updatedStickyLinksData = [];
    if (collegeListsLength > 0 && registriesLength === 0) {
      updatedStickyLinksData = stickyLinksData.filter(
        itm => itm.bannerText.replace(/\s/g, '').toLowerCase() !== REGISTRY_KEY
      );
      updatedStickyLinksData = updatedStickyLinksData.filter(
        itm =>
          itm.bannerText.replace(/\s/g, '').toLowerCase() !== NEW_REGISTRY_KEY
      );
    } else if (registriesLength > 0) {
      updatedStickyLinksData = stickyLinksData.filter(
        itm => itm.bannerText.replace(/\s/g, '').toLowerCase() !== LISTS_KEY
      );
      updatedStickyLinksData = updatedStickyLinksData.filter(
        itm => itm.bannerText.replace(/\s/g, '').toLowerCase() !== NEW_LISTS_KEY
      );
    }
    return updatedStickyLinksData;
  };

  getUpdatedBannerText = (banerText, collegeListsLength, registriesLength) => {
    let updatedBannerText = banerText;
    const enableCollegeCheckList = pathOr(
      false,
      'CollegeChecklist.enableCollegeCheckList',
      this.props.switchConfig
    );
    if (!enableCollegeCheckList) {
      return updatedBannerText;
    }
    if (
      collegeListsLength > 0 &&
      registriesLength > 0 &&
      (banerText.replace(/\s/g, '').toLowerCase() === REGISTRY_KEY ||
        banerText.replace(/\s/g, '').toLowerCase() === NEW_REGISTRY_KEY)
    ) {
      updatedBannerText = `${updatedBannerText}/${LabelsUtil.getLabel(
        this.props.registryLabel,
        'List'
      )}`;
    }
    return updatedBannerText;
  };

  getRegTypesArray = registryTypes => {
    let regTypes;
    const popularArray = pathOr(null, 'popular', registryTypes);
    const otherArray = pathOr(null, 'other', registryTypes);
    if (popularArray || otherArray) {
      regTypes = popularArray.concat(otherArray);
    }
    return regTypes;
  };

  getRegistryType = (registryName, rootLink) => {
    if (registryName === 'Commitment Ceremony') {
      return rootLink.replace(':registryType', 'commitment-ceremony');
    } else if (registryName === 'College/University') {
      return rootLink.replace(':registryType', 'college-university');
    }
    return rootLink.replace(':registryType', registryName.toLowerCase());
  };

  closePanels = () => {
    this.setState({ openDrawer: '', isPanelActive: false, keyPanel: '' });
    windowScroll.enable(false);
  };

  showAppointmentsModal = event => {
    event.preventDefault();
    triggerOpenAppModalEvent('Appointments', {
      variation: 'large',
      sourceCTA: 'registry footer',
    });
    if (this.props.fireTealiumAction) {
      const TEALIM_PAGE_INFO = {
        page_type: 'Registry',
        page_name: 'book an appointment clicked',
      };
      this.props.fireTealiumAction(
        'book an appointment clicked',
        {
          appt_scheduler_entry: 'book an appointment : registry footer',
          call_to_actiontype: 'book an appointment clicked',
          page_name: 'book an appointment clicked',
          registry_id: pathOr('', 'registry_id', this.props.activeRegistry),
          registry_type: pathOr('', 'registry_type', this.props.activeRegistry),
          page_function: 'Registry',
          navigation_path: 'Registry',
          subnavigation_path: 'Registry',
          page_type: 'Registry',
          channel: 'Registry',
          pagename_breadcrumb: 'Registry Book an Appointment',
        },
        TEALIM_PAGE_INFO
      );
    }
    this.closePanels();
  };

  isCustomPanel = id => {
    return (
      [
        CHECKLIST_KEY,
        MORE_KEY,
        REGISTRY_KEY,
        LISTS_KEY,
        NEW_LISTS_KEY,
        NEW_REGISTRY_KEY,
        BUILD,
      ].indexOf(id) !== -1
    );
  };

  isOtherLink = id => {
    const { links } = this.props.data.footer;
    return Object.prototype.hasOwnProperty.call(links, id);
  };

  togglePanel = (id, closeIcOnESC, banerText) => {
    const index = id || null;
    if (
      !closeIcOnESC &&
      this.isCustomPanel(index) &&
      index !== this.state.openDrawer
    ) {
      windowScroll.disable();
      this.setState({
        isPanelActive: true,
        openDrawer: id,
        lastPanelSelected: id,
        keyPanel: banerText,
      });
    } else if (
      !closeIcOnESC &&
      this.isOtherLink(banerText) &&
      index !== banerText &&
      index !== this.state.openDrawer
    ) {
      windowScroll.disable();
      this.setState({
        isPanelActive: true,
        openDrawer: id,
        keyPanel: banerText,
        lastPanelSelected: id,
      });
    } else {
      this.setState({
        isPanelActive: false,
        openDrawer: '',
        keyPanel: '',
        lastPanelSelected:
          id === CHECKLIST_KEY && this.clearLastPanelSelected ? '' : id,
      });
      windowScroll.enable(false);
      if (this.clearLastPanelSelected) {
        if (id === CHECKLIST_KEY) this.clearLastPanelSelected = false;
      }
    }
  };

  checkForDynamicLinks = links => {
    let dynamicLink = links;
    if (dynamicLink.indexOf('/') > -1) {
      dynamicLink = STORE_PATH + dynamicLink;
    }
    return dynamicLink;
  };

  mapLink = (link, params) => {
    const cleanLink = link ? link.replace(/^\/+/, '') : '';
    const registryTypes = this.getRegTypesArray(allRegTypes);
    const registryId = this.props.activeRegistryID || '';
    let rootLink = `${link}`;
    rootLink = this.checkForDynamicLinks(rootLink);
    if (this.props.endpoints && this.props.endpoints[cleanLink]) {
      rootLink = this.props.endpoints[cleanLink];
    }
    if (link === BROWSE_AND_GIFTS_KEY) {
      const registryTypesObj = {};
      params.split('&').forEach(item => {
        registryTypesObj[item.split('=')[0]] = item.split('=')[1];
      });
      const eventType = registryTypesObj.eventType || 'default';
      const registryType =
        registryTypes &&
        registryTypes.filter(
          obj => obj.registryName.toLowerCase() === eventType.toLowerCase()
        );
      if (registryType && registryType.length > 0) {
        rootLink = this.getRegistryType(registryType[0].registryName, rootLink);
        rootLink = rootLink.replace(
          ':registryTypeId',
          registryType[0].registryTypeId
        );
      }
      return params ? `${rootLink}?${params}` : rootLink;
    } else if (link === FLIP_FLOP) {
      const regType = this.props.activeRegistry.registryType.registryTypeName;
      rootLink = rootLink.replace(':regType', regType);
    }

    return params
      ? `${rootLink.replace(':id', registryId)}?${params}`
      : rootLink.replace(':id', registryId);
  };

  checklistToggle = (closeIcOnESC = false) => {
    this.togglePanel(CHECKLIST_KEY, closeIcOnESC);
  };

  closeInteractiveCheckList = () => {
    this.clearLastPanelSelected = true;
  };

  registryPanel = () => {
    const {
      isMoverListEnable,
      isPNHChecklistEnabledIC,
      isPNHChecklistEnabledSFooter,
      deviceBreakpoints,
    } = this.props;
    const data = this.props.registryList;
    const switchConfig = this.props.switchConfig;
    const ownRecomendedList = this.props.ownRecomendedList;
    const location = this.props.location;
    const enableCollegeCheckList = pathOr(
      false,
      'CollegeChecklist.enableCollegeCheckList',
      switchConfig
    );
    return (
      <ListRegistries
        endpoints={this.props.endpoints}
        registryList={data}
        ownRecomendedList={ownRecomendedList}
        activeRegistryID={this.props.activeRegistryID}
        selectActiveRegistry={this.props.selectActiveRegistry}
        labels={this.props.registryLabel}
        onLinkClick={this.closePanels}
        onClickOtherList={this.props.onClickOtherList}
        pageIdentifier={this.props.pageIdentifier}
        enableCollegeCheckList={enableCollegeCheckList}
        location={location}
        viewportConfig={pathOr({}, 'viewportConfig', this.props)}
        isMoverListEnable={isMoverListEnable}
        isPNHChecklistEnabledIC={isPNHChecklistEnabledIC}
        isPNHChecklistEnabledSFooter={isPNHChecklistEnabledSFooter}
        deviceBreakpoints={deviceBreakpoints}
      />
    );
  };

  morePanel = id => {
    const data = this.props.data.footer.links[id];
    const moreLinks = data && data.filter(itm => itm.bannerLink !== null);
    const links =
      moreLinks &&
      moreLinks.map((link, index) => {
        const mappedLink = this.mapLink(link.bannerLink, link.requestParams);
        let handleClick = this.closePanels;
        if (link.bannerText === APPOINTMENTS) {
          const enableBookingBug =
            pathOr(false, 'Global.enableBookingBug', this.props.switchConfig) &&
            pathOr(
              true,
              `${this.props.pageIdentifier}.enableBookingBug`,
              this.props.switchConfig
            );
          if (!enableBookingBug) {
            return null;
          }
          handleClick = this.showAppointmentsModal;
        }
        return (
          <li key={index} className="mb15">
            <PrimaryLink href={mappedLink} onClick={handleClick}>
              {link.bannerText}
            </PrimaryLink>
          </li>
        );
      });

    return <ul>{links}</ul>;
  };

  checkFlipFLopEnabled = () => {
    let isFlipFlopEnabled = false;
    const flipFlopEnabledCMS = pathOr(
      false,
      'Global.enableFlipFlop',
      this.props.switchConfig
    );
    if (flipFlopEnabledCMS && !this.isInternationalUser) {
      isFlipFlopEnabled = true;
    }
    return isFlipFlopEnabled;
  };

  checkRegAnalyzerEnabled = () => {
    let isRegAnalyzerEnabled = false;
    const regAnalyzerEnabledCMS = pathOr(
      false,
      'Global.enableRegAnalyzer',
      this.props.switchConfig
    );
    if (regAnalyzerEnabledCMS && !this.isInternationalUser) {
      isRegAnalyzerEnabled = true;
    }
    return isRegAnalyzerEnabled;
  };

  callPanelForMore = keyPanel => {
    const data = this.props.data.footer.links[keyPanel];
    if (data) return this.morePanel(keyPanel);
    return null;
  };

  renderPanel = () => {
    const panel = this.state.openDrawer;
    const { keyPanel } = this.state;
    switch (panel) {
      case REGISTRY_KEY:
      case NEW_REGISTRY_KEY:
        return this.registryPanel();
      case LISTS_KEY:
      case NEW_LISTS_KEY:
        return this.registryPanel();
      case MORE_KEY:
        return this.morePanel(keyPanel);
      default:
        return this.callPanelForMore(keyPanel);
    }
  };

  render() {
    let linkData = this.props.data.footer.stickyLinks;
    const collegeListsLength = this.props.ownRecomendedList.length;
    const registriesLength = this.props.registryList.length;

    const isFlipFlopEnabled = this.checkFlipFLopEnabled();
    const flipFlopBannerText = pathOr(
      FLIP_FLOP,
      FLIP_FLOP_BANNER_TEXT,
      this.props.registrySiteConfig
    );
    if (!isFlipFlopEnabled) {
      linkData = linkData.filter(
        obj => obj.bannerText.toLowerCase() !== flipFlopBannerText.toLowerCase()
      );
    }
    const isRegAnalyzerEnabled = this.checkRegAnalyzerEnabled();
    const regAnalyzerText = ANALYZER;
    if (!isRegAnalyzerEnabled) {
      linkData = linkData.filter(
        obj => obj.bannerText.toLowerCase() !== regAnalyzerText.toLowerCase()
      );
    }

    let stickyLinks = linkData
      .filter(itm => itm.bannerText !== 'More')
      .slice(0, this.props.stickyLinksCount);
    const moreLink = linkData.filter(itm => itm.bannerText === 'More')[0];
    const isInteractiveCheckListDisabled =
      this.props.data.displayFlags.isCheckListDisabled ||
      !this.props.interactiveCheckListFlag;
    if (isInteractiveCheckListDisabled)
      stickyLinks = stickyLinks.filter(
        obj => obj.bannerText.toLowerCase() !== 'checklist'
      );

    const stickyLinksData = moreLink
      ? stickyLinks.concat(moreLink)
      : stickyLinks;
    const InteractiveChecklistPanel = (
      <InteractiveChecklist
        routes={this.props.routes}
        locationChange={this.props.locationChange}
        isInMenu
        menuState={this.state.openDrawer === CHECKLIST_KEY}
        onCloseInteractiveCheckList={this.closeInteractiveCheckList}
        menuOnClick={this.checklistToggle}
        siteId={this.props.siteId}
        staticPageIdentifier={this.props.staticPageIdentifier}
      />
    );
    const needsHighZIndex = this.state.openDrawer === CHECKLIST_KEY;
    const enableNewBadge = pathOr(
      false,
      'Global.enableNewBadge',
      this.props.switchConfig
    );
    const updatedStickyLinksData = this.getUpdatedStickyLinksData(
      stickyLinksData,
      collegeListsLength,
      registriesLength
    );

    const newBadgeLabel = LabelsUtil.getLabel(
      this.props.registryLabel,
      'newBadgeLabel'
    );

    let linkListWidth = {};
    if (updatedStickyLinksData.length < 5)
      linkListWidth = {
        width: `${100 / updatedStickyLinksData.length}%`,
      };

    return (
      <div
        className={classnames(
          styles.registryFooter,
          needsHighZIndex && styles.highZIndex
        )}
      >
        <ul className={styles.tabList}>
          {updatedStickyLinksData.map(data => {
            const itmId = data.bannerText.replace(/\s/g, '').toLowerCase();
            const isLink = !(
              this.isCustomPanel(itmId) || this.isOtherLink(data.bannerText)
            );
            if (
              itmId !== CHECKLIST_KEY ||
              (itmId === CHECKLIST_KEY && InteractiveChecklistPanel !== null)
            ) {
              const link =
                isLink && this.mapLink(data.bannerLink, data.requestParams);
              const { pathname, search } = this.props.location;
              let banerText = data.bannerText;
              banerText = this.getUpdatedBannerText(
                banerText,
                collegeListsLength,
                registriesLength
              );
              return (
                <li key={itmId} className={styles.tabLi} style={linkListWidth}>
                  <TabButton
                    label={banerText}
                    id={itmId}
                    checkId={itmId === CHECKLIST_KEY && 'icStartBtn'}
                    link={link}
                    image={data.inActiveImageURL}
                    onClick={e => {
                      if (this.isCustomPanel(itmId)) {
                        // for custom panel e.preventDefault is required to stop url redirecting issue
                        e.preventDefault();
                      }
                      const handler =
                        itmId === 'hitormiss'
                          ? this.onClickFlipFlopLink.bind(this) // eslint-disable-line
                          : this.onClickLink.bind(this); // eslint-disable-line
                      handler(itmId, null, banerText);
                    }}
                    selected={this.state.lastPanelSelected === itmId}
                    deactivated={isLink && link !== `${pathname}${search}`}
                    itmId={itmId}
                    enableNewBadge={enableNewBadge}
                    newBadgeLabel={newBadgeLabel}
                    openDrawer={this.state.openDrawer}
                  />
                </li>
              );
            }
            return null;
          })}
        </ul>
        {this.state.isPanelActive && (
          <TabPanel
            index={0}
            active={this.state.isPanelActive}
            key={`tabpanel-0`}
            className={styles.footerPanel}
          >
            {this.renderPanel()}
          </TabPanel>
        )}
        <div // eslint-disable-line jsx-a11y/no-static-element-interactions
          className={classnames(
            styles.overlayMobile,
            this.state.isPanelActive ? styles.overlayShow : styles.overlayHide
          )}
          onClick={this.togglePanel}
        />
        {InteractiveChecklistPanel}
      </div>
    );
  }
}

RegistryFooter.propTypes = propTypes;
RegistryFooter.defaultProps = defaultProps;

export default compose(withRouter, withSiteSpectTracker)(toJS(RegistryFooter));
