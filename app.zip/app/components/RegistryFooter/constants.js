/* Keys for toggling registry footer panels */
export const MORE_KEY = 'more';
export const CHECKLIST_KEY = 'checklist';
export const REGISTRY_KEY = 'myregistry';
export const LISTS_KEY = 'mylists';
export const APPOINTMENTS = 'Book an Appointment';
export const BROWSE_AND_GIFTS_KEY = 'browseAndGifts';
export const STORE_PATH = '/store/';
export const NEW_REGISTRY_KEY = 'registry';
export const NEW_LISTS_KEY = 'lists';
export const FLIP_FLOP = 'flipFlop';
export const HIT_OR_MISS = 'hitormiss';
export const ANALYZER = 'Analyzer';
export const BUILD = 'build';
