export { default } from './RegistryFooter';
