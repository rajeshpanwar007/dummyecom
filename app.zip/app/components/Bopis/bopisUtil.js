import { isStoreBopisEnabled } from '@bbb-app/utils/StoreInfoUtils';
import { handleBopusFlag } from '@bbb-app/utils/shopInStoreUtil';
export const bopisUtil = (
  bopusAvailable,
  siteId,
  storeDetails,
  showOptions
) => {
  const isBopisOff = showOptions
    ? handleBopusFlag(bopusAvailable, siteId).length === 0
    : !isStoreBopisEnabled(storeDetails);
  const isTheSelectedStoreAvailable = !isBopisOff;
  return { isNotInStock: false, isBopisOff, isTheSelectedStoreAvailable };
};
