import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import styles from './BopisWrapper.css';

const propTypes = {
  pageSortOptions: PropTypes.func,
  renderAvailabilityFilter: PropTypes.func,
  renderPaging: PropTypes.func,
  isShiptSdd: PropTypes.bool,
  isShopInStore: PropTypes.bool,
};

const BopisWrapper = props => {
  const {
    pageSortOptions,
    renderAvailabilityFilter,
    renderPaging,
    isShiptSdd,
    isShopInStore,
  } = props;

  if (pageSortOptions)
    return (
      <div
        id="bopus-pageSortOptions-container"
        className={styles.bopusContainer}
      >
        {pageSortOptions}
      </div>
    );

  if (renderAvailabilityFilter)
    return (
      <div
        id="bopus-availabilityFilter-container"
        className={classnames(
          styles.bopusFilter,
          'flex',
          'fullWidth',
          'justify-between',
          'items-center'
        )}
      >
        <div className={classnames({ my3: isShiptSdd })}>{renderPaging()}</div>
        {/* Don't render Availabilty filter if it's SDDShipT Page */}
        {!isShiptSdd && !isShopInStore && renderAvailabilityFilter}
        {(isShopInStore || isShiptSdd) && (
          <div className={styles.plpNarrowSearch} id="dskNarrowSearch" />
        )}
      </div>
    );

  return null;
};

BopisWrapper.propTypes = propTypes;

export default BopisWrapper;
