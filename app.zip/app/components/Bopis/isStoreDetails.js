import { isEmpty } from 'lodash/fp';

export const isStoreDetails = (isStoreAvailable, storeName, isPackAndHold) => {
  const isStore = !isStoreAvailable
    ? !storeName || isEmpty(storeName) || isPackAndHold
    : false;
  return isStore;
};
