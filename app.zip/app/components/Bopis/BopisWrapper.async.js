/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';
import { options } from '@bbb-app/universal-component/options';

const BopisWrapperOptions = {
  ...options,
  loading: ({ renderSkeleton }) => renderSkeleton && renderSkeleton(),
};

const BopisWrapper = universal(
  import(/* webpackChunkName: "bopis-filter" */ './BopisWrapper'),
  BopisWrapperOptions
);

export default BopisWrapper;
/* eslint-enable extra-rules/no-commented-out-code */
