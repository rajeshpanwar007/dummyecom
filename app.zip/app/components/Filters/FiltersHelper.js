import { isEmpty, pathOr } from 'lodash/fp';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import { getCachedCookie } from '@bbb-app/utils/universalCookie';
import { parseStoreLocation } from '@bbb-app/utils/common';
import {
  getHeaderOffsets,
  transformValuesArraytoKeyValuePairs,
} from '@bbb-app/utils/filterUtils';
import getCoords from '@bbb-app/utils/getCoords';
import { LAT_LONG_COOKIE } from '@bbb-app/constants/cookies';
import { PAGE_NAME_PRODUCT_SEARCH } from '@bbb-app/constants/route/route';

const PER_PAGE_VIEW_ALL_THRESHOLD = 96;

const calculatePerPageOptionsHelper = ({
  labels,
  filterdOptions,
  count,
  itemsPerPage,
  filteredTotalPerPageFilterOptions,
}) => {
  const sPerPage = LabelsUtil.getLabel(labels, 'pagination.perPage');
  const sViewAll = LabelsUtil.getLabel(labels, 'gridFilters.viewAll');
  let viewAllItemsPerPage = itemsPerPage;
  filterdOptions.forEach(item => {
    const isViewAll =
      item.value === filterdOptions[filterdOptions.length - 1].value &&
      item.value <= PER_PAGE_VIEW_ALL_THRESHOLD &&
      count < PER_PAGE_VIEW_ALL_THRESHOLD;
    /* istanbul ignore else */

    if (isViewAll && itemsPerPage > item.value) {
      viewAllItemsPerPage = item.value;
    }

    filteredTotalPerPageFilterOptions.push({
      label: isViewAll ? sViewAll : `${item.label} ${sPerPage}`,
      props: {
        value: item.value,
      },
      key: `${item.label} ${sPerPage}`,
    });
  });
  return { viewAllItemsPerPage, filteredTotalPerPageFilterOptions };
};

/**
 * Calculates the options available in the per page drop down.
 *
 * @param {array} perPageOptions all per page options provided by the API
 * @param {number} count Number of pages
 * @param {number} itemsPerPage Number of items per page
 * @param {object} labels Labels from API
 * @returns {{filteredTotalPerPageFilterOptions: Array, viewAllItemsPerPage: *}}  Valid per page options to diplay
 */
export const calculatePerPageOptions = (
  perPageOptions,
  count,
  itemsPerPage,
  labels
) => {
  let perPageFlag = true;
  const filteredTotalPerPageFilterOptions = [];
  const filterdOptions = transformValuesArraytoKeyValuePairs(
    perPageOptions || []
  ).filter(item => {
    /* istanbul ignore else */
    if (perPageFlag && item.value <= count) {
      return perPageFlag;
    } else if (perPageFlag) {
      const tmp = perPageFlag;
      perPageFlag = false;
      return tmp;
    }
    return perPageFlag;
  });
  return calculatePerPageOptionsHelper({
    labels,
    filterdOptions,
    count,
    itemsPerPage,
    filteredTotalPerPageFilterOptions,
  });
};

export const scrollToPreviouslySelectedProduct = element => {
  const { stickyHeaderHeight, marginTop, headerBanner } = getHeaderOffsets();
  const padding = 40;
  const final =
    getCoords(element).top -
    stickyHeaderHeight +
    // For Tricky Header
    (marginTop === 0 ? headerBanner.offsetHeight : 0);
  document.body.classList.add('scroll-to-selectedproduct');
  /* istanbul ignore next */
  setTimeoutCustom(() => window.scrollTo(0, final - padding), 10);
};

/**
 * Flow controller for setting store details based on conditions
 * * Local store if set to cookie takes precedence
 * * Favorite store takes the next spot fi not local store found
 * * Akamai store is the last option
 * @param {object} Required Props from Filters component
 * * @param {object} storeDetails
 * * @param {function} getAkamaiStoreDetails
 * * @param {function} setStoreDetails
 * * @param {function} onInitStoreDetails
 * @returns null
 */
export const flowControlStoreDetails = ({
  storeDetails,
  getAkamaiStoreDetails,
  setStoreDetails,
  onInitStoreDetails,
  checklistData,
  storeId,
}) => {
  const latLongCookie = getCachedCookie(LAT_LONG_COOKIE);
  /* istanbul ignore next */
  const persisted = latLongCookie && parseStoreLocation(latLongCookie);
  /* istanbul ignore else */
  if (!persisted && !checklistData) {
    getAkamaiStoreDetails();
  } else if (
    checklistData &&
    checklistData.storeId &&
    (checklistData.listType === 'PACK_HOLD' ||
      checklistData.listType === 'PACK_HOLD_MOVING')
  ) {
    onInitStoreDetails(checklistData.storeId, checklistData);
  } else if (storeId) {
    onInitStoreDetails(storeId);
  } else {
    /* istanbul ignore else */
    if (
      isEmpty(storeDetails) ||
      persisted.storeId !== `${storeDetails.storeId}`
    ) {
      setStoreDetails(persisted);
    }
    onInitStoreDetails(persisted.storeId);
  }
};

/** To verify if the user has opened regular Category PLP or brand PLP */
export const categoryType = match => {
  const url = pathOr('', 'url', match);
  if (url.includes('category')) {
    return 'category';
  } else if (url.includes('checklist')) {
    return 'checklist';
  }
  return 'brand';
};

export const subCategoryType = (url, categoryId) => {
  if (url.includes('checklist') && url.includes(categoryId)) {
    return url.split(categoryId)[1].split('/')[1];
  }
  return null;
};

/**
 *
 * @param {string} currentStoreId store ID in the url
 * @param {string} availabilityStoreNumber current store number for availability option
 * @param {object} pnhObj pnh obj if PNH store option is selected
 */
export const checkIfSameAvailabilityOption = (
  currentStoreId,
  availabilityStoreNumber,
  pnhObj
) => {
  if (
    currentStoreId &&
    availabilityStoreNumber &&
    (pnhObj
      ? pnhObj.storeId === currentStoreId
      : availabilityStoreNumber === currentStoreId)
  ) {
    return true;
  }
  return false;
};

export const getPageHeading = (summary, selectedFilters, pageIdentifier) => {
  const isSearchResultsPage = pageIdentifier === PAGE_NAME_PRODUCT_SEARCH;
  const selectedRatingFilters = pathOr('', 'RATINGS', selectedFilters);
  const ratingsApplied =
    selectedRatingFilters &&
    (selectedRatingFilters.includes('4-0') &&
      selectedRatingFilters.includes('5-0'));
  if (!summary) return undefined;
  return ratingsApplied && !isSearchResultsPage
    ? `Top Rated ${summary}`
    : `${summary}`;
};

export const loadMoreFacetList = (
  e,
  propsForFetchingFacets,
  getMoreFacetData,
  id
) => {
  if (e && typeof e.preventDefault === 'function') {
    e.preventDefault();
  }
  const {
    paramsForFacets,
    pageName,
    search,
    siteId,
    storeNumber,
    checklistCat,
  } = propsForFetchingFacets;
  if (getMoreFacetData) {
    getMoreFacetData(
      paramsForFacets,
      pageName,
      search,
      {},
      siteId,
      storeNumber,
      id,
      true,
      checklistCat || false
    );
  }
};

export const loadMoreBrandFacet = paramObj => {
  const {
    event,
    propsForFetchingFacets,
    getMoreFacetData,
    id,
    groupByOn,
    moreRefinements,
  } = paramObj;
  const moreRefinementAvailable =
    moreRefinements === true || moreRefinements === 'true';
  if (groupByOn && moreRefinementAvailable)
    loadMoreFacetList(event, propsForFetchingFacets, getMoreFacetData, id);
};
