/* eslint max-lines: ["error", 1900]*/
/**
 * This component is responsible for rendering Filters on PLP and Search Page.
 */
import React, { PureComponent, Fragment } from 'react';
import ReactDOM from 'react-dom';
import classnames from 'classnames';
import { kebabCase, isEmpty, getOr, isEqual } from 'lodash/fp';
import debounce from 'lodash.debounce';
import { matchPath } from 'react-router';
import createFocusTrap from 'focus-trap';
import GridContainer from '@bbb-app/core-ui/grid-container';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import MediaQuery from '@bbb-app/responsive-media-query/ResponsiveMediaQuery';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import Heading from '@bbb-app/core-ui/heading';
import { isBrowser, decodeHtmlEntities } from '@bbb-app/utils/common';
import getCurrentSiteId from '@bbb-app/utils/getCurrentSiteId';
import { getSiteSpectFlag } from '@bbb-app/utils/siteSpectUtil';
import {
  isGroupByPLPActive,
  isCombinedGroupByPLPCall,
} from '@bbb-app/utils/groupBy';
import isInternetExplorer from '@bbb-app/utils/isInternetExplorer';
import { scrollToFiltersTop } from '@bbb-app/utils/scrollToFiltersTop';
import Button from '@bbb-app/core-ui/button';
import { isTbs } from '@bbb-app/utils/isTbs';
import {
  DIMENTIONAL_FILTERS,
  DEFAULT_SORT_BY,
  DEFAULT_SEARCH_SORT_BY,
} from '@bbb-app/constants/searchConstants';
import { checkPLPEDDFacetsEnabled } from '@bbb-app/utils/eddUtil';
import SlideOutOverlay from '@bbb-app/slideout-overlay/containers/SlideoutOverlay.async';
import {
  PAGE_NAME_PRODUCT_DETAILS,
  PAGE_NAME_PRODUCT_SEARCH,
  ROUTE_PDP,
} from '@bbb-app/constants/route/route';
import KEY_EVENTS from '@bbb-app/constants/commonKeyEvents';
import getPNHStoreInfoFromURL from '@bbb-app/search-stores/containers/utils/getPNHStoreInfoFromURL';
import { CHANNELTYPE_MOBILE } from '@bbb-app/constants/appConstants';
import { propTypes, defaultProps } from './props';
import FilterList from './FilterList';
import SortOptionsView from './SortOptionsView/SortOptionsView.async';
import AllFiltersView from './AllFiltersView/AllFiltersView';
import AllFiltersSeoView from './AllFiltersView/AllFiltersSeoView.async';
import Paging from './Paging';
import PageSortOptions from './PageSortOptions';
import { uiConfig } from './uiConfig';
import AppliedFiltersComponent from './AppliedFiltersComponent';
import DynamicFacetsRowRenderer from './DynamicFacetsRowRenderer';
import AvailabilityFilter from '../../containers/Search/Filters/AvailabilityFilter/AvailabilityFilter.async';
import Styles from './Filters.inline.css';
import {
  calculatePerPageOptions,
  scrollToPreviouslySelectedProduct,
  checkIfSameAvailabilityOption,
  getPageHeading,
  loadMoreBrandFacet,
} from './FiltersHelper';
import {
  SDD_KEY,
  BBBY_SITE_ID,
  TBS_BBBY_SITE_ID,
  EVENT_TYPE,
  EDD_KEY,
} from './constants';
import PNHFilterWrapper from '../../containers/Search/PNHFilterWrapper/PNHFilterWrapper.async';
import BopisWrapper from '../Bopis/BopisWrapper.async';
import FilterWrapper from './FilterWrapper';
import {
  PagingSkeleton,
  FilterSkeleton,
  SortingSkeleton,
  AppliedFilterSkeleton,
  AvailableSkeleton,
} from './FilterSkeletons';

/**
 * This component is responsible for rendering Filters on PLP and Search Page.
 * @author ktanna
 * @author hreid
 * @author mslavin
 */
const PANEL_STYLE = {
  overflowX: 'hidden',
  overflowY: 'auto',
  WebkitOverflowScrolling: 'touch',
  height: '100%',
};
const PANEL_STYLE_HEIGHT = { height: '100%' };

class Filters extends PureComponent {
  constructor(props) {
    super(props);
    this.ioCallback = this.ioCallback.bind(this);
    this.ioObserver = this.ioObserver.bind(this);
    this.onUpdateObserveProductExposure = this.onUpdateObserveProductExposure.bind(
      this
    );
    this.handleClearTealiumFiltersPLP = this.handleClearTealiumFiltersPLP.bind(
      this
    );
    this.renderPaging = this.renderPaging.bind(this);
    this.renderAppliedFilters = this.renderAppliedFilters.bind(this);
    this.renderAvailabilityFilter = this.renderAvailabilityFilter.bind(this);
    this.renderFilterVariation = this.renderFilterVariation.bind(this);
    this.setRef = this.setRef.bind(this);
    this.isNearestStoresTestActive =
      getSiteSpectFlag(null, 'PLPSearchAPI-H', true) || isTbs();

    let showAllFilters = props.displayPLPFilters; // to display all the filters on page(left section)

    if (this.props.channelType === CHANNELTYPE_MOBILE) {
      // for mobile all filters will be visible in modal window
      showAllFilters = props.prevAllFiltersState.allFiltersOpen || false;
    }

    this.state = {
      allFiltersOpen: showAllFilters,
      sortingOptionsOpen: false, // mobile only
      sameDayDelivery: false,
      activeFacetId: props.prevAllFiltersState.activeFacetId || '',
      holdScroll: false,
      scrollTop: props.scrollTop,
      isAvailabilityDropDownOpen: false,
      selectedSortOption: '',
      isCleared: false,
      productObserverStarted: false,
      productExposureTealiumStarted: false,
      productExposureTimeOut: 3000,
      productsExposed: {
        exposedId: [],
        exposedIndex: [],
      },
      allFiltersData: {
        facets: props.facetsData,
        selectedFilters: props.selectedFilters,
      },
      pnhObj: {},
      facetClick: false,
      isPanelFacetToggle: false,
      facetClickedEnable: true,
      openAllFilter: true,
      isSddTimerExpired: false,
      bopusAvailable: [],
      prevSort: '',
      isClient: false,
    };
    const { route: { pageIdentifier } } = props;
    const defaultPathname = getOr(
      '',
      'previousLocationBeforeTransitions.pathname',
      this.props.route
    );
    const pathname = getOr(
      defaultPathname,
      'previousLocationBeforeTransitions.location.pathname',
      this.props.route
    );
    // Defer rendering of Allfilters on both hard spa and soft spa for SearchResult page
    // and Category L2 & L3 until user click on Allfilter button.
    const isPLP = pageIdentifier === 'PLP';
    const isSearch = pageIdentifier === 'SearchResults';
    this.deferFilterRendering = pathname !== '' || isPLP || isSearch;
    // When page-load/hard spa Category L2 & L3 page than render AllfilterSeo which
    // renders only seo links from server side for SEO purpose.
    this.isPLPSSR = false;
    if (!isBrowser() && isPLP) {
      this.isPLPSSR = true;
      this.deferFilterRendering = false;
    }
    this.toggleAllFilters = debounce(this.handleToggleAllFilters, 250);
    this.closeAvailabilityDropdown = debounce(
      this.closeAvailabilityDropDown,
      250
    );
    // BopisAlert update store
    this.getBopusAvailability = this.getBopusAvailability.bind(this);
    this.delayScroll = undefined;
    this.delayIoObserver = undefined;
    this.delayProdExposure = undefined;
    this.isPLPFilters = props.displayPLPFilters;
  }
  /* eslint complexity: ["error", 13]*/
  componentDidMount = () => {
    this.mounted = true;
    this.ioObserverCount = 0;
    this.setState({ isClient: true });
    /* istanbul ignore else */
    if (this.isStartOutOfRange()) {
      this.props.onResetStartToInitialValue();
    }
    document.addEventListener('keydown', this.onEscape);
    /**
     * Fetch the store details (address) to display near the "available in store" checkbox.
     */
    const { route: { previousPageIdentifier } } = this.props;
    const defaultPathname = getOr(
      '',
      'locationBeforeTransitions.pathname',
      this.props.route
    );
    const pathname = getOr(
      defaultPathname,
      'locationBeforeTransitions.location.pathname',
      this.props.route
    );
    if (previousPageIdentifier === PAGE_NAME_PRODUCT_DETAILS && pathname) {
      const matched = matchPath(pathname, ROUTE_PDP, { exact: true });
      const productId = getOr('__', 'params.productId', matched);
      const element = document.querySelector(`.js-product-id-${productId}`);
      /* istanbul ignore if */
      if (element) scrollToPreviouslySelectedProduct(element);
    } else window.scrollTo(0, 0);

    /*eslint-disable */
    // Required for Tealium Snowplow ObserveProducts and Product Exposer
    /* istanbul ignore else */
    if (isBrowser() || typeof window !== "undefined")
      require("intersection-observer");

    /*eslint-enable */
    /* istanbul ignore else */
    if (!this.state.productObserverStarted) this.onObserveProductExposure();

    const enablePNHListOptions = getOr(
      false,
      'vendorSwitch.enablePNHListOptions',
      this.props
    );
    const { registries } = this.props;
    if (
      enablePNHListOptions &&
      !isEmpty(registries) &&
      !isEmpty(registries.profilePackAndHoldList) &&
      (this.props.categoryId ||
        this.props.pageIdentifierSelector === PAGE_NAME_PRODUCT_SEARCH)
    ) {
      this.setState({
        pnhCheckListSagaRequired: true,
      });
    }
    this.getBopusAvailability();
  };

  /* eslint complexity: ["error", 14]*/
  componentWillReceiveProps = nextProps => {
    if (this.props.sort !== nextProps.sort) {
      const defaultSort = DEFAULT_SEARCH_SORT_BY;
      /* istanbul ignore else */
      if (nextProps.sort === defaultSort || nextProps.sort === '-1')
        this.setState({ selectedSortOption: '' });
    }

    const profilePackAndHoldList = getOr(
      null,
      'registries.profilePackAndHoldList',
      nextProps
    );
    const prevProfilePackAndHoldList = getOr(
      null,
      'registries.profilePackAndHoldList',
      this.props
    );
    const enablePNHListOptions = getOr(
      false,
      'vendorSwitch.enablePNHListOptions',
      this.props
    );
    if (
      enablePNHListOptions &&
      !isEmpty(profilePackAndHoldList) &&
      (nextProps.categoryId ||
        this.props.pageIdentifierSelector === PAGE_NAME_PRODUCT_SEARCH) &&
      (!isEqual(profilePackAndHoldList, prevProfilePackAndHoldList) ||
        !isEqual(this.props.categoryId, nextProps.categoryId))
    ) {
      this.setState({
        pnhCheckListSagaRequired: true,
      });
    }

    if (
      (nextProps.productDataLoaded && !this.props.productDataLoaded) ||
      !isEqual(this.props.checklistData, nextProps.checklistData)
    ) {
      const { onInitStoreDetails, checklistData, storeDetails } = nextProps;
      const storeId = this.getStoreIdFromUrl();
      /* istanbul ignore else */
      if (
        checklistData &&
        checklistData.storeId &&
        (checklistData.listType === 'PACK_HOLD' ||
          checklistData.listType === 'PACK_HOLD_MOVING')
      ) {
        onInitStoreDetails(checklistData.storeId, checklistData);
      } else if (storeId && storeId !== storeDetails.storeId) {
        onInitStoreDetails(storeId);
      }
    }
    this.setState({
      allFiltersData: {
        facets: nextProps.facetsData,
        selectedFilters: nextProps.selectedFilters,
      },
    });
    this.updateOpenAllFilter(nextProps);
  };

  componentDidUpdate = (prevProps, prevState) => {
    this.setState({ prevSort: prevState.selectedSortOption });
    const { scrollFiltersTop, scrollTop } = this.props;
    /* istanbul ignore else */
    if (scrollFiltersTop && !this.state.holdScroll) {
      // Do not scroll yet.
      this.setState({ holdScroll: true });
    } else if (!scrollFiltersTop && this.state.holdScroll) {
      // Small buffer to allow DOM to settle.
      this.setState({ holdScroll: false });
    }
    /* istanbul ignore else */
    if (scrollTop !== this.state.scrollTop) {
      window.scrollTo(0, 0);
      this.setState({ scrollTop });
    }
    this.onUpdateObserveProductExposure(prevProps);
    if (
      !this.state.productExposureTealiumStarted &&
      this.state.productsExposed.exposedIndex.length > 0 &&
      prevState.productsExposed.exposedIndex !==
        this.state.productsExposed.exposedIndex
    )
      this.onProductExposureTealium();

    if (
      this.props.itemsPerPage <= this.state.productsExposed.exposedId.length &&
      this.state.productExposureTealiumStarted &&
      this.state.productObserverStarted
    )
      this.iODisconnect();
    if (
      !isEqual(
        getOr([], 'storeDetails.siteBopus', prevProps),
        getOr([], 'storeDetails.siteBopus', this.props)
      )
    ) {
      this.getBopusAvailability();
    }
  };
  componentWillUnmount = () => {
    this.mounted = false;
    /* Fix for BBBFEO-36997 (IE check for SHOPWS-1305) */
    if (!isInternetExplorer()) window.scrollTo(0, 0);

    /* istanbul ignore else */
    if (isBrowser()) {
      document.removeEventListener('keydown', this.onEscape);
      if (this.focusTrap) this.focusTrap.deactivate();

      if (
        this.state.productExposureTealiumStarted &&
        this.state.productObserverStarted
      )
        this.iODisconnect();
    }
    if (this.state.facetClick) this.setState({ facetClick: false });
    clearTimeout(this.delayIoObserver);
    clearTimeout(this.delayProdExposure);
    clearTimeout(this.delayScroll);
  };
  onObserveProductExposure = () => {
    if (isBrowser()) {
      if (this.delayIoObserver !== undefined) {
        clearTimeout(this.delayIoObserver);
      }
      /* istanbul ignore next: hard to test setTimeoutCustom inside component method */
      this.delayIoObserver = setTimeoutCustom(() => {
        this.ioObserver();
      }, 1500);
    }
  };

  onUpdateObserveProductExposure = prevProps => {
    if (!this.state.productObserverStarted) this.onObserveProductExposure();

    if (
      prevProps.itemsPerPage !== this.props.itemsPerPage ||
      prevProps.paging.start !== this.props.paging.start ||
      prevProps.recentFilterAdded !== this.props.recentFilterAdded ||
      prevProps.sort !== this.props.sort
    ) {
      this.setState({
        productObserverStarted: false,
        productsExposed: {
          exposedId: [...this.state.productsExposed.exposedId],
          exposedIndex: [],
        },
      });
      this.onObserveProductExposure();
    }
    if (prevProps.baseUrl !== this.props.baseUrl) {
      this.onObserveProductExposure();
      this.setState({
        productObserverStarted: false,
        productsExposed: {
          exposedId: [],
          exposedIndex: [],
        },
      });
    }
  };
  onProductExposureTealium = () => {
    if (isBrowser()) {
      this.setState({ productExposureTealiumStarted: true });
      if (this.delayProdExposure !== undefined) {
        clearTimeout(this.delayProdExposure);
      }
      /* istanbul ignore next: hard to test setTimeoutCustom inside component method */
      this.delayProdExposure = setTimeoutCustom(() => {
        this.props.onProductExposure(this.state.productsExposed.exposedIndex);
        if (this.mounted) {
          this.setState({
            productObserverStarted: false,
            productExposureTealiumStarted: false,
            productsExposed: {
              exposedId: [...this.state.productsExposed.exposedId],
              exposedIndex: [],
            },
          });
        }
      }, this.state.productExposureTimeOut);
    }
  };

  /**
   * Closes the drop down when escape is pressed
   * @param keyCode
   */
  onEscape = ({ keyCode }) => {
    /* istanbul ignore else */
    if (keyCode === KEY_EVENTS.KEY_ESCAPE && this.state.allFiltersOpen) {
      this.toggleAllFilters();
      const ele = document.querySelector(`.${Styles.showAllFilters}`);
      /* istanbul ignore else */
      if (ele) ele.focus();
    }
  };
  /**
   * Makes sure route is included for updateSelectedFilters if it exists in the params
   */
  onUpdateSelectedFilters = (selected, isTealiumSWSCall, pnhObj) => {
    const {
      updateSelectedFilters,
      match,
      scrollToFiltersOnChange,
      selectedPnhListId,
      eddOptionSelected,
    } = this.props;

    const selectedStore = selected === SDD_KEY ? false : selected;
    const isSDD = selected === SDD_KEY;
    const isEDD = selected === EDD_KEY;
    const pageRoute = (match && match.path && { route: match.path }) || {};
    /* istanbul ignore else */
    if (scrollToFiltersOnChange) this.scrollToFiltersTopOnChange();
    if (isEDD) {
      const jsonObj = {
        eddOptionSelected: {
          eddOptionSelected,
          isEdd: true,
        },
        ...pageRoute,
        isTealiumSWSCall,
        isEDD,
      };
      updateSelectedFilters(jsonObj);
    } else {
      const jsonObj = {
        selectedStore,
        ...pageRoute,
        isTealiumSWSCall,
        isSDD,
      };
      if (pnhObj) jsonObj.pnhObj = pnhObj;

      if (selectedPnhListId)
        jsonObj.pnhSelectedStore = selectedPnhListId.storeId;

      updateSelectedFilters(jsonObj);
    }
    if (this.props.reInitializeMarks) this.props.reInitializeMarks();
  };
  /**
   * Handles filter change events and calls update hooks
   * @param {string} facetId Facet id of the facet the selected filter belongs to
   * @param {Array} selections The selected items
   * @param {number} index Unused ... needs to be deleted
   * @param {string} singleSelection Filter name for the applied filtered
   * @param {bool} selected Indicates whether filter was selected.
   * @param {string} route The route for the current page
   * @param {bool} onFilterSelectionUpdate bool for if we need to scroll back to top of filters menu
   */
  onFilterSelectionUpdate = (
    facetId,
    selections,
    index,
    singleSelection,
    selected,
    customPriceRange
  ) => {
    const {
      updateSelectedFilters,
      match,
      selectedPnhListId,
      handleTealiumEventType,
    } = this.props;
    const pageRoute = (match && match.path && { route: match.path }) || {};
    updateSelectedFilters({
      [facetId]:
        !isEmpty(selections) && !isEmpty(singleSelection.dep_id)
          ? [singleSelection.dep_id]
          : selections,
      selected,
      ...pageRoute,
      pnhSelectedStore: selectedPnhListId ? selectedPnhListId.storeId : null,
      customPriceRange: customPriceRange || null,
    });
    /* istanbul ignore else */
    if (selected) {
      this.onActiveFacetChange(facetId);
    }
    if (handleTealiumEventType) {
      handleTealiumEventType();
    }
    if (this.props.reInitializeMarks) {
      this.props.reInitializeMarks();
    }
  };
  /**
   * Handles search within search change events and calls update hooks
   * @param {string} searchTerm Term to be used to filter grids
   */
  onSearchWithin = searchTerm => {
    const { updateSwsTerm, searchWithinSearchTerms } = this.props;
    const newTerms = searchWithinSearchTerms;
    const termIndex = searchWithinSearchTerms.indexOf(searchTerm);
    if (termIndex > -1) {
      newTerms.splice(termIndex, 1);
    } else newTerms.push(searchTerm);
    updateSwsTerm(newTerms);
    this.onUpdateSelectedFilters(undefined, true);
  };
  /**
   * onActiveFacetChange
   * handler for when a new facet is opened/closed
   * update state only when id has a value
   * @param { id } string [The facet id for facet that is active/open]
   */
  onActiveFacetChange = id => {
    /* istanbul ignore else */
    if (id) {
      this.props.setPrevAllFiltersState({
        activeFacetId: id,
      });
      this.setState({
        activeFacetId: id,
        isPanelFacetToggle: !this.state.isPanelFacetToggle,
      });
      this.handleMultipleSelection(true);
    }
  };
  onAccordionChange = id => {
    const { facetsData, propsForFetchingFacets, getMoreFacetData } = this.props;
    this.onActiveFacetChange(id);
    if (id === undefined) {
      return;
    }
    /* istanbul ignore else */
    if (this.state.activeFacetId !== id) {
      this.onSlideoutOverlayOpen();
      const paramObj = {
        event,
        propsForFetchingFacets,
        getMoreFacetData,
        id,
        groupByOn: isGroupByPLPActive(),
        moreRefinements: facetsData[id] && facetsData[id].moreRefinements,
      };
      if (id === 'BRAND_NAME' || id === 'BRAND') {
        loadMoreBrandFacet(paramObj);
      }
    }
  };
  /**
   * Handles store availability filter events
   * @param {bool} selected
   */
  onStoreAvailabilityUpdate = (selected, pnhObj) => {
    // it will add this pnhObj into search redux store
    let selectedStore = selected;
    if (selected === SDD_KEY || selected === EDD_KEY) selectedStore = false;
    this.props.setStoreAvailability(selectedStore, pnhObj);
    const { storeAvailability, storeNumber } = this.props;
    const storeId = this.getStoreIdFromUrl();
    if (
      storeAvailability && // if previous option was a store option
      selectedStore && // if current selected option is a store option
      checkIfSameAvailabilityOption(storeId, storeNumber, pnhObj)
    ) {
      return false;
    }
    this.onUpdateSelectedFilters(selected, null, pnhObj);
    /* istanbul ignore else */
    if (this.props.scrollToFiltersOnChange) this.scrollToFiltersTopOnChange();
    return true;
  };
  /**
   * Handles sort by options events
   * This hook is used for the Sort component in the right slider on mobile
   */
  onSortOptionsViewUpdate = () => {
    const { selectedSortOption, prevSort } = this.state;
    /* istanbul ignore else */
    if (selectedSortOption && selectedSortOption !== prevSort)
      this.onSortOptionUpdate(selectedSortOption);
    this.toggleSortOptions();
  };
  /**
   * Handles sort by options events
   * This hook is used by the Custom Select dropdown in desktop view.
   * @param {string} v The selected sort value.
   */
  onSortOptionUpdate = v => {
    const { filterConfiguration } = this.props;
    this.onFilterUpdate({
      sort: v,
      start: 0,
      sortOptionSet: filterConfiguration.sortingOptions,
      isMobileChannel: this.props.channelType === CHANNELTYPE_MOBILE,
    });
  };
  /**
   * Called when slideout is opened.
   */
  onSlideoutOverlayOpen = () => {
    const isMobile = this.props.channelType === CHANNELTYPE_MOBILE;
    const { activeFacetId } = this.state;
    const { facetsData, propsForFetchingFacets, getMoreFacetData } = this.props;
    if (activeFacetId === 'BRAND_NAME' || activeFacetId === 'BRAND') {
      const paramObj = {
        event,
        propsForFetchingFacets,
        getMoreFacetData,
        id: activeFacetId,
        groupByOn: isGroupByPLPActive(),
        moreRefinements:
          facetsData[activeFacetId] &&
          facetsData[activeFacetId].moreRefinements,
      };
      loadMoreBrandFacet(paramObj);
    }
    /** increasing specificity for querySelector in case there are multiple DOM nodes */
    const overlayClass = this.props.overlayWrapperClassName
      ? `.${this.props.overlayWrapperClassName}`
      : '';
    const filterViewSelector = this.isPLPFilters
      ? '.filtersViewport'
      : `.js-allFiltersView${overlayClass}`;
    const filterViewClass = document.querySelector(`${filterViewSelector}`);
    const allFiltersView = isMobile
      ? document.querySelector(`${overlayClass} .js-mob-allFiltersView`)
      : filterViewClass;
    /* istanbul ignore next: hard to reach for test case */
    this.focusTrap =
      this.focusTrap ||
      createFocusTrap(allFiltersView, {
        initialFocus: allFiltersView.querySelector('#sectionCont'),
        fallbackFocus: document.querySelector('.js-showAllFiltersButton'),
        clickOutsideDeactivates: isTbs(),
      });
    this.focusTrap.activate();
  };

  // eslint-disable-next-line
  getStoreIdFromUrl() {
    let storeId = getOr(null, 'match.params.store', this.props);
    if (storeId) {
      storeId = storeId.split('-')[1];
    }
    return storeId;
  }

  getBopusAvailability() {
    const { storeDetails } = this.props;
    if (storeDetails && storeDetails.siteBopus) {
      // eslint-disable-next-line
      this.setState({ bopusAvailable: storeDetails.siteBopus });
    }
  }

  getMobileSkeleton() {
    return (
      <div className="lg-hide md-hide">
        {this.renderSeoHeading()}
        <div className={Styles.filtersHeader}>
          <PagingSkeleton isSearch={this.props.isSearch} />
        </div>
        <div
          className={classnames(
            Styles.pageFiltersWrapper,
            `channel-type-${this.props.channelType}`
          )}
        >
          <FilterSkeleton isMobile />
          <AvailableSkeleton isMobile />
        </div>
        <section className="sm-pb2 sm-mt2">
          <AppliedFilterSkeleton height={41} />
        </section>
      </div>
    );
  }

  /**
   * Returns Desktop adaptive component for filters
   * @param {object} deviceConfig Defines an object that will contain viewport breakpoints
   * @param {bool} sortingOptionsOpen Indicates that the sortingOptions is opened
   * @param {array} sortByFilterOptions Sort options to pass to List
   * @param {bool} sortOptionSelected Indicates if sort option is selected
   * @param {object} labels Labels from Labels API.
   * @return {object} React Component.
   */
  getMobileMediaQuery = (
    deviceConfig,
    sortingOptionsOpen,
    sortByFilterOptions,
    sortOptionSelected,
    labels
  ) => {
    if (this.props.onlyAppliedFilter) {
      return (
        <div className="lg-hide md-hide"> {this.renderAppliedFilters()} </div>
      );
    }
    const isSmallView = true;
    return (
      <MediaQuery maxWidth={deviceConfig.DESKTOP - 1}>
        <Fragment>
          {this.renderPagingFunction()}
          {this.renderMobNarrowSearch()}
          {this.renderSortFilterAvailability(labels, isSmallView)}
          {this.renderAppliedFilters()}
          {this.state.sortingOptionsOpen ? (
            <SlideOutOverlay
              onOverlayClick={this.toggleSortOptions}
              show={sortingOptionsOpen}
              direction="right"
              panelWidth="100%"
              panelStyles={PANEL_STYLE}
              id="sorting-slide-out-overlay-mobile"
              overlayWrapperClassName={this.props.overlayWrapperClassName}
            >
              <SortOptionsView
                data={sortByFilterOptions}
                onClose={this.onSortOptionsViewUpdate}
                selectedItems={[sortOptionSelected]}
                onSelectionUpdate={this.updateSortSelection}
                labels={labels}
              />
            </SlideOutOverlay>
          ) : null}
        </Fragment>
      </MediaQuery>
    );
  };
  onFilterUpdate = obj => {
    this.props.onFilterUpdate(obj);
    if (this.props.reInitializeMarks) {
      this.props.reInitializeMarks();
    }
  };

  getDesktopSkeleton() {
    return (
      <section
        className="sm-hide xs-hide"
        role="region"
        aria-labelledby="filters-paging-h2"
      >
        {this.renderSeoHeading()}
        <div className={Styles.filtersHeader}>{this.renderBopisSkeleton()}</div>
        <div
          className={classnames(
            'inline-block fullWidth md-pt2',
            `channel-type-${this.props.channelType}`,
            'filtersWrapper'
          )}
        >
          <FilterSkeleton className={Styles.filterWidth} />
          <SortingSkeleton className={Styles.availableSkeletonWidth} />
        </div>
        <section className="mt075 pt2">
          <AppliedFilterSkeleton height={43} />
        </section>
      </section>
    );
  }

  getDesktopMediaQuery = (
    deviceConfig,
    filterConfiguration,
    sortOptions,
    itemsPerPage,
    labels,
    showSkeleton
  ) => {
    const { sort, sortByFilterOptions } = sortOptions;
    let localSortByFilterOptions = sortByFilterOptions;
    if (
      Array.isArray(filterConfiguration.sortingOptions) &&
      !filterConfiguration.sortingOptions.some(e => e.displayName === sort)
    ) {
      localSortByFilterOptions = [...localSortByFilterOptions];
    }

    if (this.props.onlyAppliedFilter) {
      return (
        <MediaQuery minWidth={deviceConfig.DESKTOP}>
          {' '}
          <section role="region" aria-labelledby="filters-paging-h2">
            {this.renderAppliedFilters()}
          </section>
        </MediaQuery>
      );
    }

    const wrapperProps = {
      searchTerm: this.props.searchTerm,
      renderPaging: this.renderPaging,
      pageSortOptions: null,
      renderAvailabilityFilter: this.renderAvailabilityFilter(labels),
      isShiptSdd: this.props.isShiptSdd,
      isShopInStore: this.props.isShopInStore,
      showSkeleton,
      renderSkeleton: this.renderBopisSkeleton,
    };

    if (this.isPLPFilters && this.props.displayFiltersOnLeft) {
      return (
        <div className="sm-hide xs-hide">
          <section role="region" aria-labelledby="filters-paging-h2">
            <div className={Styles.filtersHeader}>
              <FilterWrapper {...wrapperProps} />
            </div>
          </section>
        </div>
      );
    }

    if (this.isPLPFilters && this.props.onlySortingOption) {
      return (
        <PageSortOptions
          labels={labels}
          sort={sort}
          SortTypeOptionSet={localSortByFilterOptions}
          defaultPerPage={uiConfig.defaultPerPage}
          itemsPerPage={itemsPerPage}
          PerPageOptionSet={null}
          onFilterUpdate={this.props.onFilterUpdate}
          selectedPnhListId={this.props.selectedPnhListId}
        />
      );
    }

    return (
      <div className="sm-hide xs-hide">
        <section role="region" aria-labelledby="filters-paging-h2">
          <div className={Styles.filtersHeader}>
            <BopisWrapper {...wrapperProps} />
          </div>
          <div
            className={classnames(
              Styles.pageFiltersWrapper,
              `channel-type-${this.props.channelType}`,
              'filtersWrapper'
            )}
          >
            <div className={Styles.facetsWrapper}>
              <DynamicFacetsRowRenderer
                baseUrl={this.props.Url}
                selectedFilters={this.props.selectedFilters}
                allFiltersButton={this.renderShowAllFiltersButton(
                  LabelsUtil.getLabel(
                    this.props.labels,
                    'gridFilters.allFilters'
                  )
                )}
                className={Styles.dynamicFacetsRowRenderer}
              >
                {this.renderAllFacetsOnPage()}
              </DynamicFacetsRowRenderer>
            </div>
            <div className={Styles.otherOptions}>
              <BopisWrapper
                pageSortOptions={
                  <PageSortOptions
                    labels={labels}
                    sort={sort}
                    SortTypeOptionSet={localSortByFilterOptions}
                    defaultPerPage={uiConfig.defaultPerPage}
                    itemsPerPage={itemsPerPage}
                    PerPageOptionSet={null}
                    onFilterUpdate={this.props.onFilterUpdate}
                    selectedPnhListId={this.props.selectedPnhListId}
                  />
                }
                renderAvailabilityFilter={null}
                renderSkeleton={this.renderSortingSkeleton}
                className="bopisWrapper"
              />
            </div>
          </div>
          {this.renderAppliedFilters()}
        </section>
      </div>
    );
  };

  updateOpenAllFilter = nextProps => {
    const currentSWS = getOr('', 'swsParams.sws', this.props);
    const prevSWS = getOr('', 'swsParams.sws', nextProps);
    if (currentSWS && currentSWS === prevSWS)
      this.setState({
        openAllFilter: false,
      });
  };

  callAndOpenFilter = () => {
    this.handleToggleAllFilters();
  };

  isFacetClicked = value => {
    this.setState({ facetClickedEnable: value });
  };

  handleMultipleSelection = bool => {
    this.setState({ facetClick: bool });
  };

  /**
   * @function isPNHPLP - If the user selected the PNH Store in the Availability Downdown then this function return true
   * @returns {boolean}
   */
  isPNHPLP() {
    const defaultLocation = getOr(
      '',
      'locationBeforeTransitions',
      this.props.route
    );
    const newLocation = getOr(
      defaultLocation,
      'locationBeforeTransitions.location',
      this.props.route
    );
    const { isPNH } = getPNHStoreInfoFromURL(newLocation);
    return isPNH;
  }

  ioCallback = entries => {
    if (entries) {
      let spaProductCounter = 0;
      entries.forEach(entry => {
        if (
          entry.intersectionRatio > 0 &&
          !this.state.productsExposed.exposedId.includes(entry.target.id)
        ) {
          if (!entry.target.attributes.index) {
            this.setState({
              productsExposed: {
                exposedId: [
                  ...this.state.productsExposed.exposedId,
                  entry.target.id,
                ],
                exposedIndex: [
                  ...this.state.productsExposed.exposedIndex,
                  {
                    spaPosition: spaProductCounter,
                    solrPosition: '',
                  },
                ],
              },
            });
            spaProductCounter += 1;
          } else {
            this.setState({
              productsExposed: {
                exposedId: [
                  ...this.state.productsExposed.exposedId,
                  entry.target.id,
                ],
                exposedIndex: [
                  ...this.state.productsExposed.exposedIndex,
                  {
                    solrPosition: entry.target.attributes.index.value,
                  },
                ],
              },
            });
          }
        }
      });
    }
  };

  ioObserver = () => {
    const ioOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 1.0,
    };
    const observer = new IntersectionObserver(this.ioCallback, ioOptions);
    const targets = document.querySelectorAll(
      '.tealium-product-grid .tealium-product-card .tealium-product-title'
    );
    const targetsArr = Array.prototype.slice.call(targets);
    if (targetsArr.length <= 0 && this.mounted && this.ioObserverCount < 8) {
      this.ioObserverCount += 1;
      this.setState({
        productObserverStarted: false,
      });
    }
    if (
      targetsArr.length > 0 &&
      this.mounted &&
      !this.state.productObserverStarted &&
      !this.props.scrollFiltersTop &&
      !this.state.holdScroll
    ) {
      targetsArr.forEach(target => {
        observer.observe(target);
      });
      this.setState({
        productObserverStarted: true,
      });
    }
    /* istanbul ignore next: hard to call this method */
    this.iODisconnect = () => {
      observer.disconnect();
    };
  };

  /**
   *  Sets the sort index that will be used by View results action
   */
  updateSortSelection = index => {
    const { filterConfiguration, isSearch } = this.props;
    const sortingOptions = isSearch
      ? filterConfiguration.sortingOptionsSrp
      : filterConfiguration.sortingOptions;
    this.setState({
      selectedSortOption: sortingOptions[index].value,
    });
  };
  /**
   * @function toggleAvailabilityDropdown
   * Toggles Availability Dropdown
   * reverses the current state of isAvailabilityDropDownOpen state property
   */
  toggleAvailabilityDropdown = () => {
    this.setState({
      isAvailabilityDropDownOpen: !this.state.isAvailabilityDropDownOpen,
    });
  };
  /**
   * @function closeAvailabilityDropDown
   * Closes Availability Dropdown
   */
  closeAvailabilityDropDown = () => {
    this.setState({
      isAvailabilityDropDownOpen: false,
    });
  };
  /* Function that will be invoked when sorting/page options change if the `scrollToFiltersOnChange` prop is true.*/
  scrollToFiltersTopOnChange = () => {
    if (this.delayScroll !== undefined) {
      clearTimeout(this.delayScroll);
    }
    this.delayScroll = setTimeoutCustom(scrollToFiltersTop, 200);
  };

  /**
   * Checks to see if start value is greater than numFound
   * @return {boolean}
   */
  isStartOutOfRange = () => {
    const { numFound, dataLength, start } = this.props;
    return dataLength === 0 && numFound > 0 && start > 0;
  };

  handleClearTealiumFiltersPLP = data => {
    if (typeof this.props.setTealiumClearFilterCall === 'function') {
      this.props.setTealiumClearFilterCall(data);
    }
  };

  clearAllFilters = () => {
    this.props.updateSwsTerm([]);
    this.props.clearSelectedFilters();
    /* istanbul ignore else */
    if (this.props.scrollToFiltersOnChange && isBrowser()) {
      window.scrollTo(0, 0);
    }
    this.setState({
      sameDayDelivery: false,
      activeFacetId: '',
    });
    if (this.props.reInitializeMarks) {
      this.props.reInitializeMarks();
    }
  };
  handleToggleAllFilters = () => {
    this.props.setPrevAllFiltersState({
      allFiltersOpen: !this.state.allFiltersOpen,
    });
    if (this.state.allFiltersOpen && this.focusTrap) {
      this.focusTrap.deactivate();
    }
    this.setState({
      allFiltersOpen: !this.state.allFiltersOpen,
    });
  };
  /**
   * Toggles the Sort options fly out.
   */
  toggleSortOptions = () => {
    this.setState(prevState => ({
      sortingOptionsOpen: !prevState.sortingOptionsOpen,
    }));
  };

  asyncLoadPnhSagas() {
    const {
      registries,
      categoryId,
      match,
      searchTerm,
      pageIdentifierSelector,
    } = this.props;
    return (
      this.state.pnhCheckListSagaRequired && (
        <PNHFilterWrapper
          registries={registries}
          categoryId={categoryId}
          match={match}
          searchTerm={searchTerm}
          pageIdentifierSelector={pageIdentifierSelector}
        />
      )
    );
  }
  renderMobNarrowSearch() {
    const { isShopInStore, isShiptSdd } = this.props;
    return (
      <React.Fragment>
        {(isShopInStore || isShiptSdd) && (
          <section className={'my2'} id="mobNarrowSearch" />
        )}
      </React.Fragment>
    );
  }
  renderPagingFunction() {
    return (
      <React.Fragment>
        <section className={Styles.filtersHeader}>
          {this.renderPaging()}
        </section>
      </React.Fragment>
    );
  }
  renderSortFilterAvailability(labels, isSmallView) {
    return (
      <React.Fragment>
        <section
          className={classnames(
            Styles.pageFiltersWrapper,
            `channel-type-${this.props.channelType}`
          )}
        >
          <section className={Styles.facetsWrapper}>
            {this.renderShowAllFiltersButton(
              LabelsUtil.getLabel(labels, 'gridFilters.allFiltersMobileBtn')
            )}
            <Button
              className={Styles.sortListing}
              type="button"
              value={LabelsUtil.getLabel(labels, 'gridFilters.sort')}
              theme="control"
              variation="smallBorderRadius"
              onClick={this.toggleSortOptions}
            >
              {LabelsUtil.getLabel(labels, 'gridFilters.sort')}
            </Button>
          </section>
          <section className="bopisFilterWrapper bopisFeature">
            {!this.props.isShiptSdd &&
              !this.props.isShopInStore &&
              this.renderAvailabilityFilter(labels, isSmallView)}
          </section>
        </section>
      </React.Fragment>
    );
  }

  renderBopisSkeleton = () => (
    <React.Fragment>
      <PagingSkeleton isSearch={this.props.isSearch} />
      <AvailableSkeleton />
    </React.Fragment>
  );

  renderSortingSkeleton = () => <SortingSkeleton />;

  renderAvailableSkeleton = isMobile => (
    <AvailableSkeleton isMobile={isMobile} />
  );

  /**
   * Manged server side rendering of heading for seo.
   */
  renderSeoHeading() {
    const { summary, selectedFilters, pageIdentifierSelector } = this.props;
    const pageHeading = getPageHeading(
      summary,
      selectedFilters,
      pageIdentifierSelector
    );
    return (
      <Heading level={1} className={`${Styles.seoHeading} hide`}>
        {decodeHtmlEntities(pageHeading)}
      </Heading>
    );
  }

  renderAvailabilityFilter = (labels, isSmallView = false) => {
    const pnhListId = getOr('', 'route.queryString', this.props);
    const plpEDDPageFlag = getOr(
      false,
      'enableEDDPLPFacets',
      this.props.vendorSwitch
    );
    const plpEDDFacetDataState = checkPLPEDDFacetsEnabled(plpEDDPageFlag);
    const plpSDDFacetDataState = getOr(
      false,
      'enableSDDPLPFacets',
      this.props.vendorSwitch
    );
    const {
      formWrapperData,
      akamaiHeader,
      eddFacetCount,
      sameDayCount,
      eddOptionSelected,
      sddOptionSelected,
      checklistData,
      updateSelectedPNHInStore,
      nearestStoreParams,
      track,
      displayPLPFilters,
    } = this.props;
    return (
      <AvailabilityFilter
        storeDetails={this.props.storeDetails}
        pnhStoreDetails={this.props.pnhStoreDetails}
        registries={this.props.registries}
        pnhRegistries={this.props.pnhRegistries}
        vendorSwitch={this.props.vendorSwitch}
        labels={labels}
        storeAvailability={this.props.storeAvailability}
        numFound={this.props.numFound}
        storeAvailabilityCount={this.props.storeAvailabilityCount}
        sameDayDeliveryCount={this.props.sameDayDeliveryCount}
        onlineCount={this.props.onlineCount}
        toggleAvailabilityDropdown={this.toggleAvailabilityDropdown}
        onStoreAvailabilityUpdate={this.onStoreAvailabilityUpdate}
        landingZip={this.props.landingZip}
        setLandingZip={this.props.setLandingZip}
        onChangeStore={this.props.onChangeStore}
        closeAvailabilityDropdown={this.closeAvailabilityDropdown}
        isSmallView={isSmallView}
        isPNHPLP={this.isPNHPLP()}
        pnhListId={pnhListId}
        activeRegistryID={this.props.activeRegistryID}
        selectedPnhListId={this.props.selectedPnhListId}
        favouriteStore={this.props.favouriteStore}
        onUpdateSelectedFilters={this.onUpdateSelectedFilters}
        scrollToFiltersOnChange={this.props.scrollToFiltersOnChange}
        scrollToFiltersTopOnChange={this.scrollToFiltersTopOnChange}
        isEDDAvailabilityFilter={plpEDDFacetDataState}
        isSDDAvailabilityFilter={plpSDDFacetDataState}
        formWrapperData={formWrapperData}
        akamaiHeader={akamaiHeader}
        eddFacetCount={eddFacetCount}
        sameDayCount={sameDayCount}
        eddOptionSelected={eddOptionSelected}
        sddOptionSelected={sddOptionSelected}
        isLoadingAllFacet={this.props.isLoadingAllFacet}
        checklistData={checklistData}
        isBopisFilter
        isMobile={this.props.channelType === CHANNELTYPE_MOBILE}
        bopusAvailable={this.state.bopusAvailable}
        updateSelectedPNHInStore={updateSelectedPNHInStore}
        siteId={getCurrentSiteId()}
        onInitStoreDetails={this.props.onInitStoreDetails}
        nearestStoreParams={nearestStoreParams}
        track={track}
        isNearestStoresTestActive={this.isNearestStoresTestActive}
        renderSkeleton={this.renderAvailableSkeleton}
        displayPLPFilters={displayPLPFilters}
      />
    );
  };

  /**
   * Renders the Paging component
   * @return {object} React Component
   */
  renderPaging() {
    const {
      paging,
      labels,
      summary,
      selectedFilters,
      pageIdentifierSelector,
    } = this.props;
    const isDataAvailable =
      paging.start > 0 && paging.count > 0 && paging.end > 0;
    if (!isDataAvailable) {
      return <PagingSkeleton isSearch={this.props.isSearch} />;
    }
    return (
      <Paging
        paging={paging}
        labels={labels}
        heading={getPageHeading(
          summary,
          selectedFilters,
          pageIdentifierSelector
        )}
      />
    );
  }

  /**
   * Renders the show all filters button
   * @param {string} label  The button label
   */
  renderShowAllFiltersButton(label) {
    return (
      <Button
        className={classnames(
          Styles.showAllFilters,
          '__test__showAllFiltersButton',
          'js-showAllFiltersButton'
        )}
        type="button"
        value={label}
        theme="control"
        variation="smallBorderRadius"
        aria-haspopup="true"
        aria-expanded={this.state.allFiltersOpen}
        aria-controls="filters-all-filters-view"
        onClick={this.callAndOpenFilter}
      >
        {label}
      </Button>
    );
  }
  /**
   * Renders the applied filters component
   */
  renderAppliedFilters() {
    const {
      appliedFiltersOrderedSet,
      appliedFilters,
      searchWithinSearchTerms,
      isUsingState,
      pageIdentifierSelector,
      storeAvailability,
      setSDDOptionSelection,
      sddOptionSelected,
      sameDayCount,
      disableSddCheckBox,
      storeAvailabilitycount,
      sameDayDeliveryCount,
      searchTerm,
    } = this.props;
    return (
      <AppliedFiltersComponent
        labels={this.props.labels}
        appliedFiltersOrderedSet={appliedFiltersOrderedSet}
        clearSelectedFilters={this.clearAllFilters}
        appliedFilters={appliedFilters}
        updateSelectedFilters={this.onUpdateSelectedFilters}
        swsFilters={searchWithinSearchTerms}
        updateSwsFilter={this.onSearchWithin}
        setTealiumClearFilterCall={this.handleClearTealiumFiltersPLP}
        isUsingState={isUsingState}
        onStoreAvailabilityUpdate={this.onStoreAvailabilityUpdate}
        pageIdentifier={pageIdentifierSelector}
        storeAvailability={storeAvailability}
        setSDDOptionSelection={setSDDOptionSelection}
        sddOptionSelected={sddOptionSelected}
        sameDayCount={sameDayCount}
        storeAvailabilityCount={storeAvailabilitycount}
        disableSddCheckBox={disableSddCheckBox}
        searchTerm={searchTerm}
        sameDayDeliveryCount={sameDayDeliveryCount}
        displayPLPFilters={this.isPLPFilters}
      />
    );
  }

  /**
   * We are using ref of <AllFilterView {...props} /> to render <FilterSearchInput {...props} />
   * using ReactDOM.createPortal
   * - In <AllFiltersView /> component, we have renderFilterSearchInput method which returns <FilterSearchInput />
   * - Based on Device we are injecting <FilterSearchInput /> in respective node
   * - It will render FilterSearchInput only on client
   */
  renderNarrowSearchOnPLP = () => {
    if (this.allFiltersViewRef && isBrowser()) {
      const FilterSearchInput = this.allFiltersViewRef.renderFilterSearchInput(
        true
      );
      const node =
        this.props.channelType === CHANNELTYPE_MOBILE
          ? document.getElementById('mobNarrowSearch')
          : document.getElementById('dskNarrowSearch');
      if (node && FilterSearchInput) {
        return ReactDOM.createPortal(FilterSearchInput, node);
      }
    }
    return null;
  };

  renderAllFacetsOnPage(registryNames, isRegistryFlow) {
    const {
      facetsData,
      selectedFilters,
      labels,
      facetDataOrder,
      enabledTypeaheadFacetsIds,
      baseUrl,
      appliedFiltersOrderedSet,
      dimentionalFilterThresholds,
      formWrapperDataASSEMBLEDPRODUCTDIAMETERIN,
      formWrapperDataASSEMBLEDPRODUCTLENGTHIN,
      formWrapperDataASSEMBLEDPRODUCTWIDTHIN,
      formWrapperDataASSEMBLEDPRODUCTHEIGHTIN,
      formWrapperDataLOWPRICE,
      switchConfig,
      seoUrl,
      getMoreFacetData,
      propsForFetchingFacets,
    } = this.props;
    const siteId = getCurrentSiteId();
    return facetDataOrder.map((facetID, index) => {
      const facet = facetsData[facetID];
      const searchable =
        facet &&
        (facet.type === 'field' || facet.type === 'single') &&
        !isEmpty(enabledTypeaheadFacetsIds.find(val => val === facetID));
      const enableDimensionalFilters = getOr(
        false,
        'enableDimensionalFilters',
        switchConfig
      );
      const enableColorFacet = getOr(false, 'enableColorFacet', switchConfig);
      if (
        (siteId === BBBY_SITE_ID || siteId === TBS_BBBY_SITE_ID) &&
        facetID === EVENT_TYPE &&
        registryNames
      ) {
        facet.items = facet.items.filter(
          item => registryNames.indexOf(item.label) > -1
        );
      }
      /* istanbul ignore if: branch never cover due to DIMENTIONAL_FILTERS doesn't have sufficient key */
      if (
        !enableDimensionalFilters &&
        DIMENTIONAL_FILTERS.indexOf(facetID) >= 0 &&
        facetID !== 'LOW_PRICE'
      )
        return null;
      return (
        facet && (
          <FilterList
            baseUrl={baseUrl}
            id={facet.id}
            label={facet.displayName}
            data={facet.items}
            key={`facet-${index}-${facet.id}`}
            type={facet.type}
            searchable={searchable}
            labels={labels}
            onSelectionUpdate={this.onFilterSelectionUpdate}
            handleMultipleSelection={this.handleMultipleSelection}
            selectedFilters={selectedFilters}
            selectedItems={selectedFilters[facet.id]}
            facetsData={facetsData}
            appliedFiltersOrderedSet={appliedFiltersOrderedSet}
            dimentionalFilterThresholds={dimentionalFilterThresholds}
            formWrapperDataASSEMBLEDPRODUCTDIAMETERIN={
              formWrapperDataASSEMBLEDPRODUCTDIAMETERIN
            }
            formWrapperDataASSEMBLEDPRODUCTLENGTHIN={
              formWrapperDataASSEMBLEDPRODUCTLENGTHIN
            }
            formWrapperDataASSEMBLEDPRODUCTWIDTHIN={
              formWrapperDataASSEMBLEDPRODUCTWIDTHIN
            }
            formWrapperDataASSEMBLEDPRODUCTHEIGHTIN={
              formWrapperDataASSEMBLEDPRODUCTHEIGHTIN
            }
            formWrapperDataLOWPRICE={formWrapperDataLOWPRICE}
            fromAllFilterPanel={false}
            enableColorFacet={enableColorFacet}
            facetClick={this.isFacetClicked}
            isRegistryFlow={isRegistryFlow}
            seoUrl={seoUrl}
            getMoreFacetData={getMoreFacetData}
            propsForFetchingFacets={propsForFetchingFacets}
            moreRefinements={facet.moreRefinements}
          />
        )
      );
    });
  }

  setRef = node => (this.allFiltersViewRef = node);

  renderSlideOutOverlay = (
    isUpdatingFilters,
    channelType,
    facetsData,
    selectedFilters,
    paging,
    labels,
    facetDataOrder
  ) => {
    const {
      allFiltersOpen,
      activeFacetId,
      allFiltersData,
      isPanelFacetToggle,
    } = this.state;
    const { numFound } = this.props;
    if (allFiltersOpen && this.deferFilterRendering) {
      this.deferFilterRendering = false;
      // Assuming allFiltersOpen can only be true on client
      this.isPLPSSR = false;
    }

    // To use ref of <AllFiltersView {...props} />
    if (
      this.deferFilterRendering &&
      !this.props.isShopInStore &&
      !this.props.isShiptSdd
    )
      return null;

    if (this.isPLPSSR) {
      return (
        <AllFiltersSeoView
          key="AllFiltersSeo"
          data={allFiltersData}
          facetDataOrder={facetDataOrder}
          labels={labels}
          switchConfig={this.props.switchConfig}
          baseUrl={this.props.baseUrl}
          appliedFiltersOrderedSet={this.props.appliedFiltersOrderedSet}
        />
      );
    }
    const AllFiltersViewComponent = (
      <AllFiltersView
        ref={this.setRef}
        baseUrl={this.props.baseUrl}
        data={allFiltersData}
        activeFacetId={activeFacetId}
        onActiveFacetChange={this.onAccordionChange}
        onClose={this.toggleAllFilters}
        onClearAll={this.clearAllFilters}
        onSelectionUpdate={this.onFilterSelectionUpdate}
        swsTerms={this.props.searchWithinSearchTerms}
        productCount={paging.count}
        labels={labels}
        onUpdateSelectedFilters={this.onUpdateSelectedFilters}
        facetDataOrder={facetDataOrder}
        channelType={channelType}
        searchCallback={this.onSearchWithin}
        enabledTypeaheadFacetsIds={this.props.enabledTypeaheadFacetsIds}
        isOpen={allFiltersOpen}
        isBusy={isUpdatingFilters}
        isLoadingAllFacet={this.props.isLoadingAllFacet}
        appliedFiltersOrderedSet={this.props.appliedFiltersOrderedSet}
        formWrapperDataASSEMBLEDPRODUCTDIAMETERIN={
          this.props.formWrapperDataASSEMBLEDPRODUCTDIAMETERIN
        }
        formWrapperDataASSEMBLEDPRODUCTLENGTHIN={
          this.props.formWrapperDataASSEMBLEDPRODUCTLENGTHIN
        }
        formWrapperDataASSEMBLEDPRODUCTWIDTHIN={
          this.props.formWrapperDataASSEMBLEDPRODUCTWIDTHIN
        }
        formWrapperDataASSEMBLEDPRODUCTHEIGHTIN={
          this.props.formWrapperDataASSEMBLEDPRODUCTHEIGHTIN
        }
        formWrapperDataLOWPRICE={this.props.formWrapperDataLOWPRICE}
        dimentionalFilterThresholds={this.props.dimentionalFilterThresholds}
        switchConfig={this.props.switchConfig}
        isPanelFacetToggle={isPanelFacetToggle}
        showNarrowSearchResults={this.props.showNarrowSearchResults}
        numFound={numFound}
        isShopInStore={this.props.isShopInStore}
        isShiptSdd={this.props.isShiptSdd}
        getMoreFacetData={this.props.getMoreFacetData}
        propsForFetchingFacets={this.props.propsForFetchingFacets}
        displayPLPFilters={this.isPLPFilters}
      />
    );
    if (this.isPLPFilters && this.props.channelType !== CHANNELTYPE_MOBILE) {
      return AllFiltersViewComponent;
    }
    return (
      <SlideOutOverlay
        onOverlayClick={this.toggleAllFilters}
        show={allFiltersOpen}
        direction="right"
        panelWidth={
          channelType === CHANNELTYPE_MOBILE ? '100%' : uiConfig.flyoutWidth
        }
        panelStyles={PANEL_STYLE_HEIGHT}
        onSlideoutOverlayOpen={this.onSlideoutOverlayOpen}
        overlayWrapperClassName={this.props.overlayWrapperClassName}
      >
        {AllFiltersViewComponent}
      </SlideOutOverlay>
    );
  };

  /**
   * renderFilterVariation - method used to render filters on PLP disgned to work with SiteSpect AB test
   *
   * @return                 filter variation or / default filter
   */
  /* eslint complexity: ["error", 17]*/
  renderFilterVariation() {
    const {
      filterConfiguration,
      paging,
      sort,
      deviceConfig,
      itemsPerPage,
      labels,
      isSearch,
      isLoadingPage,
      isUpdatingFilters,
      channelType,
      productDataLoaded,
      isLoadingAllFacet,
      onlyAppliedFilter,
      isLoadingFacet,
      isNoResults,
      displayPLPFilters,
    } = this.props;
    const { sortingOptionsOpen, selectedSortOption } = this.state;

    const defaultSort = DEFAULT_SEARCH_SORT_BY;
    const sortBy = sort === DEFAULT_SORT_BY ? defaultSort : sort;

    const sortingOptions = isSearch
      ? filterConfiguration.sortingOptionsSrp
      : filterConfiguration.sortingOptions;

    const sortByFilterOptions = (sortingOptions || []).map(item => {
      return {
        label: item.displayName,
        props: { value: item.value },
        key: kebabCase(item.displayName),
      };
    });

    const { viewAllItemsPerPage } = calculatePerPageOptions(
      filterConfiguration.perPageOptions,
      paging.count,
      itemsPerPage,
      labels
    );
    const isProductTileLoaded = isCombinedGroupByPLPCall()
      ? !isLoadingAllFacet
      : productDataLoaded;

    /**
     * showSkeleton condition checks
     * case-1: If "onlyAppliedFilter" is true -> use "isLoadingFacet" flag to check if facets are loading
     * case-2: if "onlyAppliedFilter" is false of undefined -> use "isLoadingPage" flag to show skeleton
     */
    const showSkeleton =
      (onlyAppliedFilter && isLoadingFacet) ||
      (!onlyAppliedFilter && isLoadingPage) ||
      isUpdatingFilters ||
      (!onlyAppliedFilter && !isProductTileLoaded);
    const showDesktopSkeleton =
      showSkeleton && !this.state.facetClick && this.state.facetClickedEnable;
    if ((showSkeleton || showDesktopSkeleton) && !isNoResults) {
      return (
        <GridContainer>
          {channelType === 'MobileWeb'
            ? this.getMobileSkeleton()
            : this.getDesktopSkeleton()}
        </GridContainer>
      );
    }
    const gridClass = displayPLPFilters ? Styles.selectedFilters : '';
    return (
      <GridContainer className={gridClass}>
        {channelType === 'MobileWeb'
          ? this.getMobileMediaQuery(
              deviceConfig,
              sortingOptionsOpen,
              sortByFilterOptions,
              selectedSortOption || sortBy,
              labels
            )
          : this.getDesktopMediaQuery(
              deviceConfig,
              filterConfiguration,
              { sortByFilterOptions, sort: sortBy },
              viewAllItemsPerPage,
              labels,
              showSkeleton
            )}
      </GridContainer>
    );
  }
  /**
   * Renders the component
   * @override
   * @return {object} React Component
   */
  render() {
    const {
      paging,
      isUpdatingFilters,
      selectedFilters,
      facetsData,
      labels,
      facetDataOrder,
      channelType,
      className,
      filtersTopSpacing,
      type,
      isShopInStore,
      isShiptSdd,
      onlyAppliedFilter,
      onlySortingOption,
      onlyBopisOptions,
    } = this.props;
    if (onlyAppliedFilter || onlySortingOption || onlyBopisOptions) {
      return this.renderFilterVariation();
    }

    const filterHtml = (
      <aside
        className={classnames(
          Styles[type],
          'filtersViewport',
          Styles[className],
          Styles.customSpacing,
          filtersTopSpacing,
          this.isPLPFilters ? 'mr3' : '',
          this.isPLPFilters ? Styles.filtersWidth : ''
        )}
      >
        <Fragment>
          {this.renderFilterVariation()}
          {!this.isPLPFilters ? this.asyncLoadPnhSagas() : null}
          {this.renderSlideOutOverlay(
            isUpdatingFilters,
            channelType,
            facetsData,
            selectedFilters,
            paging,
            labels,
            facetDataOrder
          )}
          {(isShopInStore || isShiptSdd) && this.renderNarrowSearchOnPLP()}
        </Fragment>
      </aside>
    );
    return (
      <React.Fragment>
        {this.state.isClient && filterHtml}
        {!this.state.isClient && filterHtml}
      </React.Fragment>
    );
  }
}
Filters.propTypes = propTypes;
Filters.defaultProps = defaultProps;
export default Filters;
export { calculatePerPageOptions };
