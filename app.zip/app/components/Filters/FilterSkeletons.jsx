import React from 'react';
import PropTypes from 'prop-types';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper/SkeletonWrapper';

export const PagingSkeleton = ({ isSearch }) => {
  return (
    <SkeletonWrapper
      viewPort={{ height: '55px', width: '50%' }}
      preserveAspectRatio="xMinYMin meet"
      height={55}
      width={315}
    >
      <rect
        x="0"
        y={isSearch ? '22' : '5'}
        rx="5"
        ry="5"
        width="200px"
        height="12px"
      />
      {!isSearch && (
        <rect x="0" y="35" rx="4" ry="4" width="300px" height="12px" />
      )}
    </SkeletonWrapper>
  );
};

PagingSkeleton.propTypes = {
  isSearch: PropTypes.bool,
};

export const AvailableSkeleton = ({ isMobile }) => {
  if (isMobile) {
    return (
      <SkeletonWrapper
        width={405}
        height={53}
        className={'py1'}
        viewPort={{ height: '53px', width: '100%' }}
        preserveAspectRatio="xMinYMid meet"
      >
        <rect x="0" y="4" rx="4" ry="4" width="24px" height="24px" />
        <rect x="34" y="6" rx="4" ry="4" width="250px" height="16px" />
        <rect x="34" y="33" rx="4" ry="4" width="200px" height="12px" />
      </SkeletonWrapper>
    );
  }
  return (
    <SkeletonWrapper
      width={405}
      height={55}
      viewPort={{ height: '55px', width: '50%' }}
      preserveAspectRatio="xMaxYMid meet"
    >
      <rect x="0" y="4" rx="4" ry="4" width="24px" height="24px" />
      <rect x="34" y="6" rx="4" ry="4" width="250px" height="16px" />
      <rect x="84" y="33" rx="4" ry="4" width="200px" height="12px" />
      <rect x="294" y="4" rx="4" ry="4" width="110px" height="50px" />
    </SkeletonWrapper>
  );
};

AvailableSkeleton.propTypes = {
  isMobile: PropTypes.bool,
};

export const FilterSkeleton = ({ isMobile, className }) => {
  if (isMobile) {
    return (
      <SkeletonWrapper
        viewPort={{ height: '100%', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        preserveAspectRatio="xMinYMin meet"
        className="mobfilterSkeleton"
        svgProps={{ viewBox: null }}
      >
        <rect x="0" y="0" rx="4" ry="4" width="49%" height="100%" />
        <rect x="51%" y="0" rx="4" ry="4" width="49%" height="100%" />
      </SkeletonWrapper>
    );
  }
  return (
    <SkeletonWrapper
      viewPort={{ height: '60px', width: '100%' }}
      rectContainerHeight="100%"
      rectContainerWidth="100%"
      preserveAspectRatio="xMaxYMin meet"
      svgProps={{ viewBox: null }}
      className={className}
    >
      <rect x="0" y="0" rx="4" ry="4" width="110px" height="50px" />
      <rect x="124" y="0" rx="4" ry="4" width="90px" height="50px" />
      <rect x="228" y="0" rx="4" ry="4" width="110px" height="50px" />
      <rect x="352" y="15" rx="10" ry="20" width="100px" height="16px" />
    </SkeletonWrapper>
  );
};

FilterSkeleton.propTypes = {
  isMobile: PropTypes.bool,
  className: PropTypes.string,
};

export const SortingSkeleton = ({ className }) => {
  return (
    <SkeletonWrapper
      width={130}
      height={60}
      viewPort={{ height: '60px', width: '100%' }}
      preserveAspectRatio="xMaxYMin meet"
      className={className}
    >
      <rect x="0" y="0" rx="4" ry="4" width="110px" height="50px" />
    </SkeletonWrapper>
  );
};

SortingSkeleton.propTypes = {
  className: PropTypes.string,
};

export const AppliedFilterSkeleton = ({ height }) => {
  return (
    <SkeletonWrapper
      viewPort={{ height: `${height}px`, width: '100%' }}
      height={height}
      width={106}
      preserveAspectRatio="xMinYMax meet"
    >
      <rect x="0" y="0" rx="4" ry="4" width="106px" height="41px" />
    </SkeletonWrapper>
  );
};

AppliedFilterSkeleton.propTypes = {
  height: PropTypes.number,
};

AppliedFilterSkeleton.defaultProps = {
  height: 43,
};
