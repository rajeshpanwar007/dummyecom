export const uiConfig = {
  flyoutWidth: '340px',
};
