/**
 * @author : Ankit Kamboj (ankit.kamboj@idc.bedbath.com)
 * Moved below selectors from InteractiveChecklist page i.e (app\containers\InteractiveChecklist\constants.js)
    to here for fixing product listing bundle size
 */
export const SDD_KEY = 'SDD';
export const BBBY_SITE_ID = 'BuyBuyBaby';
export const TBS_BBBY_SITE_ID = 'TBS_BuyBuyBaby';
export const EVENT_TYPE = 'event_type';
export const EDD_KEY = 'EDD';
