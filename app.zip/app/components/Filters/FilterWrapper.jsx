import React from 'react';
import PropTypes from 'prop-types';
import styles from './FilterWrapper.css';

const propTypes = {
  pageSortOptions: PropTypes.func,
  renderAvailabilityFilter: PropTypes.func,
  isShiptSdd: PropTypes.bool,
  isShopInStore: PropTypes.bool,
};

const FilterWrapper = props => {
  const {
    pageSortOptions,
    renderAvailabilityFilter,
    isShiptSdd,
    isShopInStore,
  } = props;

  if (pageSortOptions)
    return (
      <div
        id="bopus-pageSortOptions-container"
        className={styles.bopusContainer}
      >
        {pageSortOptions}
      </div>
    );

  if (renderAvailabilityFilter)
    return (
      <div id="bopus-availabilityFilter-container fitlerwrapper">
        {/* Don't render Availabilty filter if it's SDDShipT Page */}
        {!isShiptSdd && !isShopInStore && renderAvailabilityFilter}
        {(isShopInStore || isShiptSdd) && (
          <div className={styles.plpNarrowSearch} id="dskNarrowSearch" />
        )}
      </div>
    );

  return null;
};

FilterWrapper.propTypes = propTypes;

export default FilterWrapper;
