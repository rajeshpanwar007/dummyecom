import React from 'react';
import PropTypes from 'prop-types';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper/SkeletonWrapper';

const FilterSkeletonMobile = ({ height }) => {
  return (
    <SkeletonWrapper
      viewPort={{ height, width: '100%' }}
      rectContainerHeight="100%"
      rectContainerWidth="100%"
      className="pt2"
      preserveAspectRatio="xMaxYMin meet"
      svgProps={{ viewBox: null }}
    >
      <rect x="0" y="10" rx="10" ry="20" width="290px" height="16px" />
      <rect x="0" y="60" rx="4" ry="4" width="100%" height="4px" />
      <rect x="0" y="76" rx="4" ry="4" width="46%" height="50px" />
      <rect x="54%" y="76" rx="4" ry="4" width="46%" height="50px" />
    </SkeletonWrapper>
  );
};

FilterSkeletonMobile.propTypes = {
  height: PropTypes.number,
};

export default FilterSkeletonMobile;
