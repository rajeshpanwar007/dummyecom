import PropTypes from 'prop-types';
import { noop } from '@bbb-app/utils/common';
import { GRID_VIEW_TYPE } from '../../constants/search';

/**
 * @param {func}   appliedFilters Called when user selects or de-selects a filter
 * @param {string} baseUrl current route URL up to the segment before the facet/filter hash
 * @param {object} paging Paging object
 * @param {any}    appliedFiltersOrderedSet Holds the values of the strings that will be displayed in selected filters widget.
 * @param {string} channelType Indicates that user is on 'mobile' or 'desktop'
 * @param {string} className className for filter
 * @param {func}   clearSelectedFilters Called when clear all button is triggered.
 * @param {object} data Contains data from API
 * @param {object} data.configurations contains filter options for sorting and per page
 * @param {array}  data.listing the Category listings returned
 * @param {number} data.numFound the number of found Category listings
 * @param {number} data.start the starting point where Category listing should display (pagination)
 * @param {object} deviceConfig provides breakpoint configuration
 * @param {func}   facetsData Transform Facet data from API
 * @param {array}  facetDataOrder A list of facets/filters keys that indicate the order to display to user.
 * @param {bool}   isUpdatingFilters determines if filters are updating
 * @param {number} itemsPerPage The current items per page value
 * @param {object} labels Contains the set of labels to display in filters
 * @param {string} listingViewIcon Name of the toggle view icon.
 * @param {func}   onChangeStore Called "change store" is clicked
 * @param {func}   onInitStoreDetails Called when store ID is present on mount
 * @param {func}   onFilterUpdate Called with Sort By or Item Per Page changes
 * @param {func}   onResetStartToInitialValue Called when user enters a start value greater than numFound.
 * @param {func}   onViewTypeSelection toggles the small view type when clicked on
 * @param {object} paging Paging object
 * @param {number} sameDayDeliveryCount Not used
 * @param {bool}   scrollFiltersTop Indicates that filters should scroll top of filters panel.
 * @param {object} selectedFilters Holds the values of the selected filters.
 * @param {func}   setStoreAvailability Called when user clicks store availability filter
 * @param {string} smallViewType The view type currently selected
 * @param {string} sort The current sort value
 * @param {bool}   storeAvailability Indicates that store availability checkbox is selected
 * @param {number} storeAvailabilityCount The number of items in the store
 * @param {object} storeDetails The store details (e.g. address) for "available in store"
 * @param {string} storeId The store ID for "available in store"
 * @param {func}   updateSelectedFilters Called when filters are selected or deselected
 * @param {object} vendorSwitch Contains config for showing and hiding components
 * @param {string} vendorSwitch.showHideSDD show or hide same day delivery component
 * @param {string} vendorSwitch.showHideAvailableInStore show or hide available in store component
 * @param {func} getAkamaiStoreDetails fetching the store details
*/
export const propTypes = {
  appliedFilters: PropTypes.func,
  appliedFiltersOrderedSet: PropTypes.any,
  baseUrl: PropTypes.string,
  selectedPnhListId: PropTypes.string,
  channelType: PropTypes.string,
  className: PropTypes.string,
  clearSelectedFilters: PropTypes.func,
  data: PropTypes.shape({
    configuration: PropTypes.object,
    listing: PropTypes.array,
    numFound: PropTypes.number,
    start: PropTypes.number,
  }),
  deviceConfig: PropTypes.object,
  registries: PropTypes.object,
  pnhRegistries: PropTypes.object,
  facetsData: PropTypes.object,
  facetDataOrder: PropTypes.array,
  isUpdatingFilters: PropTypes.bool,
  isLoadingPage: PropTypes.bool,
  itemsPerPage: PropTypes.number,
  labels: PropTypes.object,
  listingViewIcon: PropTypes.string,
  onFilterUpdate: PropTypes.func,
  onInitStoreDetails: PropTypes.func,
  onChangeStore: PropTypes.func,
  onProductExposure: PropTypes.func,
  onResetStartToInitialValue: PropTypes.func,
  onViewTypeSelection: PropTypes.func,
  paging: PropTypes.object,
  sameDayDeliveryCount: PropTypes.number,
  scrollFiltersTop: PropTypes.bool,
  scrollTop: PropTypes.number,
  selectedFilters: PropTypes.object,
  setStoreAvailability: PropTypes.func,
  smallViewType: PropTypes.string,
  sort: PropTypes.string,
  storeAvailability: PropTypes.bool,
  storeAvailabilityCount: PropTypes.number,
  storeDetails: PropTypes.object,
  pnhStoreDetails: PropTypes.object,
  storeId: PropTypes.oneOf([PropTypes.string, PropTypes.number]),
  summary: PropTypes.string,
  updateSelectedFilters: PropTypes.func,
  vendorSwitch: PropTypes.shape({
    showHideSDD: PropTypes.string,
    showHideAvailableInStore: PropTypes.string,
  }),
  enabledTypeaheadFacetsIds: PropTypes.array,
  updateSwsTerm: PropTypes.func,
  route: PropTypes.object,
  getAkamaiStoreDetails: PropTypes.func,
  numFound: PropTypes.number,
  filtersTopSpacing: PropTypes.string,
  isSearch: PropTypes.bool,
  prevAllFiltersState: PropTypes.object,
  setPrevAllFiltersState: PropTypes.func,
  isSDDEnabled: PropTypes.bool,
  setTealiumClearFilterCall: PropTypes.func,
  type: PropTypes.oneOf(['', 'Filters']),
  filterHeaderClass: PropTypes.string,
  eddOptionSelected: PropTypes.string,
  activeRegistryID: PropTypes.string,
  checklistData: PropTypes.object,
  track: PropTypes.func,
  onlyAppliedFilter: PropTypes.bool,
  setSDDOptionSelection: PropTypes.func,
  isNoResults: PropTypes.bool,
};
export const defaultProps = {
  appliedFilters: () => null,
  appliedFiltersOrderedSet: [],
  channelType: 'mobile',
  className: '',
  clearSelectedFilters: noop,
  data: {
    configuration: {
      defaultPerPage: 48,
    },
    listing: [],
    start: 0,
    numFound: 0,
  },
  deviceConfig: {
    DESKTOP: 1024,
  },
  facetsData: {},
  facetDataOrder: [],
  itemsPerPage: 0,
  labels: {},
  listingViewIcon: 'grid',
  onFilterUpdate: noop,
  onProductExposure: noop,
  onInitStoreDetails: noop,
  onChangeStore: noop,
  onResetStartToInitialValue: noop,
  onViewTypeSelection: noop,
  paging: {
    start: 0,
    end: 0,
    count: 0,
  },
  sameDayDeliveryCount: 0,
  scrollFiltersTop: false,
  scrollTop: 0,
  selectedFilters: {},
  setStoreAvailability: noop,
  smallViewType: GRID_VIEW_TYPE,
  sort: '',
  storeAvailability: false,
  updateSelectedFilters: noop,
  vendorSwitch: {
    showHideSDD: 'false',
    showHideAvailableInStore: 'false',
  },
  enabledTypeaheadFacetsIds: [],
  updateSwsTerm: noop,
  route: {},
  getAkamaiStoreDetails: noop,
  setStoreDetails: noop,
  isSearch: false,
  prevAllFiltersState: {
    allFiltersOpen: false,
    activeFacetId: '',
  },
  setPrevAllFiltersState: noop,
  productDataLoaded: true,
  type: 'Filters',
  filterHeaderClass: '',
  displayPLPFilters: false,
};
