import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { isEqual } from 'lodash/fp';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import CustomSelect from '@bbb-app/custom-select/CustomSelect';
import styles from './FindYourSchool.css';

class FindYourSchool extends React.PureComponent {
  static propTypes = {
    statesData: PropTypes.array.isRequired,
    schoolData: PropTypes.array.isRequired,
    labels: PropTypes.object,
    fetchSchoolListInfo: PropTypes.func,
    submitSchoolInfo: PropTypes.func,
  };

  static defaultProps = {
    stateCode: '',
    schoolId: '',
  };

  constructor(props) {
    super(props);

    this.state = {
      // initially school dropdown is disabled
      disableSchoolDropDown: !(props.schoolData.length > 1),
      // initially no state is selected
      isStateSelected: false,
      // initially no school/college is selected
      isCollegeSelected: false,
    };
    this.handleSelectedState = this.handleSelectedState.bind(
      this,
      'selectState'
    );
    this.handleSelectedSchool = this.handleSelectedSchool.bind(
      this,
      'selectSchool'
    );
    this.checkSchoolSubmit = this.checkSchoolSubmit.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    this.setState(() => ({
      disableSchoolDropDown: !(nextProps.schoolData.length > 1),
    }));
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (!isEqual(this.props, nextProps) || !isEqual(this.state, nextState)) {
      return true;
    }
    return false;
  }

  /**
   * @description
   *  method executes whenever state dropdown changes
   *  trigger the parent action to fetch the school/college list if the value/collegId is present
   */
  handleSelectedState = (rule, value) => {
    this.setState({ stateCode: value });

    if (value) {
      this.props.fetchSchoolListInfo(value);
      this.setState({
        isStateSelected: true,
        isCollegeSelected: false,
      });
    } else {
      this.setState({
        isStateSelected: false,
        isCollegeSelected: false,
      });
    }
  };

  /**
   * @description
   *  method executes whenever school/college dropdown changes
   */
  handleSelectedSchool = (rule, value) => {
    this.setState({ schoolId: value });

    if (value) {
      this.setState({ isCollegeSelected: true });
    } else {
      this.setState({ isCollegeSelected: false });
    }
  };

  /**
   * @description
   *  parent action triggers when user click on the submit button.
   */
  checkSchoolSubmit(e) {
    e.preventDefault();
    const {
      stateCode,
      schoolId,
      isStateSelected,
      isCollegeSelected,
    } = this.state;

    // trigger the action only when both state dropdown and school dropdown are selected.
    if (isStateSelected && isCollegeSelected) {
      this.props.submitSchoolInfo(stateCode, schoolId);
    }
  }

  render() {
    // get props passed from the parent container
    const { statesData, labels, schoolData } = this.props;

    // to avoid the side effects, setting the variable first and then using it instead of using the condition directly.
    const btnSubmitDisable =
      !this.state.isStateSelected || !this.state.isCollegeSelected;

    return (
      <form noValidate onSubmit={this.checkSchoolSubmit}>
        <GridX
          className={classnames(
            styles.formWrapper,
            'align-items-center center'
          )}
        >
          <Cell className="large-3">
            <Heading
              level={4}
              styleVariation="h4-sans"
              className={styles.headingWrapper}
            >
              {LabelsUtil.getLabel(labels, 'heading')}
            </Heading>
          </Cell>
          <Cell className={classnames(styles.inputWrapper, 'large-9')}>
            <GridX className="grid-margin-x">
              <Cell
                className={classnames(styles.selectBox, 'medium-4 large-4')}
              >
                <CustomSelect
                  name="state"
                  optionSet={statesData}
                  selectOption={this.handleSelectedState}
                  defaultValue={this.state.stateCode}
                />
              </Cell>
              <Cell
                className={classnames(styles.selectBox, 'medium-4 large-4')}
              >
                <CustomSelect
                  name="school"
                  disabled={!this.state.isStateSelected}
                  optionSet={schoolData}
                  selectOption={this.handleSelectedSchool}
                  defaultValue={this.state.schoolId}
                />
              </Cell>
              <Cell className="medium-4 large-4 sm-mt1">
                <Button
                  disabled={btnSubmitDisable}
                  type="submit"
                  className={styles.btnSubmit}
                >
                  {LabelsUtil.getLabel(labels, 'btnSubmit')}
                </Button>
              </Cell>
            </GridX>
          </Cell>
        </GridX>
      </form>
    );
  }
}

export default FindYourSchool;
