import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { getCookie } from '@bbb-app/utils/universalCookie';
import Heading from '@bbb-app/core-ui/heading';
import { noop } from '@bbb-app/utils/common';
import focus from '@bbb-app/hoc/focus';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Icon from '@bbb-app/core-ui/icon';
import Error from '@bbb-app/universal-component/Error';
import { isTbs } from '@bbb-app/utils/isTbs';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import ModalDialog from '@bbb-app/modal-dialog/containers/ModalDialog';
import { ContentBox } from '@bbb-app/pure-content/containers/content-box/ContentBox';
import Notification from '@bbb-app/cart-error-notification/components/notification';
import ErrorNotification from '@bbb-app/cart-error-notification/containers/notification/ErrorNotification.async';
import PickupProductTile from '@bbb-app/pick-up-in-store/components/pick-up-product-tile';
import SearchStores from '../../containers/SearchStores/SearchStores';
import SkuSearchStoreDetails from '../Pages/PDP/SkuSearchStoreDetails';
import styles from './PickupInStoreModal.css';
import MiniQuickViewModal from '../QuickViewModal/MiniQuickViewModal.async';
const FocusableLink = focus(PrimaryLink);
const FocusableNotification = focus(Notification);

const propTypes = {
  deviceConfig: PropTypes.object,
  onModalClose: PropTypes.func,
  labels: PropTypes.object,
  isPickupInStoreModalOpen: PropTypes.bool,
  selectedProduct: PropTypes.object,
  scene7UrlConfig: PropTypes.object,
  fetchPickupProcessData: PropTypes.func,
  referredContent: PropTypes.object,
  onSearchSubmit: PropTypes.func,
  isStoreListFetching: PropTypes.bool,
  storeList: PropTypes.object,
  selectedSKUId: PropTypes.string,
  isErrorMsg: PropTypes.object,
  distanceMap: PropTypes.object,
  handleReserveNow: PropTypes.func,
  isQuickViewOpen: PropTypes.string,
  setFavoriteStoreId: PropTypes.func,
  setStoreDetails: PropTypes.func,
  isEditRegistryModalOpen: PropTypes.bool,
  clearStoreData: PropTypes.func,
  findAStoreModal: PropTypes.bool,
  changeStore: PropTypes.bool,
  showSearchResults: PropTypes.bool,
  enableSearchFlag: PropTypes.func,
  location: PropTypes.object,
  fireTealiumAction: PropTypes.func,
  clearSearchedSkuData: PropTypes.func,
  googleMapDirectionUrl: PropTypes.object,
  registryId: PropTypes.string,
  shipToStoreError: PropTypes.array,
  resetReserveItemInStoreError: PropTypes.func,
  miniCartData: PropTypes.object,
  pickupInStoreError: PropTypes.string,
  landingZip: PropTypes.string,
  searchedZip: PropTypes.string,
  setSearchedZip: PropTypes.func,
  createPickUpInStore: PropTypes.bool,
  currentStoreDetails: PropTypes.object,
  eddResponse: PropTypes.object,
  asyncPickUpInStoreModalLoaded: PropTypes.func,
  isEditChecklistModalOpen: PropTypes.bool,
  isBopusEnabled: PropTypes.bool,
  isSetAsMyStore: PropTypes.bool,
  ShouldCheckBoxSelected: PropTypes.func,
  pageIdentifier: PropTypes.string,
  storeCount: PropTypes.any,
  isMobile: PropTypes.bool,
  selectedStore: PropTypes.string,
  updateStateData: PropTypes.func,
  identifier: PropTypes.string,
  isMultiSKU: PropTypes.bool,
  selectedProductMini: PropTypes.object,
  switchConfigGlobal: PropTypes.object,
  clickFromPLPTile: PropTypes.bool,
  resetNearestStoreState: PropTypes.func,
  updateSelectedFilter: PropTypes.func,
};

const defaultProps = {
  clearSearchedSkuData: noop,
  selectedProduct: {},
  resetReserveItemInStoreError: noop,
  landingZip: null,
};

class PickupInStoreModal extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      searchBoxDisplayed: false,
      searchFlag: false,
      registrySearchFlag: false,
      radius: '',
      searchString: '',
      showPickupProcess: false,
      zip: props.searchedZip || props.landingZip, // If the user previously searched and same needs to persist.
      focusLearnMore: false,
      tbsCheck: false,
      showAvailableStores: false,
      useCurrentLocationZip: '',
    };

    this.submitHandler = this.submitHandler.bind(this);
    this.startNewSearchHandler = this.startNewSearchHandler.bind(this);
    this.startNewSearchLinkHandler = this.startNewSearchLinkHandler.bind(this);
    this.onModalClose = this.onModalClose.bind(this);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.returnSearchSubmit = this.returnSearchSubmit.bind(this);
    this.handleShowAvailableStores = this.handleShowAvailableStores.bind(this);
    this.resetshowAvailableStoresCheckbox = this.resetshowAvailableStoresCheckbox.bind(
      this
    );
    this.isBopisFilter = props.findAStoreModal;
  }

  componentDidMount() {
    this.props.asyncPickUpInStoreModalLoaded();
    //  Show search box
    this.startNewSearchLinkHandler();
  }

  componentWillReceiveProps(nextProps) {
    const {
      isPickupInStoreModalOpen,
      showSearchFlag,
      landingZip,
      searchedZip,
    } = nextProps;
    // This check is to revert the view to pickup in store on close of modal.
    if (!isPickupInStoreModalOpen) {
      if (this.state.showPickupProcess) {
        this.goBackToPickup();
      }
      this.startNewSearchHandler();
    }
    if (showSearchFlag) {
      this.setState({
        searchFlag: true,
      });
    }
    if (!this.props.isPickupInStoreModalOpen && isPickupInStoreModalOpen) {
      // Set/Reset the zip when modal is opened, as it could change when modal is open.
      const zip = searchedZip || landingZip;
      if (this.state.zip !== zip) {
        this.setState({
          zip,
        });
      }
      if (isTbs()) {
        this.setState({
          tbsCheck: true,
        });
      }
    }
  }

  onModalClose() {
    const {
      findAStoreModal,
      enableSearchFlag,
      clearSearchedSkuData,
      resetReserveItemInStoreError,
      clickFromPLPTile,
    } = this.props;
    resetReserveItemInStoreError();
    this.setState({
      searchFlag: false,
      registrySearchFlag: false,
    });
    this.props.onModalClose(this.props.isQuickViewOpen || clickFromPLPTile);
    if (findAStoreModal) {
      this.props.clearStoreData();
    }
    clearSearchedSkuData();

    if (enableSearchFlag) {
      enableSearchFlag(false);
    }
  }

  getContentId = () => {
    const { labels, isBopusEnabled } = this.props;
    const storeProcessDetails = isBopusEnabled
      ? 'bookOnlinePickupProcessDetails'
      : 'pickUpInStoreProcessDetails';
    return (
      labels.referredContent &&
      this.props.labels.referredContent.filter(content => {
        return content.key === storeProcessDetails;
      })[0].id
    );
  };

  setRegistrySearchFlag = flag => {
    this.setState({
      registrySearchFlag: flag,
    });
  };

  resetshowAvailableStoresCheckbox = () => {
    this.setState({
      showAvailableStores: false,
    });
  };

  handleBackButtonClick(e) {
    e.preventDefault();
    // On clicking of back button reset the searchFlag state
    this.setState({
      searchFlag: false,
      registrySearchFlag: false,
    });
    // Closing find in store modal and removing pickupInStore data from store
    this.props.onModalClose();
  }

  handleShowAvailableStores = selected => {
    this.setState(() => ({
      showAvailableStores: selected,
    }));
  };

  goBackToPickup = e => {
    if (e) e.preventDefault();
    this.setState({
      showPickupProcess: false,
      focusLearnMore: true,
    });
  };

  goToPickupProcess = e => {
    e.preventDefault();
    const { fetchPickupProcessData } = this.props;
    const contentId = this.getContentId();
    fetchPickupProcessData([contentId]);
    this.setState({
      showPickupProcess: true,
    });
  };

  submitHandler(args) {
    const address = args.address;
    const query =
      args.latitude && /^\d{5}-\d{4}$/.test(address)
        ? address.substring(0, 5)
        : address;
    this.setState({
      searchFlag: true,
      searchString: args.latitude
        ? LabelsUtil.getLabel(this.props.labels, 'yourCurrentLocation')
        : query,
      radius: args.radius,
      zip: null, // To prevent start new search trigerring a search when SearchStore is mounted.
      tbsCheck: false,
      useCurrentLocationZip: args.latitude ? query : '',
    });
    const updatedData = {
      identifier: this.props.identifier || 'SearchStore',
      searchField: {
        value: query,
      },
      radiusField: { value: args.radius },
    };
    // Don't call onSearchSubmit in case of ChangeStore
    if (!this.props.findAStoreModal) this.props.onSearchSubmit(args);
    if (this.props.findAStoreModal && args.address)
      this.props.updateStateData(updatedData);
    if (this.props.setSearchedZip && args.newSearch) {
      const { selectedProduct, setSearchedZip } = this.props;
      setSearchedZip(selectedProduct.viewType, query);
    }
  }

  startNewSearchHandler(e) {
    const {
      findAStoreModal,
      resetReserveItemInStoreError,
      clearSearchedSkuData,
    } = this.props;
    if (e) e.preventDefault();
    this.setState({
      searchFlag: false,
      registrySearchFlag: false,
    });
    if (this.props.enableSearchFlag) {
      this.props.enableSearchFlag(false);
    }
    resetReserveItemInStoreError();
    clearSearchedSkuData();
    if (findAStoreModal) {
      this.props.clearStoreData();
    }
  }

  startNewSearchLinkHandler(e) {
    if (e) e.preventDefault();
    this.setState({
      searchBoxDisplayed: !this.state.searchBoxDisplayed,
    });
  }

  returnSearchSubmit() {
    const { findAStoreModal } = this.props;
    if (findAStoreModal) {
      return this.submitRegistryHandler;
    }
    return this.submitHandler;
  }

  fallback = () => {
    return (
      <ModalDialog
        titleAriaLabel="TitleText"
        toggleModalState={this.onModalClose}
        variation="small"
        verticallyCenter
        mountedState={this.props.isPickupInStoreModalOpen}
        onModalClose={this.onModalClose}
      >
        <Error />
      </ModalDialog>
    );
  };

  renderLearnMore(findAStoreModal, labels) {
    const { focusLearnMore } = this.state;
    const LinkType = focusLearnMore ? FocusableLink : PrimaryLink;
    return (
      !findAStoreModal && (
        <LinkType
          role="button"
          href="#"
          variation="primary"
          type="bold"
          onClick={this.goToPickupProcess}
        >
          {LabelsUtil.getLabel(labels, 'reserveOnlineLearnMore')}
        </LinkType>
      )
    );
  }

  renderPlacehodlers = () => {
    const { findAStoreModal } = this.props;
    if (findAStoreModal) {
      return (
        <React.Fragment>
          <div id="lodingstores" />
          <div id="renderListing" />
        </React.Fragment>
      );
    }
    return null;
  };

  // eslint-disable-next-line complexity
  render() {
    const {
      deviceConfig,
      labels,
      selectedProduct,
      scene7UrlConfig,
      storeList,
      isStoreListFetching,
      selectedSKUId,
      isErrorMsg,
      distanceMap,
      handleReserveNow,
      findAStoreModal,
      showSearchResults,
      location,
      fireTealiumAction,
      googleMapDirectionUrl,
      registryId,
      shipToStoreError,
      miniCartData,
      pickupInStoreError,
      changeStore,
      createPickUpInStore,
      currentStoreDetails,
      eddResponse,
      isBopusEnabled,
      isSetAsMyStore,
      selectedStore,
      ShouldCheckBoxSelected,
      pageIdentifier,
      storeCount,
      isMobile,
      isMultiSKU,
      selectedProductMini,
      switchConfigGlobal,
      clickFromPLPTile,
      resetNearestStoreState,
      updateSelectedFilter,
    } = this.props;
    const { showPickupProcess, tbsCheck } = this.state;
    const isFilterVisible = false;
    const isPickupInStore = true;
    const HeadingText = dangerousHTML(Heading);
    const newlyCreatedCart = !!(
      (miniCartData === null && getCookie('cartCount') === '0') ||
      (miniCartData &&
        miniCartData.atgResponse &&
        miniCartData.atgResponse.Cart &&
        miniCartData.atgResponse.Cart.cartItemCount &&
        miniCartData.atgResponse.Cart.cartItemCount === '0')
    );
    const contentData = pathOr('', 'referredContent.content', this.props);
    const iconProps = {
      type: 'caret',
      width: '8px',
      height: '8px',
      className: 'iconArrowLeft',
      focusable: 'false',
    };
    let displayBackBtn = false;
    const viewType = pathOr('', 'selectedProduct.viewType', this.props);
    if (viewType === 'quickView') {
      displayBackBtn = true;
    }
    const isWarrantyDisplayed = pathOr(
      false,
      'selectedProduct.isWarrantyDisplayed',
      this.props
    );
    const DangerousHTMLContainer = dangerousHTML(props => <span {...props} />);
    const pickUpStoreHeading = isMobile
      ? 'pickUpStoreHeadingMob'
      : 'pickUpStoreHeading';
    const selectedSkuId = selectedProductMini && selectedProductMini.SKU_ID;
    const selectedSku = pathOr('', 'selectedSKU.skuId', this.props);
    let ProductDetails = null;
    if (!findAStoreModal) {
      if (isMultiSKU && this.props.clickFromPLPTile)
        ProductDetails = (
          <MiniQuickViewModal
            selectedSkuId={selectedSkuId}
            miniQuickViewModal
            switchConfigGlobal={switchConfigGlobal}
            {...this.props}
            selectedProduct={selectedProductMini}
            clickFromPLPTile={clickFromPLPTile}
          />
        );
      else
        ProductDetails = (
          <PickupProductTile
            labels={labels}
            {...selectedProduct}
            {...scene7UrlConfig}
          />
        );
    }
    // eslint-disable-next-line complexity
    const RenderModalWithSearchStores = () => {
      if (!showPickupProcess)
        return (
          <div className={classnames(styles.pickupInStore)}>
            {isWarrantyDisplayed && (
              <Notification
                type="alert"
                theme="filled"
                className={classnames(styles.reducePadding)}
                showStatusIcon
              >
                <DangerousHTMLContainer>
                  {LabelsUtil.getLabel(labels, 'ropisWrrantyAlert')}
                </DangerousHTMLContainer>
              </Notification>
            )}
            <GridX className="large-12 small-12">
              <Cell className={classnames('large-12')}>
                {displayBackBtn ? (
                  <PrimaryLink
                    href="#"
                    className={styles.cancelLink}
                    iconProps={iconProps}
                    isIconAfterContent={false}
                    onClick={this.handleBackButtonClick}
                  >
                    {LabelsUtil.getLabel(labels, 'findInStoreBackBtn')}
                  </PrimaryLink>
                ) : null}
                {!this.state.registrySearchFlag && (
                  <HeadingText
                    level={2}
                    className={styles.heading}
                    data-locator={
                      findAStoreModal
                        ? 'selectAStoreHeading'
                        : 'pickUpStoreHeading'
                    }
                  >
                    {LabelsUtil.getLabel(
                      labels,
                      findAStoreModal ? 'findAStoreTitle' : pickUpStoreHeading
                    )}
                  </HeadingText>
                )}
              </Cell>
            </GridX>
            {!isMultiSKU && ProductDetails}
            <ErrorNotification className="mt0" errors={isErrorMsg} />
            {Array.isArray(shipToStoreError) &&
              shipToStoreError.length > 0 && (
                <FocusableNotification
                  className={classnames(styles.reducePadding)}
                  theme="filled"
                  type="error"
                  showStatusIcon
                >
                  {LabelsUtil.getLabel(labels, 'ropisErrorMessage')}
                </FocusableNotification>
              )}
            {pickupInStoreError && (
              <Paragraph className="validationErrorMessage">
                {pickupInStoreError}
              </Paragraph>
            )}
            <div
              className={classnames(styles.startNewDiv, 'pb2 mb2', {
                [styles.divBorder]: true,
              })}
            >
              <div>
                <PrimaryLink
                  role="button"
                  href="#"
                  onClick={this.startNewSearchLinkHandler}
                  variation="primary"
                  className={styles.searchLink}
                  data-locator="changeLocationCTA"
                >
                  {LabelsUtil.getLabel(labels, 'startNewSearchLabel')}
                  <Icon
                    className={classnames(
                      this.state.searchBoxDisplayed ? styles.expandSVGIcon : ''
                    )}
                    type="caret"
                    width="12px"
                    height="12px"
                  />
                </PrimaryLink>
              </div>
              <div>
                <Icon type="locations" width="16px" height="16px" />
                <span className={classnames(styles.searchString)}>
                  &nbsp;{this.state.useCurrentLocationZip ||
                    this.state.searchString}
                </span>
              </div>
            </div>
            <div
              className={classnames(
                styles.divBorder,
                'mb2',
                !this.state.searchBoxDisplayed && 'hide'
              )}
            >
              <SearchStores
                isFilterVisible={isFilterVisible}
                isPickupInStore={isPickupInStore}
                onSearchSubmit={this.submitHandler}
                registrySearchFlag={this.state.registrySearchFlag}
                setFavoriteStoreId={this.props.setFavoriteStoreId}
                setStoreDetails={this.props.setStoreDetails}
                isEditRegistryModalOpen={
                  this.props.isEditRegistryModalOpen ||
                  this.props.isEditChecklistModalOpen
                }
                startNewSearchHandler={this.startNewSearchHandler}
                closeModal={this.onModalClose}
                selectedSKUId={
                  isMultiSKU
                    ? selectedSku
                    : (selectedProduct && selectedProduct.SKU_ID) ||
                      selectedSKUId
                }
                findAStoreModal={findAStoreModal}
                showSearchResults={showSearchResults}
                quantity={selectedProduct.QUANTITY}
                tealiumFindStoreSearchData={selectedProduct}
                tealiumPathName={location}
                isQuickViewOpen={this.props.isQuickViewOpen}
                landingZip={this.state.zip}
                changeStore={changeStore}
                createPickUpInStore={createPickUpInStore}
                currentStoreDetails={currentStoreDetails}
                tbsCheck={tbsCheck}
                resetshowAvailableStores={this.resetshowAvailableStoresCheckbox}
                isBopisFilter={this.isBopisFilter}
                isSetAsMyStore={isSetAsMyStore}
                selectedStore={selectedStore}
                ShouldCheckBoxSelected={ShouldCheckBoxSelected}
                storeCount={storeCount}
                pageIdentifier={pageIdentifier}
                identifier={this.props.identifier}
                clickFromPLPTile={clickFromPLPTile}
                resetNearestStoreState={resetNearestStoreState}
                updateSelectedFilter={updateSelectedFilter}
              />
            </div>
            {this.renderPlacehodlers()}
            {!findAStoreModal && (
              <SkuSearchStoreDetails
                storeList={storeList}
                isFetching={isStoreListFetching}
                startNewSearchHandler={this.startNewSearchHandler}
                searchString={this.state.searchString}
                radius={this.state.radius}
                labels={labels}
                isErrorMsg={isErrorMsg}
                distanceMap={distanceMap}
                deviceConfig={deviceConfig}
                skuId={
                  isMultiSKU ? selectedSku : (selectedProduct || {}).SKU_ID
                }
                productId={(selectedProduct || {}).PRODUCT_ID}
                closeModal={this.onModalClose}
                handleReserveNow={handleReserveNow}
                selectedProduct={selectedProduct}
                findAStoreModal={findAStoreModal}
                location={location}
                fireTealiumAction={fireTealiumAction}
                newlyCreatedCart={newlyCreatedCart}
                googleMapDirectionUrl={googleMapDirectionUrl}
                registryId={registryId}
                shipToStoreError={shipToStoreError}
                createPickUpInStore={createPickUpInStore}
                eddResponse={eddResponse}
                isBopusEnabled={isBopusEnabled}
                showAvailableStores={this.state.showAvailableStores}
                handleShowAvailableStores={this.handleShowAvailableStores}
                setStoreDetails={this.props.setStoreDetails}
                ShouldCheckBoxSelected={ShouldCheckBoxSelected}
                storeCount={storeCount}
                pageIdentifier={pageIdentifier}
                isSetAsMyStore={isSetAsMyStore}
                selectedStore={selectedStore}
                resetNearestStoreState={resetNearestStoreState}
                updateSelectedFilter={updateSelectedFilter}
              />
            )}
          </div>
        );
      return (
        <GridX className="large-12 small-12 mb2" id="pickupProcessDetails">
          <Cell className={classnames('large-12')}>
            <FocusableLink
              role="button"
              href="#"
              variation="primary"
              type="bold"
              onClick={this.goBackToPickup}
              iconProps={{
                type: 'caret',
                className: 'iconArrowLeft',
                height: '9px',
                width: '9px',
              }}
            >
              {LabelsUtil.getLabel(labels, 'modalBackButton')}
            </FocusableLink>
          </Cell>

          {contentData && (
            <Cell className={classnames('large-12', styles.pickupProcess)}>
              <ContentBox
                data={contentData}
                params={{
                  id: this.getContentId(),
                }}
              />
            </Cell>
          )}
        </GridX>
      );
    };

    const renderWithNearByStoresABTest = () => {
      return (
        <React.Fragment>
          {ProductDetails}
          {selectedSku && RenderModalWithSearchStores()}
        </React.Fragment>
      );
    };
    return (
      <ErrorBoundary fallback={this.fallback()}>
        {this.props.clickFromPLPTile && isMultiSKU
          ? renderWithNearByStoresABTest()
          : RenderModalWithSearchStores()}
      </ErrorBoundary>
    );
  }
}

PickupInStoreModal.propTypes = propTypes;
PickupInStoreModal.defaultProps = defaultProps;

export default PickupInStoreModal;
