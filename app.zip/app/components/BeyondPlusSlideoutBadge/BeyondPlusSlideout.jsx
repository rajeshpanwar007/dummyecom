import React, { useState, useRef, useEffect } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import _merge from 'lodash/merge';
import { debounce } from 'lodash';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import CommonUtil from '@bbb-app/utils/commonUtil';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import IconButton from '@bbb-app/core-ui/icon-button';
import Img from '@bbb-app/core-ui/image';
import Icon from '@bbb-app/core-ui/icon';
import primeStyles from '@bbb-app/core-ui/primary-link/PrimaryLink.css';
import '@bbb-app/assets/icons/CloseIcon.svg';
import styles from './BeyondPlusSlideout.css';

const BeyondPlusSlideout = props => {
  const isMobile = CommonUtil.isMobileScreen(1024);
  const { content, setStorageState, profile, setUserSliderClosed } = props;
  const [scrolling, setScrolling] = useState(false);
  const isEventAdded = useRef(false);
  useEffect(
    () => {
      const onScroll = debounce(() => setScrolling(true), 40);
      if (!isEventAdded.current) {
        isEventAdded.current = true;
        return window.addEventListener('scroll', onScroll);
      }
      if (scrolling && isEventAdded.current) {
        isEventAdded.current = false;
        return window.removeEventListener('scroll', onScroll);
      }
      return () => {
        window.removeEventListener('scroll', onScroll);
      };
    },
    [scrolling]
  );

  const handleSlideoutBadge = () => {
    const expiryDays = pathOr(60, 'field_content_validity_in_days', content);
    setUserSliderClosed(true);
    setScrolling(false);
    setStorageState(expiryDays);
  };
  const getContentFields = () => {
    let contentProps = {};
    if (content) {
      contentProps = {
        ctaType: pathOr('', 'field_cta_type_desk', content),
        fieldDescription: pathOr('', 'field_description_desktop', content),
        fieldHeading: pathOr('', 'field_heading_desktop', content),
        profileName: pathOr('', 'firstName', profile),
        ctaUrl: pathOr('', 'desktopCTA.url', content),
        ctaDisplayName: pathOr('', 'desktopCTA.displayName', content),
        bPlusImage: pathOr('', 'image.url', content),
        bPlusAltText: pathOr('', 'image.alt', content),
        contentValidity: pathOr('', 'field_content_validity_in_days', content),
      };
      if (isMobile) {
        return _merge(contentProps, {
          ctaType: pathOr('', 'field_cta_type_mob', content),
          fieldDescription: pathOr('', 'field_description_mobile', content),
          fieldHeading: pathOr('', 'field_heading_mobile', content),
          ctaUrl: pathOr('', 'mobileCTA.url', content),
          ctaDisplayName: pathOr('', 'mobileCTA.displayName', content),
        });
      }
    }
    return contentProps;
  };

  const {
    fieldDescription,
    fieldHeading,
    ctaType,
    ctaUrl,
    ctaDisplayName,
    bPlusImage,
    bPlusAltText,
    profileName,
  } = getContentFields();

  const isLink = ctaType && ctaType.includes('link');
  const closeButton = (
    <IconButton
      onClick={handleSlideoutBadge}
      className={classNames(styles.closeButton, 'absolute', 'pr0')}
    >
      <Icon type="CloseIcon" width="16px" height="16px" />
    </IconButton>
  );
  const DangerousParagraph = dangerousHTML(Paragraph);
  return (
    scrolling && (
      <GridContainer>
        <GridX className={styles.plabActive}>
          <div className={styles.slideOutWrapper}>{closeButton}</div>
          <Cell
            className={classNames(styles.plabFlexcont, 'flex justify-between')}
          >
            <Cell
              className={classNames(styles.plabImgcont, 'flex justify-center')}
            >
              <Img src={bPlusImage} alt={bPlusAltText} />
            </Cell>
            <Cell
              className={classNames(styles.plabTextcont, 'flex justify-center')}
            >
              <Heading level={3} className={styles.plabHeading}>
                {!isMobile &&
                  profileName && (
                    <span
                      className={styles.profileName}
                    >{`${profileName}, `}</span>
                  )}
                <span>{fieldHeading}</span>
              </Heading>
              <DangerousParagraph className={styles.plabDesc}>
                {fieldDescription}
              </DangerousParagraph>
              <Button
                theme={isLink ? 'ghost' : 'primary'}
                onClick={handleSlideoutBadge}
                className={classNames({
                  [styles.plabButton]: isLink,
                  [primeStyles.primaryWithArrow]: isLink,
                })}
                href={ctaUrl}
                isIconAfterContent={isLink}
                iconProps={
                  isLink
                    ? {
                        type: 'arrow',
                        width: '20px',
                        height: '20px',
                      }
                    : null
                }
                variation={isLink ? '' : 'fullWidth'}
              >
                {ctaDisplayName}
              </Button>
            </Cell>
          </Cell>
        </GridX>
      </GridContainer>
    )
  );
};

BeyondPlusSlideout.propTypes = {
  content: PropTypes.object,
};

export default BeyondPlusSlideout;
