export { default } from './RelatedSearchTopicsComponent';
