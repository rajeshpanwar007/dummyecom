export const IDEABOARD_RELATED_CATEGORIES_HEADING =
  'ibdetail-ideaboardrelatedcategoriesheading';
export const IDEABOARD_RELATED_CATEGORIES_ITEM_LINK =
  'ibdetail-ideaboardrelatedcategoriesitemlink';
