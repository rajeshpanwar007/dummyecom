import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Heading from '@bbb-app/core-ui/heading';
import sanitizeSearchTerm from '@bbb-app/utils/sanitizeSearchTerm';
import GridContainer from '@bbb-app/core-ui/grid-container';
import consoleLog from '@bbb-app/utils/logger';
import LinkButton from '@bbb-app/core-ui/link-button';
import { PLP_IDENTIFIER_KEY } from '@bbb-app/constants/experienceConstants';
import styles from './RelatedSearchTopicsComponent.css';
import {
  IDEABOARD_RELATED_CATEGORIES_HEADING,
  IDEABOARD_RELATED_CATEGORIES_ITEM_LINK,
} from './dataLocators';
import {
  RELATED_CATEGORIES_CLICK_TEALIUM_ACTION,
  TEALIUM_PAGE_INFO,
  RELATED_CATEGORIES_CLICK_PAGENAME_BREADCRUMB,
} from '../../containers/ThirdParty/Tealium/Ideaboard/RelatedCategoriesTealiumHandler/constants';

// eslint-disable-next-line react/prefer-stateless-function

class RelatedSearchTopicsComponent extends React.PureComponent {
  static propTypes = {
    contextPath: PropTypes.string.isRequired,
    headingLocator: PropTypes.string,
    linkLocator: PropTypes.string,
    fireTealiumAction: PropTypes.func,
    pageName: PropTypes.string,
    relatedSearchTerms: PropTypes.array,
    isBrandPage: PropTypes.bool,
    relatedSearchTopicsData: PropTypes.object,
    routeParams: PropTypes.object,
    relatedSearchKeywords: PropTypes.array,
    enableRelatedSearches: PropTypes.bool,
  };
  static defaultProps = {
    headingLocator: IDEABOARD_RELATED_CATEGORIES_HEADING,
    linkLocator: IDEABOARD_RELATED_CATEGORIES_ITEM_LINK,
  };
  constructor(props) {
    super(props);
    this.tealiumRelatedCategoriesClickHandler = this.tealiumRelatedCategoriesClickHandler.bind(
      this
    );
  }

  createParentPageName = () => {
    let pageNameBreadcrumb = '';
    if (this.props.routeParams && this.props.routeParams.params) {
      const { level1, level2, level3 } = this.props.routeParams.params;
      if (level1 && level2 && level3) {
        pageNameBreadcrumb = `${level1}>${level2}>${level3}`;
      } else if (level1 && level2 && !level3) {
        pageNameBreadcrumb = `${level1}>${level2}>All`;
      } else if (level1 && !level2 && !level3) {
        pageNameBreadcrumb = `${level1}`;
      }
      return pageNameBreadcrumb;
    }
    return 'Category';
  };

  relatedCategoriesTealiumInfo = categoryName => {
    const parentPageName = this.createParentPageName();
    const catName = categoryName ? categoryName.toLowerCase() : '';
    const tealiumTags = {
      event_breadcrumb: `${parentPageName}>related categories>${catName}`,
      pagename_breadcrumb: RELATED_CATEGORIES_CLICK_PAGENAME_BREADCRUMB,
    };
    return Object.assign({}, tealiumTags);
  };
  tealiumRelatedCategoriesClickHandler = categoryName => {
    const relatedCategoriesTealiumPayload = this.relatedCategoriesTealiumInfo(
      categoryName
    );
    this.props.fireTealiumAction(
      RELATED_CATEGORIES_CLICK_TEALIUM_ACTION,
      relatedCategoriesTealiumPayload,
      TEALIUM_PAGE_INFO
    );
  };
  render() {
    try {
      const {
        contextPath,
        headingLocator,
        linkLocator,
        pageName,
        isBrandPage,
        relatedSearchTopicsData,
        relatedSearchKeywords,
        enableRelatedSearches,
      } = this.props;
      let list = [];
      let { relatedSearchTerms } = this.props;
      relatedSearchTerms = enableRelatedSearches
        ? relatedSearchKeywords
        : relatedSearchTerms;
      // Check for PLP and brand page
      const enableRelatedSearchTopics = !!(
        (isBrandPage &&
          relatedSearchTopicsData &&
          relatedSearchTopicsData.enableBrandRelatedSearchTopics) ||
        (relatedSearchTopicsData &&
          relatedSearchTopicsData.enableCategoryRelatedSearchTopics &&
          pageName === PLP_IDENTIFIER_KEY)
      );
      const isRelatedSearchTerm = !!(
        Array.isArray(relatedSearchTerms) && relatedSearchTerms.length > 0
      );
      if (
        enableRelatedSearchTopics &&
        isRelatedSearchTerm &&
        relatedSearchTopicsData.maxRelatedSearchTopics
      ) {
        const maxRelatedSearchTopicsInt = parseInt(
          relatedSearchTopicsData.maxRelatedSearchTopics,
          10
        );
        let relatedSearchTermsArray = relatedSearchTerms;
        // Splitting the string consisting of comma seprated related searches value into an array
        if (
          relatedSearchTerms.length === 1 &&
          relatedSearchTerms[0].indexOf(',') !== -1
        ) {
          relatedSearchTermsArray = relatedSearchTerms[0].split(',');
        }
        // Filter out the required number of related search terms
        const searchTermsFilteredArray = relatedSearchTermsArray.slice(
          0,
          maxRelatedSearchTopicsInt
        );
        list = searchTermsFilteredArray.map(item => {
          // Removes invalid characters from search term
          const searchTerm = sanitizeSearchTerm(item);
          return {
            categoryName: item,
            seoURL: `/s/${searchTerm}`,
          };
        });
        if (list && list[0]) {
          return (
            <GridContainer className={classnames('pt3')}>
              <Heading
                level={2}
                className={classnames(styles.Title, 'center', 'mb3')}
                data-locator={headingLocator}
              >
                {relatedSearchTopicsData.headerLabel}
              </Heading>
              <div className={classnames(styles.boardsList, 'center')}>
                {list.map((item, index) => {
                  let onClickProp = {};
                  if (pageName === PLP_IDENTIFIER_KEY) {
                    onClickProp = {
                      onClick: () =>
                        this.tealiumRelatedCategoriesClickHandler(
                          item.categoryName
                        ),
                    };
                  }
                  return (
                    <LinkButton
                      href={`${contextPath}${item.seoURL}`}
                      theme="tiles"
                      className={classnames('mx1', 'mb1')}
                      data-locator={linkLocator}
                      key={`${item.categoryName}-${index}`}
                      {...onClickProp}
                    >
                      {item.categoryName}
                    </LinkButton>
                  );
                })}
              </div>
            </GridContainer>
          );
        }
      }
    } catch (e) {
      consoleLog.error(e);
    }
    return null;
  }
}

export default RelatedSearchTopicsComponent;
