import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { getOr } from 'lodash/fp';
import { matchPath } from 'react-router';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { isEmpty } from 'lodash';
import {
  makeSelectSwitchConfig,
  selectContextPath,
} from '@bbb-app/selectors/configSelector';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { windowScroll, isMobileDevice, isBrowser } from '@bbb-app/utils/common';
import toJS from '@bbb-app/hoc/toJS';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import { LocalStorageUtil } from '@bbb-app/utils/localStorage';
import { SessionStorageUtil } from '@bbb-app/utils/sessionStorage';
import Icon from '@bbb-app/core-ui/icon';
import LinkButton from '@bbb-app/core-ui/link-button';
import injectReducer from '@bbb-app/hoc/injectReducer';
import injectSaga from '@bbb-app/hoc/injectSaga';
import { fetchRecentlyViewed } from '@bbb-app/recently-viewed/containers/actions';
import { makeSelectProductDetails } from '@bbb-app/recently-viewed/containers/selectors';
import recentlyViewedReducer from '@bbb-app/recently-viewed/containers/reducer';
import recentlyViewedSaga from '@bbb-app/recently-viewed/containers/sagas';
import { RECENTLY_VIEWED_STATE_KEY as recentlyViewedStateKey } from '@bbb-app/recently-viewed/containers/constants';
import { makeSelectRegistryFooterVisible } from '../../containers/RegistryFooter/RegistryFooterSelector';
import {
  makeSelectRenderWelMatStickyFooter,
  makeSelectLabels,
} from '../../containers/WelcomeMatStickyFooter/selectors';
import '../../assets/icons/ellipsis.svg';
import styles from './RecentlyViewedStickyFooter.css';
import {
  RECENTLY_VIEWED_SS_KEY,
  HIDE_STICKY_FOOTER,
  ROUTE_PDP,
  stickyFooterPages,
} from './constants';

export class RecentlyViewedStickyFooter extends React.PureComponent {
  constructor(props) {
    super(props);
    this.setClientTrue = this.setClientTrue.bind(this);
    this.state = {
      isClient: false,
      productIds: [],
    };
  }
  componentDidMount() {
    this.setClientTrue();
    if (!isMobileDevice.iPad() && !isInternationalUser()) {
      const storageUtil = new LocalStorageUtil(isBrowser());
      const productIds = storageUtil.getItem(RECENTLY_VIEWED_SS_KEY);
      if (productIds) {
        this.props.onComponentMount(productIds);
      }
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.data === prevProps.data || !prevProps.data) {
      const storageUtil = new LocalStorageUtil(isBrowser());
      const productIds = storageUtil.getItem(RECENTLY_VIEWED_SS_KEY);
      const productArray = !isEmpty(productIds)
        ? productIds.split(',', 12)
        : null;
      if (productArray && productArray.length > this.state.productIds.length) {
        this.storeProductIds(productArray);
        this.props.onComponentMount(productIds);
      }
    }
  }

  componentWillUnmount() {
    window.onbeforeunload = () => {
      localStorage.removeItem(HIDE_STICKY_FOOTER);
    };
  }

  setClientTrue() {
    this.setState({ isClient: true });
  }

  storeProductIds(productIds) {
    this.setState({ productIds });
  }

  closePanels = () => {
    const sessionUtil = new SessionStorageUtil(true);
    sessionUtil.saveItem('hideStickyFooter', true);
    windowScroll.enable(false);
  };

  renderProductTile = items => {
    const { contextPath, track } = this.props;
    const productTileContainer =
      items &&
      items.map((item, index) => {
        const finalSrc = getConcatenatedScene7URLWithImageId(
          item.SCENE7_URL,
          'StickyFooterImages',
          '140'
        );
        return index <= 11 ? (
          <LinkButton
            onClick={() => track('recentlyProduct_SS')}
            href={`${contextPath + item.SEO_URL}`}
            className={classnames(styles.panelColor, styles.imageWrapper)}
            theme="tabDark"
          >
            <img
              className={classnames(styles.imageContainer)}
              alt={item.DISPLAY_NAME}
              src={finalSrc}
            />
          </LinkButton>
        ) : null;
      });
    return productTileContainer;
  };

  renderThreeColumnLayout = filteredData => {
    const { labels } = this.props;
    let stickyFooterLabel = LabelsUtil.getLabel(
      labels,
      'recentlyStickyFooterTitle'
    );
    if (stickyFooterLabel === 'recentlyStickyFooterTitle') {
      stickyFooterLabel = 'Recently Viewed';
    }
    return (
      <ul className={classnames(styles.tabList, styles.topBorder)}>
        <li className={styles.tabLi}>
          <div
            className={classnames(styles.titlePanel, styles.panelColor)}
            href={false}
            theme="tabDark"
          >
            <span className={styles.linkLabel}>{stickyFooterLabel}</span>
          </div>
        </li>
        <li className={styles.contentTabLi}>
          <div className={styles.tileContainer}>
            {this.renderProductTile(filteredData)}
          </div>
        </li>
        <li className={styles.closeLink}>
          <LinkButton
            onClick={this.closePanels}
            className={classnames(styles.link, styles.linkOverlay)}
            href={false}
            theme="tabDark"
          >
            <div className={styles.closeIconContainer}>
              <span className={styles.closeItemImg}>
                <Icon
                  height="17px"
                  width="16px"
                  type={'close'}
                  className={styles.experimentIcon}
                />
              </span>
            </div>
          </LinkButton>
        </li>
      </ul>
    );
  };

  render() {
    const {
      isRegistryFooterVisible,
      pageIdentifier,
      enableStckyFooter,
      renderWelMatStickyFooter,
      data,
    } = this.props;

    if (
      !isRegistryFooterVisible &&
      !renderWelMatStickyFooter &&
      this.state.isClient
    ) {
      if (
        !isMobileDevice.iPad() &&
        !isInternationalUser() &&
        stickyFooterPages.includes(pageIdentifier) &&
        enableStckyFooter
      ) {
        /* eslint-disable no-nested-ternary */
        const dataForGrid =
          data instanceof Array ? data : data instanceof Object ? [data] : [];
        const sessionUtil = new SessionStorageUtil(true);
        if (
          !isEmpty(dataForGrid) &&
          !dataForGrid[0].response &&
          !sessionUtil.getItem(HIDE_STICKY_FOOTER)
        ) {
          const defaultPathname = getOr(
            '',
            'locationBeforeTransitions.pathname',
            this.props.routeData
          );
          const pathname = getOr(
            defaultPathname,
            'locationBeforeTransitions.location.pathname',
            this.props.routeData
          );
          const matched = matchPath(pathname, ROUTE_PDP, { exact: true });
          const productId = getOr('__', 'params.productId', matched);
          const filteredData = dataForGrid.filter(item => {
            return item.PRODUCT_ID !== productId;
          });
          if (!isEmpty(filteredData)) {
            return (
              <div className={classnames(styles.experimentStickyFooter)}>
                {this.renderThreeColumnLayout(filteredData)}
              </div>
            );
          }
        }
      }
    }
    return null;
  }
}

RecentlyViewedStickyFooter.propTypes = {
  isRegistryFooterVisible: PropTypes.bool,
  track: PropTypes.func,
  pageIdentifier: PropTypes.string,
  labels: PropTypes.object,
  renderWelMatStickyFooter: PropTypes.bool,
  enableStckyFooter: PropTypes.bool,
  onComponentMount: PropTypes.func,
  data: PropTypes.object,
  contextPath: PropTypes.string,
  routeData: PropTypes.object,
};

export const mapStateToProps = createStructuredSelector({
  isRegistryFooterVisible: makeSelectRegistryFooterVisible(),
  renderWelMatStickyFooter: makeSelectRenderWelMatStickyFooter(),
  data: makeSelectProductDetails(),
  contextPath: selectContextPath,
  labels: makeSelectLabels(),
  enableStckyFooter: makeSelectSwitchConfig([
    'mobile',
    'enableRecentlyViewedStickyFooter',
  ]),
});

export const mapDispatchToProps = dispatch => ({
  onComponentMount(productIds) {
    dispatch(fetchRecentlyViewed(productIds));
  },
});

const withConnect = connect(mapStateToProps, mapDispatchToProps);
const withRecentlyViewedReducer = injectReducer({
  key: recentlyViewedStateKey,
  reducer: recentlyViewedReducer,
});
const withRecentlyViewedSaga = injectSaga({
  key: recentlyViewedStateKey,
  saga: recentlyViewedSaga,
});

export default compose(
  withRecentlyViewedReducer,
  withRecentlyViewedSaga,
  withConnect
)(toJS(RecentlyViewedStickyFooter));
