/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';

import { options } from '@bbb-app/universal-component/options';

const RecentlyViewedStickyFooterAsync = universal(
  import(/* webpackChunkName: "Recently-Viewed-Sticky-Footer" */ './RecentlyViewedStickyFooter'),
  options
);

export default RecentlyViewedStickyFooterAsync;
/* eslint-enable extra-rules/no-commented-out-code */
