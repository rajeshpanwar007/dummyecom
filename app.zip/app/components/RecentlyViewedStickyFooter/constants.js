export const MORE_KEY = 'more';
export const RECENTLY_VIEWED_SS_KEY = 'recentlyViewed';
export const HIDE_STICKY_FOOTER = 'hideStickyFooter';
export const ROUTE_PDP = '/store/product/:productName/:productId';
export const stickyFooterPages = [
  'HOMEPAGE',
  'PLP',
  'CLP',
  'PDP',
  'BrandLanding',
  'SearchResults',
  'compare',
  'IdeaboardLandingPage',
];
