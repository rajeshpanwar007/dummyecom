import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { isEmpty } from 'lodash';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Carousel from '@bbb-app/carousel/CustomCarousel';
import styles from './PBar.css';
import PersonalOrders from '../../containers/PersonalizationBar/PersonalOrders/PersonalOrders';
import PersonalBeyondPlus from '../../containers/PersonalizationBar/PersonalBeyondPlus/PersonalBeyondPlus';
import PersonalFavStore from '../../containers/PersonalizationBar/PersonalFavStore/PersonalFavStore';
import PersonalIdeaBoard from '../../containers/PersonalizationBar/PersonalIdeaBoard/PersonalIdeaBoard';
import PersonalOffers from '../../containers/PersonalizationBar/PersonalOffers/PersonalOffers';
import PersonalRegistry from '../../containers/PersonalizationBar/PersonalRegistry/PersonalRegistry';
import PersonalMyFunds from '../../containers/PersonalizationBar/PersonalMyFunds/PersonalMyFunds';
import '../../assets/icons/beyondPlusBlack.svg';
import {
  ORDERS,
  BEYOND_PLUS,
  FAV_STORE,
  IDEABOARD,
  OFFERS,
  MY_FUNDS,
  REGISTRY,
} from './constants';

class PBar extends React.PureComponent {
  static propTypes = {
    labels: PropTypes.object,
    profile: PropTypes.object,
    pBarData: PropTypes.array,
    pBarTileData: PropTypes.object,
    isLoggedIn: PropTypes.bool,
    registryData: PropTypes.object,
    bpData: PropTypes.object,
    fireTealiumAction: PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.pBarLabels = {
      welcomeText: LabelsUtil.getLabel(props.labels, 'welcomeText'),
    };
    this.state = {
      isOpen: '',
      toOpen: '',
    };
  }
  featureTileCreation = pBarData => {
    const { bpData, registryData, pBarTileData } = this.props;
    if (pBarData && pBarData.length > 0 && pBarTileData) {
      const featureTiles = pBarData.map(tileData => {
        if (
          tileData.name === 'REGISTRY' &&
          (!registryData || isEmpty(registryData))
        ) {
          return null;
        } else if (
          tileData.name === 'BEYOND_PLUS' &&
          bpData &&
          bpData.bPStatus === 'R'
        ) {
          return null;
        }
        return (
          <div
            key={tileData.name}
            className={classNames(
              'large-12',
              'small-12',
              styles.individualTile
            )}
          >
            {tileData.name === REGISTRY && (
              <PersonalRegistry
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                registryData={registryData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === ORDERS && (
              <PersonalOrders
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === BEYOND_PLUS && (
              <PersonalBeyondPlus
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                bpData={bpData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === FAV_STORE && (
              <PersonalFavStore
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === IDEABOARD && (
              <PersonalIdeaBoard
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === OFFERS && (
              <PersonalOffers
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
            {tileData.name === MY_FUNDS && (
              <PersonalMyFunds
                labels={this.props.labels}
                profile={this.props.profile}
                tileData={tileData}
                fireTealiumAction={this.props.fireTealiumAction}
              />
            )}
          </div>
        );
      });

      const result = featureTiles.filter(tileData => tileData !== null);
      return result;
    }

    return null;
  };

  renderPBarCarousal = pBarData => {
    const settings = {
      arrows: true,
      accessibility: true,
      dots: false,
      slide: true,
      slidesToShow: 4,
      touchMove: true,
      slidesToScroll: 1,
      swipe: true,
      infinite: false,
      nextArrowClass: classNames(styles.slickNextArrow, 'folHard'),
      prevArrowClass: classNames(styles.slickPrevArrow, 'folHard'),
      arrowClass: classNames(styles.slickArrow),
      autoplay: false,
      draggable: false,
      className: classNames(styles.slickSliderHeight, 'largeArrow pBarSlick'),
      noMargin: false,

      responsive: [
        {
          breakpoint: 9999,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
            infinite: false,
            dots: false,
          },
        },
        {
          breakpoint: 1370,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
            infinite: false,
            dots: false,
          },
        },
        {
          breakpoint: 1250,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: false,
            dots: false,
          },
        },
        {
          breakpoint: 1023,
          settings: 'unslick',
        },
      ],
    };
    let content = '';
    if (pBarData && pBarData.length > 0) {
      content = (
        <Cell
          className={classNames(styles.wrapperContainer, 'large-12 small-12')}
        >
          <React.Fragment>
            <Carousel
              ref={this.setRef}
              {...settings}
              {...this.props}
              lazyLoad={false}
              automationLocatorPrefix="pb"
            >
              {this.featureTileCreation(pBarData)}
            </Carousel>
          </React.Fragment>
        </Cell>
      );
    }
    return <GridX className={classNames(styles.innerWrapper)}>{content}</GridX>;
  };

  render() {
    if (!this.props.pBarData) {
      return null;
    }
    return (
      <div className={classNames(styles.pBarContainer)}>
        <GridX className={classNames('pBar')}>
          <Cell
            className={classNames('large-2', 'small-12', styles.welcomeTile)}
            id="PbarStaticTile"
            tabindex="0"
            aria-label="Features Personalized"
          >
            <div>
              <Paragraph
                className={classNames('mb1 mt1', styles.welcomeText)}
                data-locator="pb-welcomemsg"
              >
                {this.pBarLabels.welcomeText}
              </Paragraph>
              <Paragraph
                className={classNames(styles.fName)}
                data-locator="pb-customername"
              >
                {this.props.profile && this.props.profile.firstName}
              </Paragraph>
              {this.props.isLoggedIn && (
                <Paragraph
                  className={classNames(styles.email)}
                  data-locator="pb-customeremail"
                >
                  {this.props.profile && this.props.profile.email}
                </Paragraph>
              )}
            </div>
          </Cell>
          <Cell
            className={classNames('large-10', 'small-12', styles.carousalPBar)}
          >
            {this.renderPBarCarousal(this.props.pBarData)}
          </Cell>
        </GridX>
        <div
          id="dummyPbar"
          tabIndex="0"
          aria-label="Personalized bar completes, please tab again"
        />
      </div>
    );
  }
}
export default PBar;
