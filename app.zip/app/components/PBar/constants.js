export const FUNDS_EMPTY_MSG =
  'Continue to My Funds to add value to your account.';
export const PENDING_EXPIRY_MSG =
  'Value will be credited to your Funds once order is shipped';
// PBAR CMS Title Mapped Constants
export const ORDERS = 'ORDERS';
export const BEYOND_PLUS = 'BEYOND_PLUS';
export const FAV_STORE = 'FAV_STORE';
export const IDEABOARD = 'IDEABOARD';
export const OFFERS = 'OFFERS';
export const MY_FUNDS = 'MY_FUNDS';
export const REGISTRY = 'REGISTRY';
