import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash/fp/isEmpty';
import Flyout from '@bbb-app/core-ui/flyout';
import { isBrowser, decodeHtmlEntities } from '@bbb-app/utils/common';
import Cell from '@bbb-app/core-ui/cell';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import styles from './Hotspot.css';

const getFlyoutDirection = (topOffset, leftOffset, shouldCenter) => {
  let flyoutDirection;
  if (
    (Math.abs(50 - leftOffset) > Math.abs(50 - topOffset) ||
      Math.abs(50 - leftOffset) > 24) &&
    !shouldCenter
  ) {
    if (leftOffset > 50) {
      flyoutDirection = 'right';
    } else {
      flyoutDirection = 'left';
    }
  } else if (topOffset > 50) {
    flyoutDirection = 'down';
  } else {
    flyoutDirection = 'up';
  }
  return flyoutDirection;
};

const Hotspot = ({
  top,
  left,
  isFlyoutOpen,
  toggleFlyout,
  idx,
  productData,
  stopPropagation,
}) => {
  if (isEmpty(top) || isEmpty(left)) return null;
  const shouldCenter = isBrowser() && window.innerWidth < 401;
  const topOffset = Number(top.replace('%', ''));
  const leftOffset = Number(left.replace('%', ''));

  const flyoutDirection = getFlyoutDirection(
    topOffset,
    leftOffset,
    shouldCenter
  );

  const flyout = (
    <div
      className={classnames(styles.absolute, styles.hotspotFlyoutContainer, {
        hide: !isFlyoutOpen,
        [styles[`${flyoutDirection}HotspotFlyout`]]: !shouldCenter,
        [styles.flyoutFlex]: flyoutDirection === 'down',
        [styles.absolute]: shouldCenter,
        [styles.hotspotAbsoluteFlyout]: shouldCenter,
      })}
      style={
        shouldCenter
          ? {
              top: `calc(${top} ${flyoutDirection === 'up' ? '+' : '-'} 27px)`,
            }
          : null
      }
    >
      <Flyout
        arrowPosition={flyoutDirection}
        dataLocator={`hotspotFlyout${idx}`}
        className={classnames(styles.hotspotFlyout)}
        showArrow={false}
        isBorderless
      >
        <Cell className={styles.flyoutCell}>
          <div className={styles.flyoutImg}>
            <img
              alt={productData.DISPLAY_NAME}
              src={getConcatenatedScene7URLWithImageId(
                productData.SCENE7_URL,
                'thumbnail'
              )}
            />
          </div>
          <div className={styles.flyoutInfo}>
            <div className={styles.flyoutTitle}>
              {decodeHtmlEntities(productData.DISPLAY_NAME)}
            </div>
            <div>
              <div className={styles.flyoutMemberTitle}>NON-MEMBER</div>
              <div className={styles.flyoutPrice}>{productData.IS_PRICE}</div>
            </div>
            {productData.BEYOND_PLUS_PRICE_RANGE_STR && (
              <div>
                <div className={styles.flyoutMemberTitle}>BEYOND +</div>
                <div className={styles.flyoutBeyondPrice}>
                  {productData.BEYOND_PLUS_PRICE_RANGE_STR}
                </div>
              </div>
            )}
            <a
              href={`/store${productData.SEO_URL}`}
              className={styles.flyoutCTA}
              onClick={e => stopPropagation(e)}
              target="_blank"
            >
              See Details
            </a>
          </div>
        </Cell>
      </Flyout>
    </div>
  );

  return (
    <React.Fragment>
      <div
        className={classnames(styles.absolute, styles.hotspotContainer)}
        style={{ top: `calc(${top} - 30px)`, left: `calc(${left} - 15px)` }}
      >
        <button
          className={classnames(styles.hotspot, {
            [styles.hotspotInactive]: !isFlyoutOpen,
            [styles.hotspotActive]: isFlyoutOpen,
          })}
          onClick={e => toggleFlyout(e, idx)}
          aria-label={`Open/close Flyout for ${decodeHtmlEntities(
            productData.DISPLAY_NAME
          )}`}
          aria-expanded={isFlyoutOpen}
        />
        <span
          className={classnames(
            styles[`${flyoutDirection}ArrowAfter`],
            styles.absolute,
            { hide: !isFlyoutOpen }
          )}
        />
        {!shouldCenter ? flyout : null}
      </div>
      {!shouldCenter ? null : flyout}
    </React.Fragment>
  );
};

Hotspot.propTypes = {
  top: PropTypes.string,
  left: PropTypes.string,
  isFlyoutOpen: PropTypes.bool,
  toggleFlyout: PropTypes.func,
  idx: PropTypes.number,
  productData: PropTypes.object,
  stopPropagation: PropTypes.func,
};

export default Hotspot;
