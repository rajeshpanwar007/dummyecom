import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x/GridX';
import Button from '@bbb-app/core-ui/button';
import styles from './StaticLeftSection.css';

export const StaticLeftSection = props => {
  if (!props) {
    return null;
  }
  return (
    <div>
      {props.asideHeader && (
        <GridX>
          <Cell>
            <p className={classnames(styles.staticHeader)}>
              {props.asideHeader}
            </p>
          </Cell>
        </GridX>
      )}
      {props.asideText && (
        <GridX>
          <Cell className="mb2">
            <span className={classnames(styles.staticText)}>
              {props.asideText}
            </span>
          </Cell>
        </GridX>
      )}
      {props.asideCTA && (
        <GridX className={classnames('grid-margin-x')}>
          <Cell
            className={classnames(
              'small-12 large-12',
              styles.couponInputButton
            )}
          >
            <Button
              href={props.asideUrl}
              theme="primary"
              className={classnames(styles.setWidth)}
              variation="fullWidth"
            >
              {props.asideCTA}
            </Button>
          </Cell>
        </GridX>
      )}
    </div>
  );
};

StaticLeftSection.propTypes = {
  asideHeader: PropTypes.string,
  asideCTA: PropTypes.string,
  asideText: PropTypes.string,
  asideUrl: PropTypes.string,
};

export default StaticLeftSection;
