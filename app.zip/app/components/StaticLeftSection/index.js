export { default } from './StaticLeftSection';
