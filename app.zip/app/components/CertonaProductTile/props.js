import { arrayOf, shape, string, func, bool, object } from 'prop-types';
import { noop } from '@bbb-app/utils/common';
import Badge from '../ProductBadge/ProductBadge';

export const defaultProps = {
  attributes: [],
  reviews: 0,
  onAddToCartFromCertona: noop,
  hideIdeaboardIcon: false,
};

export default {
  /** Product attributes to emphasize (e.g. "Wedding Registry Favorite") */
  attributes: arrayOf(string),
  /** The badge anchored to the top (e.g. "Online Only") */
  BADGE: arrayOf(shape(Badge.propTypes)),
  /** Additional classes */
  className: string,
  /** Product image for initial thumbnail */
  SCENE7_URL: string.isRequired,
  /** Flag for indicating the product as "pinned" (e.g. idea boards) */
  /** Product pricing */
  IS_PRICE: string,
  WAS_PRICE: string,
  /** Product review rating (0 - 1) */
  RATINGS: string,
  /** String title for rating ("3 out of 5 stars") */
  ratingTitle: string,
  /** Product review count (1+) */
  REVIEWS: string,
  /** String title for reviews ("100 Reviews") */
  reviewsTitle: string,
  /** Product title */
  DISPLAY_NAME: string.isRequired,
  /** Product URL */
  SEO_URL: string.isRequired,
  /** Quick Button action */
  onQuickViewButtonClick: func,
  onIdeaBoardButtonClick: func,
  onAddToCartFromCertona: func,

  hideIdeaboardIcon: bool,
  minimizeATCHandler: func,
  toggleATCHandler: func,
  viewType: string,
  fireTealiumAction: func,
  tealiumATCInfo: object,
  parentProductId: string,
  isRegistry: bool,
  isEnableATRRecommend: bool,
};

export const IMAGE_SRC = {
  preset: '140',
  width: '140',
  height: '140',
};

export const SRC_SET = [
  {
    preset: '140',
    width: '140',
    height: '140',
    sourceWidth: '1x',
  },
  {
    preset: '140',
    width: '210',
    height: '210',
    sourceWidth: '2x',
  },
];

export const SIZES_V5 = [
  {
    breakpoint: 'max-width: 1100px',
    viewportWidth: '140px',
  },
  {
    breakpoint: 'min-width: 1101px',
    viewportWidth: '270px',
  },
];

export const IMAGE_SRC_V5 = {
  preset: 'content',
  width: '405',
  height: '405',
};

export const SRC_SET_V5 = [
  {
    preset: 'content',
    width: '210',
    height: '210',
    sourceWidth: '140w',
  },
  {
    preset: 'content',
    width: '405',
    height: '405',
    sourceWidth: '270w',
  },
];
