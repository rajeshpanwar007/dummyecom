/**
 * Vertical offset for lazy loading option
 * max tile height (345 - iPhone 7 Plus) + padding (20)
 */
export const LAZY_LOAD_OFFSET = 365;

/**
 * Number of tiles to bypass when applying lazy-load flag
 * in a collection iteration
 */
export const LAZY_LOAD_SKIP = 4;
export const DATA_LOCATOR_ADD_TO_CART = '_addtoccartctabtn';
export const DATA_LOCATOR_PRODUCT_IMAGE = '_productimage';
export const DATA_LOCATOR_PRODUCT_PRICE = '_producttitleprice';
export const DATA_LOCATOR_PRODUCT_TITLE = '_producttitlelabel';
export const DATA_LOCATOR_PRODUCT_RATING = '_ratingcountlabel';
export const DATA_LOCATOR_IDEA_BOARD = '_ideaboardicon';
export const CART_CERTONA_LAYOUT = 'addToCart';
export const ATR_CERTONA_LAYOUT = 'addToRegistry';
export const ATPNH_CERTONA_LAYOUT = 'addToPNH';
export const ATR_N_CART_CERTONA_LAYOUT = 'atr_cart';
export const REPLACE_CERTONA_LAYOUT = 'replace';
export const SSWP = 'SSWP';
export const COLLECTION_PRODUCT = 'COLLECTION';
export const LAST_MINUTE_ITEMS = 'Last Minute Items (cart)';
export const PAGENAME_BREADCRUMB = 'Product Detail>';
export const CART_PAGENAME_BREADCRUMB = 'Check Out>Full Cart';
export const CART = 'cart';
export const RCNTLY_VIEWD = 'Recently Viewed Items';
export const PROUCT_CLICK = 'product click';
export const PAGENAME_PDP = 'Product Details Page';
export const INTERNAL_CAMPAIGN = 'non-internal campaign';
export const ADD_TO_CART_MODAL = 'add to cart modal';
export const NON_CROSS_SELL = 'non-cross sell';
export const CHECK_OUT = 'Check Out';
export const RECOMM_PROD_MSG = 'Other Recommended Products';
export const CART_CAPS = 'Cart';
export const CATEGORY_PAGE = 'Category Page';
export const SIMILAR_PRODUCTS = 'Similar Items';
export const ALWAYS_ENABLE_ATC_SCHEME_LIST = ['fc_lmi', 'cart_rr'];
export const TEALIUM_PAGE_INFO = {
  page_type: 'Check Out',
  page_name: 'add to cart',
};
