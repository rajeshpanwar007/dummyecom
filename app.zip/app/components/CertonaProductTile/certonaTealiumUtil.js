import isArray from 'lodash/fp/isArray';
import { additionalTealiumParms as moreTealiumParams } from '@bbb-app/recently-viewed/components/certonaTealiumUtil';

export const createTealiumImpressionObj = (...elements) => {
  /* eslint-disable */
  const [
    strategy,
    fired_from,
    productToExposed,
    searchTerm,
    context_prod_id,
    reco_exp,
  ] = elements;
  const productIds = [];
  const productTitle = [];
  const productPrice = [];
  /* istanbul ignore else  */
  if (productToExposed) {
    if (isArray(productToExposed))
      productToExposed.forEach(elem => {
        const productDetailArray = elem.split("|");
        productIds.push(productDetailArray[0]);
        productTitle.push(productDetailArray[1])
        productPrice.push(productDetailArray[2])
      });
    else productIds.push(productToExposed);
  }
  const tealiumObj = {
    strategy,
    fired_from,
    product_displayed: productIds.join(","),
    gb_products:productIds,
    searchTerm,
    context_prod_id,
    container: "solrRecommendation",
    page_type: "snowplow",
    reco_exp,
    gb_product_title: productTitle,
    gb_product_price: productPrice
  };

  return tealiumObj;
};

export const additionalTealiumParms = moreTealiumParams;
