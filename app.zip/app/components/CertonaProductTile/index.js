export { default } from './CertonaProductTile';
