/* eslint-disable max-lines */
/* eslint-disable complexity */
/* eslint-disable camelcase */
import React, { PureComponent } from 'react';
import classnames from 'classnames';
import { isEmpty } from 'lodash/fp';
import pathOr from 'lodash/fp/pathOr';
import { Link } from 'react-router-dom';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import truncate from '@bbb-app/utils/truncate';
import { getCookie } from '@bbb-app/utils/universalCookie';
import { isGroupbyActive } from '@bbb-app/utils/groupBy';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import setPdpTransitionData from '@bbb-app/utils/setPdpTransitionData';
import {
  decodeHtmlEntities,
  isBrowser,
  isHrefValidForHardSPA,
} from '@bbb-app/utils/common';
import getSiteId from '@bbb-app/utils/getSiteId';
import Button from '@bbb-app/core-ui/button';
import buttonStyles from '@bbb-app/core-ui/button/Button.inline.css';
import ImageSrcSet from '@bbb-app/core-ui/image-src-set';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import HardSpaLink from '@bbb-app/core-ui/hard-spa-link/HardSpaLink';
import hardSPALinksContext from '@bbb-app/core-ui/hard-spa-link/enableHardSPALinksContext';
import {
  NON_SEARCH,
  NON_BROWSE,
  CERTONA_PRODUCT_CLICK,
  QV_CERTONA_PRODUCT_CLICK,
  NON_CROSSELL_PRODUCT,
} from '@bbb-app/tealium/constants';
import Rating from '@bbb-app/rating/Rating';
import { PRODUCT_IMAGE_PLACEHOLDER } from '@bbb-app/constants/appConstants';
import { RATING_MAX } from '@bbb-app/constants/searchConstants';
import { getTealiumContainerName } from '@bbb-app/recently-viewed/components/certonaProductClickTealiumHelper';
import styles from './CertonaProductTile.css';
import propTypes, {
  defaultProps,
  SRC_SET,
  SRC_SET_V5,
  IMAGE_SRC,
  IMAGE_SRC_V5,
  SIZES_V5,
} from './props';
import {
  DATA_LOCATOR_ADD_TO_CART,
  DATA_LOCATOR_PRODUCT_IMAGE,
  DATA_LOCATOR_PRODUCT_PRICE,
  DATA_LOCATOR_PRODUCT_RATING,
  DATA_LOCATOR_PRODUCT_TITLE,
  DATA_LOCATOR_IDEA_BOARD,
  CART_CERTONA_LAYOUT,
  ATR_CERTONA_LAYOUT,
  ATPNH_CERTONA_LAYOUT,
  SSWP,
  COLLECTION_PRODUCT,
  ATR_N_CART_CERTONA_LAYOUT,
  PAGENAME_BREADCRUMB,
  PAGENAME_PDP,
  INTERNAL_CAMPAIGN,
  ADD_TO_CART_MODAL,
  CART_PAGENAME_BREADCRUMB,
  NON_CROSS_SELL,
  CHECK_OUT,
  CATEGORY_PAGE,
  LAST_MINUTE_ITEMS,
  ALWAYS_ENABLE_ATC_SCHEME_LIST,
  REPLACE_CERTONA_LAYOUT,
} from './constants';
import AddToCart from '../../containers/AddToCart/AddToCart.async';
import AddToPNH from '../../containers/AddToPNH/AddToPNH.async';
import RegistryUtil from '../../containers/AddToRegistry/RegistryUtil';
import PDPPrice from '../Pages/PDP/ProductDetails/Components/PDPPrice';
import AddToIdeaboard from '../../containers/AddToIdeaboard/AddToIdeaboard.async';
import ReplaceProductFromRegistry from '../../containers/Pages/Registry/ReplaceProductFromRegistry/ReplaceProductFromRegistry';
import { additionalTealiumParms } from './certonaTealiumUtil';
import PRC255Copy from '../Pages/PDP/PRC255Copy/PRC255Copy.async';
import ProductBadging from '../../containers/ProductBadging/ProductBadging';
import {
  STORE_BTN_TEXT,
  SDD_BTN_TEXT,
} from '../../containers/Certona/ctaTypeConstants';
// eslint-disable-next-line no-underscore-dangle
const hardSPALinks = hardSPALinksContext._currentValue;

/**
 * Helper component for Certona Product tile CTA buttons
 * @param {object} props
 *  @param {string} props.className className attribute for the inner button
 * @param {string} props.BADGE Badge attribute for display tags
 * @param {string} props.SCENE7_URL for image ID
 * @param {function} props.SEO_URL for Image url
 * @param {string} props.WAS_PRICE for prev price
 * @param {string} props.IS_PRICE for current price
 * @param {function} props.REVIEWS for review counts
 * @param {string} props.RATINGS for star ratings
 * @param {function} props.ratingTitle for rating titles
 * @param {function} onAddToCartFromCertona for add item to cart from certona
 */
// eslint-disable-next-line react/prop-types
class CertonaProductTile extends PureComponent {
  static propTypes = propTypes;
  static defaultProps = defaultProps;
  constructor(props) {
    super(props);
    this.state = {
      setDataForTransition: {
        price: '',
        productVariation: '',
        skuId: '',
        isUnavailable: '',
        rating: '',
        reviews: '',
        imgSelector: '',
        productId: '',
        productTitle: '',
        rollupTypeCode: '',
      },
    };
    this.onQuickViewModalButtonClick = this.onQuickViewModalButtonClick.bind(
      this
    );
    this.showCartOrRegistryButton = this.showCartOrRegistryButton.bind(this);
    this.onAddToCartFromCertona = this.onAddToCartFromCertona.bind(this);
    this.renderProductClickTealiumTags = this.renderProductClickTealiumTags.bind(
      this
    );
    this.onPDPLinkClick = this.onPDPLinkClick.bind(this);
    this.isInternationalUser = isInternationalUser();
  }
  // In order to set data in PDP state when we transition from Certona to PDP
  componentDidMount() {
    const {
      IS_PRICE,
      SKU_ID,
      RATINGS,
      PRODUCT_VARIATION,
      REVIEWS,
      DISPLAY_NAME,
      PRODUCT_ID,
      ROLLUP_TYPE_CODE,
      PRODUCT_VARIATION_s,
      enableGroupByRecommendation,
    } = this.props;
    // eslint-disable-next-line react/no-did-mount-set-state
    this.setState({
      setDataForTransition: {
        price: IS_PRICE || '',
        productVariation:
          isGroupbyActive() && enableGroupByRecommendation
            ? PRODUCT_VARIATION_s
            : PRODUCT_VARIATION,
        skuId: SKU_ID ? SKU_ID[0] : null,
        isUnavailable: false,
        rating: RATINGS || 0,
        reviews: REVIEWS,
        imgSelector: `div[data-tile-id="${SKU_ID}"] div img`,
        productId: PRODUCT_ID,
        productTitle: DISPLAY_NAME,
        rollupTypeCode: ROLLUP_TYPE_CODE,
      },
    });
  }
  /**
   * @function  onQuickViewModalButtonClick
   * @Description this function open quick view from certona
   */
  onQuickViewModalButtonClick(event) {
    const {
      quickViewMode,
      SEO_URL,
      PRODUCT_ID,
      track,
      isAbtestInstore,
    } = this.props;
    this.renderProductClickTealiumTags();
    if (typeof track === 'function' && isAbtestInstore) {
      track('InStoreProdRecProdView');
    }
    /* istanbul ignore else  */
    if (quickViewMode) {
      event.preventDefault();
    }
    this.props.onQuickViewButtonClick(
      PRODUCT_ID,
      this.props.PRODUCT_VARIATION,
      SEO_URL
    );
    /* istanbul ignore else  */
  }

  /**
   * @function  onAddToCartFromCertona
   * @Description this function call when add an item from certona
   */
  onAddToCartFromCertona() {
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    this.props.onAddToCartFromCertona(this.getCartPayload());
    /* istanbul ignore else  */
    if (this.props.fireTealiumAction) {
      this.renderProductClickTealiumTags();
    }
    if (
      typeof this.props.track === 'function' &&
      certonaIdentifier === 'fc_lmi'
    ) {
      this.props.track('click_AddToCartLMI');
    }

    if (
      typeof this.props.track === 'function' &&
      certonaIdentifier === 'AddToCart_rr' &&
      (this.props.buttonIdentifier === 'Pick It Up' ||
        this.props.buttonIdentifier === 'Pickup Here')
    ) {
      this.props.track('addToCart_ATCLocalStoreRec');
    }
  }

  onPDPLinkClick() {
    const {
      track,
      isAbtestInstore,
      quickLinks,
      isFromArticlePage,
      buttonIdentifier,
    } = this.props;
    if (typeof track === 'function' && isAbtestInstore) {
      track('InStoreProdRecProdView');
    }
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    if (typeof track === 'function' && certonaIdentifier === 'fc_lmi') {
      track('product_clickLMI');
    }
    if (
      typeof track === 'function' &&
      certonaIdentifier === 'AddToCart_rr' &&
      (buttonIdentifier === 'Pick It Up' || buttonIdentifier === 'Pickup Here')
    ) {
      this.props.track('click_ATCLocalStoreRec');
    }

    setPdpTransitionData(this.state.setDataForTransition);
    /* istanbul ignore else  */
    if (!isFromArticlePage) this.renderProductClickTealiumTags('LMI_CLICKED');
    const prodTrackVal = quickLinks
      ? 'RecentlyViwedTypeaheadClick'
      : 'product_click';
    if (typeof track === 'function') {
      track(prodTrackVal);
    }
  }

  getCartPayload() {
    const {
      PRODUCT_ID,
      SKU_ID,
      PRIMARY_CATEGORY,
      PARENT_PRODUCT,
      PRODUCT_VARIATION,
      parentProductId,
      isPickupATCModal,
      PRODUCT_VARIATION_s,
      storeIdNumber,
      enableGroupByRecommendation,
      buttonIdentifier,
    } = this.props;
    const parentProductIdValue =
      parentProductId || (PARENT_PRODUCT && PARENT_PRODUCT[0]);
    const cartProps = {
      skuId: SKU_ID ? SKU_ID[0] : '',
      prodId: PRODUCT_ID,
      qty: 1,
      productVariation:
        isGroupbyActive() && enableGroupByRecommendation
          ? // eslint-disable-next-line camelcase
            PRODUCT_VARIATION_s
          : PRODUCT_VARIATION,
      ltlShipMethod: '',
      isCertonaATC: true,
      categoryId: PRIMARY_CATEGORY,
      parentProductId: parentProductIdValue,
      tealiumData: this.renderTealiumTags(),
      storeId: this.getStoreNumber(
        isPickupATCModal,
        storeIdNumber,
        buttonIdentifier
      ),
    };
    if (buttonIdentifier.toLowerCase() === SDD_BTN_TEXT.toLowerCase())
      cartProps.isShiptSdd = true;
    return cartProps;
  }

  getStoreNumber(isPickupATCModal, storeIdNumber, buttonIdentifier) {
    if (
      isPickupATCModal ||
      buttonIdentifier.toLowerCase() === STORE_BTN_TEXT.toLowerCase()
    ) {
      return storeIdNumber;
    }
    return null;
  }
  getATCButtonAttr(disable = false) {
    return {
      theme: 'secondaryStrokeBasic',
      variation: disable ? 'deactivated' : 'fullWidth',
    };
  }

  getFavStoreId() {
    let favStoreId;
    /* istanbul ignore else  */
    const { favStoreInfo } = this.props;
    if (favStoreInfo && favStoreInfo.userSiteItems) {
      favStoreId = favStoreInfo.userSiteItems.favouriteStoreId;
    }
    return favStoreId;
  }

  getPagewiseVariables(pageIdentifier) {
    let cartAddLocation;
    let pagenameBreadcrumb;
    let pageType;
    let crossSellPageName;
    let productfindingmethod;
    const { labels, tealiumATCCertonaLabel, quickViewMode } = this.props;
    const crossSellProductId = pathOr(NON_CROSS_SELL, 'PRODUCT_ID', this.props);
    productfindingmethod = `${tealiumATCCertonaLabel ||
      ''} ${' '} (add to cart modal)`;
    cartAddLocation = ADD_TO_CART_MODAL;
    pagenameBreadcrumb = 'Add to Cart Flyout';
    if (pageIdentifier === 'CART') {
      const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
      const containerName = getTealiumContainerName(
        certonaIdentifier,
        labels,
        tealiumATCCertonaLabel,
        quickViewMode
      );
      if (`${containerName}`.includes('Last Minute Items')) {
        cartAddLocation = LAST_MINUTE_ITEMS;
      } else {
        cartAddLocation = `${containerName} (cart)`;
      }
      pagenameBreadcrumb = CART_PAGENAME_BREADCRUMB;
      pageType = CHECK_OUT;
      crossSellPageName = CART_PAGENAME_BREADCRUMB;
      productfindingmethod = `${containerName} (cart)`;
    } else if (pageIdentifier === 'PDP') {
      pageType = PAGENAME_PDP;
      crossSellPageName = `${PAGENAME_BREADCRUMB}${pathOr(
        '',
        'DISPLAY_NAME',
        this.props
      )}`;
    } else if (pageIdentifier === 'PLP') {
      pageType = CATEGORY_PAGE;
      crossSellPageName = ADD_TO_CART_MODAL;
    } else if (pageIdentifier === 'SearchResults') {
      pageType = 'Search';
      crossSellPageName = ADD_TO_CART_MODAL;
    } else if (pageIdentifier === 'BrandLanding') {
      pageType = 'Brand Page';
      crossSellPageName = ADD_TO_CART_MODAL;
    }
    const pageVariables = {
      cartAddLocation,
      pagenameBreadcrumb,
      pageType,
      crossSellPageName,
      crossSellProductId,
      productfindingmethod,
    };
    return pageVariables;
  }

  getCartData() {
    let cartAmount;
    let newlyCreatedCart = 'false';
    if (this.props.cartData) {
      if (getCookie('cartCount') === '0') {
        newlyCreatedCart = 'true';
      }
      cartAmount = pathOr(
        0,
        'currentOrder.orderPriceInfoDisplayVO.amtDue',
        this.props.cartData
      );
    }
    const cartInfo = {
      newlyCreatedCart,
      cartAmount,
    };
    return cartInfo;
  }

  getProductFindingMethodIdeaBoard() {
    const {
      quickViewMode,
      labels,
      tealiumATCCertonaLabel,
      routeData,
      productName,
      routeParams,
      isATRRecommendations,
      isFromATCRecommendations,
      buttonLayout,
      SEO_URL,
      contextPath,
      DISPLAY_NAME,
    } = this.props;

    const url = routeParams ? routeParams.url : contextPath + SEO_URL || '';
    const prodName = DISPLAY_NAME || productName;
    const { pageName } = this.getPageVars(url, prodName);
    const appPageType = this.getAppPageType(
      routeData,
      quickViewMode,
      isFromATCRecommendations,
      isATRRecommendations,
      buttonLayout
    );
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    const containerName = getTealiumContainerName(
      certonaIdentifier,
      labels,
      tealiumATCCertonaLabel,
      quickViewMode
    );
    let productFindingMethod;
    switch (appPageType) {
      case 'QUICK_VIEW':
        productFindingMethod = `${containerName} (quick view modal)`;
        break;
      case 'ATC_MODAL':
        productFindingMethod = `${containerName} (add to cart modal)`;
        break;
      case 'ATR_MODAL':
        productFindingMethod = `${containerName} (add to registry modal)`;
        break;
      case 'CART':
        productFindingMethod = `${containerName} (cart)`;
        break;
      case 'PDP':
        productFindingMethod = `${containerName} (pdp)`;
        break;
      case 'CLP':
      case 'PLP':
        productFindingMethod = `${containerName} (category page)`;
        break;
      case 'MyOffer':
        productFindingMethod = `${containerName} (coupon wallet)`;
        break;
      default:
        productFindingMethod = `${containerName} (${pageName})`;
    }
    return productFindingMethod;
  }

  getAppPageType(
    routeData,
    quickViewMode,
    isFromATCRecommendations,
    isATRRecommendations,
    buttonLayout
  ) {
    if (quickViewMode === 'true') {
      return 'QUICK_VIEW';
    } else if (isATRRecommendations && buttonLayout === ATR_CERTONA_LAYOUT) {
      return 'ATR_MODAL';
    } else if (
      isFromATCRecommendations &&
      buttonLayout === CART_CERTONA_LAYOUT
    ) {
      return 'ATC_MODAL';
    }
    return routeData;
  }

  getPageVars(url, productName) {
    let pageNameBreadcrumb = '';
    let pageType = '';
    let pageName = '';
    if (!isEmpty(url) && url.includes('/store/product/') && productName) {
      pageName = PAGENAME_PDP;
      pageNameBreadcrumb = `${PAGENAME_BREADCRUMB}${productName}`;
      pageType = PAGENAME_PDP;
    } else if (window && window.utag_data && window.utag_data.page_name) {
      pageName = window.utag_data.page_name;
      pageNameBreadcrumb = window.utag_data.pagename_breadcrumb;
      pageType = window.utag_data.page_type;
    }
    return { pageNameBreadcrumb, pageType, pageName };
  }
  getRegistryButtonLbl(actions, props) {
    const isItemAlreadyAddedToRegistry = pathOr(
      false,
      'isItemAlreadyAddedToRegistry',
      props
    );
    return isItemAlreadyAddedToRegistry
      ? actions.addedToRegistry
      : actions.addToRegistry;
  }
  productFindingMethod(containerName, pageName, routeData) {
    let productFindingMethod;
    switch (routeData) {
      case 'CART':
        productFindingMethod = `${containerName} (cart)`;
        break;
      case 'PDP':
        productFindingMethod = `${containerName} (pdp)`;
        break;
      case 'CLP':
      case 'PLP':
        productFindingMethod = `${containerName} (category page)`;
        break;
      case 'MyOffer':
        productFindingMethod = `${containerName} (coupon wallet)`;
        break;
      default:
        productFindingMethod = `${containerName} (${pageName})`;
    }
    return productFindingMethod;
  }

  addProductLayout(
    actions,
    buttonLayout,
    skuId,
    isRegistryButton,
    buttonIdentifier
  ) {
    let intlRestricted = false;
    intlRestricted = pathOr(false, 'INTL_RESTRICTED', this.props);
    if (isGroupbyActive() && this.props.enableGroupByRecommendation) {
      intlRestricted = intlRestricted.toString();
    }
    const addToRegistryButtonLbl = this.getRegistryButtonLbl(
      actions,
      this.props
    );
    if (skuId && skuId.length) {
      if (this.showCartOrRegistryButton()) {
        if (
          buttonIdentifier.toLowerCase() === STORE_BTN_TEXT.toLowerCase() ||
          buttonIdentifier.toLowerCase() === SDD_BTN_TEXT.toLowerCase()
        ) {
          return this.addCartButton(buttonIdentifier);
        }
        if (buttonLayout === ATR_N_CART_CERTONA_LAYOUT) {
          return this.renderMultipleCTA(actions);
        } else if (buttonLayout === CART_CERTONA_LAYOUT) {
          return this.addCartButton(
            actions.addToCart,
            intlRestricted === 'true' && this.isInternationalUser
          );
        } else if (
          buttonLayout === ATR_CERTONA_LAYOUT &&
          actions.addToRegistry
        ) {
          return this.addATRCTA(
            addToRegistryButtonLbl,
            'bottom',
            4,
            isRegistryButton
          );
        } else if (buttonLayout === ATPNH_CERTONA_LAYOUT && actions.addToPNH) {
          return this.addPNHCTA(actions.addToPNH);
        } else if (
          buttonLayout === REPLACE_CERTONA_LAYOUT &&
          actions.replaceProductFromRegistry
        ) {
          return this.replaceCTA(actions.replaceProductFromRegistry, true);
        }
      } else if (actions.chooseOptions) {
        if (actions.replaceProductFromRegistry) {
          return this.replaceCTA(actions.chooseOptions, false);
        }
        return this.addOptionsButton(actions.chooseOptions);
      }
      return this.addCartButton(actions.addToCart, true);
    }
    return this.addCartButton(actions.addToCart, true);
  }
  addATRCTA = (
    atrLbl,
    dropDownPosition,
    maxNumberOfElementsToShow,
    isRegistryButton
  ) => {
    const {
      PRODUCT_ID,
      SKU_ID,
      SCENE7_URL,
      DISPLAY_NAME,
      PRODUCT_VARIATION,
      viewType,
      PARENT_PRODUCT,
      certonaIdentifier,
      tealiumATCCertonaLabel,
      parentProductId,
      preventLabelOverride,
      isItemAlreadyAddedToRegistry,
      disableATRModal,
      hideLoader,
      isQuickItemAddingToRegistry,
      isRegistry,
      isEnableATRRecommend,
      PRODUCT_VARIATION_s,
      isLazyLoad = true,
      enableGroupByRecommendation,
    } = this.props;
    const priceKey =
      isGroupbyActive() && enableGroupByRecommendation
        ? 'IS_PRICE_RANGE_STR'
        : 'IS_PRICE';
    const prodPrice = pathOr(0, priceKey, this.props);
    const productVn =
      isGroupbyActive() && enableGroupByRecommendation
        ? PRODUCT_VARIATION_s
        : PRODUCT_VARIATION;
    const product = {
      SKU_SCENE7_URL: SCENE7_URL,
      DISPLAY_NAME,
      PRIMARY_CATEGORY: this.props.PRIMARY_CATEGORY,
      productVn,
      price: prodPrice,
    };
    const parentProductIdValue =
      parentProductId || (PARENT_PRODUCT && PARENT_PRODUCT[0]);
    const intlUser = this.isInternationalUser;
    return RegistryUtil.getAddToRegistryForCertona({
      skuId: SKU_ID ? SKU_ID[0] : '',
      prodId: PRODUCT_ID,
      useLabelClass: true,
      wrapperClassName: 'pb0',
      product,
      atrLbl,
      viewType,
      dropDownPosition,
      maxNumberOfElementsToShow,
      parentProductId: parentProductIdValue,
      certonaIdentifier,
      tealiumATCCertonaLabel,
      intlUser,
      certonaRestrictedClass: styles.restrictedATR,
      isRegistryButton,
      preventLabelOverride,
      isItemAlreadyAddedToRegistry,
      disableATRModal,
      hideLoader,
      isQuickItemAddingToRegistry,
      isRegistry,
      isEnableATRRecommend,
      isLazyLoad,
    });
  };
  replaceCTA = (CTALbl, isReplace) => {
    const {
      PRODUCT_ID,
      SKU_ID,
      SCENE7_URL,
      DISPLAY_NAME,
      PRODUCT_VARIATION,
      viewType,
      parentProductId,
      IS_PRICE,
      discontinuedProductDetails,
      toggleModalState,
      variation,
      sortDataByDate,
      getReplacedItemData,
      PRODUCT_VARIATION_s,
      enableGroupByRecommendation,
    } = this.props;
    const productVn =
      isGroupbyActive() && enableGroupByRecommendation
        ? PRODUCT_VARIATION_s
        : PRODUCT_VARIATION;
    const product = {
      SKU_SCENE7_URL: SCENE7_URL,
      DISPLAY_NAME,
      PRIMARY_CATEGORY: this.props.PRIMARY_CATEGORY,
      productVn,
    };
    let href;
    if (!isReplace) {
      const { contextPath, SEO_URL } = this.props;
      href = `${contextPath + SEO_URL}`;
    }
    const intlUser = this.isInternationalUser;
    return (
      <ReplaceProductFromRegistry
        skuId={SKU_ID ? SKU_ID[0] : ''}
        prodId={PRODUCT_ID}
        qty="1"
        productVariation={product.productVn}
        selectedProduct={product}
        parentProductId={parentProductId}
        viewType={viewType}
        wrapperClassName={'pb0'}
        href={href}
        replace={isReplace}
        intlUser={intlUser}
        buttonProps={{
          attr: {
            theme: 'secondaryStrokeBasic',
            className: 'fullWidth justify-center items-center',
            variation: 'inlineFlex',
          },
          children: CTALbl,
        }}
        discontinuedProductDetails={discontinuedProductDetails}
        price={IS_PRICE}
        toggleModalState={toggleModalState}
        variation={variation}
        sortDataByDate={sortDataByDate}
        getReplacedItemData={getReplacedItemData}
        hideParent={this.props.hideParent}
      />
    );
  };
  addPNHCTA = () => {
    const {
      PRODUCT_ID,
      SKU_ID,
      SCENE7_URL,
      DISPLAY_NAME,
      PRODUCT_VARIATION,
      viewType,
      PARENT_PRODUCT,
      certonaIdentifier,
      tealiumATCCertonaLabel,
      parentProductId,
      STORES,
      PRODUCT_VARIATION_s,
      enableGroupByRecommendation,
    } = this.props;
    const productVn =
      isGroupbyActive() && enableGroupByRecommendation
        ? PRODUCT_VARIATION_s
        : PRODUCT_VARIATION;
    const product = {
      SKU_SCENE7_URL: SCENE7_URL,
      DISPLAY_NAME,
      PRIMARY_CATEGORY: this.props.PRIMARY_CATEGORY,
      productVn,
      STORES,
    };
    const parentProductIdValue =
      parentProductId || (PARENT_PRODUCT && PARENT_PRODUCT[0]);
    return (
      <AddToPNH
        skuId={SKU_ID ? SKU_ID[0] : ''}
        isSuccessModalShow
        prodId={PRODUCT_ID}
        qty="1"
        productVariation={product.productVn}
        selectedProduct={product}
        parentProductId={parentProductIdValue}
        viewType={viewType}
        useLabelClass
        buttonProps={{
          attr: {
            theme: 'secondaryStrokeBasic',
            className: 'fullWidth justify-center items-center',
            variation: 'inlineFlex',
          },
        }}
        certonaIdentifier={certonaIdentifier}
        tealiumATCCertonaLabel={tealiumATCCertonaLabel}
      />
    );
  };
  addOptionsButton = optionsLbl => {
    let intlRestricted = false;
    const { contextPath, SEO_URL, certonaIdentifier } = this.props;
    intlRestricted = pathOr(false, 'INTL_RESTRICTED', this.props);
    if (isGroupbyActive() && this.props.enableGroupByRecommendation) {
      intlRestricted = intlRestricted.toString();
    }
    const href = `${contextPath +
      SEO_URL +
      this.appendStrategy(SEO_URL, certonaIdentifier)}`;
    const isOptionsDisabled =
      intlRestricted === 'true' && this.isInternationalUser;
    return hardSPALinks === true && isHrefValidForHardSPA(href) === true ? (
      <HardSpaLink
        className={classnames(
          'justify-center items-center',
          buttonStyles.button,
          buttonStyles.fullWidth,
          isOptionsDisabled
            ? buttonStyles.deactivated
            : buttonStyles.secondaryStrokeBasic
        )}
        href={href}
      >
        {optionsLbl}
      </HardSpaLink>
    ) : (
      <Link
        className={classnames(
          'justify-center items-center',
          buttonStyles.button,
          buttonStyles.fullWidth,
          isOptionsDisabled
            ? buttonStyles.deactivated
            : buttonStyles.secondaryStrokeBasic
        )}
        to={href.trim()}
        onClick={this.renderProductClickTealiumTags}
      >
        {optionsLbl}
      </Link>
    );
  };

  addCartButton = (cartLbl, atcDisabled, className) => {
    let cartLabel;
    const { viewType, isPickupATCModal, clickedOnPickItUp } = this.props;
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    const btnclass = viewType === 'PDP' ? 'mb0' : 'mb2';
    if (
      clickedOnPickItUp &&
      isPickupATCModal &&
      certonaIdentifier === 'AddToCart_rr'
    ) {
      cartLabel = 'Pick It Up';
    } else {
      cartLabel = cartLbl;
    }
    return this.props.onAddToCartFromCertona &&
      this.props.onAddToCartFromCertona.name !== 'noop' ? (
      <Button
        variation={atcDisabled ? 'deactivated' : 'fullWidth'}
        className={classnames(
          btnclass,
          atcDisabled ? styles.disableBtn : '',
          'hideOnPrint'
        )}
        tooltip={cartLabel}
        onClick={this.onAddToCartFromCertona}
        theme={viewType === 'PDP' ? 'secondaryStrokeBasic' : 'control'}
      >
        {cartLabel}
      </Button>
    ) : (
      <AddToCart
        {...this.getCartPayload()}
        buttonProps={{
          attr: this.getATCButtonAttr(atcDisabled),
          children: cartLabel,
        }}
        className={className}
      />
    );
  };

  get displayTitle() {
    return truncate(this.props.DISPLAY_NAME, 70);
  }

  showCartOrRegistryButton() {
    const {
      PRODUCT_VARIATION,
      TYPE,
      CUSTOMIZATION_OFFERED_FLAG,
      LTL_FLAG,
      certonaIdentifier,
      PRODUCT_VARIATION_s,
      enableGroupByRecommendation,
    } = this.props;
    const ltlFlag = LTL_FLAG || 'false';
    const customizationFlag =
      isGroupbyActive() && enableGroupByRecommendation
        ? CUSTOMIZATION_OFFERED_FLAG[0]
        : CUSTOMIZATION_OFFERED_FLAG;
    // Last minute items as well as college landing page certona items should always show ATC
    if (isGroupbyActive() && enableGroupByRecommendation) {
      if (
        (customizationFlag === 'No' || customizationFlag === 'N') &&
        ((PRODUCT_VARIATION_s !== COLLECTION_PRODUCT &&
          TYPE === SSWP &&
          ltlFlag === 'false') ||
          ALWAYS_ENABLE_ATC_SCHEME_LIST.indexOf(certonaIdentifier) > -1)
      ) {
        return true;
      }
    }

    if (
      (customizationFlag === 'false' || customizationFlag === 'f') &&
      ((PRODUCT_VARIATION !== COLLECTION_PRODUCT &&
        TYPE === SSWP &&
        ltlFlag === 'false') ||
        ALWAYS_ENABLE_ATC_SCHEME_LIST.indexOf(certonaIdentifier) > -1)
    ) {
      return true;
    }

    return false;
  }
  fireTealiumActions(quickViewMode, tealiumTags) {
    /* istanbul ignore else  */
    if (typeof this.props.fireTealiumAction === 'function' && quickViewMode) {
      this.props.fireTealiumAction('', tealiumTags, '');
    } else if (typeof this.props.fireTealiumAction === 'function') {
      this.props.fireTealiumAction('certona product click', tealiumTags, '');
    }
  }
  crossSellPageName(pageName, defaultValue) {
    let crossPageName;
    const { productName, DISPLAY_NAME } = this.props;
    const prodName = DISPLAY_NAME || productName;
    const CROSS_SELL_CROSSPAGENAME = productName
      ? `${PAGENAME_BREADCRUMB}${prodName}`
      : '';
    switch (pageName) {
      case 'CART':
        crossPageName = CART_PAGENAME_BREADCRUMB;
        break;
      case 'PDP':
        crossPageName = CROSS_SELL_CROSSPAGENAME;
        break;
      case 'MyOffer':
        crossPageName = 'My Account>My Offers';
        break;
      case 'HOMEPAGE':
        crossPageName = 'home page';
        break;
      case 'RegistryOwnerHome':
      case 'RegistryOwner':
        crossPageName = 'Registry View Page';
        break;
      default:
        crossPageName = defaultValue;
    }
    return crossPageName;
  }

  appendStrategy(SEO_URL, certonaIdentifier) {
    if (SEO_URL && certonaIdentifier) {
      return SEO_URL.includes('?')
        ? `&strategy=${certonaIdentifier}`
        : `?strategy=${certonaIdentifier}`;
    }
    return '';
  }
  renderMultipleCTA(actions) {
    let intlRestricted = false;
    intlRestricted = pathOr(false, 'INTL_RESTRICTED', this.props);
    if (isGroupbyActive() && this.props.enableGroupByRecommendation) {
      intlRestricted = intlRestricted.toString();
    }
    const dropDownPosition = 'bottom';
    const maxNumberOfElementsToShow = 4;
    return [
      this.addCartButton(
        actions.addToCart,
        intlRestricted === 'true' && this.isInternationalUser,
        'mb2 hideOnPrint'
      ),
      this.addATRCTA(
        actions.addToRegistry,
        dropDownPosition,
        maxNumberOfElementsToShow
      ),
    ];
  }
  renderProductBadge = productBadge => {
    let badgeConfig = '';
    if (isBrowser()) {
      const node = document.createElement('div');
      node.innerHTML = productBadge;
      badgeConfig = `${node.innerText}`;
    }
    const productBadgeArray = [
      'Exclusively Ours',
      'As Seen on TV',
      'Best Seller',
    ];
    return (
      productBadgeArray.includes(badgeConfig) && (
        <ProductBadging badge={badgeConfig} />
      )
    );
  };

  renderTealiumTags() {
    const { ltlMethod, routeData, brandInfo = {} } = this.props;
    const pageIdentifier = routeData;
    const pagewiseValues = this.getPagewiseVariables(pageIdentifier);
    const {
      cartAddLocation,
      pagenameBreadcrumb,
      pageType,
      crossSellPageName,
      crossSellProductId,
      productfindingmethod,
    } = pagewiseValues;
    const prodPrice = pathOr(0, 'IS_PRICE', this.props);
    const formattedPrice = prodPrice !== 0 ? prodPrice.replace('$', '') : '0';
    const cartTealiumInfo = this.getCartData();
    const { newlyCreatedCart, cartAmount } = cartTealiumInfo;
    const favStoreId = this.getFavStoreId();
    const cartTotalValue = parseFloat(cartAmount) + parseFloat(formattedPrice);
    const cartCount = getCookie('cartCount') || 0;
    let productID = pathOr('', 'PRODUCT_ID', this.props);
    const skuId = pathOr('', 'SKU_ID', this.props);
    const skuName = pathOr('', 'DISPLAY_NAME', this.props);
    const imageUrl = getConcatenatedScene7URLWithImageId(this.props.SCENE7_URL);
    productID = [productID];
    const tealiumConst = {
      brand_name:
        pathOr('', 'BRAND_NAME', this.props) || pathOr('', 'BRAND', this.props),
      brand_id: pathOr('', 'BRAND_ID', this.props),
      cart_total_value: cartTotalValue.toFixed(2),
      cart_total_items: parseInt(cartCount, 10) + 1,
      cart_add_location: cartAddLocation,
      category_id: pathOr('', 'L1_ID[0]', this.props),
      crossell_page: crossSellPageName,
      crossell_product: crossSellProductId,
      customer_postal_code: '',
      favourite_store_id: favStoreId,
      internal_search_term: NON_SEARCH,
      internal_campaign: INTERNAL_CAMPAIGN,
      is_ltl_item: pathOr('', 'LTL_FLAG', this.props),
      inventory_status: '',
      level_of_service: ltlMethod || '',
      merchandising_category: NON_BROWSE,
      merchandising_main_level: NON_BROWSE,
      merchandising_subcategory: NON_BROWSE,
      page_type: pageType,
      product_image_name: [pathOr('', 'DISPLAY_NAME', this.props)],
      product_has_personalization:
        isGroupbyActive() && this.props.enableGroupByRecommendation
          ? this.props.CUSTOMIZATION_OFFERED_FLAG[0]
          : this.props.CUSTOMIZATION_OFFERED_FLAG,
      product_image_url: [imageUrl],
      product_name: [pathOr('', 'DISPLAY_NAME', this.props)],
      product_price: [prodPrice],
      product_sku_id: skuId,
      product_sku_name: [skuName],
      product_url: [pathOr('', 'SEO_URL', this.props)],
      product_finding_method: productfindingmethod,
      pagename_breadcrumb: pagenameBreadcrumb,
      personalization_type: '',
      product_quantity: ['1'],
      product_sub_sub_category: [],
      product_subcategory: [],
      product_category: [],
      registrants_name: '',
      registry_add_location: '',
      registry_checklist_completion: '',
      registry_event_date: '',
      registry_favorite_categories_id: '',
      registry_favorite_categories_name: '',
      registry_id: '',
      registry_product_name_count_purchased: '',
      registry_product_name_count_requested: '',
      registry_purchased: '',
      registry_total_items: '',
      registry_total_value: '',
      registry_type: '',
      shower_celebration_date: '',
      newly_created_cart: newlyCreatedCart,
      remove_global_vars: ['language_code'],
      call_to_actiontype: 'add to cart from prc',
      boosted_search_engine: brandInfo.boosted_search_engine,
      facet_order: brandInfo.facet_order,
      facets_applied: brandInfo.facets_applied,
      ...additionalTealiumParms('fc_lmi', routeData, productID, this.props),
    };
    return tealiumConst;
  }
  renderBtns(buttonStyle, isRegistryButton) {
    const {
      actions,
      itemIndex,
      automationLocatorPrefix,
      buttonLayout,
      certonaIdentifier,
      SKU_ID,
      buttonIdentifier,
    } = this.props;
    return (
      <div
        data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_ADD_TO_CART}${itemIndex}`}
        className={buttonStyle}
        id="atr-actions"
      >
        {actions &&
        (actions.chooseOptions ||
          actions.addToCart ||
          actions.addToRegistry ||
          actions.addToPNH ||
          actions.replaceProductFromRegistry) &&
        (buttonLayout === CART_CERTONA_LAYOUT ||
          buttonLayout === ATR_CERTONA_LAYOUT ||
          buttonLayout === ATR_N_CART_CERTONA_LAYOUT ||
          buttonLayout === ATPNH_CERTONA_LAYOUT ||
          buttonLayout === REPLACE_CERTONA_LAYOUT)
          ? this.addProductLayout(
              actions,
              buttonLayout,
              SKU_ID,
              isRegistryButton,
              buttonIdentifier
            )
          : null}
      </div>
    );
  }

  // eslint-disable-next-line complexity
  renderProductClickTealiumTags(clickedItem) {
    const {
      productName,
      quickViewMode,
      routeParams,
      labels,
      tealiumATCCertonaLabel,
      routeData,
      PRODUCT_VARIATION,
      track,
      isRegistry,
      isEnableATRRecommend,
      PRODUCT_VARIATION_S,
      SEO_URL,
      contextPath,
      DISPLAY_NAME,
    } = this.props;
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    const productVn =
      isGroupbyActive() && this.props.enableGroupByRecommendation
        ? PRODUCT_VARIATION_S
        : PRODUCT_VARIATION;
    if (
      typeof track === 'function' &&
      certonaIdentifier === 'AddToCart_rr' &&
      isRegistry &&
      isEnableATRRecommend
    ) {
      track('RecommATRCount');
    }

    const containerName = getTealiumContainerName(
      certonaIdentifier,
      labels,
      tealiumATCCertonaLabel,
      quickViewMode
    );
    const url = routeParams ? routeParams.url : contextPath + SEO_URL || '';
    const prodName = DISPLAY_NAME || productName;
    const { pageNameBreadcrumb, pageType, pageName } = this.getPageVars(
      url,
      prodName
    );
    const callToActionType =
      quickViewMode || certonaIdentifier === 'AddToCart_rr'
        ? QV_CERTONA_PRODUCT_CLICK
        : CERTONA_PRODUCT_CLICK;
    let crossellPro;
    const productId = this.props.PRODUCT_ID;
    if (quickViewMode && this.props.qvData) {
      crossellPro = pathOr('', 'data.PRODUCT_ID', this.props.qvData);
    } else if (this.props.PRODUCT_ID) {
      crossellPro = this.props.PRODUCT_ID;
    } else {
      crossellPro = NON_CROSSELL_PRODUCT;
    }
    const crossSellPage =
      pageNameBreadcrumb === 'Add to Cart Flyout'
        ? 'Add to Cart modal'
        : this.crossSellPageName(routeData, pageName);
    const tealiumTags = {
      browse_refine_order: '',
      call_to_actiontype: callToActionType,
      pagename_breadcrumb: pageNameBreadcrumb,
      page_type: pageType,
      page_name: callToActionType,
      crossell_page: quickViewMode
        ? `Product Detail>${pathOr('', 'qvData.data.DISPLAY_NAME', this.props)}`
        : crossSellPage,
      crossell_product: crossellPro,
      product_finding_method:
        callToActionType === QV_CERTONA_PRODUCT_CLICK
          ? `${containerName} (${pageName})`
          : this.productFindingMethod(containerName, pageName, routeData),
      product_position_clicked: pathOr(null, 'itemIndex', this.props),
      certona_type: `${clickedItem}`,
      internal_search_term: NON_SEARCH,
      merchandising_category: NON_BROWSE,
      merchandising_main_level: NON_BROWSE,
      merchandising_subcategory: NON_BROWSE,
      internal_campaign: INTERNAL_CAMPAIGN,
      remove_global_vars: [
        'customer_city',
        'customer_name',
        'customer_state',
        'country_code',
        'language_code',
      ],
      facet_order: '',
      facets_applied: '',
      sort_order: '',
      sort_value: '',
      product_accessory_id:
        productVn === 'ACCESSORY' ? this.props.PRODUCT_ID : '',
      ...additionalTealiumParms(
        certonaIdentifier,
        routeData,
        productId,
        this.props
      ),
    };
    this.fireTealiumActions(quickViewMode, tealiumTags);
  }
  renderCertonaImage() {
    const {
      contextPath,
      SEO_URL,
      SCENE7_URL,
      quickViewMode,
      certonaIdentifier,
      version,
    } = this.props;
    const lazyLoadOptions = {
      offset: 200,
      placeholder: PRODUCT_IMAGE_PLACEHOLDER,
      alt: this.displayTitle,
    };
    return quickViewMode ? (
      <PrimaryLink
        href={`${contextPath +
          SEO_URL +
          this.appendStrategy(SEO_URL, certonaIdentifier)}`}
        onClick={this.onQuickViewModalButtonClick}
        className="fullWidth fol"
      >
        <ImageSrcSet
          alt={this.displayTitle}
          scene7imageID={SCENE7_URL}
          className={'fullWidth'}
          isScene7UrlPrefix
          srcSet={SRC_SET}
          imageSrc={IMAGE_SRC}
          lazyLoadOptions={lazyLoadOptions}
          lazyLoad={this.props.isLazyLoad}
        />
      </PrimaryLink>
    ) : (
      <PrimaryLink
        href={`${contextPath +
          SEO_URL +
          this.appendStrategy(SEO_URL, certonaIdentifier)}`}
        onClick={this.onPDPLinkClick}
        className={classnames(
          { [styles.v5ImageWrapper]: version === 'V5' },
          'fullWidth fol'
        )}
      >
        <ImageSrcSet
          alt={this.displayTitle}
          scene7imageID={SCENE7_URL}
          className={'fullWidth'}
          isScene7UrlPrefix
          srcSet={version === 'V5' ? SRC_SET_V5 : SRC_SET}
          imageSrc={version === 'V5' ? IMAGE_SRC_V5 : IMAGE_SRC}
          sizes={version === 'V5' ? SIZES_V5 : undefined}
          lazyLoadOptions={lazyLoadOptions}
          lazyLoad={this.props.isLazyLoad}
        />
      </PrimaryLink>
    );
  }
  renderRating(itemIndex) {
    const {
      REVIEWS,
      RATINGS,
      ratingTitle,
      automationLocatorPrefix,
      certonaIdentifier,
      contextPath,
      SEO_URL,
      bbby_rating,
    } = this.props;
    return (
      <PrimaryLink
        href={`${contextPath +
          SEO_URL +
          this.appendStrategy(SEO_URL, certonaIdentifier)}#reviews`}
        onClick={this.onPDPLinkClick}
        className={classnames(
          this.isInternationalUser ? styles.intlRating : '',
          'fol'
        )}
      >
        <Rating
          className={styles.rating}
          total={REVIEWS}
          value={(bbby_rating || RATINGS) / RATING_MAX}
          title={decodeHtmlEntities(ratingTitle)}
          automationLocatorPrefix={automationLocatorPrefix}
          dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_RATING}${itemIndex}`}
        />
      </PrimaryLink>
    );
  }
  // eslint-disable-next-line complexity
  render() {
    const {
      BADGE_s,
      actions,
      className,
      REVIEWS,
      itemIndex,
      automationLocatorPrefix,
      buttonLayout,
      certonaIdentifier,
      renderATCButtons,
      quickViewMode,
      contextPath,
      SEO_URL,
      labels,
      enableDynamicPricing,
      DISPLAY_NAME,
      PRODUCT_ID,
      SCENE7_URL,
      SAVINGS_PERCENTAGE,
      TYPE,
      display_LOW_PRICE,
      hideIdeaboardIcon,
      minimizeATCHandler,
      toggleATCHandler,
      isPdpPersonalizeProduct,
      enable255Copy,
      DESCRIPTION,
      isRegistryButton,
      quickLinks,
      isShowBadge,
      version,
      ...item
    } = this.props;

    const siteId = getSiteId();

    const rootStyles = classnames({
      [styles.base]: true,
      [className]: className,
    });
    const productFindingMethod = this.getProductFindingMethodIdeaBoard();
    const buttonStyle =
      buttonLayout === CART_CERTONA_LAYOUT ||
      buttonLayout === ATR_CERTONA_LAYOUT ||
      buttonLayout === ATR_N_CART_CERTONA_LAYOUT ||
      buttonLayout === REPLACE_CERTONA_LAYOUT
        ? classnames(styles.actions)
        : classnames(styles.actions, 'xs-hide', 'sm-hide');
    const toRenderATCButtons = renderATCButtons;
    let intlRestricted = false;
    intlRestricted = pathOr(false, 'INTL_RESTRICTED', this.props);
    if (isGroupbyActive() && this.props.enableGroupByRecommendation) {
      intlRestricted = intlRestricted.toString();
    }
    const TitleContainer = props =>
      quickViewMode ? (
        <PrimaryLink
          href={`${contextPath +
            SEO_URL +
            this.appendStrategy(SEO_URL, certonaIdentifier)}`}
          {...props}
          onClick={this.onQuickViewModalButtonClick}
        />
      ) : (
        <PrimaryLink
          href={`${contextPath +
            SEO_URL +
            this.appendStrategy(SEO_URL, certonaIdentifier)}`}
          {...props}
          onClick={this.onPDPLinkClick}
        />
      );
    const TitleWithDangerousHTML = dangerousHTML(TitleContainer);
    return (
      <React.Fragment>
        {isShowBadge && (
          <div className={classnames(isShowBadge ? styles.badgingStyle : '')}>
            {this.renderProductBadge(BADGE_s)}
          </div>
        )}

        <div
          className={classnames(
            rootStyles,
            quickViewMode ? styles.qvCertonaProductTile : '',
            { [styles.v5TileWrapper]: version === 'V5' }
          )}
          data-tile-id={this.props.SKU_ID}
        >
          <div
            className={classnames(
              { [styles.imageContainer]: version !== 'V5' },
              { [styles.v5ImageContainer]: version === 'V5' },
              'mb2'
            )}
            data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_IMAGE}${itemIndex}`}
          >
            {!quickLinks && (
              <div
                className={styles.ideadBoard}
                data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_IDEA_BOARD}${itemIndex}`}
              >
                {actions &&
                  actions.ideaBoard &&
                  !hideIdeaboardIcon &&
                  version !== 'V5' && (
                    <AddToIdeaboard
                      productName={DISPLAY_NAME}
                      productId={PRODUCT_ID}
                      productImageId={SCENE7_URL}
                      quickViewMode={quickViewMode}
                      minimizeATCHandler={minimizeATCHandler}
                      toggleATCHandler={toggleATCHandler}
                      page={'certona'}
                      productFindingMethod={productFindingMethod}
                      renderCustomToolTip
                      ideaboardIconId={`certona-ideaboard-icon${itemIndex}`}
                      isPdpPersonalizeProduct={isPdpPersonalizeProduct}
                    />
                  )}
              </div>
            )}
            {this.renderCertonaImage()}
          </div>
          {!quickLinks &&
            version !== 'V5' && (
              <React.Fragment>
                <React.Fragment>
                  <PDPPrice
                    dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_PRICE}${itemIndex}`}
                    enableDynamicPricing={enableDynamicPricing}
                    selectedProduct={item}
                    labels={labels}
                    locationIdentifier="Certona"
                  />
                  <TitleWithDangerousHTML
                    className={classnames({
                      [styles.title]: quickViewMode,
                    })}
                    data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_TITLE}${itemIndex}`}
                    certonaIdentifier={`${certonaIdentifier}`}
                  >
                    {this.displayTitle}
                  </TitleWithDangerousHTML>
                </React.Fragment>

                <div className={styles.ratingsContainer}>
                  {enable255Copy &&
                    DESCRIPTION &&
                    DESCRIPTION.length > 0 && (
                      <PRC255Copy
                        reviews={REVIEWS}
                        href={`${contextPath +
                          SEO_URL +
                          this.appendStrategy(SEO_URL, certonaIdentifier)}`}
                        description={DESCRIPTION}
                      />
                    )}
                  {REVIEWS > 0 && this.renderRating(itemIndex)}
                  {this.isInternationalUser ? (
                    <div className={styles.intlRestrictedMsg}>
                      {intlRestricted === 'true'
                        ? LabelsUtil.getLabel(
                            labels,
                            'intlShippingRestrictedMsg'
                          )
                        : ''}
                    </div>
                  ) : null}
                  {toRenderATCButtons
                    ? this.renderBtns(buttonStyle, isRegistryButton)
                    : null}
                </div>
              </React.Fragment>
            )}
          {version === 'V5' && (
            <div
              className={classnames({
                [styles.v5InfoWrapper]: version === 'V5',
              })}
            >
              {SAVINGS_PERCENTAGE && (
                <span
                  className={classnames(
                    styles.v5PercentageOff,
                    siteId === 'BuyBuyBaby' || siteId === 'TBS_BuyBuyBaby'
                      ? styles.fontSans
                      : styles.fontSerif,
                    'inline-block'
                  )}
                >
                  {LabelsUtil.replacePlaceholderValues(
                    LabelsUtil.getLabel(labels, 'percentageOff'),
                    [SAVINGS_PERCENTAGE]
                  )}
                </span>
              )}
              <span
                className={classnames(
                  styles.v5Price,
                  siteId === 'BuyBuyBaby' || siteId === 'TBS_BuyBuyBaby'
                    ? styles.fontSans
                    : styles.fontSerif,
                  'block'
                )}
              >
                {LabelsUtil.replacePlaceholderValues(
                  LabelsUtil.getLabel(
                    labels,
                    TYPE === 'SSWP' ? 'salePrice' : 'salePriceStarts'
                  ),
                  [display_LOW_PRICE]
                )}
              </span>
              <TitleWithDangerousHTML
                className={classnames(styles.v5ProductTitle, {
                  [styles.title]: quickViewMode,
                })}
                data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_TITLE}${itemIndex}`}
                certonaIdentifier={`${certonaIdentifier}`}
              >
                {this.displayTitle}
              </TitleWithDangerousHTML>
            </div>
          )}
        </div>
      </React.Fragment>
    );
  }
}
CertonaProductTile.defaultProps = {
  renderATCButtons: true,
  buttonIdentifier: '',
};
export default CertonaProductTile;
