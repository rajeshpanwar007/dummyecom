/**
* @Description
    This file contains the component for Create Ideaboard container

    @return {Object} - Returns a Ideaboard Landing Page Header Section html

    @author Sneha Sharma <ssharma204@sapient.com>
*
*/

import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { toast } from 'react-toastify';
import LabelUtil from '@bbb-app/utils/labelsUtil';
import Button from '@bbb-app/core-ui/button';
import '@bbb-app/styles/thirdparty/toast.css';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import styles from './CreateIdeaBoard.css';
import CreateIdeaBoardForm from '../../components/CreateIdeaBoard/CreateIdeaBoardForm';
import { MY_ACCOUNT, BREADCRUMB, CALL_TO_ACTION_TYPE } from './constants';
import CreateModalTealiumHandler from '../../containers/ThirdParty/Tealium/Ideaboard/CreateModalTealiumHandler/CreateModalTealiumHandler';

const propTypes = {
  labels: PropTypes.object,
  getIdeaboards: PropTypes.func,
  isLoggedIn: PropTypes.bool,
  ideaboardsList: PropTypes.array,
  dataLocatorMap: PropTypes.object,
  pageIdentifier: PropTypes.string,
  fireTealiumAction: PropTypes.func,
};

/**
 * Helper component for CreateIdeaBoard Modal
 * @name CreateIdeaBoard
 * @param {object} props
 * @param {object} props.labels contains Ideaboard Labels
 * @param {func} props.getIdeaboards contains action to be dispatched on click of success modal
 * @param {bool} props.isLoggedIn contains logged in status
 * @param {object} props.ideaboardsList contains array of user ideaboards
 * @param {array} props.dataLocatorMap mappings for data locators
 * */
export class CreateIdeaBoard extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalMountedState: false,
      ideaBoardName: '',
    };
    this.openSuccessModalState = this.openSuccessModalState.bind(this);
  }
  /**
   * @method getTealiumParams to set tealium params for load event
   */
  getTealiumParams() {
    return {
      call_to_actiontype: CALL_TO_ACTION_TYPE,
      channel: MY_ACCOUNT,
      content_pagetype: '',
      crossell_page: '',
      crossell_product: '',
      feo_site_indicator: '',
      ideaboard_name: '',
      internal_search_term: '',
      navigation_path: MY_ACCOUNT,
      page_function: MY_ACCOUNT,
      pagename_breadcrumb: BREADCRUMB,
      product_finding_method: '',
      product_pagetype: '',
      subnavigation_path: MY_ACCOUNT,
    };
  }
  getIdeaBoardName(ideaBoardName) {
    this.setState({ ideaBoardName });
  }
  toggleModalState = state => {
    this.setState({ modalMountedState: state });
  };

  createBtnClickHandler = event => {
    event.preventDefault();
    this.setState({ modalMountedState: !this.state.modalMountedState });
  };

  openSuccessModalState(state, ideaBoardName) {
    this.toggleModalState(!state);
    toast(
      LabelUtil.getLabel(this.props.labels, 'ideaboardCreateSuccessMessage', [
        ideaBoardName,
      ])
    );
    this.getIdeaBoardName(ideaBoardName);
    this.props.getIdeaboards();
  }

  render() {
    const {
      dataLocatorMap,
      isLoggedIn,
      ideaboardsList,
      labels,
      pageIdentifier,
      fireTealiumAction,
    } = this.props;
    return (
      <React.Fragment>
        {this.state.modalMountedState && (
          <CreateModalTealiumHandler utagData={this.getTealiumParams()} />
        )}
        <Button
          theme={pageIdentifier === 'ideaboardDetail' ? 'secondary' : 'primary'}
          onClick={this.createBtnClickHandler}
          className={classnames(styles.createIdeaBoardButton)}
          {...dataLocatorMap.dataLocatorCreateButton}
        >
          {pageIdentifier === 'ideaboardDetail'
            ? LabelUtil.getLabel(labels, 'createIdeaboardBtn')
            : LabelUtil.getLabel(labels, 'createIdeaBoard')}
        </Button>
        <ModalDialog
          mountedState={this.state.modalMountedState}
          toggleModalState={this.toggleModalState}
          titleAriaLabel={'Create IdeaBoard Modal'}
          verticallyCenter
          variation="small"
          scrollDisabled={false}
          initialFocus={isLoggedIn ? '#create-ideaboardName' : ''}
          contentWrapperClass={classnames(styles.createIdeaboardModal)}
        >
          <CreateIdeaBoardForm
            onCancelLinkClick={this.toggleModalState}
            openSuccessModalState={this.openSuccessModalState}
            labels={labels}
            isLoggedIn={isLoggedIn}
            ideaboardsList={ideaboardsList}
            fireTealiumAction={fireTealiumAction}
          />
        </ModalDialog>
      </React.Fragment>
    );
  }
}

CreateIdeaBoard.propTypes = propTypes;

export default CreateIdeaBoard;
