export const CREATE_IDEABOARD_TEALIUM_PAGENAME = {
  page_type: 'My Account',
  page_name: 'create ideaboard',
};
export const CREATE_IDEABOARD_TEALIUM_ACTION = 'create ideaboard';
export const MY_ACCOUNT = 'My Account';
export const BREADCRUMB = 'My Account>Create New Idea Board';
export const IDEABOARD_STATUS = 'new';
export const CALL_TO_ACTION_TYPE = 'ideaboard create modal';
export const EDIT_IDEABOARD_TEALIUM_PAGENAME = {
  page_type: 'My Account',
  page_name: 'rename ideaboard',
};
export const EDIT_IDEABOARD_TEALIUM_ACTION = 'rename ideaboard';
export const EDIT_BREADCRUMB_LINK_LOCATIONNAME = 'My Account>Idea Board';
export const EDIT_IDEABOARD_LINK_NAME = 'Edit';
export const RENAME_IDEABOARD_LINK_NAME = 'Rename Board';
export const EDIT_IDEABOARD_PRIVACY_TOGGLE_PAGE_NAME =
  'ideaboard privacy toggle';
export const CALL_TO_ACTION_TYPE_IB_TOGGLE = 'ideaboard privacy toggle';
export const EDIT_BREADCRUMB_IB_TOGGLE = 'My Account>Idea Board';
