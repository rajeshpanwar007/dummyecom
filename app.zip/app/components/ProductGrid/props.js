import { array, string, bool, object, func } from 'prop-types';
import { noop } from '@bbb-app/utils/common';

export const defaultProps = {
  items: [],
  isLoading: false,
  isGridView: true,
  isCollegePage: false,
  onDidMount: noop,
  maxTilesRender: 7,
  rowItemsCount: 4,
  tabletRowItemsCount: 3,
  mobileRowItemsCount: 2,
};

/**
 * @param {string} className [Css classnames to be applied to class]
 * @param {bool}   dynamicPrice [Bool to determine how pricing displays on product tiles]
 * @param {array}  items [Array of product items for grid. Structure outlined in product tile]
 * @param {bool}   isLoading [Determines whether or not to show skeleton tiles]
 * @param {bool}   labels [labels object to be used in subcomponents]
 * @param {bool}   isGridView determines whether the Product Grid view type is a grid or not
 * @param {bool}   lazyLoad pass-thru prop for lazy-loading tiles
 * @param {func}    itemRenderer  function that renders the cell component
 * @param {object} switchConfig pass-thru prop for configuration of compare button on tiles
 * @param {bool}   isAvailableInStore pass-thru prop for rendering tile cta if available in stores
 * @param {bool}   isBrandPage if page grid is rendering in is a Brand PLP
*/
export default {
  className: string,
  dynamicPrice: bool,
  items: array,
  isCollegePage: bool,
  isBrandPage: bool,
  isLoading: bool,
  labels: object,
  isGridView: bool,
  lazyLoad: bool,
  backgroundColor: string,
  itemRenderer: func.isRequired,
  switchConfig: object,
  isAvailableInStore: bool,
  renderItems: bool,
  bpData: object,
};

/**
 * @param {string} className [Css classnames to be applied to class]
 * @param {bool}   isGridView determines whether the Skeleton Product Grid view type is a grid or not
 */
export const skeletonPropTypes = {
  className: string,
  isGridView: bool,
  backgroundColor: '',
};
