export const SERVICE_WORKER_MESSAGE_VALUE = 'plp';
export const SKELETON_TILES_MOBILE = 2;
export const SKELETON_TILES = 7;
export const CLIENTMETRICS_COOKIE = 'clientMetrics';
export const SIZES_DESKTOP_AND_TWO_COLUMN_MOBILE = [
  {
    breakpoint: 'min-width: 1024px',
    viewportWidth: '256px',
  },
  {
    breakpoint: 'min-width: 768px) and (max-width: 1023px',
    viewportWidth: '24vw',
  },
  {
    breakpoint: 'min-width: 321px) and (max-width: 767px',
    viewportWidth: '16vw',
  },
  {
    breakpoint: 'max-width: 320px',
    viewportWidth: '39vw',
  },
];
export const SIZES_DESKTOP_AND_SINGLE_COLUMN_MOBILE = [
  {
    breakpoint: 'min-width: 1024px',
    viewportWidth: '256px',
  },
  {
    breakpoint: 'min-width: 768px) and (max-width: 1023px',
    viewportWidth: '24vw',
  },
  {
    breakpoint: 'min-width: 321px) and (max-width: 767px',
    viewportWidth: '93vw',
  },
  {
    breakpoint: 'max-width: 320px',
    viewportWidth: '88vw',
  },
];

export const IMAGE_SRC = {
  preset: 'imagePLP',
  width: '256',
  height: '256',
};

export const SRC_SET = [
  {
    preset: 'imagePLP',
    width: '177',
    height: '177',
    sourceWidth: '177w',
  },
  {
    preset: 'imagePLP',
    width: '236',
    height: '236',
    sourceWidth: '236w',
  },
  {
    preset: 'imagePLP',
    width: '363',
    height: '363',
    sourceWidth: '363w',
  },
];
