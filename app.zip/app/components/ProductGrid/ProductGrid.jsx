import React from 'react';
import classnames from 'classnames';
import throttle from 'lodash/throttle';
import pathOr from 'lodash/fp/pathOr';
import isEmpty from 'lodash/isEmpty';
import { isEqual } from 'lodash';
import GridContainer from '@bbb-app/core-ui/grid-container';
import { getCachedCookie } from '@bbb-app/utils/universalCookie';
import { isBrowser } from '@bbb-app/utils/common';
import { getSiteSpectFlag } from '@bbb-app/utils/siteSpectUtil';
import { isGroupByPLPActive } from '@bbb-app/utils/groupBy';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { isStoreBopisEnabled } from '@bbb-app/utils/StoreInfoUtils';
import isTbs from '@bbb-app/utils/isTbs';
import Instrumentation from '@bbb-app/core-ui/instrumentation';
import {
  VISUAL_VARIANT_COLOR,
  VISUAL_VARIANT_SIZE,
} from '@bbb-app/constants/searchConstants';
import getStoreFromCookies from '@bbb-app/utils/getStoreFromCookies';
import GoogleDfp from '@bbb-app/google-dfp/containers/GoogleDfp.async';
import { SDD_ATTRIBUTE_KEY } from '@bbb-app/redux/market-eligibility/constants';

import propTypes, { defaultProps, skeletonPropTypes } from './props';
import styles from './ProductGrid.inline.css';
import ProductGridSkeleton from './Skeleton';
import { default as withLoading } from '../HOC/withLoading'; // eslint-disable-line import/no-named-default
import ProductBadging from '../../containers/ProductBadging/ProductBadging';
import {
  SRC_SET,
  IMAGE_SRC,
  SIZES_DESKTOP_AND_TWO_COLUMN_MOBILE,
  SIZES_DESKTOP_AND_SINGLE_COLUMN_MOBILE,
  SKELETON_TILES_MOBILE,
  SKELETON_TILES,
  CLIENTMETRICS_COOKIE,
} from './constants';
import PLPsnippet from '../../containers/abtests/PLPsnippet/PLPsnippet';
import { isABTestActive } from './ssUtil';
import PromoteIQ from '../../containers/Search/PromoteIQ/PromoteIQ.async';
import {
  PagingSkeleton,
  AppliedFilterSkeleton,
  AvailableSkeleton,
  SortingSkeleton,
} from '../Filters/FilterSkeletons';
import Paging from '../Filters/Paging';
import { getPageHeading } from '../Filters/FiltersHelper';
import AllFiltersSkeleton from '../Filters/AllFiltersView/Skeleton/Skeleton';

/**
 * Displays a Product grid of product tiles.
 *
 * For more information about the component please refer to
 * the README: docs/storybook/product-grid.md
 */

export class ProductGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    this.isInternationalUser = isInternationalUser();
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScroll = throttle(this.handleScroll, 50);
    this.injectGoogleDFP = this.injectGoogleDFP.bind(this);
    this.getInstrumentation = this.getInstrumentation.bind(this);
    this.showProductBadge = this.showProductBadge.bind(this);
    this.isSddEligible = getCachedCookie(SDD_ATTRIBUTE_KEY);
    this.isClientMetricsCookie = getCachedCookie(CLIENTMETRICS_COOKIE);
    this.isPlpMobileExperiment = false;
    this.isSpecAvailMsg = isABTestActive('SpecAvailMsg');
    this.isSizePricePLP = isABTestActive('SizePricePLP');
    this.isNearbyStoresTestActive = getSiteSpectFlag(
      null,
      'NearbyStores',
      false
    );
    this.isGroupbyActive = isGroupByPLPActive();
    this.isProductLoadedTriggered = false;
    this.renderGridHeader = this.renderGridHeader.bind(this);
    this.renderPaging = this.renderPaging.bind(this);
  }
  componentDidMount() {
    /* istanbul ignore else */
    if (!this.isInternationalUser) {
      this.props.onDidMount();
    }

    // Since ProductGrid is getting mounted on every transition hence this code is working fine and it's required
    // because in some scenarios, componentDidUpdate isn't getting called at all - this component only gets rendered once
    // in those scenarios.
    this.productDataLoaded();
    window.addEventListener('scroll', this.handleScroll);
  }

  shouldComponentUpdate(nextProps, nextState) {
    /* istanbul ignore else */
    if (
      !isEqual(this.props, nextProps) ||
      !isEqual(this.state, nextState) ||
      nextProps.renderItems
    ) {
      return true;
    }
    return false;
  }
  componentDidUpdate() {
    /* istanbul ignore else */
    if (!this.isProductLoadedTriggered) {
      this.productDataLoaded();
    }
  }
  getInstrumentation() {
    return (
      <Instrumentation
        markName={'ux-section-product-list'}
        zoneName={'ux-primary-content-displayed'}
      />
    );
  }

  /**
   * This function is used for showing badges on PLP and category page

   */
  showProductBadge(item) {
    const isNewArrival = pathOr(false, 'props.categoryId[0]', this) === '10008';
    /* Collect All The EXPP attributes entries into a new array */
    const badge = pathOr(null, 'badge', item);
    /* Make the keys of the new array same as it is on other pages  */
    if (badge)
      return <ProductBadging badge={badge} isNewArrival={isNewArrival} />;
    return null;
  }

  injectGoogleDFP(items, index) {
    if (!isBrowser()) {
      return null;
    }
    const bannerData = this.productGridBanner(items, index);
    if (bannerData) {
      return (
        <section
          className={classnames(
            styles.googleAdBanner,
            styles.dfpGridBanner,
            'large-12'
          )}
        >
          <GoogleDfp
            nonExperienceDrivenData={bannerData.data}
            isFromNonExperience
          />
        </section>
      );
    }
    return null;
  }

  productGridBanner(items, index) {
    const {
      googleDFPConfig,
      tabletRowItemsCount,
      mobileRowItemsCount,
      displayPLPFilters,
    } = this.props;
    let { rowItemsCount } = this.props;
    const banner1Config = pathOr('', 'googleAdBanner1st', googleDFPConfig);
    const banner2Config = pathOr('', 'googleAdBanner2nd', googleDFPConfig);
    /* istanbul ignore else */
    if (displayPLPFilters) {
      // to display 3 products in a single row - PLP Filter Redesign
      rowItemsCount = 3;
    }
    if (innerWidth >= 768 && innerWidth < 1024) {
      rowItemsCount = tabletRowItemsCount;
    }
    /* istanbul ignore else */
    if (innerWidth < 768) {
      rowItemsCount = mobileRowItemsCount;
    }

    const showgoogleAdBanner1st = banner1Config && banner1Config.showAds;
    const adIndexCheckForBanner1st =
      items.length > rowItemsCount * banner1Config.showAfterRowNo &&
      index === rowItemsCount * banner1Config.showAfterRowNo - 1;
    if (showgoogleAdBanner1st && adIndexCheckForBanner1st) {
      return {
        data: banner1Config,
        bannerPosition: 'googleAdBanner1st',
      };
    }
    const showgoogleAdBanner2nd = banner2Config && banner2Config.showAds;
    const adIndexCheckForBanner2nd =
      items.length > rowItemsCount * banner2Config.showAfterRowNo &&
      index === rowItemsCount * banner2Config.showAfterRowNo - 1;
    if (showgoogleAdBanner2nd && adIndexCheckForBanner2nd) {
      return {
        data: banner2Config,
        bannerPosition: 'googleAdBanner2nd',
      };
    }
    return null;
  }

  /**
   * Get the filter Color selected.
   */
  selectedColor = () => {
    const selectedFilters = this.props.selectedFilters
      ? this.props.selectedFilters
      : '';
    const selectedColorGroup =
      selectedFilters.COLOR_GROUP ||
      selectedFilters.COLORGROUP_s ||
      selectedFilters[VISUAL_VARIANT_COLOR];
    return selectedColorGroup && selectedColorGroup.length === 1
      ? selectedColorGroup[0]
      : '';
  };
  /**
   * Get the filter Size selected.
   */
  selectedSize = () => {
    const selectedFilters = this.props.selectedFilters
      ? this.props.selectedFilters
      : '';
    const selectedFilterBinSize =
      selectedFilters.s_f_binSize || selectedFilters[VISUAL_VARIANT_SIZE];
    return selectedFilterBinSize && selectedFilterBinSize.length === 1
      ? selectedFilterBinSize[0]
      : '';
  };

  handleScroll() {
    const y = window.scrollY || window.pageYOffset;
    /* istanbul ignore else */
    if (y > 150 && typeof this.props.setProductGridRender === 'function') {
      this.props.setProductGridRender(true);
      window.removeEventListener('scroll', this.handleScroll);
    }
  }

  productDataLoaded() {
    const { checkIsProductLoaded, items } = this.props;
    if (items && items.length && checkIsProductLoaded) {
      checkIsProductLoaded();
      this.isProductLoadedTriggered = true;
    }
  }

  renderIndexCount() {
    /* istanbul ignore else */
    if (!isBrowser()) {
      return null;
    }
    let rowItemsCount = 4;
    /* istanbul ignore else */
    if (innerWidth >= 768 && innerWidth < 1024) {
      rowItemsCount = 3;
    }
    /* istanbul ignore else */
    if (innerWidth < 768) {
      rowItemsCount = 1;
    }
    const index = rowItemsCount * 4;
    return index;
  }

  /**
   * Renders the Paging component
   * @return {object} React Component
   */
  renderPaging() {
    const {
      filtersDataObj,
      labels,
      summary,
      selectedFilters,
      pageIdentifier,
    } = this.props;
    const isDataAvailable =
      filtersDataObj.paging.start > 0 &&
      filtersDataObj.paging.count > 0 &&
      filtersDataObj.paging.end > 0;
    if (!isDataAvailable) {
      return <PagingSkeleton isSearch={this.props.isSearch} />;
    }
    return (
      <Paging
        paging={filtersDataObj.paging}
        labels={labels}
        heading={getPageHeading(summary, selectedFilters, pageIdentifier)}
      />
    );
  }

  renderGridHeader() {
    const { filterComponent } = this.props;
    return (
      <GridContainer className="sm-hide xs-hide">
        <div className={classnames(`plpGridHeader flex mt1`)}>
          <div className={classnames(styles.cell, styles.noPadding)}>
            {this.renderPaging()}
          </div>
          <div className={classnames(styles.cell, styles.appliedFilters)}>
            {filterComponent({
              onlyAppliedFilter: true,
            })}
          </div>
          <div className={classnames(styles.cell, styles.sortingOptions)}>
            {filterComponent({
              onlySortingOption: true,
            })}
          </div>
        </div>
      </GridContainer>
    );
  }

  renderPLPWithAllFilters() {}
  /* eslint complexity: ["error", 30]*/

  renderProductGrid() {
    const {
      items,
      className,
      isLoading,
      isGridView,
      itemRenderer,
      scrollTablet,
      renderItems,
      maxTilesRender,
      searchTerm,
      storeDetails,
      plpSnippet,
      TipTile,
      appliedFacetCount,
      storeAvailability,
      PageParams,
      Cookie,
      channelType,
      inStockOnline,
      pageIdentifier,
      isLoggedIn,
      sws,
      siteId,
      disableSddCheckBox,
      scene7UrlConfig,
      isPromoteIQEnabled,
      promoteIQConfig,
      formWrapperData,
      runClickTracker,
      displayPLPFilters,
      ...otherProps
    } = this.props;

    const PromoteIQIndex = this.renderIndexCount();
    let SIZES = SIZES_DESKTOP_AND_TWO_COLUMN_MOBILE;
    const filterColor = this.selectedColor();
    const isStoreAvailable = storeDetails && isStoreBopisEnabled(storeDetails);
    let filterSize = this.selectedSize();
    filterSize = filterSize ? filterSize.toUpperCase() : '';
    if (!isGridView) {
      SIZES = SIZES_DESKTOP_AND_SINGLE_COLUMN_MOBILE;
    }
    const cookieStore = getStoreFromCookies();
    let storeName = '';
    const initialTenProductId = [];
    const url = promoteIQConfig && promoteIQConfig.url;
    const params = PageParams && PageParams.start - PageParams.perPage >= 0;
    const sorting = PageParams && PageParams.sort;
    const isFilterApplied =
      !appliedFacetCount &&
      !storeAvailability &&
      !params &&
      !inStockOnline &&
      pageIdentifier === 'SearchResults' &&
      !sws &&
      siteId === 'BedBathUS' &&
      isPromoteIQEnabled &&
      sorting === 'BEST_MATCH';
    if (!isEmpty(cookieStore)) {
      storeName = cookieStore.commonName;
    }

    return (
      <GridContainer className={displayPLPFilters ? styles.plpGrid : ''}>
        <div
          className={classnames(
            styles.base,
            isGridView ? styles.gridViewBase : '',
            className,
            isLoading ? styles.loading : '',
            scrollTablet ? styles.scrollTablet : '',
            displayPLPFilters ? styles.plpGridStyle : ''
          )}
          aria-live="off"
          role="region"
        >
          <PLPsnippet
            divClassName={classnames(
              styles.cell,
              displayPLPFilters ? styles.plpFilters : '',
              {
                [styles.listView]: !isGridView,
                [styles.gridView]: isGridView && !this.isPlpMobileExperiment,
              }
            )}
            items={items}
            injectGoogleDFP={this.injectGoogleDFP}
            renderItems={renderItems}
            maxTilesRender={maxTilesRender}
            isGridView={isGridView}
            isLoading={isLoading}
            sizes={SIZES}
            srcSet={SRC_SET}
            imageSrc={IMAGE_SRC}
            filterColor={filterColor}
            filterSize={filterSize}
            itemRenderer={itemRenderer}
            searchTerm={searchTerm}
            remainProps={{ ...otherProps, storeAvailability }}
            showProductBadge={this.showProductBadge}
            isInternationalUser={this.isInternationalUser}
            getInstrumentation={this.getInstrumentation}
            isPlpMobileExperiment={this.isPlpMobileExperiment}
            plpSnippet={plpSnippet}
            TipTile={TipTile}
            isSpecAvailMsg={this.isSpecAvailMsg}
            isSizePricePLP={this.isSizePricePLP}
            isSddEligible={this.isSddEligible}
            isClientMetricsCookie={this.isClientMetricsCookie}
          >
            {items.map((item, index) => {
              if (
                typeof window !== 'undefined' &&
                index >= maxTilesRender &&
                !renderItems
              ) {
                return null;
              }
              if (index < 16 && isPromoteIQEnabled) {
                initialTenProductId.push(
                  this.isGroupbyActive
                    ? `BedBathUS_${item.PRODUCT_ID}`
                    : `BedBathUS_${item.productId}`
                );
              }
              return (
                <React.Fragment>
                  {index === PromoteIQIndex &&
                    isFilterApplied && (
                      <PromoteIQ
                        divClassName={classnames(
                          styles.cell,
                          displayPLPFilters ? styles.plpFilters : '',
                          {
                            [styles.listView]: !isGridView,

                            removeSSListViewStyles:
                              isGridView && this.isPlpMobileExperiment,
                          },
                          pageIdentifier === 'PLP' ||
                          (pageIdentifier === 'SearchResults' &&
                            isGridView &&
                            !this.isPlpMobileExperiment)
                            ? [styles.gridViewForPLP]
                            : [styles.gridView]
                        )}
                        items={items}
                        isGridView={isGridView}
                        isLoading={isLoading}
                        index={index}
                        SIZES={SIZES}
                        SRC_SET={SRC_SET}
                        IMAGE_SRC={IMAGE_SRC}
                        isInternationalUser={this.isInternationalUser}
                        filterColor={filterColor}
                        filterSize={filterSize}
                        itemRenderer={itemRenderer}
                        searchTerm={searchTerm}
                        showProductBadge={this.showProductBadge}
                        isPlpMobileExperiment={this.isPlpMobileExperiment}
                        isStoreAvailable={isStoreAvailable}
                        storeDetails={storeDetails}
                        isSizePricePLP={this.isSizePricePLP}
                        isTbs={isTbs()}
                        isNearbyStoresTestActive={this.isNearbyStoresTestActive}
                        isSddEligible={this.isSddEligible}
                        storeName={storeName}
                        remainProps={otherProps}
                        isATRModalHide={this.props.isATRModalHide}
                        initialTenProductId={initialTenProductId.toString()}
                        Cookie={Cookie}
                        isMobileOnly={channelType === 'MobileWeb'}
                        isLoggedIn={isLoggedIn}
                        promoteIQConfig={promoteIQConfig}
                        promoteIQUrl={url}
                      />
                    )}

                  <div
                    key={
                      this.isGroupbyActive ? item.PRODUCT_ID : item.productId
                    }
                    className={classnames(
                      styles.cell,
                      displayPLPFilters ? styles.plpFilters : '',
                      {
                        [styles.listView]: !isGridView,

                        removeSSListViewStyles:
                          isGridView && this.isPlpMobileExperiment,
                      },
                      (pageIdentifier === 'PLP' ||
                        pageIdentifier === 'SearchResults' ||
                        pageIdentifier === 'BrandLanding') &&
                      isGridView &&
                      !this.isPlpMobileExperiment
                        ? [styles.gridViewForPLP]
                        : [styles.gridView]
                    )}
                  >
                    {this.showProductBadge(item)}
                    {itemRenderer(item, index, {
                      badge: pathOr(null, 'badge', item),
                      items: items.length,
                      isGridView,
                      isLoading,
                      imageSrcSet: true,
                      sizes: SIZES,
                      srcSet: SRC_SET,
                      imageSrc: IMAGE_SRC,
                      itemIndex: index,
                      isInternationalUser: this.isInternationalUser,
                      filterColor,
                      filterSize,
                      searchTerm,
                      isPlpMobileExperiment: this.isPlpMobileExperiment,
                      isStoreAvailable,
                      storeDetails,
                      isSizePricePLP: this.isSizePricePLP,
                      isTbs: isTbs(),
                      isNearbyStoresTestActive: this.isNearbyStoresTestActive,
                      isSddEligible: this.isSddEligible,
                      isClientMetricsCookie: this.isClientMetricsCookie,
                      storeName,
                      ...otherProps,
                      isATRModalHide: this.props.isATRModalHide,
                      isGroupbyActive: this.isGroupbyActive,
                      pageIdentifier,
                      storeAvailability,
                      disableSddCheckBox,
                      scene7UrlConfig,
                      formWrapperData,
                      runClickTracker,
                      sponsored: item.sponsored,
                      clickTracker: item.click_tracker,
                      impressionTracker: item.impression_tracker,
                    })}
                    {((items.length > 4 && index === 3) ||
                      (items.length < 4 && index === items.length - 1)) &&
                      this.getInstrumentation()}
                  </div>
                  {this.injectGoogleDFP(items, index)}
                </React.Fragment>
              );
            })}
          </PLPsnippet>
        </div>
      </GridContainer>
    );
  }
  render = () => {
    const {
      backgroundColor,
      scrollTablet,
      pageIdentifier,
      filterComponent,
      isShiptSdd,
      displayPLPFilters,
    } = this.props;
    let isPLPPage = false;

    if (
      pageIdentifier === 'PLP' ||
      pageIdentifier === 'SearchResults' ||
      pageIdentifier === 'BrandLanding'
    ) {
      isPLPPage = true;
    }

    if (displayPLPFilters) {
      // Change for PD-60 | PLP Filters redesign
      return (
        <div
          className={classnames(
            backgroundColor || styles.color,
            scrollTablet ? styles.scrollOverflow : '',
            isPLPPage ? styles.gridContainerPLP : '',
            'pt3',
            styles.gridWithFilters
          )}
        >
          {this.renderGridHeader()}
          <div
            className={classnames(
              styles.plpGridBody,
              'plp-grid grid-container'
            )}
          >
            {filterComponent({ isShiptSdd, displayFiltersOnLeft: true })}
            {this.renderProductGrid()}
          </div>
        </div>
      );
    }
    return (
      <div
        className={classnames(
          backgroundColor || styles.color,
          scrollTablet ? styles.scrollOverflow : '',
          isPLPPage ? `${styles.gridContainerPLP}` : ''
        )}
      >
        {this.renderProductGrid()}
      </div>
    );
  };
}

export const Skeleton = ({
  className,
  isGridView,
  channelType,
  displayPLPFilters,
}) => {
  if (displayPLPFilters && channelType !== 'MobileWeb') {
    return (
      <div className={styles.color}>
        <div
          className={classnames(
            styles.color,
            styles.gridContainerPLP,
            'pt3',
            styles.gridWithFilters
          )}
        >
          <GridContainer>
            <div className={classnames(`plpGridHeader flex mt1`)}>
              <div className={classnames(styles.cell, styles.noPadding, 'mr3')}>
                <PagingSkeleton isSearch />
                <AvailableSkeleton />
              </div>
              <div
                className={classnames(
                  styles.cell,
                  styles.appliedFilters,
                  styles.plpGridStyle
                )}
              >
                <AppliedFilterSkeleton height={43} />
              </div>
              <div className={classnames(styles.cell, styles.sortingOptions)}>
                <SortingSkeleton />
              </div>
            </div>
          </GridContainer>
          <div
            className={classnames(
              styles.plpGridBody,
              'plp-grid grid-container'
            )}
          >
            <div className={classnames(styles.w25, 'mr3')}>
              <AllFiltersSkeleton />
            </div>
            <div
              className={classnames(
                styles.base,
                isGridView ? styles.gridViewBase : '',
                className,
                styles.w75
              )}
            >
              <ProductGridSkeleton
                count={
                  channelType === 'MobileWeb'
                    ? SKELETON_TILES_MOBILE
                    : SKELETON_TILES
                }
                className={classnames(
                  styles.cell,
                  isGridView ? styles.gridView : '',
                  displayPLPFilters ? styles.plpFilters : ''
                )}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className={styles.color}>
      <GridContainer>
        <div
          className={classnames(
            styles.base,
            isGridView ? styles.gridViewBase : '',
            className
          )}
        >
          <ProductGridSkeleton
            count={
              channelType === 'MobileWeb'
                ? SKELETON_TILES_MOBILE
                : SKELETON_TILES
            }
            className={classnames(
              styles.cell,
              isGridView ? styles.gridView : '',
              displayPLPFilters ? styles.plpFilters : ''
            )}
          />
        </div>
      </GridContainer>
    </div>
  );
};

Skeleton.propTypes = skeletonPropTypes;

ProductGrid.propTypes = propTypes;

ProductGrid.defaultProps = defaultProps;

export default withLoading(({ isLoading }) => !!isLoading, Skeleton)(
  React.memo(ProductGrid)
);
