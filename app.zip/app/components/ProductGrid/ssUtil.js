import { getSiteSpectAssignment } from '@bbb-app/utils/siteSpectUtil';

const PLP_TILE = 'PLPTile';

export default () =>
  getSiteSpectAssignment(
    null,
    {
      fallback: false,
      tests: { [PLP_TILE]: true },
    },
    false,
    [PLP_TILE]
  );

export const isABTestActive = variantConst => {
  const variantExperiment = variantConst;
  const searchVariant = {
    fallback: false,
    tests: { [variantExperiment]: 'VARIANT-A' },
  };

  const assignedVariation = getSiteSpectAssignment(null, searchVariant, false, [
    variantExperiment,
  ]);

  return assignedVariation && assignedVariation === 'VARIANT-A';
};
