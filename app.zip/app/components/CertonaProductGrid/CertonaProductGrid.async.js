/* eslint-disable extra-rules/no-commented-out-code */

import universal from 'react-universal-component';
import React from 'react';
import PropTypes from 'prop-types';
import LazyLoad from '@bbb-app/core-ui/lazy-load';
import { options } from '@bbb-app/universal-component/options';

const CertonaProductGridAsync = universal(
  import(/* webpackChunkName: "lazy-certona-component" */ './CertonaProductGrid'),
  options
);

const CertonaProductGrid = props => {
  const { lazyload } = props;
  if (lazyload)
    return (
      <LazyLoad threshold={100}>
        <CertonaProductGridAsync {...props} />
      </LazyLoad>
    );

  return <CertonaProductGridAsync {...props} />;
};

CertonaProductGrid.propTypes = {
  lazyload: PropTypes.bool,
};

export default CertonaProductGrid;
/* eslint-enable extra-rules/no-commented-out-code */
