export const SKELETON_PRODUCT_COUNT = '6';
