import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import _merge from 'lodash/merge';
import { debounce } from 'lodash';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import Carousel from '@bbb-app/carousel/CustomCarousel';
import { RATING_MAX } from '@bbb-app/constants/searchConstants';
import styles from './CertonaProductGrid.css';
import inlineStyles from './CertonaProductGrid.inline.css';
import CertonaProductTile from '../CertonaProductTile/CertonaProductTile';
import CertonaSingleContainer from '../CertonaSingleContainer/CertonaSingleContainer';
/**
 * Helper component for Certona Product grid CTA buttons
 * @param {object} props
 * @param {string} props.className className attribute for the inner button
 * @param {string} props.items items attribute to manipulate response
 * @param {function} props.deviceConfig for dimension, either desktop or mobile
 * @param {function} onAddToCartFromCertona for add item to cart from certona
 */
// eslint-disable-next-line react/prop-types
const propTypes = {
  className: PropTypes.string,
  items: PropTypes.array,
  isLoading: PropTypes.bool,
  labels: PropTypes.object,
  deviceConfig: PropTypes.object,
  contextPath: PropTypes.string,
  slidesToShow: PropTypes.number,
  ctaLabels: PropTypes.object,
  buttonLayout: PropTypes.string,
  similarItemsLabels: PropTypes.object,
  view: PropTypes.string,
  automationLocatorPrefix: PropTypes.string,
  certonaIdentifier: PropTypes.string,
  onQuickViewButtonClick: PropTypes.func,
  carouselSettings: PropTypes.object,
  isFromATCRecommendations: PropTypes.bool,
  onAddToCartFromCertona: PropTypes.func,
  renderATCButtons: PropTypes.bool,
  quickViewMode: PropTypes.bool,
  viewType: PropTypes.string,
  addPadding: PropTypes.bool,
  enableDynamicPricing: PropTypes.bool,
  minimizeATCHandler: PropTypes.func,
  toggleATCHandler: PropTypes.func,
  fireTealiumAction: PropTypes.func,
  cartData: PropTypes.object,
  favStoreInfo: PropTypes.object,
  tealiumCtaData: PropTypes.func,
  productName: PropTypes.string,
  routeParams: PropTypes.object,
  tealiumATCInfo: PropTypes.object,
  routeData: PropTypes.string,
  tealiumATCCertonaLabel: PropTypes.string,
  isLazyLoad: PropTypes.bool,
  parentProductId: PropTypes.string,
  qvData: PropTypes.object,
  isATRRecommendations: PropTypes.bool,
  plpBreadcrumbInfo: PropTypes.object,
  brandInfo: PropTypes.object,
  certonaInfo: PropTypes.any,
  isFromArticlePage: PropTypes.string,
  track: PropTypes.func,
  productId: PropTypes.string,
  toggleModalState: PropTypes.func,
  discontinuedProductDetails: PropTypes.object,
  variation: PropTypes.string,
  sortDataByDate: PropTypes.func,
  getReplacedItemData: PropTypes.func,
  onScrollCapture: PropTypes.func,
  isPdpPersonalizeProduct: PropTypes.bool,
  pageIdentifier: PropTypes.string,
  contextId: PropTypes.string,
  recoExp: PropTypes.string,
  fireTealiumEvent: PropTypes.bool,
  checktriggerTealiumEvent: PropTypes.func,
  enable255Copy: PropTypes.bool,
  labelType: PropTypes.string,
  isRegistryButton: PropTypes.bool,
  preventLabelOverride: PropTypes.bool,
  hideIdeaboardIcon: PropTypes.bool,
  skuLookUpMap: PropTypes.array,
  hideLoader: PropTypes.bool,
  isQuickItemAddingToRegistry: PropTypes.bool,
  disableATRModal: PropTypes.bool,
  isNeedToShowTotalItem: PropTypes.bool,
  isAbtestInstore: PropTypes.bool,
  storeClickHandler: PropTypes.func,
  inStoreItems: PropTypes.array,
  commonName: PropTypes.string,
  enhancComponent: PropTypes.bool,
  dynamicTitleMap: PropTypes.object,
  selectedTab: PropTypes.string,
  isFetching: PropTypes.bool,
  isInTest: PropTypes.string,
  testProducts: PropTypes.array,
  quickLinks: PropTypes.bool,
  isRegistry: PropTypes.bool,
  isEnableATRRecommend: PropTypes.bool,
  isPickupATCModal: PropTypes.bool,
  buttonIdentifier: PropTypes.string,
  storeIdNumber: PropTypes.string,
  clickedOnPickItUp: PropTypes.bool,
  isShowBadge: PropTypes.bool,
  enableGroupByRecommendation: PropTypes.bool,
  groupbySearchId: PropTypes.string,
  hideParent: PropTypes.func,
  version: PropTypes.string,
  isShiptSdd: PropTypes.bool,
  showSDDResults: PropTypes.bool,
  otherProductLabel: PropTypes.string,
};
const defaultProps = {
  slidesToShow: 6,
  buttonLayout: 'quickview',
  carouselSettings: {},
  addPadding: false,
  deviceConfig: {},
  onScrollCapture: () => {},
};

const getCertonaView = type => {
  switch (type) {
    case 'single':
      return CertonaSingleContainer;

    default:
      return CertonaProductTile;
  }
};

const CertonaProductGrid = ({
  items,
  deviceConfig,
  className,
  isLoading,
  labels,
  contextPath,
  slidesToShow,
  ctaLabels,
  buttonLayout,
  similarItemsLabels,
  onQuickViewButtonClick,
  automationLocatorPrefix,
  certonaIdentifier,
  carouselSettings,
  isFromATCRecommendations,
  view = 'list',
  onAddToCartFromCertona,
  renderATCButtons,
  quickViewMode,
  viewType,
  addPadding,
  enableDynamicPricing,
  minimizeATCHandler,
  toggleATCHandler,
  fireTealiumAction,
  cartData,
  favStoreInfo,
  tealiumCtaData,
  productName,
  routeParams,
  tealiumATCInfo,
  routeData,
  tealiumATCCertonaLabel,
  isLazyLoad,
  parentProductId,
  qvData,
  isATRRecommendations,
  plpBreadcrumbInfo,
  brandInfo,
  certonaInfo,
  isFromArticlePage,
  track,
  productId,
  toggleModalState,
  discontinuedProductDetails,
  variation,
  sortDataByDate,
  getReplacedItemData,
  onScrollCapture,
  isPdpPersonalizeProduct,
  pageIdentifier,
  contextId,
  recoExp,
  fireTealiumEvent,
  checktriggerTealiumEvent,
  enable255Copy,
  labelType,
  isRegistryButton,
  preventLabelOverride,
  hideIdeaboardIcon,
  skuLookUpMap,
  hideLoader,
  isQuickItemAddingToRegistry,
  disableATRModal,
  isNeedToShowTotalItem,
  isAbtestInstore,
  storeClickHandler,
  inStoreItems,
  commonName,
  enhancComponent,
  dynamicTitleMap,
  selectedTab,
  isFetching,
  isInTest,
  testProducts,
  quickLinks,
  isRegistry,
  isEnableATRRecommend,
  isPickupATCModal,
  buttonIdentifier,
  storeIdNumber,
  clickedOnPickItUp,
  isShowBadge,
  enableGroupByRecommendation,
  groupbySearchId,
  hideParent,
  version,
  isShiptSdd,
  showSDDResults,
  otherProductLabel,
}) => {
  const CertonaView = getCertonaView(view);
  if (typeof track === 'function' && quickLinks) {
    track('RecentlyViwedTypeaheadLoad');
  }
  let orgItems = items;
  if (isInTest && testProducts) {
    orgItems = testProducts;
  }
  const numberOfItemNeedToShow = isNeedToShowTotalItem
    ? orgItems && orgItems.length - 1
    : 11;
  const renderCertonaProductTile = isDesktop =>
    orgItems.map((item, index) => {
      const prodId = item && item.PRODUCT_ID ? item.PRODUCT_ID : '';
      const prodName = item && item.DISPLAY_NAME ? item.DISPLAY_NAME : '';
      const prodPrice =
        item && item.IS_PRICE_RANGE_STR ? item.IS_PRICE_RANGE_STR : '';
      return index <= numberOfItemNeedToShow ? (
        <div
          key={index}
          productId={`${prodId}|${prodName}|${prodPrice}`}
          className={classnames(
            view !== 'single'
              ? classnames(
                  {
                    'sm-mx2': version !== 'V5',
                  },
                  'tealium-product-tile',
                  styles.cell
                )
              : undefined,
            isFromATCRecommendations || addPadding
              ? styles.atcRecommendation
              : '',
            styles.maxHeight,
            { [styles.v5Grid]: version === 'V5' }
          )}
        >
          <CertonaView
            {...item}
            itemIndex={index + 1}
            automationLocatorPrefix={automationLocatorPrefix}
            actions={ctaLabels}
            contextPath={contextPath}
            onQuickViewButtonClick={onQuickViewButtonClick}
            onAddToCartFromCertona={onAddToCartFromCertona}
            similarItemsLabels={similarItemsLabels}
            buttonLayout={buttonLayout}
            certonaIdentifier={certonaIdentifier}
            viewType={viewType}
            ratingTitle={LabelsUtil.getLabel(labels, 'ratingTitle', [
              Number(item.RATINGS),
              RATING_MAX,
            ])}
            renderATCButtons={renderATCButtons}
            quickViewMode={quickViewMode}
            enableDynamicPricing={enableDynamicPricing}
            labels={labels}
            isFromATCRecommendations={isFromATCRecommendations}
            minimizeATCHandler={minimizeATCHandler}
            toggleATCHandler={toggleATCHandler}
            fireTealiumAction={fireTealiumAction}
            cartData={cartData}
            favStoreInfo={favStoreInfo}
            tealiumCtaData={tealiumCtaData}
            productName={productName}
            isDesktop={isDesktop}
            routeParams={routeParams}
            tealiumATCInfo={tealiumATCInfo}
            routeData={routeData}
            tealiumATCCertonaLabel={tealiumATCCertonaLabel}
            isLazyLoad={isLazyLoad}
            parentProductId={parentProductId}
            qvData={qvData}
            isATRRecommendations={isATRRecommendations}
            plpBreadcrumbInfo={plpBreadcrumbInfo}
            brandInfo={brandInfo}
            certonaInfo={certonaInfo}
            pageIdentifier={pageIdentifier}
            isFromArticlePage={isFromArticlePage}
            track={track}
            discontinuedProductId={productId}
            toggleModalState={toggleModalState}
            discontinuedProductDetails={discontinuedProductDetails}
            variation={variation}
            sortDataByDate={sortDataByDate}
            getReplacedItemData={getReplacedItemData}
            isPdpPersonalizeProduct={isPdpPersonalizeProduct}
            contextId={contextId}
            recoExp={recoExp}
            fireTealiumEvent={fireTealiumEvent}
            checktriggerTealiumEvent={checktriggerTealiumEvent}
            enable255Copy={enable255Copy}
            labelType={labelType}
            isRegistryButton={isRegistryButton}
            preventLabelOverride={preventLabelOverride}
            hideIdeaboardIcon={hideIdeaboardIcon}
            isItemAlreadyAddedToRegistry={
              skuLookUpMap && skuLookUpMap[item.SKU_ID[0]]
            }
            disableATRModal={disableATRModal}
            hideLoader={hideLoader}
            isQuickItemAddingToRegistry={isQuickItemAddingToRegistry}
            isAbtestInstore={isAbtestInstore}
            storeClickHandler={storeClickHandler}
            inStoreItems={inStoreItems}
            commonName={commonName}
            enhancComponent={enhancComponent}
            dynamicTitleMap={dynamicTitleMap}
            selectedTab={selectedTab}
            isFetching={isFetching}
            quickLinks={quickLinks}
            isRegistry={isRegistry}
            isEnableATRRecommend={isEnableATRRecommend}
            isPickupATCModal={isPickupATCModal}
            buttonIdentifier={buttonIdentifier}
            storeIdNumber={storeIdNumber}
            clickedOnPickItUp={clickedOnPickItUp}
            isShowBadge={isShowBadge}
            enableGroupByRecommendation={enableGroupByRecommendation}
            groupbySearchId={groupbySearchId}
            hideParent={hideParent}
            version={version}
            isShiptSdd={isShiptSdd}
            showSDDResults={showSDDResults}
            otherProductLabel={otherProductLabel}
          />
        </div>
      ) : null;
    });

  const isDesktop = deviceConfig.MIDDLEDESKTOP < window.innerWidth;
  const settings = {
    arrows: orgItems.length > parseInt(slidesToShow, 10),
    dots: false,
    slide: true,
    infinite: false,
    touchMove: true,
    slidesToScroll: slidesToShow, // BBBFEO-339_Certona+Recommendations
    swipe: true,
    draggable: false,
    onAfterChange: onScrollCapture,
  };

  const mergeCarouselSettings = _merge(settings, carouselSettings);
  const signalProps = onScrollCapture ? debounce(onScrollCapture, 400) : '';
  if (view === 'single') {
    return (
      <Cell
        className={classnames(
          'small-12',
          className,
          isLoading ? styles.loading : ''
        )}
      >
        {renderCertonaProductTile()}
      </Cell>
    );
  }
  return (
    <Cell
      className={classnames(
        'small-12',
        'mx-auto',
        {
          'large-11': version !== 'V5',
          'large-12': version === 'V5',
        },
        quickLinks ? styles.certonaHeightTypeahead : inlineStyles.certonaHeight,
        className,
        isLoading ? styles.loading : ''
      )}
    >
      {isDesktop ? (
        <Carousel
          labels={labels}
          automationLocatorPrefix={automationLocatorPrefix}
          className={styles.arrowButton}
          {...mergeCarouselSettings}
          slidesToShow={slidesToShow}
        >
          {renderCertonaProductTile(isDesktop)}
        </Carousel>
      ) : (
        <div
          className={classnames({
            [styles.mobileContainer]: version !== 'V5',
            [styles.mobileContainerV5]: version === 'V5',
          })}
          onScrollCapture={signalProps}
        >
          {renderCertonaProductTile(isDesktop)}
        </div>
      )}
    </Cell>
  );
};

CertonaProductGrid.propTypes = propTypes;
CertonaProductGrid.defaultProps = defaultProps;

export default CertonaProductGrid;
