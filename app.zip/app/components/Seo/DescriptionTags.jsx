import React from 'react';
import Helmet from 'react-helmet';
import { string } from 'prop-types';
import { decodeHtmlEntities } from '@bbb-app/utils/common';

const DescriptionTags = ({ children }) => {
  const value = decodeHtmlEntities(children);
  return (
    <Helmet>
      <meta name="description" content={value} />
      <meta property="og:description" content={value} />
    </Helmet>
  );
};

DescriptionTags.propTypes = {
  children: string.isRequired,
};

export default DescriptionTags;
