import React from 'react';
import Helmet from 'react-helmet';
import { string } from 'prop-types';

const UrlTags = ({ children }) => (
  <Helmet>
    <link rel="canonical" href={children} />
    <meta property="og:url" content={children} />
  </Helmet>
);

UrlTags.propTypes = {
  children: string.isRequired,
};

export default UrlTags;
