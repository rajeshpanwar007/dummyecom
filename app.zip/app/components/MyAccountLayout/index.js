export { default } from './MyAccountLayout';
