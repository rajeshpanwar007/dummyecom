export const LOGOUT_CLASS = 'logoutUser';
