import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { pathOr } from 'lodash/fp';
import GridContainer from '@bbb-app/core-ui/grid-container';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import MyAccountLeftNav from '@bbb-app/account-navigation/containers/MyAccountLeftNav.async';
import MyAccountSelectModal from '@bbb-app/account-navigation/containers/MyAccountSelectModal.async';
import styles from './MyAccountLayout.css';
import { LOGOUT_CLASS } from './constants';
const propTypes = {
  className: PropTypes.string,
  asideAttrs: PropTypes.object,
  asideContent: PropTypes.any.isRequired,
  mainContent: PropTypes.any.isRequired,
  mainContentProps: PropTypes.object,
  headingContent: PropTypes.any.isRequired,
  headingContentProps: PropTypes.object,
  isLoggedIn: PropTypes.bool,
  myFundsSosBanner: PropTypes.func,
};

const defaultProps = {
  className: null,
  asideAttrs: null,
  mainContentAttrs: null,
  isLoggedIn: true,
  addAddress: PropTypes.func,
};

const handleLogout = (e, mainContentProps) => {
  //  istanbul ignore else
  if (e.target.classList.contains(LOGOUT_CLASS)) {
    e.preventDefault();
    mainContentProps.logOutClick();
  }
};

const MyAccountLayout = ({
  className,
  asideAttrs,
  mainContent: MainContent,
  mainContentProps,
  headingContentProps,
  headingContent: HeadingContent,
  isLoggedIn,
  myFundsSosBanner,
  ...props
}) => {
  return (
    <div className="fullWidthWhiteGreyBg">
      <GridContainer className={styles.accountWrapper}>
        <GridX
          className={classnames('grid-margin-x', className, styles.pageWrapper)}
        >
          <Cell className="large-2 sm-hide xs-hide">
            {isLoggedIn && (
              <HeadingContent level={2} {...headingContentProps} />
            )}
            <aside>
              <MyAccountLeftNav
                variation="leftRailNav"
                dataLocator="leftNav"
                isLoggedIn={isLoggedIn}
                logOutWrapper={classnames('pt2', styles.logOutWrapperNew)}
                leftRailNav={styles.leftRailNavNew}
                handleLogout={e => handleLogout(e, mainContentProps)}
                logoutText={LabelsUtil.getLabel(
                  asideAttrs.labels,
                  'leftNav.logout'
                )}
                {...asideAttrs}
              />
            </aside>
          </Cell>
          <Cell
            className={classnames(
              'large-10 small-12 relative',
              styles.pageContent
            )}
          >
            <GridX>
              <Cell>
                <h2
                  className={classnames(
                    'lg-hide md-hide center mb15 hideOnPrint',
                    styles.myAccountTitle
                  )}
                >
                  {LabelsUtil.getLabel(
                    asideAttrs.labels,
                    'leftNav.myAccountLbl'
                  )}
                </h2>
              </Cell>
              <Cell className="lg-hide md-hide mb3">
                <MyAccountSelectModal
                  name="accountnav"
                  selectOption={(value, index, e) =>
                    handleLogout(e, mainContentProps)}
                  modalHeader={LabelsUtil.getLabel(
                    asideAttrs.labels,
                    'leftNav.myAccountLbl'
                  )}
                  ariaCurrentFlag
                  {...asideAttrs}
                  endPoints={mainContentProps.endpoints}
                />
              </Cell>
              {myFundsSosBanner && (
                <Cell className="large-11 large-offset-1 small-12">
                  {myFundsSosBanner()}
                </Cell>
              )}
              <Cell className="large-11 large-offset-1 small-12 relative">
                {headingContentProps.subHeading && (
                  <Heading
                    level={1}
                    className="mb125"
                    styleVariation="h3-sans"
                    data-locator={headingContentProps.dataLocatorValue}
                  >
                    {pathOr(
                      'My Checklist and Pack & Holds',
                      'subHeading',
                      headingContentProps
                    )}
                  </Heading>
                )}
                <MainContent {...mainContentProps} {...props} />
              </Cell>
            </GridX>
          </Cell>
        </GridX>
      </GridContainer>
    </div>
  );
};

MyAccountLayout.propTypes = propTypes;
MyAccountLayout.defaultProps = defaultProps;

export default MyAccountLayout;
