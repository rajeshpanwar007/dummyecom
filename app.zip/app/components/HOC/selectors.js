import { Map } from 'immutable';
import { createSelector } from 'reselect';
import { ROUTE_STATE_KEY } from '@bbb-app/constants/experienceConstants';

const routeStateKey = state => state.get(ROUTE_STATE_KEY);

export const selectRoute = createSelector(routeStateKey, state => {
  /* istanbul ignore else */
  if (state instanceof Map) {
    return state.toJS();
  }
  return state;
});
export const currentLocationSelector = createSelector(
  selectRoute,
  routeState => routeState.location
);
