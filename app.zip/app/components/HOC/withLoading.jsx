import { branch, renderComponent } from 'recompose';

export default (test, Skeleton) => branch(test, renderComponent(Skeleton));
