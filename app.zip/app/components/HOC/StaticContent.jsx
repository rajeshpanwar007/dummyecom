/* istanbul ignore file */
import { createElement, useRef } from 'react';

// A hacky solution to prevent hydration
// see: https://github.com/facebook/react/issues/10923#issuecomment-338715787
// on server, simply render content
// on client, render empty content using dangerouslySetInnerHTML,
// which normally causes a warning of content mismatch and keeps the existing content
// also add suppressHydrationWarning to turn off the warning.
export default function StaticContent({
  children,
  element = 'div',
  disable,
  content = '',
  ...props
}) {
  const ref = useRef(null);
  const isServer = typeof window === 'undefined';
  // if we're in the server or a spa navigation, just render it
  if (isServer || disable) {
    return createElement(element, {
      ...props,
      children,
    });
  }

  // avoid re-render on the client
  return createElement(element, {
    ...props,
    ref,
    suppressHydrationWarning: true,
    dangerouslySetInnerHTML: { __html: content },
  });
}
