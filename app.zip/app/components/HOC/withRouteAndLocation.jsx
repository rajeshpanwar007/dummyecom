import { compose, withProps } from 'recompose';
import { connect } from 'react-redux';
import { matchRoutes } from 'react-router-config';
import { head } from 'lodash/fp';
import { createStructuredSelector } from 'reselect';

import { currentLocationSelector } from './selectors';
import createRoutes from '../../../app/routes';

const mapStateToProps = createStructuredSelector({
  location: currentLocationSelector,
});

const withRouteAndLocation = path =>
  compose(
    withProps(() => head(matchRoutes(createRoutes(), path))),
    connect(mapStateToProps)
  );

export default withRouteAndLocation;
