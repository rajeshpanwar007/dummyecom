import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import styles from './Ideaboard.css';

export const Ideaboard = props => {
  return (
    <div
      data-locator="clppage-ideaboardsection"
      className={styles.ideaboardsection}
    >
      <Heading level={2} className={classnames('teaserTitle', 'center', 'mb3')}>
        {LabelsUtil.getLabel(props.labels, 'ideaBoardTitle')}
      </Heading>

      <GridX className="flex justify-center">
        <div className={classnames(styles.ideaboardTile, 'mb1', 'ml0')} />
        <div className={classnames(styles.ideaboardTile, 'mb1', 'sm-mr0')} />
        <div className={classnames(styles.ideaboardTile, 'mb1', 'sm-ml0')} />
        <div className={classnames(styles.ideaboardTile, 'mb1', 'mr0')} />
      </GridX>
    </div>
  );
};

Ideaboard.propTypes = {
  labels: PropTypes.object,
};

export default Ideaboard;
