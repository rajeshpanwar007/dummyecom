export { default } from './Ideaboard';
