export { default } from './BookingBugModal';
