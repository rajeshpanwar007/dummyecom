import { createSelector } from 'reselect';

export const selectLabels = state => state.get('labels');
export const selectViewportConfig = state => state.get('viewportConfig');

export const makeLabels = () => {
  return createSelector(selectLabels, labelsState =>
    labelsState.getIn(['Registry', 'Bookingbug'])
  );
};

export const selectSiteConfig = () =>
  createSelector(selectViewportConfig, viewPortConfig =>
    viewPortConfig.get('siteConfig')
  );

export const selectSwitchConfig = () =>
  createSelector(selectViewportConfig, viewPortConfig =>
    viewPortConfig.get('switchConfig')
  );

export const selectThirdPartyDataConfig = () =>
  createSelector(selectViewportConfig, viewPortConfig =>
    viewPortConfig.get('thirdPartyDataConfig')
  );

export const selectPageConfigGlobal = () =>
  createSelector(selectViewportConfig, viewPortConfig =>
    viewPortConfig.get('pageConfig')
  );

export const appModalState = state => state.get('globalAppModalState');
