export const APPOINTMENTSURL =
  'https://bespoke.bookingbug.com/bbb/staging/new_booking.html';
