import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { noop } from '@bbb-app/utils/common';
import getSiteId from '@bbb-app/utils/getSiteId';
import toJS from '@bbb-app/hoc/toJS';
import ModalDialog from '@bbb-app/modal-dialog/containers/ModalDialog';
import { makeSelectActiveRegistry } from '@bbb-app/selectors/registrySelectors';
import { selectRouterLocation } from '@bbb-app/selectors/appSelectors';
import { makeSelectProfile } from '@bbb-app/selectors/accountSelectors';
import { getLoggedIn } from '@bbb-app/header/containers/selectors';
import SearchStores from '../../containers/SearchStores/SearchStores';
import BookAnAppointmentModalTealiumHandler from '../../containers/ThirdParty/Tealium/BookAnAppointmentModalTealiumHandler/BookAnAppointmentModalTealiumHandler';
import {
  makeLabels,
  selectSiteConfig,
  selectThirdPartyDataConfig,
  selectPageConfigGlobal,
  appModalState,
} from './selectors';
import style from './BookingBugModal.css';
import { APPOINTMENTSURL } from './constants';
/**
 * Bookingbug -  booking bug component
 */
/* eslint complexity: ["error", 22]*/
export class BookingBugModal extends React.PureComponent {
  getCatId = (
    pathname,
    collegeCatId,
    pageConfigGlobal,
    isCollege,
    appointmentRouteCatIdMapping
  ) => {
    if (isCollege) {
      return collegeCatId;
    }
    let catId;
    let index = 0;
    const entries = Object.entries(appointmentRouteCatIdMapping);
    while (!catId && index < entries.length) {
      if (pathname === entries[index][0]) {
        catId = entries[index][1];
      }
      index += 1;
    }
    return catId || pathOr('', 'catId', pageConfigGlobal);
  };

  renderContent() {
    const {
      siteId,
      labels,
      isLoggedIn,
      profile,
      storeId,
      activeRegistry,
      thirdPartyDataConfig,
      pageConfig,
      findAStoreModal,
      router,
      globalModalState,
    } = this.props;

    const siteIdNumber =
      { BedBathUS: '1', BuyBuyBaby: '2', BedBathCanada: '3' }[siteId] || '1';

    const reg = {
      registryId: '',
      firstName: '',
      lastName: '',
      email: '',
      contactNum: '',
      coRegEmail: '',
      coRegFirstName: '',
      coRegLastName: '',
      eventDate: '',
      favStoreId: '',
      preselectedServiceRef: '',
    };

    const pathname = pathOr('', 'location.pathname', router);
    const collegeCatId = pathOr(
      '',
      'AppointmentRouteCatIdMapping.collegeCatId',
      pageConfig
    );
    const appointmentRouteCatIdMapping = pathOr(
      {},
      'AppointmentRouteCatIdMapping',
      pageConfig
    );
    const isCollege = pathOr('', 'props.isCollege', globalModalState);

    if (isLoggedIn && findAStoreModal !== undefined && findAStoreModal) {
      const {
        primaryRegistrantLastName,
        primaryRegistrantEmail,
        coRegistrantLastName,
      } = activeRegistry;
      reg.registryId = pathOr('', 'registryId', activeRegistry);
      reg.firstName = pathOr('', 'primaryRegistrantFirstName', activeRegistry);
      reg.lastName =
        primaryRegistrantLastName !== 'masked' && primaryRegistrantLastName;
      reg.email =
        !primaryRegistrantEmail.includes('*') && primaryRegistrantEmail;
      reg.contactNum =
        pathOr('', 'primaryRegistrantPrimaryPhoneNum', activeRegistry) || '';
      reg.coRegFirstName =
        pathOr('', 'coRegistrantFirstName', activeRegistry) || '';
      reg.coRegLastName =
        coRegistrantLastName !== 'masked' &&
        coRegistrantLastName !== null &&
        coRegistrantLastName;
      reg.eventDate = pathOr('', 'eventDate', activeRegistry);
      reg.favStoreId = pathOr('', 'favStoreId', activeRegistry);
    } else if (
      isLoggedIn &&
      profile !== undefined &&
      Object.keys(profile).length > 0
    ) {
      const { email, lastName } = profile;
      reg.firstName = pathOr('', 'firstName', profile);
      reg.lastName = lastName !== null && lastName;
      reg.email = email && !email.includes('*') && email;
      reg.contactNum = pathOr('', 'phone', profile);
    }

    // TODO:  Use labels object to get message and url from CMS.
    const catId = this.getCatId(
      pathname,
      collegeCatId,
      pageConfig.Global,
      isCollege,
      appointmentRouteCatIdMapping
    );

    let title = '';
    let url = '';

    title = LabelsUtil.getLabel(labels, 'appointmentsTitle');
    url = pathOr(
      APPOINTMENTSURL,
      'bookingBug.appointmentsUrl',
      thirdPartyDataConfig
    );
    url = `${url}?abc=1&siteId=${siteIdNumber}&storeId=${storeId}&regFN=${reg.firstName}&regLN=${reg.lastName}&coregFN=${reg.coRegFirstName}&coregLN=${reg.coRegLastName}&email=${reg.email}&coregEmail=${reg.coRegEmail}&contactNum=${reg.contactNum}&registryId=${reg.registryId}&eventDate=${reg.eventDate}&catID=${catId}`;

    if (storeId) {
      return (
        <div className={classnames(style.outerWrapper)}>
          <div className={classnames(style.titleWrapper)}>{title}</div>
          <div className={classnames(style.iframeWrapper)}>
            <iframe src={url} />
          </div>
        </div>
      );
    }
    return (
      <div>
        <h2>{LabelsUtil.getLabel(labels, 'findAppointmentNearYou')}</h2>
        <div className={classnames(style.mediumLight)}>
          <p>{LabelsUtil.getLabel(labels, 'findAppointmentText')}</p>
        </div>
        <SearchStores
          {...this.props}
          findAStoreModal
          isFilterVisible={false}
          isPickupInStore
        />
      </div>
    );
  }

  render() {
    const { mountedState = false, onModalClose, labels } = this.props;
    return (
      <ErrorBoundary>
        <ModalDialog
          titleText={LabelsUtil.getLabel(labels, 'appointmentsTitle')}
          mountedState={mountedState}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'bookingBugIframeLbl')}
          closeIconShow
          verticallyCenter
          onModalDidClose={noop}
          onModalClose={onModalClose}
          variation={'large'}
          dialogClass={style.dialogClass}
          rclModalClass={style.modalClass}
          contentWrapperClass={style.contentWrapperClass}
        >
          {mountedState === true && <BookAnAppointmentModalTealiumHandler />}
          {this.renderContent()}
        </ModalDialog>
      </ErrorBoundary>
    );
  }
}

BookingBugModal.propTypes = {
  siteId: PropTypes.string,
  labels: PropTypes.object,
  isLoggedIn: PropTypes.bool,
  profile: PropTypes.object,
  mountedState: PropTypes.bool,
  onModalClose: PropTypes.func,
  storeId: PropTypes.string,
  thirdPartyDataConfig: PropTypes.object,
  pageConfig: PropTypes.object,
  activeRegistry: PropTypes.object,
  findAStoreModal: PropTypes.bool,
  router: PropTypes.object,
  globalModalState: PropTypes.object,
};

export const mapStateToProps = createStructuredSelector({
  siteId: getSiteId,
  labels: makeLabels(),
  isLoggedIn: getLoggedIn(),
  profile: makeSelectProfile(),
  siteConfig: selectSiteConfig(),
  pageConfig: selectPageConfigGlobal(),
  thirdPartyDataConfig: selectThirdPartyDataConfig(),
  activeRegistry: makeSelectActiveRegistry(),
  router: selectRouterLocation(),
  globalModalState: appModalState,
});

export default connect(mapStateToProps)(toJS(BookingBugModal));
