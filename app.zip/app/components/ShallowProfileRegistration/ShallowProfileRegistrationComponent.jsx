/** Libraries */
import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import { Redirect } from 'react-router';
import isEmpty from 'lodash/fp/isEmpty';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import isUserLoggedIn from '@bbb-app/utils/isUserLoggedIn';
import isTbs from '@bbb-app/utils/isTbs';
/** Components */
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import ShallowVerificationMsg from '@bbb-app/account-signin/containers/email-verification/ShallowVerificationMsg';
import { InternalServerHttpErrorPath } from '@bbb-app/constants/route/route';
import styles from './ShallowProfileRegistrationComponent.css';

// pending logic - labels, Popup data, user email, redirect to 404 if no email ID
const ShallowProfileRegistrationComponent = props => {
  const {
    userEmailId,
    emailSentData,
    emailSentError,
    sendEmailVerification,
    clearVerificationEmail,
    location,
    accountRegLabels,
    endpoints,
  } = props;
  const emailId =
    userEmailId ||
    new URLSearchParams(props.location.search).get('emailId') ||
    pathOr('', 'state.emailId', location);
  if (isUserLoggedIn() && !isTbs()) {
    return (
      <Redirect
        to={pathOr('', 'signIn', endpoints) || '/store/account/Login'}
      />
    );
  }
  if (isEmpty(emailId)) {
    return <Redirect to={InternalServerHttpErrorPath} />;
  }
  return (
    <GridX className="grid-container pt3">
      <Cell
        className={classNames(
          'small-12 large-6 mx-auto',
          styles.shallowProfileRegistrationWrapper
        )}
      >
        <Heading
          level={1}
          className={classNames(
            styles.shallowProfileRegistrationHeading,
            'mb2 sm-mb2'
          )}
        >
          {LabelsUtil.getLabel(
            accountRegLabels,
            'registration.justOneMoreStepHeading'
          )}
        </Heading>
        <ShallowVerificationMsg
          shallowRegistrationPage
          emailId={emailId}
          sendEmailVerification={sendEmailVerification}
          emailSentData={emailSentData}
          emailSentError={emailSentError}
          clearVerificationEmail={clearVerificationEmail}
          labels={accountRegLabels}
          location={location}
        />
      </Cell>
    </GridX>
  );
};

ShallowProfileRegistrationComponent.propTypes = {
  userEmailId: PropTypes.string,
  emailSentData: PropTypes.object,
  emailSentError: PropTypes.object,
  sendEmailVerification: PropTypes.func,
  clearVerificationEmail: PropTypes.func,
  location: PropTypes.object,
  accountRegLabels: PropTypes.object,
  endpoints: PropTypes.object,
};

export default ShallowProfileRegistrationComponent;
