import React from 'react';
import PropTypes from 'prop-types';
import { isEqual } from 'lodash/fp';
import classnames from 'classnames';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Icon from '@bbb-app/core-ui/icon';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import '@bbb-app/assets/icons/locations.svg';
import '../../assets/icons/clipboard.svg';

import styles from './FindYourSchoolDetails.css';

class FindYourSchoolDetails extends React.PureComponent {
  static propTypes = {
    getSelectedSchool: PropTypes.object,
    clearSelectedSchoolInfo: PropTypes.func,
    labels: PropTypes.object,
  };

  constructor(props) {
    super(props);
    this.resetSchoolData = this.resetSchoolData.bind(this);
  }

  /**
   * @description
   *  This function only returns the markup for pdf section.
   *  It was created to maintain the render() function's length under 100 lines.
   */

  shouldComponentUpdate(nextProps, nextState) {
    if (!isEqual(this.props, nextProps) || !isEqual(this.state, nextState)) {
      return true;
    }
    return false;
  }
  getPdfSection(data, labels) {
    return (
      <Cell className="large-6 medium-6 small-12">
        <div
          className={classnames(
            'relative left-align mb3',
            styles.schoolPdfInfo,
            styles.schoolDetailsWrapper
          )}
        >
          <Icon
            type="clipboard"
            width="21"
            height="32"
            className={classnames(
              'absolute top-0 left-0',
              styles.schoolPdfInfoSvg
            )}
          />
          <Heading level={3} className={classnames(styles.detailsHeading)}>
            {LabelsUtil.getLabel(labels, 'pdfSheetTitle')}
          </Heading>
          <Paragraph className={classnames('m0 mb0', styles.paragraph)}>
            {LabelsUtil.getLabel(labels, 'defaultPdfDescription')}
          </Paragraph>
          <PrimaryLink
            className={classnames('mt1', styles.hyperlinks)}
            href={data.field_link}
            target="_blank"
          >
            {LabelsUtil.getLabel(labels, 'pdfSheetLink')}
          </PrimaryLink>
        </div>
      </Cell>
    );
  }

  resetSchoolData(e) {
    e.preventDefault();
    this.props.clearSelectedSchoolInfo();
  }

  render() {
    const data = this.props.getSelectedSchool;
    const { labels } = this.props;
    if (data) {
      return (
        <div>
          {data.field_selectedUniversity && (
            <div className="center">
              <Heading
                level={1}
                className={classnames('center m0', styles.schoolTitle)}
              >
                {data.field_selectedUniversity}
              </Heading>
              <PrimaryLink
                href="#"
                onClick={this.resetSchoolData}
                className={classnames(styles.resetButton, styles.hyperlinks)}
              >
                {LabelsUtil.getLabel(labels, 'btnReset')}
              </PrimaryLink>
            </div>
          )}
          <GridX
            className={classnames(
              'center grid-margin-x ',
              styles.findYourSchoolDetails
            )}
          >
            {data.field_link && this.getPdfSection(data, labels)}
            <Cell className="large-6 medium-6 small-12 left-align mb3">
              <div
                className={classnames(
                  'inline-block relative ml2',
                  styles.schoolDetailsWrapper
                )}
              >
                <Icon
                  type="locations"
                  width="23"
                  height="30"
                  className={classnames(
                    'absolute top-0 left-0',
                    styles.storeInfoSvg
                  )}
                />
                {/* Store Heading and paragragh text in the following
                    section is static for now and will be changed at the time
                    of store integration story */}
                <Heading
                  level={3}
                  className={classnames(styles.detailsHeading)}
                >
                  Okemos
                </Heading>
                <Paragraph className={classnames('m0 mb0', styles.paragraph)}>
                  1982 West Grand River Avenue<br />
                  Okemos, MI 48864
                </Paragraph>
                <PrimaryLink
                  href="#"
                  className={classnames('mt1', styles.hyperlinks)}
                >
                  {LabelsUtil.getLabel(labels, 'storeDirections')}
                </PrimaryLink>
                <span
                  className={classnames(
                    'inline-block align-middle',
                    styles.linkDivider
                  )}
                >
                  |
                </span>
                <PrimaryLink
                  href="#"
                  className={classnames('mt1', styles.hyperlinks)}
                >
                  {LabelsUtil.getLabel(labels, 'findStore')}
                </PrimaryLink>
              </div>
            </Cell>
          </GridX>
        </div>
      );
    }
    return null;
  }
}

export default FindYourSchoolDetails;
