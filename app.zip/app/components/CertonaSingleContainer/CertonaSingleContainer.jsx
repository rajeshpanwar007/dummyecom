/* eslint-disable jsx-a11y/no-static-element-interactions */

import React, { PureComponent } from 'react';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import truncate from '@bbb-app/utils/truncate';
import { getCookie } from '@bbb-app/utils/universalCookie';
import setPdpTransitionData from '@bbb-app/utils/setPdpTransitionData';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Picture from '@bbb-app/core-ui/picture';
import Img from '@bbb-app/core-ui/image/CoreImage';
import Icon from '@bbb-app/core-ui/icon';
import getConcatenatedScene7URLWithImageId from '@bbb-app/utils/getConcatenatedScene7URLWithImageId';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import {
  CERTONA_PRODUCT_CLICK,
  QV_CERTONA_PRODUCT_CLICK,
  NON_INTERNAL_CAMPAIGN,
  NON_CROSSELL_PRODUCT,
  NON_BROWSE,
  NON_SEARCH,
  QUICK_VIEW,
} from '@bbb-app/tealium/constants';
import Rating from '@bbb-app/rating/Rating';
import { PRODUCT_IMAGE_PLACEHOLDER } from '@bbb-app/constants/appConstants';
import { RATING_MAX } from '@bbb-app/constants/searchConstants';
import { isBrowser } from '@bbb-app/utils/common';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import { getTealiumContainerName } from '@bbb-app/recently-viewed/components/certonaProductClickTealiumHelper';
import styles from './CertonaSingleContainer.css';
import propTypes, { defaultProps } from './props';
import PDPrice from '../../components/Pages/PDP/ProductDetails/Components/PDPPrice/PDPPrice';

import {
  DATA_LOCATOR_PRODUCT_PRICE,
  DATA_LOCATOR_PRODUCT_RATING,
  DATA_LOCATOR_PRODUCT_TITLE,
  DATA_LOCATOR_PRODUCT_IMAGE,
  PAGENAME_BREADCRUMB,
  PAGENAME_PDP,
  SIMILAR_PRODUCTS,
} from '../CertonaProductTile/constants';

import {
  CERTONA_DATA_LOCATOR_HEADING_LABEL,
  PDP,
} from '../../containers/Certona/constants';

import {
  additionalTealiumParms,
  createTealiumImpressionObj,
} from '../CertonaProductTile/certonaTealiumUtil';

/**
 * Helper component for Certona Single Product Container
 * @param {object} props
 *  @param {string} props.className className attribute for the inner button
 * @param {string} props.BADGE Badge attribute for display tags
 * @param {string} props.SCENE7_URL for image ID
 * @param {function} props.SEO_URL for Image url
 * @param {string} props.WAS_PRICE for prev price
 * @param {string} props.IS_PRICE for current price
 * @param {function} props.REVIEWS for review counts
 * @param {string} props.RATINGS for star ratings
 * @param {function} props.ratingTitle for rating titles
 */
// eslint-disable-next-line react/prop-types

class CertonaSingleContainer extends PureComponent {
  static propTypes = propTypes;
  static defaultProps = defaultProps;
  constructor(props) {
    super(props);
    this.onPDPLinkClick = this.onPDPLinkClick.bind(this);
    this.fireTealium = this.fireTealium.bind(this);
    this.handleDropDownClick = this.handleDropDownClick.bind(this);
    this.onPDPLinkClickabTest = this.onPDPLinkClickabTest.bind(this);
  }
  componentDidMount() {
    if (this.props.fireTealiumEvent) {
      const {
        PRODUCT_ID,
        certonaIdentifier,
        routeData,
        fireTealiumAction,
        contextId,
        pageIdentifier,
        RANK,
        recoExp,
        discontinuedProductId,
        groupbySearchId,
      } = this.props;
      const firedFromValue =
        pageIdentifier === 'QuickView_PLP' ? 'QV' : routeData;
      const containerContextId = contextId || discontinuedProductId;
      const tealiumInfo = createTealiumImpressionObj(
        certonaIdentifier,
        firedFromValue,
        PRODUCT_ID,
        '',
        containerContextId,
        recoExp
      );
      if (RANK) tealiumInfo.epic_rank = RANK;
      else tealiumInfo.epic_rank = '';
      tealiumInfo.groupbySearchId = groupbySearchId;
      fireTealiumAction('prc_impression', tealiumInfo, routeData);
      this.props.checktriggerTealiumEvent(false);
    }
  }
  onPDPLinkClick() {
    const { SKU_ID, PRODUCT_ID, DISPLAY_NAME } = this.props;
    setPdpTransitionData(
      `div[data-tile-id="${SKU_ID}"] div img`,
      '',
      '',
      PRODUCT_ID,
      DISPLAY_NAME
    );
    this.fireTealium();
  }

  onPDPLinkClickabTest() {
    const { SKU_ID, PRODUCT_ID, DISPLAY_NAME } = this.props.inStoreItems;
    setPdpTransitionData(
      `div[data-tile-id="${SKU_ID}"] div img`,
      '',
      '',
      PRODUCT_ID,
      DISPLAY_NAME
    );
    if (typeof this.props.track === 'function') {
      this.props.track('InStoreProdRecProdView');
    }
    this.fireTealium();
  }
  getPagewiseValues(certonaIdentifier, routeData, quickViewMode) {
    const containerName = getTealiumContainerName(
      certonaIdentifier,
      this.props.labels,
      this.props.tealiumATCCertonaLabel,
      quickViewMode
    );
    let pageType = 'Quick View';
    let crossellPage = QUICK_VIEW;
    let productFindingMethod = `${containerName} (${QUICK_VIEW})`;
    let pagenameBreadcrumb;
    const displayName = pathOr('', 'productName', this.props);
    if (certonaIdentifier === 'pdp_oos') {
      if (routeData === 'PDP' && !quickViewMode) {
        pageType = PAGENAME_PDP;
        crossellPage = `${PAGENAME_BREADCRUMB}${displayName}`;
        productFindingMethod = `${SIMILAR_PRODUCTS} (${PDP})`;
        pagenameBreadcrumb = `${PAGENAME_BREADCRUMB}${displayName}`;
      }
      if (quickViewMode) {
        if (routeData === 'SearchResults') {
          pagenameBreadcrumb = 'Search';
        }
        if (routeData === 'PLP') {
          pagenameBreadcrumb = pathOr(
            '',
            'plpBreadcrumbInfo.pagename_breadcrumb',
            this.props
          );
        }
        if (routeData === 'BrandLanding') {
          pagenameBreadcrumb = pathOr(
            '',
            'brandInfo.pagename_breadcrumb',
            this.props
          );
        }
      }
    }
    return { pageType, pagenameBreadcrumb, crossellPage, productFindingMethod };
  }

  getCertonaScrollLink = label => {
    return (
      <button
        href="#"
        onClick={this.scrollToCertona}
        className={classnames(styles.lightLink, 'mt15')}
      >
        <span>{label}</span>
      </button>
    );
  };

  get displayTitle() {
    return truncate(this.props.DISPLAY_NAME, 100);
  }
  get displayTitleabTest() {
    const { inStoreItems } = this.props;
    const inStoreItemsValue = inStoreItems && inStoreItems[0];
    return truncate(inStoreItemsValue.DISPLAY_NAME, 100);
  }

  fireTealiumContent(routeData, tealiumTags) {
    if (routeData && routeData.pageIdentifier === 'contentHubGroup') {
      const defaultPathname = pathOr(
        '',
        'locationBeforeTransitions.pathname',
        routeData
      );
      const url = pathOr(
        defaultPathname,
        'locationBeforeTransitions.location.pathname',
        routeData
      );

      let pageName;
      if (url) {
        if (url.includes('/blogs/story')) {
          pageName = `Content Page>Story`;
        } else if (url.includes('/blogs/recipe')) {
          pageName = `Content Page>Recipe`;
        } else if (url.includes('/blogs/section')) {
          pageName = `Content Page>Section`;
        } else if (url.includes('/blogs/tag')) {
          pageName = `Content Page>Tag`;
        } else if (url.includes('/blogs')) {
          pageName = `Content Page`;
        }
      }
      const tealiumData = {
        page_type: 'Content Page',
        pagename_breadcrumb: pageName,
        crossell_page: pageName,
        product_finding_method: pageName,
      };
      const tags = Object.assign({}, tealiumTags, tealiumData);
      if (this.props.fireTealiumAction) {
        this.props.fireTealiumAction('certona product click', tags, '');
      }
    }
  }

  fireTealium() {
    const certonaIdentifier = pathOr('', 'certonaIdentifier', this.props);
    const quickViewMode = pathOr(false, 'quickViewMode', this.props);
    const routeData = pathOr('', 'routeData', this.props);
    const {
      pageType,
      pagenameBreadcrumb,
      crossellPage,
      productFindingMethod,
    } = this.getPagewiseValues(certonaIdentifier, routeData, quickViewMode);
    const productId = pathOr('', 'PRODUCT_ID', this.props);
    const jsessionId = getCookie('JSESSIONID');
    const isModal = quickViewMode || certonaIdentifier === 'AddToCart_rr';
    const callToActionType = isModal
      ? QV_CERTONA_PRODUCT_CLICK
      : CERTONA_PRODUCT_CLICK;
    const pageName = isModal ? QV_CERTONA_PRODUCT_CLICK : CERTONA_PRODUCT_CLICK;
    const firedFromValue = pageType === 'Quick View' ? 'QV' : routeData;
    const tealiumTags = {
      call_to_actiontype: callToActionType,
      page_name: pageName,
      page_type: pageType,
      pagename_breadcrumb: pagenameBreadcrumb,
      jsession_id: jsessionId,
      crossell_page: crossellPage,
      crossell_product: productId || NON_CROSSELL_PRODUCT,
      product_finding_method: productFindingMethod,
      internal_search_term: NON_SEARCH,
      merchandising_category: NON_BROWSE,
      merchandising_main_level: NON_BROWSE,
      merchandising_subcategory: NON_BROWSE,
      internal_campaign: NON_INTERNAL_CAMPAIGN,
      ...additionalTealiumParms(
        certonaIdentifier,
        routeData,
        productId,
        this.props
      ),
    };
    this.fireTealiumContent(firedFromValue, tealiumTags);

    if (
      this.props.certonaIdentifier === 'pdp_oos' &&
      this.props.fireTealiumAction
    ) {
      this.props.fireTealiumAction('certona product click', tealiumTags, '');
    }
  }
  appendStrategy(SEO_URL, certonaIdentifier) {
    if (SEO_URL && certonaIdentifier) {
      return SEO_URL.includes('?')
        ? `&strategy=${certonaIdentifier}`
        : `?strategy=${certonaIdentifier}`;
    }
    return '';
  }
  appendStrategyAbtest(SEO_URL, certonaIdentifier) {
    if (SEO_URL && certonaIdentifier) {
      return SEO_URL.includes('?')
        ? `&strategy=${certonaIdentifier}`
        : `?strategy=${certonaIdentifier}`;
    }
    return '';
  }

  handleDropDownClick(e) {
    e.preventDefault();
    if (this.props.selectedTab === 'All') {
      this.props.storeClickHandler('Facet');
      this.props.track('InStoreProdRecTab');
    } else this.props.storeClickHandler('All');
  }
  scrollToCertona = () => {
    if (isBrowser()) {
      let element = document.getElementById('pdp_cav');
      if (element) {
        element.scrollIntoView({ behavior: 'auto', block: 'center' });
      } else {
        element = document.querySelector('[data-locator=SocialAnnex] div');
        if (element)
          element.scrollIntoView({ behavior: 'auto', block: 'center' });
        setTimeoutCustom(() => {
          element = document.getElementById('pdp_cav');
          if (element)
            element.scrollIntoView({
              behavior: 'auto',
              block: 'center',
            });
        }, 2000);
      }
    }
  };
  render() {
    const {
      SCENE7_URL,
      SEO_URL,
      REVIEWS,
      RATINGS,
      ratingTitle,
      contextPath,
      similarItemsLabels,
      automationLocatorPrefix,
      certonaIdentifier,
      labels,
      enableDynamicPricing,
      otherProductLabel,
      ...item
    } = this.props;

    const hashParam = '#reviews';

    const TitleContainer = props => (
      <PrimaryLink
        href={`${contextPath +
          SEO_URL +
          this.appendStrategy(SEO_URL, certonaIdentifier)}`}
        onClick={this.fireTealium}
        title={SEO_URL}
        {...props}
      />
    );
    const TitleWithDangerousHTML = dangerousHTML(TitleContainer);

    const category = {
      breakpoints: [
        {
          defaultFallback: true,
          breakpoint: 1440,
          mediaquery: 'min-width',
          imageWidth: 140,
          imageHeight: 140,
          preset: '140',
          pixelRatios: [1, 1.5],
        },
        {
          defaultFallback: true,
          breakpoint: 1024,
          mediaquery: 'min-width',
          imageWidth: 120,
          imageHeight: 120,
          preset: '140',
          pixelRatios: [1, 1.5],
        },
        {
          defaultFallback: true,
          breakpoint: 768,
          mediaquery: 'min-width',
          imageWidth: 97,
          imageHeight: 97,
          preset: '140',
          pixelRatios: [1, 1.5],
        },
        {
          defaultFallback: true,
          breakpoint: 425,
          mediaquery: 'min-width',
          imageWidth: 90,
          imageHeight: 90,
          preset: '140',
          pixelRatios: [1, 1.5],
        },
      ],
    };

    const renderSingleProduct = () => {
      return (
        <GridX className="grid-margin-x">
          <Cell
            className={classnames(styles.image, 'auto')}
            data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_IMAGE}`}
          >
            <PrimaryLink
              href={`${contextPath +
                SEO_URL +
                this.appendStrategy(SEO_URL, certonaIdentifier)}`}
            >
              <Picture
                lazyLoadOptions={{
                  placeholder: PRODUCT_IMAGE_PLACEHOLDER,
                }}
                category={category}
                lazyLoad={this.props.isLazyLoad}
              >
                <Img
                  alt={this.displayTitle}
                  src={getConcatenatedScene7URLWithImageId(
                    SCENE7_URL,
                    'certonaImage'
                  )}
                  scene7imageID={SCENE7_URL}
                />
              </Picture>
            </PrimaryLink>
          </Cell>
          <Cell className="auto">
            <div className={styles.productDescription}>
              <PDPrice
                dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_PRICE}`}
                enableDynamicPricing={enableDynamicPricing}
                selectedProduct={item}
                labels={labels}
                fromCertonaSingleContainer
              />
              <header
                className={styles.title}
                title={this.displayTitle}
                data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_TITLE}`}
              >
                <TitleWithDangerousHTML>
                  {this.displayTitle}
                </TitleWithDangerousHTML>
              </header>
              {REVIEWS > 0 ? (
                <PrimaryLink href={`${contextPath + SEO_URL + hashParam}`}>
                  <Rating
                    className={styles.rating}
                    total={REVIEWS}
                    value={RATINGS / RATING_MAX}
                    title={ratingTitle}
                    dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_RATING}`}
                    isNavigable={false}
                  />
                </PrimaryLink>
              ) : null}
            </div>
          </Cell>
        </GridX>
      );
    };
    const renderAbtestSingleProduct = inStoreItems => {
      const inStoreItemsValue = inStoreItems && inStoreItems[0];
      const { isFetching } = this.props;
      return !isFetching &&
        inStoreItemsValue &&
        this.props.selectedTab === 'Facet' ? (
        <GridX className="grid-margin-x">
          <Cell
            className={classnames(styles.image, 'auto')}
            data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_IMAGE}`}
          >
            <PrimaryLink
              href={`${contextPath +
                inStoreItemsValue.SEO_URL +
                this.appendStrategyAbtest(
                  inStoreItemsValue.SEO_URL,
                  certonaIdentifier
                )}`}
              onClick={this.onPDPLinkClickabTest}
            >
              <Picture
                lazyLoadOptions={{
                  placeholder: PRODUCT_IMAGE_PLACEHOLDER,
                }}
                category={category}
                lazyLoad={this.props.isLazyLoad}
              >
                <Img
                  alt={this.displayTitleabTest}
                  src={getConcatenatedScene7URLWithImageId(
                    inStoreItemsValue.SCENE7_URL,
                    'certonaImage'
                  )}
                  scene7imageID={inStoreItemsValue.SCENE7_URL}
                />
              </Picture>
            </PrimaryLink>
          </Cell>
          <Cell className="auto">
            <div className={styles.productDescription}>
              <PDPrice
                dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_PRICE}`}
                enableDynamicPricing={enableDynamicPricing}
                selectedProduct={item}
                labels={labels}
                fromCertonaSingleContainer
              />
              <header
                className={styles.title}
                title={this.displayTitleabTest}
                data-locator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_TITLE}`}
                onClick={this.onPDPLinkClickabTest}
              >
                <TitleWithDangerousHTML>
                  {this.displayTitleabTest}
                </TitleWithDangerousHTML>
              </header>
              {inStoreItemsValue.REVIEWS > 0 ? (
                <PrimaryLink
                  href={`${contextPath +
                    inStoreItemsValue.SEO_URL +
                    hashParam}`}
                >
                  <Rating
                    className={styles.rating}
                    total={inStoreItemsValue.REVIEWS}
                    value={inStoreItemsValue.RATINGS / RATING_MAX}
                    title={ratingTitle}
                    dataLocator={`${automationLocatorPrefix}_${certonaIdentifier}${DATA_LOCATOR_PRODUCT_RATING}`}
                    isNavigable={false}
                  />
                </PrimaryLink>
              ) : null}
            </div>
          </Cell>
        </GridX>
      ) : (
        <SkeletonWrapper
          width={370}
          height={310}
          viewPort={{ height: 310, width: '100%' }}
          rectContainerHeight="100%"
          rectContainerWidth="100%"
          preserveAspectRatio="xMinYMin meet"
          className={classnames(styles.similarItemCertona, 'p2 mb2')}
        >
          <rect x="0" y="0" rx="10" ry="10" width="100%" height="40" />
          <rect x="0" y="50" rx="10" ry="10" width="100%" height="80" />
          <rect x="0" y="150" rx="10" ry="10" width="140" height="170" />
          <rect x="150" y="160" rx="5" ry="5" width="60" height="20" />
          <rect x="150" y="200" rx="10" ry="10" width="170" height="60" />
          <rect x="150" y="280" rx="5" ry="5" width="80" height="15" />
        </SkeletonWrapper>
      );
    };

    const renderHeading = () => {
      if (!this.props.enhancComponent) {
        const dynamicHeadline = pathOr(
          '',
          'pdp_oos',
          this.props.dynamicTitleMap
        );

        return (
          <React.Fragment>
            {similarItemsLabels && (
              <h3
                className={styles.heading}
                data-locator={`${this.props
                  .automationLocatorPrefix}_${certonaIdentifier}${CERTONA_DATA_LOCATOR_HEADING_LABEL}`}
              >
                {!dynamicHeadline &&
                  LabelsUtil.getLabel(similarItemsLabels, 'heading')}
                {dynamicHeadline}
              </h3>
            )}
          </React.Fragment>
        );
      }

      return (
        <React.Fragment>
          {similarItemsLabels && (
            <h3
              className={classnames(styles.heading, 'mb2')}
              data-locator={`${this.props
                .automationLocatorPrefix}_${certonaIdentifier}${CERTONA_DATA_LOCATOR_HEADING_LABEL}`}
            >
              We found a similar product
            </h3>
          )}
        </React.Fragment>
      );
    };
    const renderstoreButton = () => {
      return (
        this.props.enhancComponent && (
          <Cell>
            <div className={classnames(styles.storeDetailsHeading, 'mt2')}>
              <p
                className={styles.availableText}
                data-locator={`${this.props
                  .automationLocatorPrefix}_${certonaIdentifier}${CERTONA_DATA_LOCATOR_HEADING_LABEL}`}
              >
                {avaialbleInLocalStore} &nbsp;
                <span
                  title={avaialbleInLocalStore}
                  onClick={this.handleDropDownClick}
                >
                  <Icon
                    className={classnames(
                      this.props.selectedTab === 'Facet'
                        ? styles.expandSVGIcon
                        : '',
                      `${styles.iconDesign}`
                    )}
                    type="caret"
                    width="12px"
                    height="12px"
                  />
                </span>
              </p>
              <p className={styles.InStoreDropDownstoreText}>
                {this.props.commonName}
              </p>
            </div>
          </Cell>
        )
      );
    };
    const avaialbleInLocalStore = `Available in your local store`;
    return (
      <React.Fragment>
        <PrimaryLink
          href={`${contextPath +
            SEO_URL +
            this.appendStrategy(SEO_URL, certonaIdentifier)}`}
          onClick={this.onPDPLinkClick}
          className={classnames(styles.textDecoration)}
        >
          <article
            className={classnames(styles.certonaSingleContainer)}
            data-tile-id={this.props.SKU_ID}
          >
            {renderHeading()}
            {renderSingleProduct()}
            {renderstoreButton(avaialbleInLocalStore)}
            {this.props.selectedTab === 'Facet' &&
              renderAbtestSingleProduct(this.props.inStoreItems)}
          </article>
        </PrimaryLink>
        {otherProductLabel && this.getCertonaScrollLink(otherProductLabel)}
      </React.Fragment>
    );
  }
}

export default CertonaSingleContainer;
