import { arrayOf, shape, string, bool } from 'prop-types';
import Badge from '../ProductBadge/ProductBadge';

export const defaultProps = {
  attributes: [],
  reviews: 0,
};

export default {
  /** Product attributes to emphasize (e.g. "Wedding Registry Favorite") */
  attributes: arrayOf(string),
  /** The badge anchored to the top (e.g. "Online Only") */
  BADGE: shape(Badge.propTypes),
  /** Additional classes */
  className: string,
  /** Product unique identifier */
  productId: string,
  /** Product image for initial thumbnail */
  SCENE7_URL: string.isRequired,
  /** Flag for indicating the product as "pinned" (e.g. idea boards) */
  /** Product pricing */
  IS_PRICE: string,
  WAS_PRICE: string,
  /** Product review rating (0 - 1) */
  RATINGS: string,
  /** String title for rating ("3 out of 5 stars") */
  ratingTitle: string,
  /** Product review count (1+) */
  REVIEWS: string,
  /** String title for reviews ("100 Reviews") */
  reviewsTitle: string,
  /** Product title */
  DISPLAY_NAME: string.isRequired,
  /** Product URL */
  SEO_URL: string.isRequired,
  selectedTab: string,
  isFetching: bool,
};
