export { default } from './CertonaSingleContainer';
