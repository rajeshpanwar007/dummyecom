import React from 'react';
import { isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import ResponsiveMediaQuery from '@bbb-app/responsive-media-query/ResponsiveMediaQuery';
import SkuInStoreItemList from '../Pages/PDP/SkuInStoreItemList/SkuInStoreItemList';

export const StoreListComponent = props => {
  const {
    deviceConfig,
    storeList,
    labels,
    distanceMap,
    specialityCodes,
    switchConfig,
    isLoggedIn,
    findAStoreModal,
    setFavoriteStoreId,
    setStoreDetails,
    closeModal,
    accountProfile,
    removeFavoriteStore,
    addFavoriteStore,
    googleMapDirectionUrl,
    selectStore,
    selectedStore,
    ShouldCheckBoxSelected,
    pageIdentifier,
    storeCount,
    displayClosestStoreBadge,
    changeStore,
    showSelectStore,
    displayBookAnAppointment,
    storeListByAddress,
    customEventsModal,
    triggerStoreSearchTealiumEvent,
    isEditRegistryModalOpen,
    createPickUpInStore,
    channelType,
    activeRegistry,
    pathname,
    pickUpStore,
    pickUpStoreLabel,
    isPNHDashboard,
    localStoreHeading,
    findStorePage,
    setSDDOptionSelection,
    isForEventsPage,
    storeEventList,
    toggleParentUnderlay,
    toggleStoreEventModal,
    isBopisFilter,
    resetNearestStoreState,
    updateSelectedFilter,
    renderGoogleDfp,
  } = props;

  const handleEventStores = () => {
    if (isForEventsPage) {
      return !isEmpty(storeEventList) ? storeEventList : [];
    }
    return !isEmpty(storeListByAddress) ? storeListByAddress : storeList;
  };

  const storeListData = handleEventStores();

  return (
    <ErrorBoundary>
      <ResponsiveMediaQuery maxWidth={deviceConfig.TABLET - 1}>
        <SkuInStoreItemList
          storeList={storeListData}
          labels={labels}
          distanceMap={distanceMap}
          specialityCodes={specialityCodes}
          isFindAStore
          switchConfig={switchConfig}
          isLoggedIn={isLoggedIn}
          findAStoreModal={findAStoreModal}
          changeStore={changeStore}
          setFavoriteStoreId={setFavoriteStoreId}
          setStoreDetails={setStoreDetails}
          isEditRegistryModalOpen={isEditRegistryModalOpen}
          closeModal={closeModal}
          isMobile
          findStorePage={findStorePage}
          setSDDOptionSelection={setSDDOptionSelection}
          accountProfile={accountProfile}
          addFavoriteStore={addFavoriteStore}
          removeFavoriteStore={removeFavoriteStore}
          googleMapDirectionUrl={googleMapDirectionUrl}
          selectStore={selectStore}
          selectedStore={selectedStore}
          ShouldCheckBoxSelected={ShouldCheckBoxSelected}
          pageIdentifier={pageIdentifier}
          storeCount={storeCount}
          displayClosestStoreBadge={displayClosestStoreBadge}
          showSelectStore={showSelectStore}
          displayBookAnAppointment={displayBookAnAppointment}
          customEventsModal={customEventsModal}
          fireTealiumAction={triggerStoreSearchTealiumEvent}
          createPickUpInStore={createPickUpInStore}
          channelType={channelType}
          activeRegistry={activeRegistry}
          pathname={pathname}
          pickUpStore={pickUpStore}
          pickUpStoreLabel={pickUpStoreLabel}
          isPNHDashboard={isPNHDashboard}
          localStoreHeading={localStoreHeading}
          isForEventsPage={isForEventsPage}
          toggleParentUnderlay={toggleParentUnderlay}
          toggleStoreEventModal={toggleStoreEventModal}
          isBopisFilter={isBopisFilter}
          resetNearestStoreState={resetNearestStoreState}
          updateSelectedFilter={updateSelectedFilter}
          renderGoogleDfp={renderGoogleDfp}
        />
      </ResponsiveMediaQuery>
      <ResponsiveMediaQuery minWidth={deviceConfig.TABLET}>
        <SkuInStoreItemList
          storeList={storeListData}
          labels={labels}
          distanceMap={distanceMap}
          specialityCodes={specialityCodes}
          isFindAStore
          findStorePage={findStorePage}
          setSDDOptionSelection={setSDDOptionSelection}
          switchConfig={switchConfig}
          isLoggedIn={isLoggedIn}
          findAStoreModal={findAStoreModal}
          changeStore={changeStore}
          setFavoriteStoreId={setFavoriteStoreId}
          setStoreDetails={setStoreDetails}
          isEditRegistryModalOpen={isEditRegistryModalOpen}
          closeModal={closeModal}
          accountProfile={accountProfile}
          addFavoriteStore={addFavoriteStore}
          removeFavoriteStore={removeFavoriteStore}
          googleMapDirectionUrl={googleMapDirectionUrl}
          selectStore={selectStore}
          selectedStore={selectedStore}
          ShouldCheckBoxSelected={ShouldCheckBoxSelected}
          pageIdentifier={pageIdentifier}
          storeCount={storeCount}
          displayClosestStoreBadge={displayClosestStoreBadge}
          showSelectStore={showSelectStore}
          displayBookAnAppointment={displayBookAnAppointment}
          customEventsModal={customEventsModal}
          fireTealiumAction={triggerStoreSearchTealiumEvent}
          createPickUpInStore={createPickUpInStore}
          channelType={channelType}
          activeRegistry={activeRegistry}
          pathname={pathname}
          pickUpStore={pickUpStore}
          pickUpStoreLabel={pickUpStoreLabel}
          isPNHDashboard={isPNHDashboard}
          localStoreHeading={localStoreHeading}
          isForEventsPage={isForEventsPage}
          toggleParentUnderlay={toggleParentUnderlay}
          toggleStoreEventModal={toggleStoreEventModal}
          isBopisFilter={isBopisFilter}
          resetNearestStoreState={resetNearestStoreState}
          updateSelectedFilter={updateSelectedFilter}
          renderGoogleDfp={renderGoogleDfp}
        />
      </ResponsiveMediaQuery>
    </ErrorBoundary>
  );
};

StoreListComponent.propTypes = {
  labels: PropTypes.object.isRequired,
  deviceConfig: PropTypes.object.isRequired,
  switchConfig: PropTypes.object,
  specialityCodes: PropTypes.array.isRequired,
  findAStoreModal: PropTypes.bool,
  setFavoriteStoreId: PropTypes.func,
  setStoreDetails: PropTypes.func,
  closeModal: PropTypes.func,
  storeList: PropTypes.array,
  distanceMap: PropTypes.object,
  isLoggedIn: PropTypes.bool,
  accountProfile: PropTypes.object.isRequired,
  removeFavoriteStore: PropTypes.func.isRequired,
  addFavoriteStore: PropTypes.func.isRequired,
  googleMapDirectionUrl: PropTypes.object,
  selectStore: PropTypes.func.isRequired, // Action to select store for non logged in user
  selectedStore: PropTypes.string, // Selected store id in case of non logged in user
  triggerStoreSearchTealiumEvent: PropTypes.func,
  ShouldCheckBoxSelected: PropTypes.func,
  pageIdentifier: PropTypes.string,
  storeCount: PropTypes.any,
  changeStore: PropTypes.bool,
  displayClosestStoreBadge: PropTypes.bool,
  showSelectStore: PropTypes.bool,
  displayBookAnAppointment: PropTypes.bool,
  storeListByAddress: PropTypes.array,
  customEventsModal: PropTypes.bool,
  isEditRegistryModalOpen: PropTypes.bool,
  createPickUpInStore: PropTypes.bool,
  channelType: PropTypes.string,
  activeRegistry: PropTypes.object,
  pathname: PropTypes.string,
  pickUpStore: PropTypes.object,
  pickUpStoreLabel: PropTypes.string,
  isPNHDashboard: PropTypes.bool,
  localStoreHeading: PropTypes.string,
  findStorePage: PropTypes.bool,
  isForEventsPage: PropTypes.bool,
  storeEventList: PropTypes.array,
  toggleParentUnderlay: PropTypes.func,
  setSDDOptionSelection: PropTypes.func,
  toggleStoreEventModal: PropTypes.func,
  isBopisFilter: PropTypes.any,
  resetNearestStoreState: PropTypes.func,
  updateSelectedFilter: PropTypes.func,
  renderGoogleDfp: PropTypes.func,
};

export default StoreListComponent;
