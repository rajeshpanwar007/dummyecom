/* eslint max-lines: ["error", 1130]*/
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { isUndefined, isEmpty, uniq, keyBy, sortBy } from 'lodash';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import ServiceUtil from '@bbb-app/utils/serviceUtil';
import { makeStoresData } from '@bbb-app/context/stores-context/makeStoresData';
import {
  scrollToElement,
  getElementHeight,
  isBedBathCanada,
  isBrowser,
} from '@bbb-app/utils/common';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Button from '@bbb-app/core-ui/button';
import { isTbs } from '@bbb-app/utils/isTbs';
import getLatLongFromCookie from '@bbb-app/utils/getLatLongFromCookie';
import FormWrapper from '@bbb-app/forms/containers/FormWrapper/FormWrapper';
import FormInput from '@bbb-app/forms/containers/FormInput/FormInput';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import statesCAContext from '@bbb-app/context/states-ca-context/statesCAContext';
import ResponsiveMediaQuery from '@bbb-app/responsive-media-query/ResponsiveMediaQuery';
import GoogleDfp from '@bbb-app/google-dfp/containers/GoogleDfp.async';
import '@bbb-app/assets/icons/locations.svg';
import StoresFound from '@bbb-app/search-stores/components/stores-found';
import MapQuest from '@bbb-app/search-stores/components/map-quest';
import { searchStoreTealium } from '@bbb-app/search-stores/components/searchStoreTealium';
import Skeleton from '@bbb-app/search-stores/components/stores-found/skeleton';
import StoreListComponent from './StoreList';
import inlineStyles from './SearchStores.inline.css';
import styles from './SearchStores.css';
import FilterList from '../Filters/FilterList';

const storesConfig = makeStoresData();
// eslint-disable-next-line no-underscore-dangle
const canadaStates = statesCAContext._currentValue;
class SearchStores extends React.PureComponent {
  constructor(props) {
    super(props);
    const { searchRadius, filterData } = props;
    const isCanada = isBedBathCanada();
    const bbbystores = pathOr(false, 'bbbystores', props.queryString);
    const babystores = pathOr(false, 'babystores', props.queryString);
    const filter = [];
    filterData.forEach(filterItemData => {
      if (
        filterItemData.selected &&
        !(
          isCanada &&
          ((filterItemData.key === 'store-10' && !bbbystores && babystores) ||
            (filterItemData.key === 'store-40' && bbbystores && !babystores))
        )
      ) {
        filter.push(filterItemData.key);
      }
    });
    this.state = {
      radiusField: searchRadius.default,
      isStoresSearched: false,
      filter,
      originApplied: '',
      isCurrentLocation: false,
      locationError: false,
      isCanada,
    };
    this.onFilterSelectionUpdate = this.onFilterSelectionUpdate.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCurrentLocation = this.handleCurrentLocation.bind(this);
    this.handleApplyFilter = this.handleApplyFilter.bind(this);
    this.fireTealiumEvent = this.fireTealiumEvent.bind(this);
    this.handleProvinceClick = this.handleProvinceClick.bind(this);
    this.getAvailableCanadaStores = this.getAvailableCanadaStores.bind(this);
    this.handleEventStores = this.handleEventStores.bind(this);
    this.handleEventStoresDataList = this.handleEventStoresDataList.bind(this);
    this.renderGoogleDfp = this.renderGoogleDfp.bind(this);
  }

  componentDidMount() {
    const props = this.props;
    this.renderSearchResults(props);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.isPNHDashboard && typeof window !== 'undefined') {
      document.getElementById('selectStoreWrraper').scrollIntoView();
    }
    if (
      (this.props.clickFromPLPTile &&
        (nextProps.selectedSKUId &&
          nextProps.selectedSKUId !== this.props.selectedSKUId)) ||
      (nextProps.queryString &&
        nextProps.queryString !== this.props.queryString)
    ) {
      this.renderSearchResults(nextProps);
    }
  }

  /**
   * Handles filter change event
   *
   * @param {string} id id of filter
   * @param {Array} selections The selected items
   *
   */
  onFilterSelectionUpdate = (id, selections) => {
    this.setState({
      filter: selections,
    });
  };

  /**
   * Returns filter array, based on current siteId, to send as params for mapQuest API
   * in case of Find a Store modal.
   *
   * @returns {array} Array of store-id
   */
  getFilterId() {
    const { siteId } = this.props;
    const configArray = storesConfig.map(configObj => {
      if (configObj.siteId === siteId) {
        return configObj.key;
      }
      return null;
    });

    return configArray.filter(val => val);
  }

  getAvailableCanadaStores = storeDataList =>
    uniq(
      storeDataList &&
        storeDataList.searchResults &&
        storeDataList.searchResults.map(item => item.fields.state)
    );

  getCookieZip() {
    const { akamaiHeader, isPickupInStore, findAStoreModal } = this.props;
    let cookieZip;
    if (isPickupInStore && !findAStoreModal) {
      const existingLatLong = getLatLongFromCookie('latLngCookie');
      cookieZip = existingLatLong
        ? existingLatLong.postalCode.split(/[-,+]/)[0]
        : pathOr(null, 'data.zip', akamaiHeader);
    }
    return cookieZip;
  }

  fireTealiumEvent(isCurrentLocationCall) {
    const {
      tealiumFindStoreSearchData,
      tealiumPathName,
      cartState,
      triggerStoreSearchTealiumEvent,
      isQuickViewOpen,
    } = this.props;
    const MYACCOUNT_PAGETYPE = 'Find_A_Store';
    if (triggerStoreSearchTealiumEvent) {
      const tealiumTags = searchStoreTealium(
        cartState,
        tealiumFindStoreSearchData,
        tealiumPathName,
        isQuickViewOpen,
        this.props.breadcrumbTealiumData,
        isCurrentLocationCall
      );
      let actionType;
      let pageType;
      if (tealiumTags) {
        actionType = tealiumTags.ACTION_TYPE;
        pageType = tealiumTags.PAGE_TYPE;
        delete tealiumTags.ACTION_TYPE;
        delete tealiumTags.PAGE_TYPE;
      }
      if (pageType === MYACCOUNT_PAGETYPE) {
        triggerStoreSearchTealiumEvent(actionType, tealiumTags, pageType);
      }
    }
  }

  search(
    searchField,
    radiusField,
    newSearch = false,
    latLong = false,
    nextSelectedSKUId
  ) {
    const {
      selectedSKUId,
      onSearchSubmit,
      setRegistrySearchFlag,
      findAStoreModal,
      quantity,
      favoriteStoreDetails,
      isFindAStore,
      isForEventsPage,
      contentId,
    } = this.props;
    const { filter } = this.state;
    const favoriteStoreId = pathOr('', '[0].storeId', favoriteStoreDetails);
    this.setState({
      isStoresSearched: true,
      originApplied: searchField.value,
      isCurrentLocation: false,
    });
    if (setRegistrySearchFlag && findAStoreModal) {
      setRegistrySearchFlag(true);
      this.setState({ searchField: '' });
    }
    /**
     * Calling onSearchSubmit with different params, based on findAStoreModal flag. Flag is true
     * in case of change store cta on create/edit registry.
     */
    if (findAStoreModal) {
      const filterId = this.getFilterId();
      onSearchSubmit({
        address: searchField.value,
        radius: radiusField.value ? radiusField.value : this.state.radiusField,
        selectedSKUId,
        filter: filterId,
        quantity,
        favoriteStoreId,
      });
    } else if (latLong) {
      onSearchSubmit({
        radius: this.state.radiusField,
        filter,
        selectedSKUId: isTbs() ? selectedSKUId : null,
        quantity: isTbs() ? quantity : null,
        latitude: searchField.value.lat,
        longitude: searchField.value.lng,
        favoriteStoreId,
        isFindAStore,
      });
    } else if (isForEventsPage) {
      onSearchSubmit({
        address: searchField.value,
        radius: radiusField.value || this.state.radiusField,
        selectedSKUId,
        filter,
        quantity,
        favoriteStoreId,
        newSearch,
        isForEventsPage,
        contentId,
      });
    } else {
      onSearchSubmit({
        address: searchField.value,
        radius: radiusField.value ? radiusField.value : this.state.radiusField,
        selectedSKUId: nextSelectedSKUId || selectedSKUId,
        filter,
        quantity,
        favoriteStoreId,
        newSearch,
        isFindAStore,
      });
      if (this.props.resetshowAvailableStores)
        this.props.resetshowAvailableStores();
    }
    this.fireTealiumEvent(false);
  }

  triggerSearch(zip, searchRadius, nextSelectedSKUId) {
    const searchField = { value: zip };
    const radiusField = { value: searchRadius };
    this.search(searchField, radiusField, false, false, nextSelectedSKUId);
  }

  triggerSearchStore(lat, lng, searchRadius) {
    const searchField = {
      value: {
        lat,
        lng,
      },
    };
    const radiusField = { value: searchRadius };
    this.search(searchField, radiusField, false, true);
  }

  /**
   * @param {event} event
   * Handles search stores form submission
   */
  handleSubmit(obj) {
    const { searchField, radiusField } = this.props.formWrapperData;
    const hasErrors = Object.keys(obj).length;
    if (!hasErrors) {
      this.search(searchField, radiusField, true);
      if (this.props.isForEventsPage) this.props.zipModalSubmitted(true);
    }
  }

  /**
   * @param {event} event
   * Handles click on province links under heading to scroll to respective results.
   */
  handleProvinceClick = (e, link) => {
    e.preventDefault();
    scrollToElement(link, -getElementHeight('header'));
  };

  /**
   * Gets current location zip code
   */
  /* istanbul ignore next */
  fetchZipFromLocation(latitude, longitude) {
    if (!latitude || !longitude) {
      return Promise.reject('Lat/Long Missing');
    }
    const { key, reverseURL } = this.props.mapQuestConfig;

    const param = {
      key,
      location: `${latitude},${longitude}`,
    };
    return ServiceUtil.triggerServerRequest({
      url: reverseURL,
      method: 'GET',
      params: param,
    }).then(data => data.body.results[0].locations[0].postalCode);
  }

  /**
   * Handles current location CTA click
   */
  /* istanbul ignore next */
  handleCurrentLocation() {
    // Reset search form field.
    const { formWrapperData, clearForm } = this.props;
    clearForm({
      obj: { searchField: formWrapperData.searchField },
      identifier: this.props.identifier || 'SearchStore',
    });
    const success = position => {
      const {
        onSearchSubmit,
        selectedSKUId,
        favoriteStoreDetails,
        quantity,
      } = this.props;
      const { latitude, longitude } = position.coords;
      // Need the zip to save in store for subsequent auto-search
      this.fetchZipFromLocation(latitude, longitude)
        .then(zip => {
          const { filter, isCanada } = this.state;
          const { radiusField } = this.props.formWrapperData;
          const favoriteStoreId = pathOr(
            '',
            '[0].storeId',
            favoriteStoreDetails
          );
          this.setState({
            isCurrentLocation: true,
            locationError: false,
          });
          if (isCanada) {
            const filterId = this.getFilterId();
            onSearchSubmit({
              address: zip,
              radius: radiusField.value
                ? radiusField.value
                : this.state.radiusField,
              selectedSKUId,
              filter: filterId,
              quantity,
              favoriteStoreId,
              isFindAStore: false,
            });
          } else {
            onSearchSubmit({
              address: zip,
              radius: radiusField.value
                ? radiusField.value
                : this.state.radiusField,
              filter,
              selectedSKUId,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              quantity,
              favoriteStoreId,
              newSearch: true,
            });
          }
        })
        .catch(() => {
          this.setState({
            locationError: true,
          });
        });
    };
    const error = () => {
      this.setState({
        locationError: true,
      });
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(success, error);
    } else {
      this.setState({
        locationError: true,
      });
    }
    this.fireTealiumEvent(true);
  }

  /**
   * Handles apply filter CTA on mobile
   */
  handleApplyFilter() {
    const { searchField } = this.state;
    if (searchField) {
      this.handleSubmit();
    }
  }

  handleEventStores(
    eventPage,
    storeAddresList,
    originalStoreList,
    eventStoreList
  ) {
    if (eventPage) {
      return eventStoreList;
    }
    return !isEmpty(storeAddresList) ? storeAddresList : originalStoreList;
  }

  handleEventStoresDataList(eventPage, storeResults, stores, eventStoreList) {
    if (eventPage) {
      return eventStoreList;
    }
    return !isEmpty(storeResults) ? storeResults : stores;
  }

  /* eslint complexity: ["error", 11]*/
  renderSearchResults(props) {
    const favoriteStoreDetails = props.favoriteStoreDetails
      ? props.favoriteStoreDetails[0]
      : null;
    const lat = favoriteStoreDetails ? favoriteStoreDetails.latitude : '';
    const lng = favoriteStoreDetails ? favoriteStoreDetails.longitude : '';
    const tbsLat = pathOr(null, 'currentStoreDetails.latitude', props);
    const tbsLng = pathOr(null, 'currentStoreDetails.longitude', props);
    const { searchRadius, queryString, clickFromPLPTile } = props;
    const landingZip = props.searchedZip || props.landingZip;
    const cookieZip = this.getCookieZip();
    if (
      isTbs() &&
      tbsLat &&
      tbsLng &&
      props.tbsCheck &&
      !props.findAStoreModal
    ) {
      this.triggerSearchStore(tbsLat, tbsLng, searchRadius);
    } else if (queryString && queryString.searchStoreParam) {
      this.triggerSearch(queryString.searchStoreParam, searchRadius.default);
    } else if (landingZip) {
      this.triggerSearch(landingZip, searchRadius.default);
    } else if (lat && lng && props.findStorePage) {
      this.triggerSearchStore(lat, lng, searchRadius);
    } else if (this.state.isCanada && this.props.isFindAStore) {
      this.triggerSearchStore(searchRadius);
    } else if (cookieZip) {
      if (clickFromPLPTile) {
        this.triggerSearch(
          cookieZip,
          searchRadius.default,
          props.selectedSKUId
        );
      } else {
        this.triggerSearch(cookieZip, searchRadius.default);
      }
    }
  }
  /**
   * Renders search text field along with its validation
   */
  renderSearchField() {
    const { labels, formWrapperData, isForEventsPage, isMobile } = this.props;
    return (
      <div
        className={classnames(
          styles.searchField,
          inlineStyles.searchField,
          'sm-mb2',
          'md-mb0',
          {
            [styles.eventsSearchField]: isForEventsPage,
            [styles.searchCa]: this.state.isCanada && isMobile,
          }
        )}
      >
        <FormInput
          id="searchField"
          name="searchField"
          type="text"
          isRequired
          label={LabelsUtil.getLabel(labels, 'searchField')}
          labelPosition="append"
          value={formWrapperData && formWrapperData.searchField.value}
          searchFieldError={
            formWrapperData && formWrapperData.searchField.searchFieldError
          }
          identifier={this.props.identifier || 'SearchStore'}
          validation="storeLocatorOmnibarInput"
          aria-label={LabelsUtil.getLabel(labels, 'searchField')}
          data-locator="findAStorePage-searchField"
        />
      </div>
    );
  }

  renderErrorMessage(labels) {
    return (
      <p role="alert" className="validationErrorMessage">
        {LabelsUtil.getLabel(labels, 'locationError')}
      </p>
    );
  }
  /**
   * Renders search radius drop down
   */
  renderSearchRadius() {
    const {
      labels,
      searchRadius,
      deviceConfig,
      formWrapperData,
      isForEventsPage,
      isMobile,
    } = this.props;
    return (
      <div
        className={classnames(
          styles.radiusField,
          inlineStyles.radiusField,
          'sm-mb15',
          'md-mb0',
          {
            'display-none': isForEventsPage,
            [styles.searchCa]: this.state.isCanada && isMobile,
          }
        )}
      >
        <ResponsiveMediaQuery minWidth={deviceConfig.TABLET}>
          <FormInput
            id="radiusField"
            type="select"
            name="radiusField"
            labelStyle="inlineLabel"
            label={LabelsUtil.getLabel(labels, 'radiusField')}
            optionSet={searchRadius.options}
            defaultValue={
              isUndefined(formWrapperData)
                ? this.state.radiusField
                : formWrapperData.radiusField.value
            }
            radiusFieldError={
              formWrapperData && formWrapperData.radiusField.radiusFieldError
            }
            identifier={this.props.identifier || 'SearchStore'}
            validation="radiusField"
            description={LabelsUtil.getLabel(labels, 'radiusField')}
            data-locator="findAStorePage-searchRadiusDropdown"
          />
        </ResponsiveMediaQuery>
        <ResponsiveMediaQuery maxWidth={deviceConfig.TABLET - 1}>
          <FormInput
            id="radiusField"
            type="select"
            name="radiusField"
            labelStyle="inlineLabel"
            label={LabelsUtil.getLabel(labels, 'radiusField')}
            optionSet={searchRadius.options}
            modalSelectionHeading={LabelsUtil.getLabel(labels, 'radiusField')}
            modalSelectionMobile
            modalBreakpoint={deviceConfig.TABLET}
            defaultValue={
              isUndefined(formWrapperData)
                ? this.state.radiusField
                : formWrapperData.radiusField.value
            }
            radiusFieldError={
              formWrapperData && formWrapperData.radiusField.radiusFieldError
            }
            identifier={this.props.identifier || 'SearchStore'}
            validation="radiusField"
            data-locator="findAStorePage-searchRadiusDropdown"
          />
        </ResponsiveMediaQuery>
      </div>
    );
  }
  /**
   * Renders filter
   */
  renderFilter() {
    const { labels, filterData, deviceConfig, isForEventsPage } = this.props;
    const { filter } = this.state;
    const noOfFilters = filter.length ? ` (${filter.length})` : '';
    return (
      <ErrorBoundary>
        <ResponsiveMediaQuery maxWidth={deviceConfig.TABLET - 1}>
          <FilterList
            id="filters"
            label={`${LabelsUtil.getLabel(
              labels,
              'filtersField'
            )}${noOfFilters}`}
            data={filterData}
            type="field"
            modalSelectionMobile
            modalBreakpoint={1024}
            modalSelectionHeading={LabelsUtil.getLabel(labels, 'filter')}
            filterBtnVariation="adjustableWidth"
            filterButtonClass={classnames('fullWidth')}
            styles={classnames(
              styles.specialityCodesFilter,
              inlineStyles.specialityCodesFilter,
              'sm-mb3',
              'md-mb0',
              { 'display-none': isForEventsPage }
            )}
            onSelectionUpdate={this.onFilterSelectionUpdate}
            selectedItems={filter}
            optionsContainerAlignment="right"
            submitButtonLabel={LabelsUtil.getLabel(labels, 'applyFilterLabel')}
            submitHandler={this.handleApplyFilter}
            allowHeaders
            collapseDropdown={false}
            data-locator={this.props.locator}
          />
        </ResponsiveMediaQuery>
        <ResponsiveMediaQuery minWidth={deviceConfig.TABLET}>
          <FilterList
            id="filters"
            label={`${LabelsUtil.getLabel(
              labels,
              'filtersField'
            )}${noOfFilters}`}
            data={filterData}
            type="field"
            modalBreakpoint={deviceConfig.TABLET}
            modalSelectionHeading={LabelsUtil.getLabel(labels, 'filter')}
            filterBtnVariation="adjustableWidth"
            filterButtonClass={classnames('fullWidth')}
            styles={classnames(
              styles.specialityCodesFilter,
              inlineStyles.specialityCodesFilter,
              {
                'display-none': isForEventsPage,
              }
            )}
            onSelectionUpdate={this.onFilterSelectionUpdate}
            selectedItems={filter}
            optionsContainerAlignment="right"
            allowHeaders
            containerClass={classnames(
              styles.specialityCodesFilter,
              inlineStyles.specialityCodesFilter
            )}
            collapseDropdown={false}
            data-locator={this.props.locator}
          />
        </ResponsiveMediaQuery>
      </ErrorBoundary>
    );
  }

  renderGoogleDfp(banner, index) {
    const { googleDFPConfig, findAStoreModal, findStorePage } = this.props;
    if (!googleDFPConfig || !googleDFPConfig.FindAStore) {
      return null;
    }
    const type = index === 0 ? 'BelowResults' : `BelowResults${index}`;
    const adSlot = {};
    adSlot[banner] = {
      type,
      showAds: true,
    };
    const googConfig = { ...googleDFPConfig.FindAStore, ...adSlot };
    const data = googConfig[banner];
    return !findAStoreModal && findStorePage && data && data.showAds ? (
      <Cell className={classnames('large-10')}>
        <GoogleDfp
          nonExperienceDrivenData={data}
          isFromNonExperience
          findStorePage
          findStoreIndex={index}
        />
      </Cell>
    ) : null;
  }

  renderPNHStoredataList() {
    const { storeResults, pickUpStore, isPNHDashboard } = this.props;
    let storeDataListPNH = '';
    if (storeResults && isPNHDashboard && pickUpStore) {
      storeDataListPNH = storeResults.searchResults.filter(
        item => item.fields.RecordId === pickUpStore.storeId
      );
      storeResults.searchResults = storeDataListPNH;
    }
    return storeResults;
  }

  renderToggleStoreList(storeDataList) {
    const { isPNHDashboard } = this.props;
    return isPNHDashboard ? this.renderPNHStoredataList() : storeDataList;
  }

  renderStoreListing = () => {
    const {
      isForEventsPage,
      isFetchingStores,
      findAStoreModal,
      storeEventList,
    } = this.props;
    if (isForEventsPage || !isFetchingStores) {
      const listingNode =
        isBrowser() && document.getElementById('renderListing');
      if (findAStoreModal && listingNode) {
        return ReactDOM.createPortal(
          <StoreListComponent
            {...this.props}
            storeEventList={storeEventList}
            isBopisFilter={this.props.isBopisFilter}
          />,
          listingNode
        );
      }
      return (
        <StoreListComponent
          {...this.props}
          storeEventList={storeEventList}
          renderGoogleDfp={this.renderGoogleDfp}
        />
      );
    }
    return null;
  };

  renderStoreLoadingSekelton = () => {
    const { isFetchingStores, findAStoreModal } = this.props;
    if (isFetchingStores) {
      const skeletonNode = document.getElementById('lodingstores');

      if (findAStoreModal && skeletonNode) {
        return ReactDOM.createPortal(
          <Cell className={classnames('large-10')}>
            <Skeleton />
          </Cell>,
          skeletonNode
        );
      }
      return null;
    }
    return null;
  };

  /* eslint complexity: ["error", 17]*/
  render() {
    const {
      labels,
      gridXClass,
      cellClass,
      isFilterVisible,
      isPickupInStore,
      isFetchingStores,
      stores,
      deviceConfig,
      mapQuestConfig,
      storeList,
      registrySearchFlag,
      findAStoreModal,
      startNewSearchHandler,
      formWrapperData,
      locationName,
      initOnModalMount,
      noBorderTop,
      noPaddingTop,
      storeResults,
      storeListByAddress,
      isFindAStore,
      findStorePage,
      renderMapOnEachLoad,
      localStoreHeading,
      isPNHDashboard,
      isForEventsPage,
      zipSubmitted,
      storeEventList,
      isFetchingEventStores,
      startNewEventModal,
      enableFindStoreSearchViewOnCanada,
    } = this.props;
    const { isCanada } = this.state;
    const storeDataList = this.handleEventStoresDataList(
      isForEventsPage,
      storeResults,
      stores,
      storeEventList
    );
    const storeListData = this.handleEventStores(
      isForEventsPage,
      storeListByAddress,
      storeList,
      storeEventList
    );
    const { originApplied, isCurrentLocation, locationError } = this.state;
    const currentLocationMsg = LabelsUtil.getLabel(
      labels,
      'yourCurrentLocation'
    );
    let displayLocation;
    if (locationName) {
      displayLocation = locationName;
    } else {
      displayLocation =
        isCurrentLocation || typeof originApplied === 'object'
          ? currentLocationMsg
          : originApplied;
    }
    let availableRegionsInCanada = [];
    let canadaRegionData = {};
    let isCanadaFindAStore = false;
    // Returns only the states that are available in the store results and excludes states that do not have BBB stores.
    if (!enableFindStoreSearchViewOnCanada) {
      availableRegionsInCanada = sortBy(
        this.getAvailableCanadaStores(storeDataList)
      );
      // Converts array to easily-mappable objects with states as each object.
      canadaRegionData = keyBy(canadaStates, 'props.value');
      isCanadaFindAStore = isCanada && isFindAStore;
    }

    return (
      <GridX
        className={classnames(
          gridXClass,
          !registrySearchFlag && {
            [styles.pickupInStore]: isPickupInStore || findAStoreModal,
            [styles.borderSetting]: isPickupInStore && isFindAStore,
          }
        )}
      >
        {!enableFindStoreSearchViewOnCanada &&
          isCanadaFindAStore &&
          isBrowser() && (
            <React.Fragment>
              {isFetchingStores && (
                <Cell className={classnames('large-10')}>
                  <Skeleton />
                </Cell>
              )}
              {!isFetchingStores && (
                <Cell
                  className={classnames(
                    styles.stateLinks,
                    'large-10',
                    'lg-py3',
                    'sm-pt2 sm-pb3 borderBottom'
                  )}
                  id="scrollToStateLinks"
                >
                  {availableRegionsInCanada.map(item => (
                    <li>
                      <PrimaryLink
                        href={`#linkTo${item}`}
                        onClick={e =>
                          this.handleProvinceClick(
                            e,
                            `#linkTo${canadaRegionData[item].props.value}`
                          )}
                      >
                        {canadaRegionData[item].name}
                      </PrimaryLink>
                    </li>
                  ))}
                </Cell>
              )}
            </React.Fragment>
          )}

        <Cell
          className={classnames(cellClass, {
            mb2: !findStorePage,
          })}
        >
          <FormWrapper
            noValidate
            onSubmit={this.handleSubmit}
            formWrapperData={formWrapperData}
            styles={styles}
            identifier={this.props.identifier || 'SearchStore'}
          >
            {!registrySearchFlag &&
              (!isCanadaFindAStore ||
                (enableFindStoreSearchViewOnCanada && isCanadaFindAStore)) && (
                <React.Fragment>
                  <div
                    className={classnames(
                      inlineStyles.searchStores,
                      styles.searchStores,
                      'flex',
                      'justify-between',
                      styles.blockContainer,
                      {
                        [styles.eventsForm]: isForEventsPage,
                        'display-none': zipSubmitted,
                      }
                    )}
                  >
                    {this.renderSearchField()}
                    {this.renderSearchRadius()}
                    {isFilterVisible && this.renderFilter()}
                    <div
                      className={classnames(
                        styles.searchBtn,
                        inlineStyles.searchBtn,
                        {
                          [styles.eventBtnWrapper]: isForEventsPage,
                        }
                      )}
                    >
                      <Button
                        id="seachStoresSubmit"
                        type="submit"
                        theme="secondary"
                        variation="fullWidth"
                        aria-label="Search stores submit"
                        className={classnames('md-mb0', {
                          [styles.eventSearchBtn]: isForEventsPage,
                        })}
                        data-locator="findAStorePage-searchButton"
                      >
                        {LabelsUtil.getLabel(labels, 'searchButton')}
                      </Button>
                    </div>
                  </div>
                  <div
                    className={classnames(
                      cellClass,
                      styles.currentLocation,
                      'sm-pb15',
                      'md-pb3',
                      {
                        [styles.eventCurrentLocation]: isForEventsPage,
                        'display-none': isForEventsPage || zipSubmitted,
                      },
                      !isFindAStore && styles.setPadding
                    )}
                  >
                    <Button
                      theme={!isFindAStore ? 'ghost' : 'ghostDark'}
                      iconProps={
                        !isFindAStore
                          ? null
                          : {
                              type: 'locations',
                            }
                      }
                      variation="noPadding"
                      onClick={this.handleCurrentLocation}
                    >
                      {LabelsUtil.getLabel(labels, 'useCurrentLocation')}
                    </Button>
                    {/* Unable to retrieve location */}
                    {locationError && this.renderErrorMessage(labels)}
                  </div>
                </React.Fragment>
              )}
            <ErrorBoundary>
              {(!isCanadaFindAStore ||
                (enableFindStoreSearchViewOnCanada && isCanadaFindAStore)) &&
                !findAStoreModal && (
                  <StoresFound
                    heading={
                      !isPNHDashboard
                        ? LabelsUtil.getLabel(labels, 'storesFoundHeading', [
                            storeListData.length,
                            displayLocation,
                          ])
                        : localStoreHeading
                    }
                    description={LabelsUtil.getLabel(
                      labels,
                      'storesFoundDescription'
                    )}
                    storeList={storeDataList}
                    isFetching={isFetchingStores}
                    findAStoreModal={findAStoreModal}
                    startNewSearchHandler={startNewSearchHandler}
                    labels={labels}
                    noBorderTop={noBorderTop}
                    noPaddingTop={noPaddingTop}
                    findStorePage={this.props.findStorePage}
                    isMobile={this.props.isMobile}
                    isForEventsPage={isForEventsPage}
                    isFetchingEventStores={isFetchingEventStores}
                    storeEventList={storeEventList}
                    locationName={displayLocation}
                    zipSubmitted={zipSubmitted}
                    startNewEventModal={startNewEventModal}
                    isBopisFilter={this.props.isBopisFilter}
                    formData={formWrapperData}
                  />
                )}
            </ErrorBoundary>
            {!isPickupInStore && (
              <ResponsiveMediaQuery minWidth={deviceConfig.TABLET}>
                {(!isCanadaFindAStore ||
                  (enableFindStoreSearchViewOnCanada && isCanadaFindAStore)) &&
                  !isForEventsPage && (
                    <ErrorBoundary>
                      <MapQuest
                        stores={this.renderToggleStoreList(storeDataList)}
                        mapQuestConfig={mapQuestConfig}
                        storesConfig={storesConfig}
                        labels={labels}
                        show={!isFetchingStores}
                        initOnModalMount={initOnModalMount}
                        renderMapOnEachLoad={renderMapOnEachLoad}
                        isPNHDashboard={isPNHDashboard}
                        isCanada={isCanada}
                        isCurrentLocation={this.state.isCurrentLocation}
                      />
                    </ErrorBoundary>
                  )}
              </ResponsiveMediaQuery>
            )}
            {this.renderStoreLoadingSekelton()}
            {this.renderStoreListing()}
          </FormWrapper>
        </Cell>
      </GridX>
    );
  }
}

SearchStores.propTypes = {
  labels: PropTypes.object.isRequired,
  searchRadius: PropTypes.object,
  filterData: PropTypes.array,
  deviceConfig: PropTypes.object.isRequired,
  gridXClass: PropTypes.string,
  cellClass: PropTypes.string,
  onSearchSubmit: PropTypes.func,
  selectedSKUId: PropTypes.string,
  isPickupInStore: PropTypes.bool,
  findAStoreModal: PropTypes.bool,
  setRegistrySearchFlag: PropTypes.func,
  registrySearchFlag: PropTypes.bool,
  startNewSearchHandler: PropTypes.func,
  isFilterVisible: PropTypes.bool,
  storeList: PropTypes.array,
  isFetchingStores: PropTypes.bool,
  stores: PropTypes.object, // Mapquest response
  mapQuestConfig: PropTypes.object.isRequired,
  quantity: PropTypes.string,
  siteId: PropTypes.string,
  favoriteStoreDetails: PropTypes.array,
  formWrapperData: PropTypes.object,
  tealiumFindStoreSearchData: PropTypes.object,
  tealiumPathName: PropTypes.object,
  cartState: PropTypes.object,
  triggerStoreSearchTealiumEvent: PropTypes.func,
  isQuickViewOpen: PropTypes.bool,
  findStorePage: PropTypes.bool,
  breadcrumbTealiumData: PropTypes.object,
  //  landingZip: PropTypes.string,
  locationName: PropTypes.string,
  initOnModalMount: PropTypes.bool,
  noBorderTop: PropTypes.bool,
  noPaddingTop: PropTypes.bool,
  storeResults: PropTypes.object,
  storeListByAddress: PropTypes.array,
  clearForm: PropTypes.func,
  isMobile: PropTypes.bool,
  isFindAStore: PropTypes.bool,
  locator: PropTypes.string,
  renderMapOnEachLoad: PropTypes.bool,
  queryString: PropTypes.object,
  googleDFPConfig: PropTypes.object,
  pickUpStore: PropTypes.object,
  isPNHDashboard: PropTypes.bool,
  localStoreHeading: PropTypes.string,
  isForEventsPage: PropTypes.bool,
  zipModalSubmitted: PropTypes.func,
  zipSubmitted: PropTypes.bool,
  storeEventList: PropTypes.bool,
  isFetchingEventStores: PropTypes.bool,
  startNewEventModal: PropTypes.func,
  contentId: PropTypes.string,
  akamaiHeader: PropTypes.object,
  enableFindStoreSearchViewOnCanada: PropTypes.bool,
  resetshowAvailableStores: PropTypes.func,
  isBopisFilter: PropTypes.bool,
  identifier: PropTypes.string,
  clickFromPLPTile: PropTypes.bool,
};
SearchStores.defaultProps = {
  favoriteStoreDetails: [],
  searchRadius: {},
  filterData: [],
  gridXClass: '',
  cellClass: '',
  isPickupInStore: false,
  isFilterVisible: true,
  storeList: [],
  distanceMap: {},
  isLoggedIn: false,
  stores: null,
  quantity: 1,
  landingZip: null,
  customEventsModal: false,
  isPNHDashboard: false,
  localStoreHeading: null,
  isForEventsPage: false,
  storeEventList: [],
  enableFindStoreSearchViewOnCanada: false,
};
export default SearchStores;
