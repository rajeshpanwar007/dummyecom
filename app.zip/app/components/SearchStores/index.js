export { default } from './SearchStores';
