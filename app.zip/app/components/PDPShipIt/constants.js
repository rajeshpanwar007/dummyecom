export const CUSTOMIZATION = 'customization';
