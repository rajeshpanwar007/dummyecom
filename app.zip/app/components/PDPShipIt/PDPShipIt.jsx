/* eslint-disable no-useless-escape */
/* eslint-disable extra-rules/no-commented-out-code */
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import { isArray, isEmpty } from 'lodash';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { isSDDTimeUp } from '@bbb-app/utils/isSDDTimeUp';
import { isBedBathCanada } from '@bbb-app/utils/common';
import Cell from '@bbb-app/core-ui/cell/Cell';
import GridX from '@bbb-app/core-ui/grid-x/GridX';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import Icon from '@bbb-app/core-ui/icon';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import ContentBox from '@bbb-app/pure-content/containers/content-box/ContentBox';
import '@bbb-app/assets/icons/homeDelivery.svg';
import '@bbb-app/assets/icons/infoIcon.svg';
import '@bbb-app/assets/icons/sameDayDelivery.svg';
import personalizationUtil from '../Pages/PDP/ProductDetails/Components/Personalization/util';
import ShippingOptions from '../../containers/Pages/PDP/ShippingOptions/ShippingOptions.async';
import { CUSTOMIZATION } from './constants';
import Styles from './PDPShipIt.css';
import inlineStyles from './PDPShipIt.inline.css';
import TruckDeliveryOptions from '../Pages/PDP/LTL/TruckDeliveryOptions';

const DangerousText = dangerousHTML(DangerousText);

class PDPShipIt extends React.PureComponent {
  constructor(props) {
    super(props);
    const customizationDesc = pathOr(
      '',
      'selectedProduct.ELIGIBLE_CUSTOMIZATION_DESCRIP',
      this.props.atcProps
    );
    this.customizationEligibility = isArray(customizationDesc)
      ? customizationDesc[0].toLowerCase() === CUSTOMIZATION
      : customizationDesc.toLowerCase() === CUSTOMIZATION;
    this.isInternationalUser = isInternationalUser();
    this.onError = this.onError.bind(this);
    this.onSuccess = this.onSuccess.bind(this);
    this.getCTA = this.getCTA.bind(this);
    this.getDeliveryIcon = this.getDeliveryIcon.bind(this);
    this.renderPersonalizationHeader = this.renderPersonalizationHeader.bind(
      this
    );
    this.getBackbuttonIcon = this.getBackbuttonIcon.bind(this);

    this.state = {
      modalMountedState: false,
    };
  }

  onError = msg => {
    this.props.showError(msg);
  };

  onSuccess = (qty = 1) => {
    const {
      changeQuantity,
      removeRefNumForVendorPrice,
      vendorPriceDetails,
    } = this.props;
    changeQuantity(qty);
    removeRefNumForVendorPrice(vendorPriceDetails);
  };
  /* eslint complexity: ["error", 13]*/
  getCTA() {
    const {
      AddToCart,
      atcProps,
      labels,
      query,
      subscriptionSelection,
      isRBYR,
      isRBYRRegistryEnabled,
      isProductAvailable,
      isPdpPersonalizeProduct,
      subscriptionItem,
      showPersonalization,
      quickViewMode,
      quantity,
      swatchError,
      refNum,
      viewType,
      themeATC,
      parentProductValue,
      atcLabel,
      type,
      validateCallToAction,
      updateCallToAction,
      getRegistryId,
      getPersonalizationByType,
      sddOnly,
      isChooseOption,
      sddMarketData,
      registryUserName,
      sddEddZip,
    } = this.props;

    let ctaLabel = sddOnly
      ? LabelsUtil.getLabel(labels, 'sddDeliveryCTALbl')
      : LabelsUtil.getLabel(labels, atcLabel);

    const dataLocator = sddOnly ? 'pdp-Deliverybutton' : 'pdp-addtocartbutton';
    const ariaLabel = sddOnly ? 'deliveryErrorTooltip' : 'atcErrorTooltip';

    const productType = atcProps.selectedProduct.TYPE;

    // This is a new flag driven by real-time data that says whether the product is in stock for that store
    const sddAvailable = sddOnly
      ? pathOr(null, 'selectedProduct.sddAvailable', atcProps)
      : null;

    const isSelectedStoreAvailable =
      productType === 'MSWP' && !atcProps.selectedSkuId
        ? true
        : this.getStoreAvailability(
            pathOr([], 'storeIds', sddMarketData.marketData),
            pathOr([], 'STORES', atcProps.selectedProduct),
            sddAvailable
          );

    // IF product/SKU is out of stock
    if (sddOnly && !isSelectedStoreAvailable) {
      ctaLabel = LabelsUtil.getLabel(labels, 'sddOOOCTALbl');
    }

    const enableCTA = sddOnly
      ? this.isSddEligibility() && isSelectedStoreAvailable
      : isProductAvailable;
    return showPersonalization ? (
      getPersonalizationByType(type, atcProps, null, true)
    ) : (
      <AddToCart
        isRBYRItem={isRBYR}
        registryUserName={registryUserName}
        subscriptionItem={subscriptionItem}
        every={subscriptionSelection && subscriptionSelection.every}
        everyPeriod={
          subscriptionSelection && subscriptionSelection.every_period
        }
        frequencyLabel={subscriptionSelection && subscriptionSelection.label}
        enableRBYRFeature={atcProps.enableRBYRFeature && isRBYRRegistryEnabled}
        prodId={atcProps.selectedProduct.PRODUCT_ID}
        skuId={atcProps.selectedSKU.skuId}
        qty={quantity}
        swatchError={swatchError}
        ltlFlag={atcProps.selectedProduct.LTL_FLAG}
        productVariation={atcProps.selectedProduct.PRODUCT_VARIATION}
        refnum={refNum}
        viewType={viewType || 'PDP'}
        buttonProps={{
          attr: {
            theme: enableCTA ? themeATC : 'deactivated',
            className: classnames(
              this.isInternationalUser || quickViewMode
                ? Styles.button
                : Styles.shortButton,
              'fullWidth'
            ),
            'data-locator': dataLocator,
            'aria-describedby': ariaLabel,
          },
          children: ctaLabel,
          disabled: !enableCTA,
        }}
        onClientError={validateCallToAction}
        updateCallToAction={updateCallToAction}
        onSuccess={this.onSuccess}
        onError={this.onError}
        parentProductId={parentProductValue}
        registryId={getRegistryId(query)}
        closeQuickViewModal={atcProps.closeModal}
        onModalHide={atcProps.hideModal}
        isPdpPersonalizeProduct={isPdpPersonalizeProduct}
        {...atcProps}
        isShiptSdd={sddOnly}
        isChooseOption={isChooseOption}
        sddOnly={sddOnly}
        isSelectedStoreAvailable={isSelectedStoreAvailable}
        sddEddZip={sddEddZip}
      />
    );
  }

  getDeliveryIcon() {
    if (this.props.sddOnly) {
      return (
        <Icon
          className={classnames(Styles.icon)}
          type="sameDayDelivery"
          width="21px"
          height="21px"
        />
      );
    }
    return (
      <Icon
        className={Styles.icon}
        type="homeDelivery"
        width="27px"
        height="15px"
      />
    );
  }

  /**
   * @param {Array of Store from sddEligible zip in string datatype} storeIds
   * @param {Array of store from the sku api in integer datatype} storeList
   * checks for greater than 0 to return true/false rather than storeId
   */
  getStoreAvailability = (storeIds, storeList, sddAvailable) => {
    if (sddAvailable !== null) return sddAvailable;
    return (
      !isEmpty(storeIds) &&
      !isEmpty(storeList) &&
      storeList.find(store => {
        return store.toString() === storeIds[0].toString();
      }) > 0
    );
  };

  getSddAttributes = () => {
    const {
      atcProps,
      labels,
      sddMarketData,
      quickViewMode,
      viewType,
      sddOnly,
      switchConfigGlobal,
    } = this.props;
    const productType = atcProps.selectedProduct.TYPE;
    const isDynamicSDDTimer = pathOr(
      'false',
      'enableDynamicSddMessage',
      switchConfigGlobal
    );

    // This is a new flag driven by real-time data that says whether the product is in stock for that store
    const sddAvailable = sddOnly
      ? pathOr(null, 'selectedProduct.sddAvailable', atcProps)
      : null;

    if (productType === 'MSWP' && !atcProps.selectedSkuId) {
      return (
        <Paragraph className={Styles.sddLabel}>
          {LabelsUtil.getLabel(labels, 'pickUpStoreNotSelected')}
        </Paragraph>
      );
    }
    /**
     * To show SDD not eligible message
     */
    if (!this.isSddEligibility()) {
      return (
        <Paragraph className={Styles.sddLabel}>
          {LabelsUtil.getLabel(labels, 'SddNotEligible')}
        </Paragraph>
      );
    }

    const isSelectedStoreAvailable = this.getStoreAvailability(
      pathOr([], 'storeIds', sddMarketData.marketData),
      pathOr([], 'STORES', atcProps.selectedProduct),
      sddAvailable
    );

    if (!isSelectedStoreAvailable) {
      return (
        <Paragraph className={classnames(Styles.sddLabel)}>
          {LabelsUtil.getLabel(labels, 'sddOutOfStock')}
        </Paragraph>
      );
    }
    let orderMsgLabel;
    const ACTION_URL = '/store/static/SddPolicies';
    const displayCutOffTime = isBedBathCanada()
      ? LabelsUtil.getLabel(labels, 'displayCutOffTime')
      : sddMarketData.marketData.displayCutOffTime;
    const isSDDTodayAvailable =
      sddMarketData &&
      sddMarketData.marketData.sddFlag &&
      !isSDDTimeUp(displayCutOffTime);
    if (isDynamicSDDTimer) {
      orderMsgLabel = isSDDTodayAvailable ? 'orderMsg' : 'orderMsgTmrw';
    } else {
      orderMsgLabel = 'orderMsg';
    }
    return (
      sddMarketData &&
      sddMarketData.marketData &&
      sddMarketData.marketData.sddAndBOPISinfo && (
        <Paragraph className={Styles.sddLabel}>
          <DangerousText>
            {LabelsUtil.getLabel(labels, orderMsgLabel, [
              sddMarketData.marketData.displayCutOffTime,
              sddMarketData.marketData.displayGetByTime,
            ])}
          </DangerousText>
          {/* Suppress for Choose Option SDD */}
          {!(quickViewMode || viewType === 'quickView') &&
          sddMarketData.marketData.minShipFee ? (
            <React.Fragment>
              {LabelsUtil.getLabel(labels, 'orderMsgSubLbl', [
                sddMarketData.marketData.minShipFee,
              ])}
              <Button
                onClick={this.modalClickHandler(ACTION_URL)}
                iconProps={{
                  type: 'infoIcon',
                  width: '14px',
                  height: '14px',
                  className: Styles.infoIconMargin,
                }}
                isIconAfterContent
                theme="link"
                variation="smallLink"
              />
              <ModalDialog
                mountedState={this.state.modalMountedState[ACTION_URL]}
                toggleModalState={this.toggleModalState}
                titleAriaLabel="aria-label"
                verticallyCenter
                variation="small"
                scrollDisabled={false}
              >
                <ContentBox
                  params={{
                    page_url: ACTION_URL,
                    type: 'open_container',
                  }}
                  location={ACTION_URL}
                  errorMsg={LabelsUtil.getLabel(
                    this.props.labels,
                    'lblModalLoadError'
                  )}
                />
              </ModalDialog>
            </React.Fragment>
          ) : null}
        </Paragraph>
      )
    );
  };

  getBackbuttonIcon() {
    return (
      <div className={Styles.backButton} id="back-button">
        <Icon type="caret" className="icon" height="12px" width="12px" />
        <span>Back</span>
      </div>
    );
  }

  /**
   * Checks for sddEligibility and SDD market data
   * for quickView checks for sddEligiblity from sku : isShipTSddEligibleSKU
   */

  isSddEligibility = () => {
    const isSddEligibility =
      this.props.sddMarketData &&
      this.props.sddMarketData.marketData &&
      this.props.sddMarketData.marketData.sddFlag;
    return isSddEligibility;
  };

  modalClickHandler = ACTION_URL => e => {
    e.preventDefault();
    this.toggleModalState({ [ACTION_URL]: true });
    this.props.atcProps.getModalContent(
      {
        page_url: ACTION_URL,
        type: 'open_container',
      },
      {
        pagePath: ACTION_URL,
      }
    );
  };
  toggleModalState = state => {
    this.setState({ modalMountedState: state || {} });
  };

  renderPersonalizationHeader() {
    const { showPersonalization, labels, type } = this.props;

    return showPersonalization
      ? personalizationUtil.renderPersonalizationHeader(
          labels,
          type,
          this.isInternationalUser,
          this.customizationEligibility,
          true,
          true
        )
      : null;
  }

  render() {
    const {
      atcProps,
      zipProps,
      labels,
      showPersonalization,
      isOutOfStock,
      showNotifyFlag,
      getIsOutOfStock,
      viewType,
      pdpState,
      sddOnly,
      sddEddZip,
      setSddEddZip,
      selectedProduct,
      selectedStoreDetail,
      pickUpSelectStoreDetails,
      hurryThreshold,
    } = this.props;

    const selectedSkuId = pathOr(
      undefined,
      'selectedSkuId',
      this.props.atcProps
    );
    const isLTL = pathOr(
      false,
      'selectedProduct.LTL_FLAG',
      this.props.atcProps
    );

    const LTLCondition =
      !sddOnly && selectedSkuId && (isLTL === 'true' || isLTL === '1');

    const isBopusExcluded =
      pathOr('0', 'selectedProduct.BOPUS_EXCLUSION_FLAG', atcProps) === '1' ||
      this.isInternationalUser;

    const sddAvailable = pathOr(null, 'sddAvailable', selectedProduct);
    const sddATS = pathOr(null, 'sddATS', selectedProduct);
    const selectedStore =
      (!isEmpty(pickUpSelectStoreDetails) && pickUpSelectStoreDetails[0]) ||
      (!isEmpty(selectedStoreDetail) && selectedStoreDetail) ||
      pathOr({}, 'storeDetails[0]', this.props);
    const isSelectedStoreOOS =
      sddAvailable !== null
        ? !sddAvailable
        : Boolean(selectedSkuId) &&
          !isEmpty(selectedStore) &&
          !pathOr([], 'STORES', selectedProduct).find(
            storeId => storeId === Number(selectedStore.storeId)
          );
    return this.isInternationalUser ? (
      this.getCTA()
    ) : (
      <div
        id={sddOnly ? 'pdpShipIt-sdd' : 'pdpShipIt'}
        key="key-PDPShipIt"
        className={classnames(Styles.wrapper, inlineStyles.wrapper, 'mb1')}
      >
        <GridX>
          <Cell className="small-12">
            <ShippingOptions
              {...zipProps}
              labels={zipProps.pdpProps.labels}
              getCTA={this.getCTA}
              getDeliveryIcon={this.getDeliveryIcon}
              separatorClass={classnames(Styles.separator)}
              showPersonalization={showPersonalization}
              renderPersonalizationHeader={this.renderPersonalizationHeader}
              headerStyle={Styles.message}
              isOutOfStock={isOutOfStock}
              isShipIt
              modalBackButtonStyle={Styles.modalBackBtn}
              viewType={viewType}
              getBackbuttonIcon={this.getBackbuttonIcon}
              LTLCondition={LTLCondition}
              pdpState={pdpState}
              sddOnly={sddOnly}
              sddEddZip={sddEddZip}
              setSddEddZip={setSddEddZip}
            />
          </Cell>
          {!sddOnly &&
            isOutOfStock && (
              <Cell className={'small-12'}>
                <div className={classnames(Styles.lightMessage)}>
                  {LabelsUtil.getLabel(labels, 'shipItOutOfStock')}
                </div>
                {getIsOutOfStock(
                  isOutOfStock,
                  showNotifyFlag,
                  atcProps,
                  labels,
                  true
                )}
              </Cell>
            )}
          {sddOnly && this.getSddAttributes()}
          {sddOnly &&
            Boolean(selectedSkuId) &&
            !isSelectedStoreOOS &&
            sddATS !== null &&
            sddATS <= hurryThreshold && (
              <Cell className={classnames(Styles.hurryMsg, 'small-11 pt1')}>
                {LabelsUtil.getLabel(labels, 'hurryMsg', [sddATS])}
              </Cell>
            )}
          <TruckDeliveryOptions
            ctaLabel={LabelsUtil.getLabel(this.props.atcProps.labels, 'tdoCTA')}
            viewType={this.props.viewType}
            LTLCondition={LTLCondition}
            getModalContent={this.props.atcProps.getModalContent}
          />
          {isBopusExcluded && !sddOnly ? (
            <Cell className="small-12 mt1">
              {LabelsUtil.getLabel(labels, 'notSoldInStores')}
            </Cell>
          ) : null}
        </GridX>
      </div>
    );
  }
}

PDPShipIt.propTypes = {
  AddToCart: PropTypes.any,
  atcProps: PropTypes.object,
  labels: PropTypes.object,
  query: PropTypes.object,
  zipProps: PropTypes.object,
  subscriptionSelection: PropTypes.object,
  isRBYR: PropTypes.bool,
  isRBYRRegistryEnabled: PropTypes.bool,
  isProductAvailable: PropTypes.bool,
  isPdpPersonalizeProduct: PropTypes.bool,
  subscriptionItem: PropTypes.bool,
  showPersonalization: PropTypes.bool,
  quickViewMode: PropTypes.bool,
  isOutOfStock: PropTypes.bool,
  showNotifyFlag: PropTypes.bool,
  quantity: PropTypes.number,
  swatchError: PropTypes.string,
  refNum: PropTypes.string,
  viewType: PropTypes.string,
  themeATC: PropTypes.string,
  parentProductValue: PropTypes.string,
  atcLabel: PropTypes.string,
  type: PropTypes.string,
  vendorPriceDetails: PropTypes.array,
  validateCallToAction: PropTypes.func,
  updateCallToAction: PropTypes.func,
  changeQuantity: PropTypes.func,
  removeRefNumForVendorPrice: PropTypes.func,
  showError: PropTypes.func,
  getRegistryId: PropTypes.func,
  getPersonalizationByType: PropTypes.func,
  getIsOutOfStock: PropTypes.func,
  pdpState: PropTypes.object,
  sddOnly: PropTypes.bool,
  sddMarketData: PropTypes.object,
  isChooseOption: PropTypes.bool,
  sddEddZip: PropTypes.string,
  setSddEddZip: PropTypes.func,
  registryUserName: PropTypes.string,
  switchConfigGlobal: PropTypes.bool,
  selectedProduct: PropTypes.object,
  pickUpSelectStoreDetails: PropTypes.array,
  selectedStoreDetail: PropTypes.object,
  hurryThreshold: PropTypes.number,
};

export default PDPShipIt;
