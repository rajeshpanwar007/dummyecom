import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import { noop } from '@bbb-app/utils/common';
import getSiteId from '@bbb-app/utils/getSiteId';
import toJS from '@bbb-app/hoc/toJS';
import ModalDialog from '@bbb-app/modal-dialog/containers/ModalDialog';
import { makeSelectProfile } from '@bbb-app/selectors/accountSelectors';
import { getLoggedIn } from '@bbb-app/header/containers/selectors';
import SearchStores from '../../containers/SearchStores/SearchStores';
import {
  makeLabels,
  selectSiteConfig,
  selectSwitchConfig,
  selectThirdPartyDataConfig,
  selectPageConfigGlobal,
} from './selectors';
import style from './EventModal.css';
import { EVENTSURL } from './constants';
/**
 * EventModal - EventModal booking bug component
 */

export class EventModal extends React.Component {
  componentDidUpdate(prevProps) {
    const { toggleParentUnderlay, mountedState, isForEventsPage } = this.props;
    if (isForEventsPage && prevProps.mountedState === false && mountedState) {
      toggleParentUnderlay(false);
    }
  }

  componentWillUnmount() {
    const { toggleParentUnderlay, isForEventsPage } = this.props;
    if (isForEventsPage) {
      toggleParentUnderlay(true);
    }
  }

  renderContent() {
    const {
      siteId,
      labels,
      isLoggedIn,
      profile,
      storeId,
      getStoreName,
      getStoreAddress,
      getStoreDirection,
      getStoreDetails,
      getStoreTimings,
      switchConfig,
      thirdPartyDataConfig,
      pageConfig,
    } = this.props;

    const siteIdNumber =
      { BedBathUS: '1', BuyBuyBaby: '2', BedBathCanada: '3' }[siteId] || '1';

    const reg = {
      registryId: '',
      firstName: '',
      lastName: '',
      email: '',
      contactNum: '',
      coRegEmail: '',
      coRegFirstName: '',
      coRegLastName: '',
      eventDate: '',
      preselectedServiceRef: '',
    };

    if (isLoggedIn && profile && profile.firstName) {
      const { email, lastName } = profile;
      reg.firstName = pathOr('', 'firstName', profile);
      reg.lastName = lastName !== null && lastName;
      reg.email = email && !email.includes('*') && email;
      reg.contactNum = pathOr('', 'phone', profile);
    }

    // TODO:  Use labels object to get message and url from CMS.
    let eventGroupId = '';
    if (pageConfig !== undefined && pageConfig.eventGroupId !== undefined) {
      eventGroupId = pageConfig.eventGroupId;
    }
    let eventId = '';
    if (pageConfig !== undefined && pageConfig.eventId !== undefined) {
      eventId = pageConfig.eventId;
    }

    let catId = '';
    if (pageConfig !== undefined && pageConfig.catId !== undefined) {
      catId = pageConfig.catId;
    }
    let title = '';
    let url = '';

    title = LabelsUtil.getLabel(labels, 'eventsTitle');
    if (pathOr(false, 'Global.enableBookingBug', switchConfig)) url = '';
    url = pathOr(EVENTSURL, 'bookingBug.eventsUrl', thirdPartyDataConfig);
    url = `${url}?abc=1&siteId=${siteIdNumber}&storeId=${storeId}&regFN=${reg.firstName}&regLN=${reg.lastName}&coregFN=${reg.coRegFirstName}&coregLN=${reg.coRegLastName}&email=${reg.email}&coregEmail=${reg.coRegEmail}&contactNum=${reg.contactNum}&registryId=${reg.registryId}&eventDate=${reg.eventDate}&catID=${catId}&eventID=${eventId}&eventGroupID=${eventGroupId}`;

    if (storeId) {
      return (
        <div>
          <center> {<Heading level={1}>{title}</Heading>}</center>
          <div className={classnames(style.storeDetailsModal)}>
            {getStoreName}
            <div className={classnames(style.addresses)}>
              <div className={classnames(style.storeAddressDetail)}>
                {getStoreAddress}
                {getStoreDirection}
                {getStoreDetails}
              </div>
              <div className={classnames(style.bbModal)}>
                <div className={classnames(style.storeTimingsDetails)}>
                  {getStoreTimings}
                </div>
              </div>
            </div>
          </div>
          <iframe className={classnames(style.frameWrapper)} src={url} />
        </div>
      );
    }
    return (
      <div>
        <h2>{LabelsUtil.getLabel(labels, 'findAppointmentNearYou')}</h2>
        <div className={classnames(style.mediumLight)}>
          <p>{LabelsUtil.getLabel(labels, 'findAppointmentText')}</p>
        </div>
        <SearchStores />
      </div>
    );
  }

  render() {
    const { mountedState = false, onModalClose, labels } = this.props;
    return (
      <ErrorBoundary>
        <ModalDialog
          titleText={LabelsUtil.getLabel(labels, 'eventsTitle')}
          mountedState={mountedState}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'bookingBugIframeLbl')}
          closeIconShow
          verticallyCenter
          onModalDidClose={noop}
          onModalClose={onModalClose}
          variation={'large'}
        >
          {this.renderContent()}
        </ModalDialog>
      </ErrorBoundary>
    );
  }
}

EventModal.propTypes = {
  siteId: PropTypes.string,
  labels: PropTypes.object,
  isLoggedIn: PropTypes.bool,
  profile: PropTypes.object,
  mountedState: PropTypes.bool,
  onModalClose: PropTypes.func,
  storeId: PropTypes.string,
  getStoreName: PropTypes.string,
  getStoreAddress: PropTypes.string,
  getStoreDirection: PropTypes.string,
  getStoreDetails: PropTypes.string,
  getStoreTimings: PropTypes.string,
  switchConfig: PropTypes.object,
  pageConfig: PropTypes.object,
  thirdPartyDataConfig: PropTypes.object,
  toggleParentUnderlay: PropTypes.func,
  isForEventsPage: PropTypes.bool,
};

export const mapStateToProps = createStructuredSelector({
  siteId: getSiteId,
  labels: makeLabels(),
  isLoggedIn: getLoggedIn(),
  profile: makeSelectProfile(),
  siteConfig: selectSiteConfig(),
  switchConfig: selectSwitchConfig(),
  thirdPartyDataConfig: selectThirdPartyDataConfig(),
  pageConfig: selectPageConfigGlobal(),
});

export default connect(mapStateToProps)(toJS(EventModal));
