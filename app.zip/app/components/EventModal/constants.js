export const EVENTSURL =
  'https://bespoke.bookingbug.com/bbb/staging/new_event.html';
