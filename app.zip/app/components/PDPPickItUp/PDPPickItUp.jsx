import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash/isEmpty';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell/Cell';
import GridX from '@bbb-app/core-ui/grid-x/GridX';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import { isTbs } from '@bbb-app/utils/isTbs';
import Button from '@bbb-app/core-ui/button';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import Icon from '@bbb-app/core-ui/icon/Icon';
import getStoreFromCookies from '@bbb-app/utils/getStoreFromCookies';
import '@bbb-app/assets/icons/Store.svg';
import PickUpInStore from '../../containers/Pages/PDP/PickUpInStore/PickUpInStore';

import pickUpInStoreUtil from '../Pages/PDP/ProductDetails/Components/DeliveryOptions/Components/PickUpInStore/util';

import Styles from './PDPPickItUp.css';
import inlineStyles from './PDPPickItUp.inline.css';

const DangerousHTML = dangerousHTML(DangerousHTML);

class PDPPickItUp extends React.PureComponent {
  constructor(props) {
    super(props);
    this.isTbs = isTbs();
    this.isInternationalUser = isInternationalUser();
  }

  getFindInStoreLink(pdpProps, displayFindInStoreLink, selectedSkuId) {
    return selectedSkuId ? displayFindInStoreLink(pdpProps, true) : null;
  }

  // eslint-disable-next-line complexity
  render() {
    const {
      selectedSkuId,
      findInStoreHandler,
      onClientError,
      updateCallToAction,
      displayFindInStoreLink,
      pathOr,
      labels,
      selectedProduct,
      swatchError,
      siteId,
      tbsCurrentStoreId,
      mPulseEnabled,
      isSubscriptionSelected,
      isPrimary,
      isPdpTrue,
      pdpProps,
      selectedStoreDetail,
      miniQuickViewMode,
      storeOnlyAvailable,
      pickUpSelectStoreDetails,
      nearestStoreAvailabilty,
      isStoreDetailsFetching,
      storelist,
      storeFetchingError,
      viewType,
    } = this.props;

    // This is a new flag and value driven by real-time data that shows the product availability the current store
    const bopisAvailable = pathOr(null, 'bopisAvailable', selectedProduct);
    const bopisATS = pathOr(null, 'bopisATS', selectedProduct);

    const selectedStoreId = pathOr(
      null,
      'storeId',
      this.props.selectedStoreDetail
    );
    let storeData = this.props.storeData;

    if (
      bopisAvailable === false &&
      storeData.filter(store => store.storeId === selectedStoreId)
    ) {
      storeData = storeData.filter(store => store.storeId !== selectedStoreId);
    }

    const isInStock = bopisAvailable || storeData.length > 0;
    const closestInStockStoreName =
      (isInStock && !isEmpty(storeData) && storeData[0].commonName) || '';

    const { showChangeStoreOnTbs } = pdpProps;

    const type = pathOr(null, 'TYPE', selectedProduct);

    const isBopusExcluded =
      pathOr('0', 'BOPUS_EXCLUSION_FLAG', selectedProduct) === '1';

    /*
      storeDetails: List of stores from PickUpInStore's API call BEFORE filtering against selected SKU's "STORES" field
      storeData: List of stores from PickUpInStore's API call AFTER filtering against selected SKU's "STORES" field
    */
    const activeStoreArray = pathOr(
      [],
      `${!selectedSkuId ? 'storeDetails' : 'storeData'}`,
      this.props
    );

    const selectedStore =
      (!isEmpty(pickUpSelectStoreDetails) && pickUpSelectStoreDetails[0]) ||
      (!isEmpty(selectedStoreDetail) && selectedStoreDetail) ||
      pathOr({}, 'storeDetails[0]', this.props);

    const isSelectedStoreOOS =
      bopisAvailable !== null
        ? !bopisAvailable
        : Boolean(selectedSkuId) &&
          !isEmpty(selectedStore) &&
          !pathOr([], 'STORES', selectedProduct).find(
            storeId => storeId === Number(selectedStore.storeId)
          );

    let closestStore = {};
    if (nearestStoreAvailabilty) {
      closestStore =
        activeStoreArray.find(
          store => store.storeId === nearestStoreAvailabilty
        ) || selectedStoreDetail;
    } else if (!isEmpty(selectedStoreDetail) && !isEmpty(activeStoreArray)) {
      closestStore =
        activeStoreArray.find(
          store => store.storeId === selectedStoreDetail.storeId
        ) || selectedStoreDetail;
    } else if (!isEmpty(selectedStoreDetail)) {
      closestStore = selectedStoreDetail;
    } else if (!isEmpty(activeStoreArray)) {
      closestStore = activeStoreArray[0];
    }

    const useNextClosestStore = isInStock && isSelectedStoreOOS;

    const storeFromCookies = getStoreFromCookies();
    const pickUpStoreName =
      pathOr(
        null,
        'commonName',
        pickUpSelectStoreDetails && pickUpSelectStoreDetails[0]
      ) || closestStore.commonName;

    const storeName =
      pickUpStoreName || pathOr(null, 'commonName', storeFromCookies);
    const postalCode =
      closestStore.postalCode || pathOr(null, 'postalCode', storeFromCookies);
    const state = closestStore.state || pathOr(null, 'state', storeFromCookies);

    const isCurbsideMsgEnabled = pathOr(
      false,
      'curbsideMsgEnabled',
      pdpProps.switchConfig
    );
    const siteBopus =
      Array.isArray(closestStore.siteBopus) &&
      closestStore.siteBopus.filter(concept => concept.siteId === siteId);
    const bopusFlag =
      !isEmpty(siteBopus) &&
      Array.isArray(siteBopus) &&
      parseInt(siteBopus[0].bopusFlag, 10);

    const curbSideFlag = parseInt(closestStore.curbSideFlag, 10) || 0;
    const availableLabelKey =
      isCurbsideMsgEnabled &&
      !isNaN(bopusFlag) &&
      !isNaN(curbSideFlag) &&
      `bopus${bopusFlag}Curbside${curbSideFlag}`;

    const isStoreDisabled = bopusFlag === 0;

    const hurryThreshold = pathOr(
      5,
      'config.pageConfig.PDP.hurryThreshold',
      pdpProps
    );

    const message = pickUpInStoreUtil.displayMessage(
      DangerousHTML,
      this.isTbs,
      {
        labels,
        selectedSkuId,
        storeData,
        isBopusExcluded,
        isInternationalUser: this.isInternationalUser,
        showChangeStoreOnTbs,
        tbsCurrentStoreId,
        isStoreDisabled,
        isPdpTrue: true,
        type,
        postalCode,
        storeName,
        state,
        availableLabelKey,
        isSelectedStoreOOS,
        storeOnlyAvailable,
        isStoreDetailsFetching,
        storelist,
        storeFetchingError,
        isInStock,
      }
    );

    const tbsMessage = pickUpInStoreUtil.displayTbsMessage(
      DangerousHTML,
      this.isTbs,
      tbsCurrentStoreId,
      showChangeStoreOnTbs,
      labels,
      true
    );

    return !isBopusExcluded && !this.isInternationalUser ? (
      <div
        id="pdpPickItUp"
        key="key-PDPPickItUp"
        className={classnames(Styles.wrapper, inlineStyles.wrapper, 'mb1')}
      >
        <GridX>
          <Cell className="small-1">
            <Icon
              className={Styles.icon}
              type="Store"
              width="100%"
              height="21px"
            />
          </Cell>
          {isSubscriptionSelected ? (
            <Cell className="small-11 px1">
              {LabelsUtil.getLabel(labels, 'subscriptionPickItUpMsg')}
            </Cell>
          ) : (
            <React.Fragment>
              {isStoreDisabled ? (
                <Cell className="small-11 px1">
                  {message}
                  {this.getFindInStoreLink(
                    pdpProps,
                    displayFindInStoreLink,
                    selectedSkuId
                  )}
                </Cell>
              ) : (
                <Cell className={`${inlineStyles.heading} small-6 pr1`}>
                  {storeName ? (
                    <div>
                      {LabelsUtil.getLabel(
                        labels,
                        curbSideFlag === 2 && !storeOnlyAvailable
                          ? 'curbSideHeadingSpecific'
                          : 'pickItUpHeadingSpecific',
                        useNextClosestStore
                          ? [closestInStockStoreName]
                          : [storeName]
                      )}
                    </div>
                  ) : (
                    <div>
                      {LabelsUtil.getLabel(
                        labels,
                        curbSideFlag === 2
                          ? 'curbSideHeadingGeneric'
                          : 'pickItUpHeadingGeneric'
                      )}
                    </div>
                  )}
                  {this.getFindInStoreLink(
                    pdpProps,
                    displayFindInStoreLink,
                    selectedSkuId
                  )}
                </Cell>
              )}
              {!isStoreDisabled && (
                <Cell className="small-5">
                  {isSelectedStoreOOS && !isInStock ? (
                    <Button
                      className={Styles.button}
                      theme="deactivated"
                      variation="fullWidth"
                    >
                      {LabelsUtil.getLabel(labels, 'outOfStock')}
                    </Button>
                  ) : (
                    <PickUpInStore
                      findInStoreHandler={findInStoreHandler}
                      onClientError={onClientError}
                      updateCallToAction={updateCallToAction}
                      swatchError={swatchError}
                      mPulseEnabled={mPulseEnabled}
                      isSubscriptionSelected={isSubscriptionSelected}
                      isPdpTrue={isPdpTrue}
                      isPrimary={isPrimary}
                      miniQuickViewMode={miniQuickViewMode}
                      clickedOnPickItUp
                      nearestStoreAvailabilty={nearestStoreAvailabilty}
                      useNextClosestStore={useNextClosestStore}
                      closestInStockStoreName={closestInStockStoreName}
                      viewType={viewType}
                      {...pdpProps}
                      replaceProps={this.props.replaceProps}
                      quickAddProps={this.props.quickAddProps}
                      pickupInStock={isInStock || !isSelectedStoreOOS}
                    />
                  )}
                </Cell>
              )}
            </React.Fragment>
          )}
          {message &&
            !isSubscriptionSelected &&
            !isStoreDisabled && (
              <Cell className="small-12">
                <div
                  className={classnames(inlineStyles.message, Styles.separator)}
                >
                  {message}
                </div>
              </Cell>
            )}
          {Boolean(selectedSkuId) &&
            !isSelectedStoreOOS &&
            bopisATS !== null &&
            bopisATS <= hurryThreshold && (
              <Cell className={classnames(Styles.hurryMsg, 'small-11 pt1')}>
                {LabelsUtil.getLabel(labels, 'hurryMsg', [bopisATS])}
              </Cell>
            )}
          {isInStock &&
            isSelectedStoreOOS &&
            !isEmpty(selectedStoreDetail) && (
              <Cell className={classnames('small-11 pt1')}>
                {LabelsUtil.getLabel(labels, 'outOfStockAt', [
                  selectedStoreDetail.commonName,
                ])}
              </Cell>
            )}
          {this.isTbs &&
            tbsMessage && <Cell className="small-12 mt2">{tbsMessage}</Cell>}
        </GridX>
      </div>
    ) : null;
  }
}

PDPPickItUp.propTypes = {
  selectedSkuId: PropTypes.any,
  findInStoreHandler: PropTypes.func,
  onClientError: PropTypes.func,
  updateCallToAction: PropTypes.func,
  displayFindInStoreLink: PropTypes.func,
  pathOr: PropTypes.func,
  pdpProps: PropTypes.object,
  labels: PropTypes.object,
  selectedProduct: PropTypes.object,
  storeData: PropTypes.array,
  selectedStoreDetail: PropTypes.object,
  swatchError: PropTypes.string,
  siteId: PropTypes.string,
  tbsCurrentStoreId: PropTypes.string,
  mPulseEnabled: PropTypes.bool,
  isSubscriptionSelected: PropTypes.bool,
  isPrimary: PropTypes.bool,
  isPdpTrue: PropTypes.bool,
  miniQuickViewMode: PropTypes.bool,
  storeOnlyAvailable: PropTypes.bool,
  pickUpSelectStoreDetails: PropTypes.array,
  nearestStoreAvailabilty: PropTypes.string,
  isStoreDetailsFetching: PropTypes.bool,
  storelist: PropTypes.object,
  storeFetchingError: PropTypes.object,
  viewType: PropTypes.string,
  replaceProps: PropTypes.object,
  quickAddProps: PropTypes.object,
};

export default PDPPickItUp;
