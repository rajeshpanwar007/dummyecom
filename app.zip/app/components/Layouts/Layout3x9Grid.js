/**
 * Layout3x9Grid: Layout3x9Grid is a layout template of two grids in 30-90 ration with 10 spacing to the right.
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import isEmpty from 'lodash/isEmpty';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';

/**
 * 
 * @param {object} regions - the object data required for the specification of the components to be placed on which region 
 * @param {*} controllerProps - the controller props for the layout
 */
const Layout3x9Grid = (regions, controllerProps = {}, componentMap = {}) => {
  if (!isEmpty(regions)) {
    return (
      <React.Fragment>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="first">
              {getComponents(regions, 'first', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-3" id="second">
              {getComponents(regions, 'second', controllerProps, componentMap)}
            </Cell>
            <Cell className="large-9" id="third">
              {getComponents(regions, 'third', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="fourth">
              {getComponents(regions, 'fourth', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
      </React.Fragment>
    );
  }
  return null;
};

export default Layout3x9Grid;
