/**
 * LayoutSingleColorRegion: LayoutSingleColorRegion is a layout template of page without sidebar and gray background in main content .
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import isEmpty from 'lodash/isEmpty';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';
import styles from './Region.css';

const LayoutSingleColorRegion = (
  regions,
  controllerProps = {},
  componentMap = {}
) => {
  if (!isEmpty(regions)) {
    return (
      <React.Fragment>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12 " id="first">
              {getComponents(regions, 'first', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
        <div className={styles.colorRegion}>
          <GridContainer>
            <Cell className="large-12" id="second">
              {getComponents(regions, 'second', controllerProps, componentMap)}
            </Cell>
          </GridContainer>
        </div>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="third">
              {getComponents(regions, 'third', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
      </React.Fragment>
    );
  }
  return null;
};

export default LayoutSingleColorRegion;
