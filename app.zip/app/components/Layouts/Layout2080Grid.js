/**
 * Layout2080Grid: Layout2080Grid is a layout template for having sidebar in left and main content on right.
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/

import React from 'react';
import isEmpty from 'lodash/isEmpty';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';

const Layout2080Grid = (regions, controllerProps = {}, componentMap = {}) => {
  if (!isEmpty(regions)) {
    return (
      <GridX className="grid-margin-x">
        <Cell className="large-12" id="first">
          {getComponents(regions, 'first', controllerProps, componentMap)}
        </Cell>

        <Cell className="large-2 medium-4" id="second">
          {getComponents(regions, 'second', controllerProps, componentMap)}
        </Cell>
        <Cell className="large-10 medium-8" id="third">
          {getComponents(regions, 'third', controllerProps, componentMap)}
        </Cell>

        <Cell className="large-12" id="fourth">
          {getComponents(regions, 'fourth', controllerProps, componentMap)}
        </Cell>
      </GridX>
    );
  }
  return null;
};

export default Layout2080Grid;
