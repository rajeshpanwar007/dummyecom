import LayoutSingleWhiteRegion from './LayoutSingleWhiteRegion';
import LayoutSingleColorRegion from './LayoutSingleColorRegion';
import Layout5050Region from './Layout5050Region';
import Layout2080Grid from './Layout2080Grid';
import Layout8020Grid from './Layout8020Grid';
import Layout8x4WideRegion from './Layout8x4WideRegion';
import MultiRegion from './MultiRegion';
import Layout3x9Grid from './Layout3x9Grid';
import LayoutGreyHeaderSingleWhiteRegion from './LayoutGreyHeaderSingleWhiteRegion';

const layouts = {
  default: LayoutSingleWhiteRegion,
  LayoutSingleWhiteRegion,
  LayoutSingleColorRegion,
  Layout5050Region,
  Layout2080Grid,
  Layout8020Grid,
  Layout8x4WideRegion,
  MultiRegion,
  Layout3x9Grid,
  LayoutGreyHeaderSingleWhiteRegion,
};

export default layouts;
