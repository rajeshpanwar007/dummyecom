/**
 * Layout8x4WideRegion: Layout8x4WideRegion is a layout template of having second region 8 grids and third region having 4 grids specially. Rest regions occupied whole 12 grids.
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import isEmpty from 'lodash/isEmpty';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';

const Layout8x4WideRegion = (
  regions,
  controllerProps = {},
  componentMap = {}
) => {
  if (!isEmpty(regions)) {
    return (
      <React.Fragment>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="first">
              {getComponents(regions, 'first', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-8" id="second">
              {getComponents(regions, 'second', controllerProps, componentMap)}
            </Cell>
            <Cell className="large-4" id="third">
              {getComponents(regions, 'third', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="fourth">
              {getComponents(regions, 'fourth', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
      </React.Fragment>
    );
  }
  return null;
};

export default Layout8x4WideRegion;
