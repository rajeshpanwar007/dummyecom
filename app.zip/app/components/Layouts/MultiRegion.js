/**
 * MultiRegion: MultiRegion is a layout template of page with multiple full width grids and background of alternative grid are gray .
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import classNames from 'classnames';
import isEmpty from 'lodash/isEmpty';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';
import styles from './Region.css';

const MultiRegion = (regions, labels = null, componentMap = {}) => {
  if (!isEmpty(regions)) {
    return (
      <React.Fragment>
        <GridContainer>
          <GridX className={classNames('grid-margin-x', styles.multiRegion)}>
            <Cell className="large-12" id="firstW">
              {getComponents(regions, 'firstW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="firstC">
              {getComponents(regions, 'firstC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="secondW">
              {getComponents(regions, 'secondW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="secondC">
              {getComponents(regions, 'secondC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="thirdW">
              {getComponents(regions, 'thirdW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="thirdC">
              {getComponents(regions, 'thirdC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="fourthW">
              {getComponents(regions, 'fourthW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="fourthC">
              {getComponents(regions, 'fourthC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="fifthW">
              {getComponents(regions, 'fifthW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="fifthC">
              {getComponents(regions, 'fifthC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="sixthW">
              {getComponents(regions, 'sixthW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="sixthC">
              {getComponents(regions, 'sixthC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="seventhW">
              {getComponents(regions, 'seventhW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="seventhC">
              {getComponents(regions, 'seventhC', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="eighthW">
              {getComponents(regions, 'eighthW', labels, componentMap)}
            </Cell>
            <Cell className="large-12" id="eighthC">
              {getComponents(regions, 'eighthC', labels, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
      </React.Fragment>
    );
  }
  return null;
};

export default MultiRegion;
