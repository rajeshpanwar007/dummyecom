/**
 * LayoutGreyHeaderSingleWhiteRegion: LayoutGreyHeaderSingleWhiteRegion is a layout template of page with grey header, without sidebar and white background in main content .
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import isEmpty from 'lodash/isEmpty';
import GridContainer from '@bbb-app/core-ui/grid-container';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';
import styles from './Layout.css';

const LayoutGreyHeaderSingleWhiteRegion = (
  regions,
  controllerProps = {},
  componentMap = {}
) => {
  if (!isEmpty(regions)) {
    return (
      <div className={styles.greyHeaderLayout}>
        <GridContainer>
          <GridX className="grid-margin-x">
            <Cell className="large-12" id="first">
              {getComponents(regions, 'first', controllerProps, componentMap)}
            </Cell>
            <Cell className="large-12" id="second">
              {getComponents(regions, 'second', controllerProps, componentMap)}
            </Cell>
            <Cell className="large-12" id="third">
              {getComponents(regions, 'third', controllerProps, componentMap)}
            </Cell>
          </GridX>
        </GridContainer>
      </div>
    );
  }
  return null;
};

export default LayoutGreyHeaderSingleWhiteRegion;
