/**
 * Layout8020Grid: Layout8020Grid is a layout template of having main content on left side and sidebar on right side.
 * @param  {[Object]} components [Object of components]
 *    sample use- contactPage container *
*/
import React from 'react';
import isEmpty from 'lodash/isEmpty';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import { getComponents } from '../../utils/getComponents';

const Layout8020Grid = (regions, controllerProps = {}, componentMap = {}) => {
  if (!isEmpty(regions)) {
    return (
      <GridX className="grid-margin-x">
        <Cell className="large-12" id="first">
          {getComponents(regions, 'first', controllerProps, componentMap)}
        </Cell>

        <Cell className="large-10 medium-8" id="second">
          {getComponents(regions, 'second', controllerProps, componentMap)}
        </Cell>
        <Cell className="large-2 medium-4" id="third">
          {getComponents(regions, 'third', controllerProps, componentMap)}
        </Cell>

        <Cell className="large-12" id="fourth">
          {getComponents(regions, 'fourth', controllerProps, componentMap)}
        </Cell>
      </GridX>
    );
  }
  return null;
};

export default Layout8020Grid;
