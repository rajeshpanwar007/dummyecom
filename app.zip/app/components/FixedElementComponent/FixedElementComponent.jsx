import React from 'react';
import pathOr from 'lodash/fp/pathOr';
import PropTypes from 'prop-types';
import MediaQuery from 'react-responsive';
import { getCachedCookie, getCookie } from '@bbb-app/utils/universalCookie';
import { isBedBathCanada } from '@bbb-app/utils/common';
import addDay from '@bbb-app/utils/addDay';
import SddBadge from '@bbb-app/core-ui/sdd-badge/SddBadge.async';
import { SDD_LANDING_ZIP_ELIGIBILITY } from '@bbb-app/redux/market-eligibility/constants';

import InteractiveChecklist from '../../containers/InteractiveChecklist/InteractiveChecklist.async';
import RegistryFooter from './../../containers/RegistryFooter/RegistryFooter.async';
import WelcomeMatStickyFooter from '../../containers/WelcomeMatStickyFooter/WelcomeMatStickyFooter.async';
import RecentlyViewedStickyFooter from '../../components/RecentlyViewedStickyFooter/RecentlyViewedStickyFooter.async';
import StickyCheckout from '../../containers/Footer/StickyCheckout/StickyCheckout.async';

/**
 * FixedElementComponent
 * Wrapper around all the sticky button
 */
export const FixedElementComponent = props => {
  const {
    showRegistryFooter,
    routes,
    locationChange,
    flagToShowICList,
    fixedElementState,
    resetRegistryFooterRenderedStatus,
    resetWelcomeMatStickyFooterRenderedStatus,
    isLoggedIn,
    pageIdentifier,
    deviceConfig,
    routeData,
    sDDSwitchConfig,
    openSDDModal,
    SDDLabels,
    enableStickyCheckout,
    isStickyFooter,
    isMobile,
    welcomeMatFlag,
    isInternationalEnabled,
    siteId,
  } = props;
  if (locationChange) {
    if (!showRegistryFooter && fixedElementState.registryFooterRendered) {
      resetRegistryFooterRenderedStatus();
    }
    if (fixedElementState.welcomeMatFooterRendered) {
      resetWelcomeMatStickyFooterRenderedStatus();
    }
  }
  const sddModal = getCachedCookie('sddModal');
  const sddAttribute = getCachedCookie('sddAttribute');
  const landingZipEligibility = getCachedCookie(SDD_LANDING_ZIP_ELIGIBILITY);
  const getSDDBadge = () => {
    if (
      sddModal !== 'true' &&
      pageIdentifier === 'HOMEPAGE' &&
      sddAttribute &&
      landingZipEligibility
    ) {
      return (
        <MediaQuery maxWidth={deviceConfig.DESKTOP - 1}>
          <SddBadge openModal={openSDDModal} labels={SDDLabels} />
        </MediaQuery>
      );
    }
    return <React.Fragment />;
  };

  /* function used to show the stickyCheckout section in the footer */
  const isCartEmpty = () => {
    const cartCount = Number(getCookie('cartCount'));
    const stickyCookie = getCachedCookie('CloseStickyCheckout');
    let isEnabled = false;
    if (!stickyCookie && cartCount > 0) {
      isEnabled = true;
    }

    return isEnabled;
  };

  const isIcAndStickyfooterChecked = () => {
    const eventDate = pathOr('', 'makeSelectActiveRegistry.eventDate', props);
    const eventType = pathOr(null, 'makeSelectActiveRegistry.eventType', props);
    const { thresholdEventDay } = props;
    const processFlag = pathOr(
      '',
      'makeSelectActiveRegistry.processFlag',
      props
    );
    const isPackAndHold =
      eventType === 'PACK_HOLD' || eventType === 'PACK_HOLD_MOVING';
    let registryEventDate = eventDate;
    if (!thresholdEventDay) return true;
    else if (!registryEventDate) return true;
    else if (isPackAndHold && processFlag !== 'N') return true;
    else if (isPackAndHold && processFlag === 'N') return false;

    if (isBedBathCanada()) {
      const dateSplit = registryEventDate.split('/');
      registryEventDate = `${dateSplit[1]}/${dateSplit[0]}/${dateSplit[2]}`;
    }
    const addEventDate = addDay(
      new Date(registryEventDate),
      Number(thresholdEventDay) + 1
    );
    const isActiveRegistryExpired = new Date() <= addEventDate;
    if (isActiveRegistryExpired) {
      return true;
    }
    return false;
  };

  const isICVissible =
    flagToShowICList &&
    isLoggedIn &&
    !showRegistryFooter &&
    isIcAndStickyfooterChecked();

  return (
    <div className="hideOnPrint">
      {isICVissible ? <InteractiveChecklist siteId={siteId} /> : null}

      {showRegistryFooter &&
        isLoggedIn &&
        isIcAndStickyfooterChecked() && (
          <RegistryFooter
            routes={routes}
            locationChange={locationChange}
            siteId={siteId}
          />
        )}

      {!welcomeMatFlag &&
        isInternationalEnabled && (
          <MediaQuery maxWidth={deviceConfig.DESKTOP - 1}>
            <WelcomeMatStickyFooter />
          </MediaQuery>
        )}
      <MediaQuery maxWidth={deviceConfig.DESKTOP - 1}>
        <RecentlyViewedStickyFooter
          isLoggedIn={isLoggedIn}
          pageIdentifier={pageIdentifier}
          routeData={routeData}
        />
      </MediaQuery>
      {sDDSwitchConfig.enableSDD && sDDSwitchConfig.homePageFlag ? (
        getSDDBadge()
      ) : (
        <React.Fragment />
      )}
      {!isMobile &&
        isCartEmpty() &&
        enableStickyCheckout &&
        isStickyFooter && <StickyCheckout isICVissible={isICVissible} />}
    </div>
  );
};

FixedElementComponent.defaultProps = {
  showRegistryFooter: false,
  routes: {},
  flagToShowICList: false,
  sDDSwitchConfig: {
    homePageFlag: null,
    enableSDD: null,
  },
};
FixedElementComponent.propTypes = {
  showRegistryFooter: PropTypes.bool,
  locationChange: PropTypes.bool,
  flagToShowICList: PropTypes.bool,
  routes: PropTypes.object,
  fixedElementState: PropTypes.object,
  resetRegistryFooterRenderedStatus: PropTypes.func,
  isLoggedIn: PropTypes.bool,
  resetWelcomeMatStickyFooterRenderedStatus: PropTypes.func,
  pageIdentifier: PropTypes.string,
  deviceConfig: PropTypes.object,
  routeData: PropTypes.object,
  sDDSwitchConfig: PropTypes.object,
  openSDDModal: PropTypes.func,
  SDDLabels: PropTypes.object,
  enableStickyCheckout: PropTypes.bool,
  isStickyFooter: PropTypes.bool,
  isMobile: PropTypes.bool,
  welcomeMatFlag: PropTypes.bool,
  isInternationalEnabled: PropTypes.bool,
  siteId: PropTypes.string,
};

export default FixedElementComponent;
