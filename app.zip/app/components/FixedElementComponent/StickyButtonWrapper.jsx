import React from 'react';
import pathOr from 'lodash/fp/pathOr';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import MediaQuery from 'react-responsive';
import { isBrowser, renderComponentByDevice } from '@bbb-app/utils/common';
import Experiment from '@bbb-app/site-spect/Experiment';
import ABVariant from '@bbb-app/site-spect/ABVariant';
import isTbs from '@bbb-app/utils/isTbs';
import { LocalStorageUtil } from '@bbb-app/utils/localStorage';
import styles from './FixedElementComponent.css';
import BackToTop from '../Footer/BackToTop/BackToTop.async';
import { PRODUCT_COMPARE_V1 } from './constants';
import CompareDocket from '../../containers/Pages/Compare/CompareDocket/CompareDocket.async';

export const getDataFromLocalStorage = key => {
  const storageUtil = new LocalStorageUtil(isBrowser());
  return storageUtil.getItem(key)
    ? storageUtil
        .getItem(key)
        .split(';')
        .map(element => {
          const compareData = element.split(':');
          return {
            productId: compareData[0],
            skuId: compareData[1],
            imageId: compareData[2],
            productName: compareData[3] ? unescape(compareData[3]) : '',
          };
        })
    : [];
};

/**
 * StickyButtonWrapper
 * Wrapper around all the sticky button
 */

export const StickyButtonWrapper = props => {
  StickyButtonWrapper.defaultProps = {
    showRegistryFooter: false,
    routes: {},
  };

  const propTypes = {
    isMobile: PropTypes.bool,
    fixedElementState: PropTypes.object,
    backToTopConfig: PropTypes.object,
    deviceConfig: PropTypes.object,
    footerlabels: PropTypes.object,
    productCompareCall: PropTypes.bool,
    pdpProductCompareData: PropTypes.object,
    switchConfigGlobal: PropTypes.object,
  };
  StickyButtonWrapper.propTypes = propTypes;

  const productCompareLocalStorageList = getDataFromLocalStorage(
    'productCompare'
  );
  const PDPproductCompareDocket =
    props.pdpProductCompareData && props.pdpProductCompareData.length > 0;

  const { productCompare } = { ...props.productCompareCall };
  const PLPproductCompareDocket = productCompare && productCompare.length > 0;

  const getCompareDocket = () => {
    return (
      (props.pageIdentifier === 'PDP' ||
        props.pageIdentifier === 'PLP' ||
        props.pageIdentifier === 'SearchResults' ||
        props.pageIdentifier === 'BrandLanding') &&
      (productCompareLocalStorageList.length > 0 ||
        PDPproductCompareDocket ||
        PLPproductCompareDocket) && (
        <Experiment fallback={<CompareDocket {...props} ssEnabled={false} />}>
          <ABVariant id={PRODUCT_COMPARE_V1}>
            <CompareDocket null />
          </ABVariant>
        </Experiment>
      )
    );
  };

  const getBackToTop = (backToTopConfig, deviceConfig, footerlabels) => {
    if (backToTopConfig && backToTopConfig.backToTop) {
      return (
        <MediaQuery maxWidth={deviceConfig.DESKTOP - 1}>
          <div className="my1">
            <BackToTop config={backToTopConfig} labels={footerlabels} />
          </div>
        </MediaQuery>
      );
    }
    return '';
  };
  const enableLiveChatIpad = pathOr(
    false,
    'enableLiveChatIpad',
    props.switchConfigGlobal
  );
  const enableLiveChatAndroid = pathOr(
    false,
    'enableLiveChatAndroid',
    props.switchConfigGlobal
  );
  const elementObject = {
    alignRight: [
      <div id="moveToTopStickyContainer">
        {getBackToTop(
          props.backToTopConfig,
          props.deviceConfig,
          props.footerlabels
        )}
      </div>,
      <div
        id="opinionLabStickyContainer"
        className={classnames({ tbsFeedbackImg: isTbs(), folDeep: true })}
      />,
    ],
    alignLeft: [getCompareDocket()],
  };

  if (
    isBrowser() &&
    renderComponentByDevice(enableLiveChatIpad, enableLiveChatAndroid)
  ) {
    elementObject.alignRight.push(<div id="liveChatStickyContainer" />);
  }

  const { fixedElementState, isMobile } = props;
  let moveLeft = '';
  let moveUp = '';
  if (fixedElementState && fixedElementState.icRendered && !isMobile) {
    moveLeft = styles.stickyContainerLeft;
  }
  if (
    fixedElementState &&
    (fixedElementState.stickyFooterRendered ||
      fixedElementState.registryFooterRendered ||
      fixedElementState.welcomeMatFooterRendered)
  ) {
    moveUp = styles.stickyContainerAbove;
  }

  const renderElement = Object.keys(elementObject).map(item => {
    return (
      <div
        className={classnames(
          styles.stickyContainer,
          styles[item],
          item === 'alignRight' ? moveLeft : '',
          moveUp
        )}
      >
        {elementObject[item].map(childItem => {
          if (
            pathOr(false, 'props.id', childItem) ===
              'opinionLabStickyContainer' &&
            props.isScriptLoaded
          ) {
            return <React.Fragment>{childItem}</React.Fragment>;
          }
          return <React.Fragment>{childItem}</React.Fragment>;
        })}
      </div>
    );
  });

  return <React.Fragment>{renderElement}</React.Fragment>;
};

export default StickyButtonWrapper;
