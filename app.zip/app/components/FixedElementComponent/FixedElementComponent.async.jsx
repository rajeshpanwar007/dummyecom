/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';

import { options } from '@bbb-app/universal-component/options';

const FixedElementComponent = universal(
  import(/* webpackChunkName: "lazy-FixedElementComponent" */ './FixedElementComponent'),
  options
);

export default FixedElementComponent;

/* eslint-enable extra-rules/no-commented-out-code */
