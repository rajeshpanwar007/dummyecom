export { default } from './FixedElementComponent';
