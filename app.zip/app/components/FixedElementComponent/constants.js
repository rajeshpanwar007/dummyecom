export const PRODUCT_COMPARE_V1 = 'PDPCompare';
