import React from 'react';
import PropTypes from 'prop-types';
import { isEmpty, pathOr } from 'lodash/fp';
import classnames from 'classnames';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Loader from '@bbb-app/core-ui/section-loader';
import Heading from '@bbb-app/core-ui/heading';
import HyperLink from '@bbb-app/core-ui/hyper-link';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Image from '@bbb-app/core-ui/image';
import LocalNotificationMessage from '@bbb-app/core-ui/local-notification';
import TealiumHandler from '@bbb-app/tealium/TealiumHandler';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import styles from './CurbsideOrderStatus.css';
import { MODAL_STATE } from './constants';

/**
 * @function  ModalHeader
 * @return {Object} React Component
 * @description Returns modal header
 */
export const ModalHeader = ({
  orderNumber,
  orderIdBarCodeImage,
  labels,
  errorMessage,
  showNotificationMsg,
}) => {
  const barcodeSrc = `data:image/png;base64,${orderIdBarCodeImage}`;
  return (
    <React.Fragment>
      <Cell>
        <Heading level={3} className={classnames('pb175', styles.mainHeading)}>
          {LabelsUtil.getLabel(labels, 'pickupYourOrderLabel')}
        </Heading>
      </Cell>
      {errorMessage &&
        (showNotificationMsg ? (
          <LocalNotificationMessage
            MsgContent={{
              status: 'error',
              content: errorMessage,
            }}
            contentIsFetching={false}
            customWrapperClass={styles.notificationWrapper}
            customIconClass={styles.notificationIcon}
            isShowIcon
            hideCloseIcon
          />
        ) : (
          <Cell>
            <Paragraph
              variation="errorMessage"
              theme="primary"
              className="validationErrorMessage"
            >
              {errorMessage}
            </Paragraph>
          </Cell>
        ))}
      <Cell>
        <Heading level={4} className={classnames('pb1', styles.subHeading)}>
          {orderNumber}
        </Heading>
      </Cell>
      <Cell className={classnames('pb2', styles.barcodeImage)}>
        <Image alt="barcode" src={barcodeSrc} />
      </Cell>
    </React.Fragment>
  );
};

ModalHeader.propTypes = {
  orderNumber: PropTypes.string,
  orderIdBarCodeImage: PropTypes.string,
  labels: PropTypes.Object,
  errorMessage: PropTypes.string,
  showNotificationMsg: PropTypes.bool,
};

/**
 * @function  getPickupOrder
 * @return {Object} React Component
 * @description Returns pickup order modal data
 */
export const getPickupOrder = (
  orderNumber,
  orderIdBarCodeImage,
  setCurrentModalState,
  labels
) => {
  const tealiumConstants = {
    page_name: 'I want Curbside',
    page_type: 'My Account',
    category_name: 'My Account',
    subcategory_name: 'My Account',
    channel: 'My Account',
  };
  return (
    <GridX>
      <ErrorBoundary>
        <TealiumHandler
          identifier="I want Curbside"
          utagData={tealiumConstants}
          tealiumPageInfoNotAvailable
        />
      </ErrorBoundary>
      <ModalHeader
        orderNumber={orderNumber}
        orderIdBarCodeImage={orderIdBarCodeImage}
        labels={labels}
      />
      <Cell>
        <Heading level={4} className={classnames('my2', styles.subHeading)}>
          {LabelsUtil.getLabel(labels, 'curbsidePickupLabel')}
        </Heading>
      </Cell>
      <Cell className={classnames('mb2', styles.curbsidePickupLogo)}>
        <Image
          alt="curbside pickup logo"
          src="/static/assets/images/imgCurbsidePickup.jpg"
        />
      </Cell>
      <Cell>
        <Paragraph className="pb275" theme="mediumLight">
          {LabelsUtil.getLabel(labels, 'sendCarInfoLabel')}
        </Paragraph>
      </Cell>
      <Cell className="small-12 large-6 mb3">
        <Button
          variation={'fullWidth'}
          theme="primary"
          onClick={() => setCurrentModalState(MODAL_STATE.VEHICLE_FORM)}
        >
          {LabelsUtil.getLabel(labels, 'iWantCurbsideLabel')}
        </Button>
      </Cell>
      <Cell>
        <PrimaryLink
          href="#"
          className={classnames(styles.ratherCallStoreLabel)}
          onClick={() => setCurrentModalState(MODAL_STATE.CALL_STORE)}
          variation="primary"
        >
          {LabelsUtil.getLabel(labels, 'ratherCallStoreLabel')}
        </PrimaryLink>
      </Cell>
    </GridX>
  );
};

/**
 * @function  VehicleDetails
 * @return {Object} React Component
 * @description Returns vehicle details entered by the user
 */
export const VehicleDetails = ({
  orderNumber,
  orderIdBarCodeImage,
  phone,
  vehicleInfo,
  pickupName,
  profileName,
  labels,
  curbsideOrderError,
  isMobileScreen,
}) => {
  const customerNote = pathOr('', 'customerNote', vehicleInfo);
  const parkingSlot = pathOr('', 'parkingSlot', vehicleInfo);
  const error = pathOr(false, 'response.data', curbsideOrderError);
  let errorMessage = '';
  /* istanbul ignore next */
  if (!isEmpty(error)) {
    errorMessage = pathOr('', 'errorMessages[0].message', error);
  }
  return (
    <div className={classnames('flex flex-column', styles.listType)}>
      <ModalHeader
        orderNumber={orderNumber}
        orderIdBarCodeImage={orderIdBarCodeImage}
        labels={labels}
        errorMessage={errorMessage}
      />
      {!customerNote && !errorMessage && <Loader />}
      <div className="pt2" />
      {profileName && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'pickupPersonLabel')}
          </div>
          <span className={pickupName ? 'mb2' : ''}>{profileName}</span>
        </React.Fragment>
      )}
      {pickupName && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'altPickupPersonLabel')}
          </div>
          <span>{pickupName}</span>
        </React.Fragment>
      )}
      <span className="mb2">
        {LabelsUtil.getLabel(labels, 'showGovtIdLabel')}
      </span>
      {customerNote && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'rideDetailsLabel')}
          </div>
          <span className={parkingSlot ? 'pb1' : 'mb2'}>{customerNote}</span>
        </React.Fragment>
      )}
      {parkingSlot && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'slotNumberLabel')}
          </div>
          <span className="mb2">{parkingSlot}</span>
        </React.Fragment>
      )}
      <span className={classnames('pb1 mr025', styles.contactInfo)}>
        {LabelsUtil.getLabel(labels, 'needHelpLabel')}
        <span className={classnames(styles.storePhone)}>
          {isMobileScreen && (
            <HyperLink
              variation="phoneNumber"
              textDecoration="textDecorationNone"
              href={`tel:${phone.replace(/(\D+)/g, '')}`}
            >
              {phone}
            </HyperLink>
          )}
          {!isMobileScreen && phone}
        </span>
      </span>
    </div>
  );
};

VehicleDetails.propTypes = {
  orderNumber: PropTypes.string,
  orderIdBarCodeImage: PropTypes.string,
  phone: PropTypes.string,
  vehicleInfo: PropTypes.Object,
  labels: PropTypes.Object,
  curbsideOrderError: PropTypes.Object,
  pickupName: PropTypes.string,
  profileName: PropTypes.string,
  isMobileScreen: PropTypes.bool,
};

/**
 * @function  getCallStore
 * @return {Object} React Component
 * @description Returns call store modal data
 */
export const getCallStore = (phone, isMobileScreen, labels) => {
  const callText = !isMobileScreen && ` Please call ${phone}`;
  return (
    <GridX>
      <Cell>
        <Heading level={3} className={classnames('pb175', styles.mainHeading)}>
          {LabelsUtil.getLabel(labels, 'pickupYourOrderLabel')}
        </Heading>
      </Cell>
      <Cell>
        <Heading level={4} className={classnames(styles.subHeading)}>
          {LabelsUtil.getLabel(labels, 'storeAssociateLabel')}
        </Heading>
      </Cell>
      <Paragraph
        className={classnames(styles.callStoreLabel)}
        theme="mediumLight"
      >
        {LabelsUtil.getLabel(labels, 'deliverYourOrderLabel')}
        {callText}
      </Paragraph>
      {isMobileScreen && (
        <Cell className="small-12 large-6">
          <HyperLink
            variation="phoneNumber"
            textDecoration="textDecorationNone"
            href={`tel:${phone.replace(/(\D+)/g, '')}`}
            className={classnames(
              'primary flex items-center justify-center',
              styles.callStore
            )}
          >
            {LabelsUtil.getLabel(labels, 'callStoreLabel')}
          </HyperLink>
        </Cell>
      )}
    </GridX>
  );
};

/**
 * @function  getStorePickup
 * @return {Object} React Component
 * @description Returns modal data when Curbside feature is not available for store
 */
// eslint-disable-next-line max-params
export const getStorePickup = (
  orderNumber,
  orderIdBarCodeImage,
  phone,
  pickupName,
  profileName,
  orderPickupDate,
  labels,
  isMobileScreen
) => {
  return (
    <div className={classnames('flex flex-column', styles.listType)}>
      <ModalHeader
        orderNumber={orderNumber}
        orderIdBarCodeImage={orderIdBarCodeImage}
        labels={labels}
      />
      <div className="pb1 pt2">
        {LabelsUtil.getLabel(labels, 'cancellationOrderLabel')}
      </div>
      <span className="mb2">{orderPickupDate}</span>
      {profileName && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'pickupPersonLabel')}
          </div>
          <span className={pickupName ? 'mb2' : ''}>{profileName}</span>
        </React.Fragment>
      )}
      {pickupName && (
        <React.Fragment>
          <div className="pb1">
            {LabelsUtil.getLabel(labels, 'altPickupPersonLabel')}
          </div>
          <span>{`${pickupName}`}</span>
        </React.Fragment>
      )}
      <span className="mb3">
        {LabelsUtil.getLabel(labels, 'showGovtIdLabel')}
      </span>
      <span className={classnames('pb1 mr025', styles.contactInfo)}>
        {LabelsUtil.getLabel(labels, 'needHelpLabel')}
        <span className={classnames(styles.storePhone)}>
          {isMobileScreen && (
            <HyperLink
              variation="phoneNumber"
              textDecoration="textDecorationNone"
              href={`tel:${phone.replace(/(\D+)/g, '')}`}
            >
              {phone}
            </HyperLink>
          )}
          {!isMobileScreen && phone}
        </span>
      </span>
    </div>
  );
};
