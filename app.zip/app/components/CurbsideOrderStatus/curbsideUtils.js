/* istanbul ignore file */
import pathOr from 'lodash/fp/pathOr';
import isEmpty from 'lodash/fp/isEmpty';
import { getMyAccountPageConfig } from '@bbb-app/utils/myAccountUtils/siteConfig';
import { sortArrayByOrder } from '@bbb-app/utils/common';
import { compareDates } from '@bbb-app/utils/addDay';
import { ORDER_STATUS, ORDER_MAP } from './Common/constants';
export const fetchStores = (shippingGroups, storeDetail, submittedDateTime) => {
  let stores = [];
  const isValid = isOrderExpired(submittedDateTime);
  if (shippingGroups.length && storeDetail && isValid) {
    shippingGroups.forEach(group => {
      const {
        storeId,
        stateDetail,
        pickupDate,
        extendedPickupDate,
        id,
        sgLevelPickupOptions,
      } = group;
      if (storeId !== null && stateDetail) {
        const data = {
          ...storeDetail[storeId],
          pickupDate,
          extendedPickupDate,
          id,
          sgLevelPickupOptions,
        };
        const status = getOrderStatus(stateDetail);
        if (data && status > -1) {
          data.stateDetail = status;
          stores.push(data);
        }
      }
    });
  }
  stores = stores.length
    ? sortArrayByOrder(stores, ORDER_MAP, 'stateDetail')
    : stores;
  return stores;
};
export const getStoreDetailsMap = storeDetail => {
  const stores = {};
  if (storeDetail.length) {
    storeDetail.forEach(store => {
      const storeId = store.storeId;
      stores[storeId] = store;
    });
  }
  return stores;
};
export const getOrderStatus = state => {
  const status = state && state.toLowerCase();
  switch (status) {
    case 'order being processed':
      return 0;
    case 'submitted':
      return 0;
    case 'ready for pickup':
      return 1;
    case 'picked up':
      return 2;
    case 'completed':
      return 2;
    case 'complete':
      return 2;
    default:
      return -1;
  }
};
export const getOrderNumber = (bbbOrderVO = {}) => {
  const shippingGroups = pathOr([], 'shippingGroups', bbbOrderVO);
  if (shippingGroups && shippingGroups.length > 0) {
    return shippingGroups.find(group => {
      return ORDER_STATUS.indexOf(group.stateDetail) > -1;
    });
  }
  return null;
};
export const getListOfCurbsideOrderIds = (orderList = []) => {
  if (orderList && orderList.length > 0) {
    const orderIds = orderList.reduce((orderIdArray, order) => {
      const bbbOrderVO = pathOr({}, 'bbbOrderVO', order);
      const submittedDateTime = pathOr('', 'submittedDateTime', bbbOrderVO);
      const onlineOrderNumber = pathOr('', 'onlineOrderNumber', order);
      if (
        bbbOrderVO &&
        isOrderExpired(submittedDateTime) &&
        getOrderNumber(bbbOrderVO)
      ) {
        orderIdArray.push(onlineOrderNumber);
      }
      return orderIdArray;
    }, []);
    return orderIds.toString();
  }
  return null;
};
export const getListOfCurbsideOrderIdsForOrderDetails = orderDetail => {
  if (!isEmpty(orderDetail)) {
    const orderIdsArray = [];
    const onlineOrderNumber = pathOr('', 'onlineOrderNumber', orderDetail);
    if (getOrderNumber(orderDetail)) {
      orderIdsArray.push(onlineOrderNumber);
    }
    return orderIdsArray.toString();
  }
  return null;
};
export const getCurbsideOrdersInTransit = (data = []) => {
  if (data && data.length > 0) {
    const orderIds = data.reduce((ids, order) => {
      if (order.curbsideStatusCode && order.curbsideStatusCode < 4) {
        ids.push(order.orderId);
      }
      return ids;
    }, []);
    if (orderIds.length) {
      const orders = {};
      orders.orderId = orderIds.toString();
      return orders;
    }
    return null;
  }
  return null;
};
/* istanbul ignore next */
export const isOrderExpired = submittedDateTime => {
  const deliveredDays = getMyAccountPageConfig(
    'deliveredOrderStatusAvailable',
    7
  );
  const submittedDate =
    submittedDateTime &&
    typeof submittedDateTime === 'string' &&
    submittedDateTime.split(' ')[0];
  return compareDates(submittedDate, deliveredDays);
};
export const isCurbsideAvailableForOrder = orderDetail => {
  const shippingGroups = pathOr([], 'shippingGroups', orderDetail);
  const submittedDateTime = pathOr('', 'submittedDateTime', orderDetail);
  let isStoreAvailable = false;
  const isValid = isOrderExpired(submittedDateTime);
  if (isValid) {
    isStoreAvailable = shippingGroups.some(group => {
      const stateDetail = pathOr('', 'stateDetail', group);
      const orderStatus = getOrderStatus(stateDetail);
      return group.storeId !== null && orderStatus !== -1;
    });
  }
  return isStoreAvailable;
};
export const formatDateForCurbside = d => {
  // To change date format from 'mm/dd/yyyy' to 'dd/mm/yyyy'for US .

  const dateParts = d.split('/');
  if (dateParts.length === 3) {
    return `${dateParts[1]}/${dateParts[0]}/${dateParts[2]}`;
  }
  return '';
};
