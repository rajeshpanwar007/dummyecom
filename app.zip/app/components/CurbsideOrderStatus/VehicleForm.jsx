/* istanbul ignore file */
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import { isEmpty, pathOr } from 'lodash/fp';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Paragraph from '@bbb-app/core-ui/paragraph';
import TealiumHandler from '@bbb-app/tealium/TealiumHandler';
import FormInput from '@bbb-app/forms/containers/FormInput/FormInput';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import styles from './CurbsideOrderStatus.css';
import { MODAL_STATE } from './constants';
import { ModalHeader } from './Curbside';

/**
 *
 *
 * @class VehicleForm
 * @extends {React.PureComponent}
 */
class VehicleForm extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      customerNote: '',
      parkingSlot: '',
    };
  }

  componentWillReceiveProps(nextProps) {
    const { status, toggleModalMountedState } = this.props;
    /* istanbul ignore next */
    if (status !== nextProps.status && nextProps.status === 'ok') {
      toggleModalMountedState();
    }
  }

  componentWillUnmount() {
    const errCode = pathOr(
      '',
      'vehicleSubmitError.errorMessages[0].code',
      this.props
    );
    // On Unmounting of Modal, reset the Error
    if (
      errCode === 'STORE_CLOSED' &&
      typeof this.props.resetVehicleError === 'function'
    ) {
      this.props.resetVehicleError();
    }
  }

  /**
   * @function  validateSlotValue
   * @param {object} e event
   * @description Validate the pickup slot field in the form
   */
  validateSlotValue = e => {
    /* istanbul ignore next */
    return e.target.validity.valid && this.handleInputChange(e);
  };

  /**
   * @function  handleInputChange
   * @param {object} e event
   * @description Update the state with input value
   */
  handleInputChange = e => {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value });
  };

  /**
   * @function  submitForm
   * @description submit handler of the vehicle form
   */
  submitForm = e => {
    e.preventDefault();
    e.stopPropagation();
    const { customerNote, parkingSlot } = this.state;
    const {
      orderId,
      storeId,
      setVehicleDetail,
      encryptOrderId,
      fireTealiumAction,
    } = this.props;
    const tealiumConstants = {
      call_to_actiontype: 'CS_Ride Details',
    };
    setVehicleDetail(
      {
        orderId,
        storeId,
        customerNote: customerNote.substring(0, 60),
        parkingSlot,
      },
      encryptOrderId
    );
    fireTealiumAction('CS_Ride Details', tealiumConstants, '');
  };

  render() {
    const {
      orderId,
      setCurrentModalState,
      vehicleSubmitError,
      orderIdBarCodeImage,
      labels,
      status,
    } = this.props;
    const { customerNote, parkingSlot } = this.state;
    const error =
      pathOr(false, 'response.data', vehicleSubmitError) || vehicleSubmitError;
    let errorMessage = '';
    let errCode = '';
    /* istanbul ignore next */
    if (!isEmpty(error)) {
      errorMessage = pathOr('', 'errorMessages[0].message', error);
      errCode = pathOr('', 'errorMessages[0].code', error);
    }
    const isDisabled = status === true;
    const isStoreClosedError = errCode === 'STORE_CLOSED';

    const tealiumConstants = {
      page_name: 'Ride Details Screen',
      page_type: 'My Account',
      category_name: 'My Account',
      subcategory_name: 'My Account',
      channel: 'My Account',
    };
    return (
      <form
        id="vehicleDetails"
        name="vehicleDetailsform"
        noValidate
        onSubmit={this.submitForm}
      >
        <ErrorBoundary>
          <TealiumHandler
            identifier="Ride Details Screen"
            utagData={tealiumConstants}
            tealiumPageInfoNotAvailable
          />
        </ErrorBoundary>
        <GridX>
          <ModalHeader
            orderNumber={orderId}
            orderIdBarCodeImage={orderIdBarCodeImage}
            labels={labels}
            errorMessage={isStoreClosedError && errorMessage}
            showNotificationMsg
          />
          <Cell>
            <Heading level={4} className={classnames('my2', styles.subHeading)}>
              {LabelsUtil.getLabel(labels, 'curbsidePickupLabel')}
            </Heading>
          </Cell>
          <Paragraph className="mb125" theme="mediumLight">
            {LabelsUtil.getLabel(labels, 'findYouLabel')}
          </Paragraph>
          <Cell className="mb2">
            <FormInput
              id="customerNote"
              type="textarea"
              className={classnames('pr15', styles.txtCustomerNote)}
              name="customerNote"
              value={customerNote}
              label="Describe your ride (eg: Black Ford SUV)"
              onChange={e => this.handleInputChange(e)}
              aria-label="ride detail"
              maxLength="60"
              labelPosition="prepend"
              disabled={isDisabled}
              required
              counterDisplaySettings={{
                count: 60,
                countPosition: 'prepend',
                position: 'append',
                feedbackRemainingText: LabelsUtil.getLabel(
                  labels,
                  'charactersRemainingLabel',
                  ['']
                ),
              }}
            />
          </Cell>
          <Cell className="pb03">
            <FormInput
              id="parkingSlot"
              type="text"
              className={classnames(styles.parkingSlotInput)}
              name="parkingSlot"
              value={parkingSlot}
              placeholder="Your Pickup Slot Number"
              onChange={e => this.validateSlotValue(e)}
              aria-label="pickup slot"
              maxLength="3"
              pattern="[0-9]*"
              disabled={isDisabled}
            />
          </Cell>
          {!isStoreClosedError &&
            errorMessage && (
              <Cell className="pb1">
                <Paragraph
                  variation="errorMessage"
                  theme="primary"
                  className="validationErrorMessage"
                >
                  {errorMessage}
                </Paragraph>
              </Cell>
            )}
          <Cell className="small-12 large-6">
            <Button
              type="submit"
              className={classnames('mb2', styles.submitBtn)}
              theme={isStoreClosedError ? 'deactivated' : 'primary'}
              variation={'fullWidth'}
              disabled={!customerNote || isDisabled || isStoreClosedError}
            >
              {LabelsUtil.getLabel(labels, 'submitDetailsLabel')}
            </Button>
          </Cell>
          <Cell>
            <PrimaryLink
              href="#"
              className={classnames(styles.ratherCallStoreLabel)}
              onClick={() => setCurrentModalState(MODAL_STATE.CALL_STORE)}
              variation="primary"
            >
              {LabelsUtil.getLabel(labels, 'ratherCallStoreLabel')}
            </PrimaryLink>
          </Cell>
        </GridX>
      </form>
    );
  }
}

VehicleForm.propTypes = {
  orderId: PropTypes.string,
  setCurrentModalState: PropTypes.func,
  setVehicleDetail: PropTypes.func,
  storeId: PropTypes.string,
  vehicleSubmitError: PropTypes.Object,
  encryptOrderId: PropTypes.string,
  orderIdBarCodeImage: PropTypes.string,
  labels: PropTypes.Object,
  status: PropTypes.bool,
  fireTealiumAction: PropTypes.func,
  toggleModalMountedState: PropTypes.func,
  resetVehicleError: PropTypes.func,
};

export default VehicleForm;
