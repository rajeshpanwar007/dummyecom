import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import qs from 'qs';
import pathOr from 'lodash/fp/pathOr';
import isEmpty from 'lodash/fp/isEmpty';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import HyperLink from '@bbb-app/core-ui/hyper-link';
import {
  getMyAccountPageConfig,
  getMyAccountSwitchConfig,
} from '@bbb-app/utils/myAccountUtils/siteConfig';
import Button from '@bbb-app/core-ui/button';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import Carousel from '@bbb-app/carousel/CustomCarousel';
import { addDays } from '@bbb-app/utils/addDay';

import styles from './CurbsideOrderStatus.css';
import {
  CAROUSEL_SETTINGS,
  MODAL_STATE,
  PICKUP_TYPE,
  PICKUP_PERSON_FORM,
  ALLOWED_STORES,
  OPEN_STORES_STATUS,
  CLOSED_STORES_STATUS,
} from './constants';
import {
  getPickupOrder,
  getCallStore,
  getStorePickup,
  VehicleDetails,
} from './Curbside';
import VehicleForm from './VehicleForm';
import ProgressStepBar from '../common/ProgressStepBar/ProgressStepBar';
import CurbsidePickUpPersonComponent from './CubsidePickUpPersonComponent';
/**
 *
 *
 * @class CurbsideOrderStatus
 * @extends {React.PureComponent}
 */
class CurbsideOrderStatusComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modalMountedState: false,
      currentModalState: MODAL_STATE.STORE_PICKUP,
      storeId: '',
      phone: '',
    };
    this.identifier = PICKUP_PERSON_FORM;
  }
  /* istanbul ignore next */
  componentDidMount() {
    const locationSearch = pathOr('', 'search', location);
    const query = qs.parse(locationSearch, { ignoreQueryPrefix: true });
    const curbsideEmailFlow = pathOr(false, 'curbsideEmail', query);
    if (curbsideEmailFlow) {
      const urlStoreId = pathOr(false, 'storeId', query);
      const { storeOrderDetail } = this.props;
      if (Array.isArray(storeOrderDetail)) {
        const store = storeOrderDetail.find(
          item => item.storeId === urlStoreId
        );
        if (typeof store === 'object') {
          const isOrderReady = store.stateDetail === 1;
          if (isOrderReady) {
            const { curbSideFlag, phone, storeId } = store;
            const curbsideOrder = this.getCurbsideDetails(storeId);
            const customerNote = pathOr(null, 'customerNote', curbsideOrder);
            let modalState = MODAL_STATE.STORE_PICKUP;
            if (customerNote) {
              modalState = MODAL_STATE.VEHICLE_DETAILS;
            } else if (
              curbSideFlag &&
              curbSideFlag !== PICKUP_TYPE.PICKUP_STORE
            ) {
              modalState = MODAL_STATE.VEHICLE_PICKUP;
            }
            /* eslint-disable react/no-did-mount-set-state */
            this.setState({
              currentModalState: modalState,
              modalMountedState: true,
              storeId,
              phone,
            });
          }
        }
      }
    }
  }
  /**
   * @function  getModal
   * @return {Object} React component
   * @description Renders modal dialog component
   */

  getModal = () => {
    const {
      orderNumber,
      isMobileScreen,
      setVehicleDetail,
      vehicleSubmitError,
      encryptOrderId,
      orderIdBarCodeImage,
      orderhistorytime,
      status,
      labels,
      curbsideOrderError,
      fireTealiumAction,
      bbbOrderVO,
      resetVehicleError,
    } = this.props;
    const pickupFirstName = pathOr('', 'pickupFirstName', bbbOrderVO);
    const pickupLastName = pathOr('', 'pickupLastName', bbbOrderVO);
    const pickupName = pickupFirstName
      ? `${pickupFirstName} ${pickupLastName}`
      : '';
    const billingAddress = pathOr({}, 'billingAddress', bbbOrderVO);
    const firstName = pathOr('', 'firstName', billingAddress);
    const lastName = pathOr('', 'lastName', billingAddress);
    const profileName = firstName ? `${firstName} ${lastName}` : '';
    const { currentModalState, phone, storeId } = this.state;
    const pickupDays = getMyAccountPageConfig('pickupAvailableDays', 2);
    const orderPickupDate = addDays(orderhistorytime, pickupDays);
    return (
      <ModalDialog
        mountedState={this.state.modalMountedState}
        toggleModalState={this.toggleModalMountedState}
        titleAriaLabel={`modal`}
        variation="small"
        verticallyCenter
      >
        {currentModalState === MODAL_STATE.VEHICLE_PICKUP &&
          getPickupOrder(
            orderNumber,
            orderIdBarCodeImage,
            this.setCurrentModalState,
            labels
          )}
        {currentModalState === MODAL_STATE.CALL_STORE &&
          getCallStore(phone, isMobileScreen, labels)}
        {currentModalState === MODAL_STATE.VEHICLE_FORM && (
          <VehicleForm
            orderId={orderNumber}
            setCurrentModalState={this.setCurrentModalState}
            toggleModalMountedState={this.toggleModalMountedState}
            setVehicleDetail={setVehicleDetail}
            storeId={storeId}
            vehicleSubmitError={vehicleSubmitError}
            encryptOrderId={encryptOrderId}
            orderIdBarCodeImage={orderIdBarCodeImage}
            status={status}
            labels={labels}
            fireTealiumAction={fireTealiumAction}
            resetVehicleError={resetVehicleError}
          />
        )}
        {currentModalState === MODAL_STATE.VEHICLE_DETAILS && (
          <VehicleDetails
            orderNumber={orderNumber}
            orderIdBarCodeImage={orderIdBarCodeImage}
            phone={phone}
            vehicleInfo={this.getCurbsideDetails(storeId)}
            labels={labels}
            curbsideOrderError={curbsideOrderError}
            pickupName={pickupName}
            profileName={profileName}
            isMobileScreen={isMobileScreen}
          />
        )}
        {currentModalState === MODAL_STATE.STORE_PICKUP &&
          getStorePickup(
            orderNumber,
            orderIdBarCodeImage,
            phone,
            pickupName,
            profileName,
            orderPickupDate,
            labels,
            isMobileScreen
          )}
      </ModalDialog>
    );
  };
  /**
   * @function  setCurrentModalState
   * @param {object} currentState modal current state
   * @description Sets the modal state
   */
  setCurrentModalState = currentState => {
    /* istanbul ignore next */
    this.fireAction(currentState);
    this.setState({ currentModalState: currentState });
  };
  /**
   * @function  getCurbsideDetails
   * @param {string} storeId store id
   * @description returns curbside details of the order
   */
  getCurbsideDetails = storeId => {
    const { curbsideOrderDetails, orderNumber } = this.props;
    const curbsideDetails = pathOr(
      {},
      [orderNumber, storeId],
      curbsideOrderDetails
    );
    return curbsideDetails;
  };
  getMessageHeader = (orderStatusIndex, messageHeader) => {
    const { labels } = this.props;
    const lblMessageHeader = [
      'processingOrderLabel',
      'orderReadyLabel',
      'thankyouLabel',
    ];
    if (orderStatusIndex === 0) {
      return LabelsUtil.getLabel(labels, lblMessageHeader[0]);
    } else if (orderStatusIndex === 2) {
      return LabelsUtil.getLabel(labels, lblMessageHeader[2]);
    }
    return messageHeader || LabelsUtil.getLabel(labels, lblMessageHeader[1]);
  };
  getMessage = (store, orderStatusIndex, message, statusCode) => {
    const { labels, isMobileScreen } = this.props;
    const storePhone = pathOr('', 'phone', store);
    if (orderStatusIndex > -1 && orderStatusIndex < 2 && !statusCode) {
      return (
        <span>
          {`at ${store.commonName}, ${store.state}`}
          <span className={classnames('ml025', styles.storePhone)}>
            {isMobileScreen && (
              <HyperLink
                variation="phoneNumber"
                textDecoration="textDecorationNone"
                href={`tel:${storePhone.replace(/(\D+)/g, '')}`}
              >
                {storePhone}
              </HyperLink>
            )}
            {!isMobileScreen && storePhone}
          </span>
        </span>
      );
    } else if (orderStatusIndex === 2 || statusCode === 4) {
      return LabelsUtil.getLabel(labels, 'enjoyedCurbsideLabel');
    }
    return message;
  };

  getStoreMsgHeader = () => {
    const { labels } = this.props;
    return LabelsUtil.getLabel(labels, 'storeCurrentlyClosed');
  };

  fireAction = currentState => {
    const { fireTealiumAction } = this.props;
    let tealiumConstants;
    switch (currentState) {
      case MODAL_STATE.VEHICLE_PICKUP: {
        tealiumConstants = {
          call_to_actiontype: 'CS_At Store',
        };
        return fireTealiumAction('CS_At Store', tealiumConstants, '');
      }
      case MODAL_STATE.VEHICLE_FORM: {
        tealiumConstants = {
          call_to_actiontype: 'CS_Want Curbside',
        };
        return fireTealiumAction('CS_Want Curbside', tealiumConstants, '');
      }
      case MODAL_STATE.CALL_STORE: {
        tealiumConstants = {
          call_to_actiontype: 'CS_Call Store',
        };
        return fireTealiumAction('CS_Call Store', tealiumConstants, '');
      }
      default:
        return true;
    }
  };
  /**
   * @function  toggleModalMountedState
   * @description Changes the modal state
   */
  toggleModalMountedState = () => {
    /* istanbul ignore next */
    this.setState({ modalMountedState: !this.state.modalMountedState });
  };

  /**
   * @function  buttonClickHandler
   * @param {object} store store details
   * @param {string} customerNote vehicle details entered by the user
   * @description changes the modal state
   */
  buttonClickHandler = (store, customerNote) => {
    const { curbSideFlag, storeId, phone } = store;
    let modalState = MODAL_STATE.STORE_PICKUP;
    if (customerNote) {
      modalState = MODAL_STATE.VEHICLE_DETAILS;
    } else if (curbSideFlag && curbSideFlag !== PICKUP_TYPE.PICKUP_STORE) {
      modalState = MODAL_STATE.VEHICLE_PICKUP;
    }
    this.fireAction(modalState);
    this.setState(
      {
        currentModalState: modalState,
        storeId,
        phone,
      },
      this.toggleModalMountedState()
    );
  };
  /**
   * checking orderstatusindex on the basis of curbsideOrderstatus
   */
  orderStsIndex = (statusCode, store) => {
    return statusCode === 4 ? 2 : store.stateDetail;
  };
  /**
   * checking curbside status and store  state-detail for order ready status
   */
  orderReady = (store, statusCode) => {
    return store.stateDetail === 1 && (!statusCode || statusCode !== 4);
  };
  /**
   * checking curbside message and curbside statuscode for help text
   */
  showHelpText = (curbsideOrder, statusCode) => {
    return curbsideOrder.message && (!statusCode || statusCode !== 4);
  };
  /**
   * checking to show message header class on the basis of order status
   */
  messageHeaderClass = (
    orderStatusIndex,
    statusCode,
    showStoreHoursMessage
  ) => {
    return orderStatusIndex === 2 || statusCode > 3 || showStoreHoursMessage;
  };
  /**
   * @function  renderCurbsideMessage
   * @param {string} curbSideFlag flag indicates whether curbside pickup is available
   * @description return the message if curbside pickup is available for the given store
   */

  renderCurbsideMessage = curbSideFlag => {
    const { labels } = this.props;
    let message = '';
    if (curbSideFlag === PICKUP_TYPE.CURBSIDE_PICKUP_AVAILABLE) {
      message = LabelsUtil.getLabel(labels, 'pickupAvailableLabel');
    } else if (curbSideFlag === PICKUP_TYPE.CURBSIDE_PICKUP_ONLY) {
      message = LabelsUtil.getLabel(labels, 'pickupOnlyLabel');
    }
    return message;
  };
  renderProgressBar = orderStatusIndex => {
    const { labels } = this.props;
    if (orderStatusIndex > -1) {
      return null;
    }
    return <ProgressStepBar progress={orderStatusIndex} labels={labels} />;
  };
  /**
 * return the  Text for I m at store and pickupbar code
 */
  renderAtStoreAndPickupBtn = (
    disableBtnForClosedStores,
    store,
    curbsideOrder,
    ctaText
  ) => {
    return (
      <React.Fragment>
        <Button
          variation="fullWidth"
          className={classnames(styles.storeBtn)}
          theme={disableBtnForClosedStores ? 'deactivated' : 'primary'}
          disabled={disableBtnForClosedStores}
          onClick={() =>
            this.buttonClickHandler(store, curbsideOrder.customerNote)}
        >
          {ctaText}
        </Button>
      </React.Fragment>
    );
  };
  /**
   * @function  renderStoreTimingMessage
   * @param  store contains store data using for store status and message
   * @param isAtStore is used to check (i m at store) Button
   * @description return the message if store status is available for the given store and isAtstore is true
   */
  renderStoreTimingMessage = (store, storeStatusForHours, isAtStore) => {
    if (isAtStore) {
      const storeMessageClassname = OPEN_STORES_STATUS.includes(
        storeStatusForHours
      )
        ? styles.storeMsgOpen
        : styles.storeMsgClosed;

      const storeMsg = pathOr('', 'storeMessege', store);
      const storeOpenCloseMsg = storeMsg && storeMsg.split(',');
      const storeOpenCloseStatusMsg = storeOpenCloseMsg[0];
      const storeHoursMsg = storeOpenCloseMsg[1];
      if (storeStatusForHours && storeStatusForHours !== 1) {
        return (
          <div className={classnames(styles.storeMessageBold)}>
            <span className={classnames(storeMessageClassname)}>
              {storeOpenCloseStatusMsg}
            </span>
            {!isEmpty(storeHoursMsg) ? `,${storeHoursMsg}` : ''}
          </div>
        );
      }
    }
    return null;
  };
  /**
   * @function  renderCarouselContent
   * @description renders carousel content
   */
  renderCarouselContent() {
    const {
      labels,
      storeOrderDetail,
      isMobileScreen,
      formWrapperDataPickUpPersonForm,
      altPickupFirstName,
      altPickupLastName,
      fetchAltPickupPersonFormData,
      clearIdentifierStateData,
      altPickupEmail,
      userRegistrationInfo,
      endPoint,
      identifier,
      bbbOrderVO,
      fireTealiumAction,
      altPickupPersonError,
      clearPickupPersonInfo,
      onSuccessPickupPerson,
    } = this.props;
    /**
     * Key used to show/hide ADD/EDIT CTA for pickup person
     */
    const isAltPickupPersonEnabled = getMyAccountSwitchConfig(
      'enableAltPickupPerson',
      false
    );
    /**
     * Key used to show/hide EXTEND CTA for pickup date
     */
    const isPickupDateEnabled = getMyAccountSwitchConfig(
      'enablePickupDate',
      false
    );
    /**
     * Key used to show/hide store messages and enable/disable im at store btn
     */
    const isStoreHoursMessageEnabled = getMyAccountSwitchConfig(
      'enableStoreHoursMessage',
      false
    );
    const orderId = pathOr('', 'orderId', bbbOrderVO);
    const encryptOrderIdForpickup = pathOr('', 'encryptOrderId', bbbOrderVO);
    const pickupExtendDays = pathOr('', 'pickupExtendDays', bbbOrderVO);
    /* eslint complexity: ["error", 12]*/
    return storeOrderDetail.map(store => {
      const curbsideOrder = store && this.getCurbsideDetails(store.storeId);
      const statusCode = pathOr(null, 'curbsideStatusCode', curbsideOrder);
      const infoMessage =
        statusCode < 1 &&
        store &&
        this.renderCurbsideMessage(store.curbSideFlag);
      const isOrderReady = this.orderReady(store, statusCode);

      const orderStatusIndex = this.orderStsIndex(statusCode, store);
      const isShowNeedHelpText = this.showHelpText(curbsideOrder, statusCode);
      const storeStatusForHours = store.storeStatus;
      const showStoreHoursMessage =
        isStoreHoursMessageEnabled && storeStatusForHours === 4;
      const messageHeaderClassname = this.messageHeaderClass(
        orderStatusIndex,
        statusCode,
        showStoreHoursMessage
      )
        ? styles.blacktext
        : '';
      /**
         * showPickupCTAs  is introduced here to check when pickupBarCode button is enable then not showing ADD/Edit and Extend CTA's
         */
      let ctaText = '';
      let showPickupCTAs = true;

      const isAtStore =
        infoMessage && curbsideOrder && !curbsideOrder.customerNote;
      if (isOrderReady) {
        if (isAtStore) {
          ctaText = LabelsUtil.getLabel(labels, 'atStoreLabel');
        } else {
          if (store.curbSideFlag !== PICKUP_TYPE.PICKUP_STORE) {
            showPickupCTAs = false;
          }
          ctaText = LabelsUtil.getLabel(labels, 'pickupBarcodeLabel');
        }
      }
      const disableBtnForClosedStores =
        isStoreHoursMessageEnabled &&
        isAtStore &&
        CLOSED_STORES_STATUS.includes(storeStatusForHours);
      return (
        store && (
          <div className={classnames(styles.px55)}>
            <Heading
              level={3}
              className={classnames('pb175', styles.progressBar)}
            >
              {orderStatusIndex > -1 ? (
                <ProgressStepBar progress={orderStatusIndex} labels={labels} />
              ) : null}
            </Heading>
            <div
              className={classnames(
                'flex justify-between',
                styles.curbsideSection
              )}
            >
              <div
                className={classnames(
                  styles.curbsideSubSection,
                  styles.verticalLine
                )}
              >
                <div
                  className={classnames(
                    styles.orderStatus,
                    `${messageHeaderClassname}`
                  )}
                >
                  {showStoreHoursMessage
                    ? this.getStoreMsgHeader()
                    : this.getMessageHeader(
                        orderStatusIndex,
                        curbsideOrder.messageHeader
                      )}
                </div>
                <div className={classnames(styles.orderMessage)}>
                  {this.getMessage(
                    store,
                    store.stateDetail,
                    curbsideOrder.message,
                    statusCode
                  )}
                </div>
                {showStoreHoursMessage ? (
                  <div className={classnames('mb2', styles.orderMessage)}>
                    {store.storeMessege}

                    <PrimaryLink
                      className={classnames(styles.colorAdd)}
                      href={endPoint.findAStore}
                      data-locator="check-store-hours-button"
                    >
                      {LabelsUtil.getLabel(labels, 'checkStoreHours')}
                    </PrimaryLink>
                  </div>
                ) : (
                  ''
                )}
                {!curbsideOrder.message &&
                  infoMessage && (
                    <div className={classnames('mb2', styles.orderMessage)}>
                      {infoMessage}
                    </div>
                  )}
                {isShowNeedHelpText && (
                  <div className={classnames('mb2', styles.orderMessage)}>
                    <span className={classnames('mr025')}>
                      {LabelsUtil.getLabel(labels, 'needHelpLabel')}
                    </span>
                    <span className={classnames(styles.storePhone)}>
                      {isMobileScreen && (
                        <HyperLink
                          variation="phoneNumber"
                          textDecoration="textDecorationNone"
                          href={`tel:${store.phone.replace(/(\D+)/g, '')}`}
                        >
                          {store.phone}
                        </HyperLink>
                      )}
                      {!isMobileScreen && store.phone}
                    </span>
                  </div>
                )}
                {(isAltPickupPersonEnabled || isPickupDateEnabled) &&
                  showPickupCTAs && (
                    <CurbsidePickUpPersonComponent
                      labels={labels}
                      identifier={this.identifier}
                      formWrapperDataPickUpPersonForm={
                        formWrapperDataPickUpPersonForm
                      }
                      altPickupFirstName={altPickupFirstName}
                      altPickupLastName={altPickupLastName}
                      curbsideOrderStatus={curbsideOrder.curbsideStatusCode}
                      fetchAltPickupPersonFormData={
                        fetchAltPickupPersonFormData
                      }
                      curbsideOrderDetails={curbsideOrder}
                      altPickupPersonDetails={this.props.altPickupPersonDetails} // use this for showing error msg from new Ms
                      clearIdentifierStateData={clearIdentifierStateData}
                      altPickupEmail={altPickupEmail}
                      isPickupDateEnabled={isPickupDateEnabled}
                      extendedPickupDate={
                        store.extendedPickupDate === null
                          ? ''
                          : store.extendedPickupDate
                      }
                      pickupDate={pathOr('', 'pickupDate', store)}
                      userRegistrationInfo={userRegistrationInfo}
                      endPoint={endPoint}
                      pageType={identifier}
                      pickupExtendDays={pickupExtendDays}
                      storeStateDetail={store.stateDetail}
                      fireTealiumAction={fireTealiumAction}
                      shippingGroupId={store.id}
                      storeId={store.storeId}
                      orderNumber={this.props.orderNumber}
                      encryptOrderId={encryptOrderIdForpickup}
                      altPickupPersonError={altPickupPersonError}
                      clearPickupPersonInfo={clearPickupPersonInfo}
                      onSuccessPickupPerson={onSuccessPickupPerson}
                      isAltPickupPersonEnabled={isAltPickupPersonEnabled}
                      orderId={orderId}
                      isStoreOnlyPickup={
                        store.curbsideFlag !== PICKUP_TYPE.PICKUP_STORE
                      }
                    />
                  )}
              </div>
              {isOrderReady && (
                <div className={classnames(styles.storeBtnText)}>
                  {this.renderAtStoreAndPickupBtn(
                    disableBtnForClosedStores,
                    store,
                    curbsideOrder,
                    ctaText
                  )}

                  {isStoreHoursMessageEnabled &&
                  isAtStore &&
                  ALLOWED_STORES.includes(storeStatusForHours)
                    ? this.renderStoreTimingMessage(
                        store,
                        storeStatusForHours,
                        isAtStore
                      )
                    : ''}
                </div>
              )}
            </div>
          </div>
        )
      );
    });
  }
  /**
   * @function  renderCarousel
   * @description return the carousel containing the curbside messages and renders modal as per given state
   */
  renderCarousel = () => {
    const { storeOrderDetail } = this.props;
    return (
      <React.Fragment>
        <div
          className={classnames('pb1 pt15', styles.featuredCurbside, styles.bb)}
        >
          <Carousel
            arrows={storeOrderDetail.length > 1}
            dots={storeOrderDetail.length > 1}
            {...CAROUSEL_SETTINGS}
            labels={this.props.labels} // labels passed here for Previous and Next button label values
          >
            {this.renderCarouselContent()}
          </Carousel>
          {this.getModal()}
        </div>
      </React.Fragment>
    );
  };
  render() {
    const { storeOrderDetail } = this.props;
    return (
      storeOrderDetail && !!storeOrderDetail.length && this.renderCarousel()
    );
  }
}
CurbsideOrderStatusComponent.propTypes = {
  orderNumber: PropTypes.string,
  storeOrderDetail: PropTypes.array,
  labels: PropTypes.object,
  isMobileScreen: PropTypes.bool,
  setVehicleDetail: PropTypes.func,
  curbsideOrderDetails: PropTypes.Object,
  status: PropTypes.bool,
  vehicleSubmitError: PropTypes.Object,
  encryptOrderId: PropTypes.string,
  orderIdBarCodeImage: PropTypes.string,
  orderhistorytime: PropTypes.string,
  curbsideOrderError: PropTypes.Object,
  fireTealiumAction: PropTypes.func,
  bbbOrderVO: PropTypes.Object,
  formWrapperDataPickUpPersonForm: PropTypes.object,
  altPickupFirstName: PropTypes.string,
  altPickupLastName: PropTypes.string,
  fetchAltPickupPersonFormData: PropTypes.func,
  clearIdentifierStateData: PropTypes.func,
  altPickupPersonDetails: PropTypes.Object,
  altPickupEmail: PropTypes.string,
  userRegistrationInfo: PropTypes.Object,
  endPoint: PropTypes.string,
  identifier: PropTypes.string,
  altPickupPersonError: PropTypes.Object,
  clearPickupPersonInfo: PropTypes.func,
  onSuccessPickupPerson: PropTypes.bool,
  resetVehicleError: PropTypes.func,
};
CurbsideOrderStatusComponent.defaultProps = {
  isMobileScreen: false,
};
export default CurbsideOrderStatusComponent;
