import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import classnames from 'classnames';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { isBedBathCanada } from '@bbb-app/utils/common';
import Cell from '@bbb-app/core-ui/cell';
import Button from '@bbb-app/core-ui/button';
import Icon from '@bbb-app/core-ui/icon';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import styles from './CurbsideOrderStatus.css';
import AddEditPickUpPerson from './AddEditPickUpPerson/AddEditPickUpPerson';
import CurbsideWindowExtension from './AddEditPickUpPerson/CurbsideWindowExtension';
import { formatDate, dateAsPerLocale } from '../../utils/formatDate';
import {
  ADD_PICKUP_PERSON,
  PICKUP_CLOSE_MODAL,
  PICKUP_PERSON_MODAL_OVERLAY,
  PICKUP_PERSON_DIALOG,
  ORDER_IN_PROCESSING,
  READY_FOR_PICKUP_ORDER,
  MYACCOUNT,
  EXTEND_PICKUP,
  EXTEND_PICK_UP_PAGE,
  ADD,
  EDIT,
} from './constants';
import CurbsidePickUpTealiumHandler from '../../../app/containers/ThirdParty/Tealium/CurbsidePickUpTealiumHandler/CurbsidePickUpTealiumHandler';
/**
   * It will display Add/Edit CTA on the basis of alternate Pickup person
   */
const renderCta = (isPickupAvailable, labels) => {
  return LabelsUtil.getLabel(
    labels,
    isPickupAvailable ? 'editPickUpPerson' : 'addPickUpPerson'
  );
};
/**
 * Render for pickup date
 * @param {*} labels
 * @param {*} windowPickupDate   pickupdate to show with extend if its in Ms then will show that otherwise show it from atg
 * @param {*} isPickUpDateExtendable key , valued as true/false is used to show Extend CTA or not and its coming from MS orders
 * @param {*} windowModalClickHandler is used to call when click on Extend CTA
 * @param {*} curbsideOrderDetails is used here if prop(pickUpDateExtendable) is not present in the object(curbsideOrderDetails) OR if it is present and its value is true then we show the CTA else we do not show
 */
const renderPickupDateDetail = (
  labels,
  windowPickupDate,
  isPickUpDateExtendable,
  windowModalClickHandler,
  curbsideOrderDetails
) => {
  return (
    <React.Fragment>
      <Cell className={classnames('mb2')}>
        <span
          className={classnames(
            styles.marginRightForExtension,
            styles.nameFontWeight
          )}
        >
          {LabelsUtil.getLabel(labels, 'pickupBy')}
        </span>
        <span
          className={classnames(
            styles.marginRightForExtension,
            styles.nameFontWeight
          )}
        >
          {isBedBathCanada()
            ? formatDate(windowPickupDate, 'dd month, yyyy')
            : formatDate(windowPickupDate, 'month dd, yyyy')}
        </span>
        {!Object.prototype.hasOwnProperty.call(
          curbsideOrderDetails,
          'pickUpDateExtendable'
        ) || isPickUpDateExtendable ? (
          <Button
            data-locator="extend-addPickUpPerson"
            onClick={windowModalClickHandler}
            theme={'link'}
            variation="blacklink"
          >
            <Cell className={classnames('center', styles.colorAdd)}>
              {LabelsUtil.getLabel(labels, 'extend')}
            </Cell>
          </Button>
        ) : (
          ''
        )}
      </Cell>
    </React.Fragment>
  );
};
/**
 *
 * @param {*} labels
 * @param {*} isPickupAvailable checking names from MS first then from Atg response
 * @param {*} firstName alternate Pikcup person
 * @param {*} lastName
 * @param {*} addModalClickHandler
 */
const renderPickupPersonDetail = (
  labels,
  isPickupAvailable,
  firstName,
  lastName,
  addModalClickHandler,
  pageType
) => {
  const pickUpName =
    pageType === 'TrackOrderGuestNew' ? firstName : `${firstName} ${lastName}`;
  return (
    <React.Fragment>
      <Cell className={classnames('mt1', styles.alternatePickup)}>
        <span>{LabelsUtil.getLabel(labels, 'alternatePickupPerson')}</span>
      </Cell>
      <Cell>
        {isPickupAvailable ? (
          <span className={classnames('mr1', styles.nameFontWeight)}>
            {pickUpName}
          </span>
        ) : (
          <span className={classnames('mr1', styles.nameFontWeight)}>
            {LabelsUtil.getLabel(labels, 'none')}
          </span>
        )}
        <Button
          data-locator="order-addPickUpPerson"
          theme={'link'}
          onClick={addModalClickHandler}
          variation="blacklink"
        >
          <Cell className={classnames('center', styles.colorAdd)}>
            {renderCta(isPickupAvailable, labels)}
          </Cell>
        </Button>
      </Cell>
    </React.Fragment>
  );
};
/* eslint complexity: ["error", 11]*/
export const CurbsidePickUpPersonComponent = ({
  labels,
  identifier,
  formWrapperDataPickUpPersonForm,
  altPickupFirstName,
  altPickupLastName,
  fetchAltPickupPersonFormData,
  curbsideOrderDetails,
  clearIdentifierStateData,
  altPickupEmail,
  extendedPickupDate,
  pickupDate,
  userRegistrationInfo,
  endPoint,
  pageType,
  pickupExtendDays,
  storeStateDetail,
  isPickupDateEnabled,
  fireTealiumAction,
  shippingGroupId,
  storeId,
  orderNumber,
  encryptOrderId,
  altPickupPersonError,
  clearPickupPersonInfo,
  onSuccessPickupPerson,
  isAltPickupPersonEnabled,
  orderId,
  isStoreOnlyPickup,
}) => {
  /**
   * On Success of API, unmounting the pop up modal
   */
  /* istanbul ignore next */
  useEffect(
    () => {
      if (onSuccessPickupPerson) {
        setMountedState(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [onSuccessPickupPerson]
  );
  /**
   *  userRegistrationInfo = get user-email from stateful registration/status api for track Order
   */
  const profileResponseForTrackOrderModal = pathOr(
    null,
    'atgResponse',
    userRegistrationInfo
  );
  const modalProps = {
    titleAriaLabel: LabelsUtil.getLabel(labels, 'addPickupPerson'),
    verticallyCenter: true,
    variation: 'small',
    underlayClickExits: true,
    scrollDisabled: false,
    titleId: ADD_PICKUP_PERSON,
    closeDataLocator: PICKUP_CLOSE_MODAL,
    modalDataLocator: PICKUP_PERSON_MODAL_OVERLAY,
    dialogID: PICKUP_PERSON_DIALOG,
    rclModalClass: styles.pickupPersonModal,
    dialogClass: styles.pickupPersonAndExtendModal,
  };
  /**
   * Here we getting response from ATG and MS for firstName and Lastname
   * First will check from MS if its not there then it check from ATG
   * altPickupFirstName,altPickupLastName  from ATG
   * altPersonFirstName,altPersonLastName from MS
   * curbsideOrderDetails from MS
   */
  const firstName =
    pathOr('', 'altPersonFirstName', curbsideOrderDetails) ||
    altPickupFirstName ||
    '';
  const lastName =
    pathOr('', 'altPersonLastName', curbsideOrderDetails) ||
    altPickupLastName ||
    '';
  /**
   * Here we getting response from ATG and MS for pickupDate
   * First will check from MS if its not there then it check from ATG
   * pickupDate  from ATG
   * pickUpByDate from MS
   */
  const pickupDateFromMs = pathOr('', 'pickUpByDate', curbsideOrderDetails);
  const pickupDateToShowonScreen = pickupDateFromMs || pickupDate || '';
  const windowPickupDate = pickupDateFromMs
    ? new Date(pickupDateFromMs)
    : dateAsPerLocale(pickupDateToShowonScreen);
  /**
   * Created boolean to check need to show Extend cta or not ,
   * because Cta will show when in MS Orders isPickUpDateExtendable is true
   */
  const isPickUpDateExtendable = pathOr(
    false,
    'pickUpDateExtendable',
    curbsideOrderDetails
  );
  const isPickupAvailable = firstName !== '' || lastName !== '';
  /**
   * Here handling of which modal will render on click of Add/Edit and Extend
   */
  const [mountedState, setMountedState] = useState(false);
  const [currentModalView, setCurrentModalView] = useState('pickupPerson');
  // Firing Tealium Events
  const fireAction = extendPickUpState => {
    const lblAddEdit = isPickupAvailable ? EDIT : ADD;
    const tealiumConstants = {
      navigation_path: MYACCOUNT,
      subnavigation_path: MYACCOUNT,
      page_function: MYACCOUNT,
      channel: MYACCOUNT,
      pagename_breadcrumb:
        extendPickUpState === 'extendClick'
          ? EXTEND_PICK_UP_PAGE
          : `MYACCOUNT > BOPIS PickUp Name ${lblAddEdit}`,
      call_to_actiontype:
        extendPickUpState === 'extendClick'
          ? EXTEND_PICKUP
          : `${lblAddEdit} alt pickup`,
    };
    return fireTealiumAction('Click', tealiumConstants, '');
  };
  const handleCancel = () => {
    setMountedState(false);
    clearPickupPersonInfo();
  };
  /**
   * Render on click of Add/Edit
   */
  const addModalClickHandler = () => {
    setMountedState(true);
    setCurrentModalView('pickupPerson');
    clearPickupPersonInfo();
  };
  /**
 * Render on click of Extend
 */
  const windowModalClickHandler = () => {
    setMountedState(true);
    setCurrentModalView('pickupExtension');
    clearPickupPersonInfo();
  };
  /**
   * storeStateDetail  is getting from store.stateDetail, which specifies that Order is in
   * processing state or Ready for Pickup
   * isPickupDateEnabled  checking if it is enable then Extend date would render
   * isAltPickupPersonEnabled  checking if it is enable then ADD/Edit pick up Person would render
   *  */
  return (
    <React.Fragment>
      {[ORDER_IN_PROCESSING, READY_FOR_PICKUP_ORDER].includes(
        storeStateDetail
      ) && (
        <div className={classnames(styles.featuredPickup)}>
          <Cell className={classnames(styles.orderMessage)}>
            <span>
              {isStoreOnlyPickup
                ? ''
                : LabelsUtil.getLabel(labels, 'curbsidePickupHeading')}
            </span>
          </Cell>
          {isPickupDateEnabled &&
            READY_FOR_PICKUP_ORDER === storeStateDetail && (
              <div>
                {renderPickupDateDetail(
                  labels,
                  windowPickupDate,
                  isPickUpDateExtendable,
                  windowModalClickHandler,
                  curbsideOrderDetails
                )}
              </div>
            )}
          {isAltPickupPersonEnabled && (
            <div>
              {renderPickupPersonDetail(
                labels,
                isPickupAvailable,
                firstName,
                lastName,
                addModalClickHandler,
                pageType
              )}
            </div>
          )}
        </div>
      )}
      <ModalDialog
        mountedState={mountedState}
        toggleModalState={state => {
          setMountedState(state);
        }}
        onModalClose={handleCancel}
        customCloseIcon={<Icon width="16" height="16" type="close" />}
        {...modalProps}
      >
        {currentModalView === 'pickupExtension' ? (
          <CurbsideWindowExtension
            labels={labels}
            identifier={identifier}
            handleCancel={handleCancel}
            curbsideDetails={curbsideOrderDetails}
            extendedPickupDate={extendedPickupDate}
            fetchAltPickupPersonFormData={fetchAltPickupPersonFormData}
            pickupExtendDays={pickupExtendDays}
            shippingGroupId={shippingGroupId}
            storeId={storeId}
            orderNumber={orderNumber}
            encryptOrderId={encryptOrderId}
            altPickupPersonError={altPickupPersonError}
            clearPickupPersonInfo={clearPickupPersonInfo}
            setMountedState={setMountedState}
            onSuccessPickupPerson={onSuccessPickupPerson}
            fireAction={fireAction}
          />
        ) : (
          <AddEditPickUpPerson
            labels={labels}
            identifier={identifier}
            formWrapperDataPickUpPersonForm={formWrapperDataPickUpPersonForm}
            handleCancel={handleCancel}
            fetchAltPickupPersonFormData={fetchAltPickupPersonFormData}
            curbsideDetails={curbsideOrderDetails}
            clearIdentifierStateData={clearIdentifierStateData}
            isPickupAvailable={isPickupAvailable}
            altPickupEmail={altPickupEmail}
            firstName={firstName}
            lastName={lastName}
            profileResponseForTrackOrderModal={
              profileResponseForTrackOrderModal
            }
            endPoint={endPoint}
            pageType={pageType}
            shippingGroupId={shippingGroupId}
            storeId={storeId}
            orderNumber={orderNumber}
            encryptOrderId={encryptOrderId}
            altPickupPersonError={altPickupPersonError}
            setMountedState={setMountedState}
            clearPickupPersonInfo={clearPickupPersonInfo}
            onSuccessPickupPerson={onSuccessPickupPerson}
            orderId={orderId}
            fireAction={fireAction}
          />
        )}
        <CurbsidePickUpTealiumHandler
          isPickupAvailable={isPickupAvailable}
          currentModalView={currentModalView}
        />
      </ModalDialog>
    </React.Fragment>
  );
};
CurbsidePickUpPersonComponent.propTypes = {
  labels: PropTypes.Object,
  identifier: PropTypes.string,
  formWrapperDataPickUpPersonForm: PropTypes.Object,
  altPickupFirstName: PropTypes.string,
  altPickupLastName: PropTypes.string,
  fetchAltPickupPersonFormData: PropTypes.func,
  curbsideOrderDetails: PropTypes.Object,
  clearIdentifierStateData: PropTypes.func,
  altPickupEmail: PropTypes.string,
  extendedPickupDate: PropTypes.Date,
  pickupDate: PropTypes.Date,
  userRegistrationInfo: PropTypes.Object,
  endPoint: PropTypes.string,
  pageType: PropTypes.string,
  pickupExtendDays: PropTypes.any,
  storeStateDetail: PropTypes.int,
  isPickupDateEnabled: PropTypes.bool,
  fireTealiumAction: PropTypes.func,
  shippingGroupId: PropTypes.string,
  storeId: PropTypes.string,
  orderNumber: PropTypes.string,
  encryptOrderId: PropTypes.string,
  altPickupPersonError: PropTypes.Object,
  clearPickupPersonInfo: PropTypes.func,
  onSuccessPickupPerson: PropTypes.bool,
  isAltPickupPersonEnabled: PropTypes.bool,
  orderId: PropTypes.string,
  isStoreOnlyPickup: PropTypes.bool,
};
export default CurbsidePickUpPersonComponent;
