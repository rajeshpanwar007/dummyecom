import classnames from 'classnames';
import styles from './CurbsideOrderStatus.css';

const CAROUSEL_SETTINGS = {
  slide: true,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        swipe: true,
      },
    },
  ],
  slidesToShow: 1,
  touchMove: true,
  slidesToScroll: 1,
  swipe: false,
  infinite: false,
  speed: 500,
  autoplay: false,
  lazyLoad: false,
  dotsClass: classnames(styles.customDots),
  className: 'smallArrow roundedCorners',
};

const MODAL_STATE = {
  VEHICLE_PICKUP: 'vehiclePickup',
  CALL_STORE: 'callStore',
  VEHICLE_FORM: 'vehicleForm',
  VEHICLE_DETAILS: 'vehicleDetails',
  STORE_PICKUP: 'storePickup',
};

const PICKUP_TYPE = {
  PICKUP_STORE: '0',
  CURBSIDE_PICKUP_AVAILABLE: '1',
  CURBSIDE_PICKUP_ONLY: '2',
};

// Identifier for alternate pick up person
const PICKUP_PERSON_FORM = 'pickupPersonForm';
const ADD_PICKUP_PERSON = 'addPickupPerson';
const PICKUP_CLOSE_MODAL = 'pickupPersonModal-modalcloseicon';
const PICKUP_PERSON_MODAL_OVERLAY = 'pickupPersonModal-modaloverlay';
const PICKUP_PERSON_DIALOG = 'pickupPersonModalDialog';
const ORDER_IN_PROCESSING = 0;
const READY_FOR_PICKUP_ORDER = 1;
const MYACCOUNT = 'My Account';
const EXTEND_PICKUP = 'extend pickup time';
const EXTEND_PICK_UP_PAGE = 'My Account >BOPIS Extented Pickup Time';
const ADD = 'add';
const EDIT = 'edit';
const ALLOWED_STORES = [1, 2, 3]; // stores status for store hours message
const OPEN_STORES_STATUS = [1, 2]; // store status when its open
const CLOSED_STORES_STATUS = [3, 4]; // store status when its close
export {
  CAROUSEL_SETTINGS,
  MODAL_STATE,
  PICKUP_TYPE,
  PICKUP_PERSON_FORM,
  ADD_PICKUP_PERSON,
  PICKUP_CLOSE_MODAL,
  PICKUP_PERSON_MODAL_OVERLAY,
  PICKUP_PERSON_DIALOG,
  ORDER_IN_PROCESSING,
  READY_FOR_PICKUP_ORDER,
  MYACCOUNT,
  EXTEND_PICKUP,
  EXTEND_PICK_UP_PAGE,
  ADD,
  EDIT,
  ALLOWED_STORES,
  OPEN_STORES_STATUS,
  CLOSED_STORES_STATUS,
};
