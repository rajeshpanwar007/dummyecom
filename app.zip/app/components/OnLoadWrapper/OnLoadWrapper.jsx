import React from 'react';
import PropTypes from 'prop-types';
import isBrowser from '@bbb-app/utils/isBrowser';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary/ErrorBoundary';

/**
 * @property propTypes
 * @description Defined property types for component
 */
const propTypes = {
  children: PropTypes.node,
};

class OnLoadWrapper extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isWindowLoaded: false,
    };
  }

  componentDidMount() {
    /* istanbul ignore else */
    if (isBrowser() && window.addEventListener) {
      window.addEventListener('load', () => {
        this.renderLoad();
      });
    } else {
      window.onload = () => this.renderLoad();
    }
  }

  renderLoad = () => {
    this.setState({ isWindowLoaded: true });
  };

  /**
   * Render OnLoadWrapper component to remove element from critical rendering path
   * @param {Object} props
   */
  render() {
    const { children } = this.props;
    const { isWindowLoaded } = this.state;
    return <ErrorBoundary>{isWindowLoaded && children}</ErrorBoundary>;
  }
}

OnLoadWrapper.propTypes = propTypes;
export default OnLoadWrapper;
