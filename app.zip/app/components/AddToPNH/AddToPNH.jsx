import React from 'react';
import PropTypes from 'prop-types';
import pathOr from 'lodash/fp/pathOr';
import isEmpty from 'lodash/fp/isEmpty';
import isArray from 'lodash/fp/isArray';
import classnames from 'classnames';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import MemoizeLast from '@bbb-app/utils/memoizeLast';
import uniqueKeys from '@bbb-app/utils/uniqueKeys';
import { isTouchDevice } from '@bbb-app/utils/common';
import CustomSelect from '@bbb-app/custom-select/CustomSelect';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import CustomTooltip from '@bbb-app/core-ui/custom-tooltip/CustomTooltip';
import AsyncModalDialogWithATCModal from '../../containers/common/ATCATRModal/ATCATRModalWithModalDialog.async';
import {
  setParentProductID,
  addToRegistryStarted,
  addToRegistryUtility,
} from '../AddToRegistry/AddToRegistryUtil';
import {
  ACTIVE_PNH_STATUS,
  ACTION_PNH,
  NO_QTY,
  NO_SIZE,
  NO_SWATCH,
  VDC_SKU_TYPE_VALUE,
  CUSTOMIZATION_OFFERED_FLAG_VALUE,
  PERSONALIZATION_TYPE_VALUE,
} from './constants';
import styles from './AddToPNH.css';

class AddToPNH extends React.PureComponent {
  static propTypes = {
    skuId: PropTypes.string,
    isSuccessModalShow: PropTypes.bool,
    qty: PropTypes.string,
    size: PropTypes.string,
    products: PropTypes.object,
    registries: PropTypes.object.isRequired,
    selectedProduct: PropTypes.object.isRequired,
    swatch: PropTypes.string,
    swatchError: PropTypes.object,
    genericError: PropTypes.string,
    buttonProps: PropTypes.object,
    dropdownProps: PropTypes.object,
    useLabelClass: PropTypes.bool,
    labelClassName: PropTypes.string,
    wrapperClassName: PropTypes.string,
    registryId: PropTypes.string,
    labels: PropTypes.object,
    validationLabels: PropTypes.object,
    wrapperClass: PropTypes.string,
    enabledGlobalSwitches: PropTypes.object.isRequired,
    endpoints: PropTypes.object,
    scene7UrlConfig: PropTypes.object,
    viewType: PropTypes.string,
    addToRegistryState: PropTypes.object,
    calledFromRegistry: PropTypes.bool,
    markFavRegistryItem: PropTypes.func,
    uniqueKey: PropTypes.string,
    pageIdentifier: PropTypes.string,
    onClientError: PropTypes.func,
    updateCallToAction: PropTypes.func,
    ownRecommendedRegistriesFetched: PropTypes.bool,
    modalATRDidClose: PropTypes.func,
    closeQuickViewModal: PropTypes.func,
    onModalHide: PropTypes.func,
    isPNHPLP: PropTypes.bool,
    activeRegistry: PropTypes.object,
    isATPNHEnabled: PropTypes.bool,
    labelOOS: PropTypes.string,
    labelUnavailable: PropTypes.string,
  };

  static defaultProps = {
    buttonProps: {
      attr: {
        'aria-describedby': 'atpnhErrorTooltip',
        className: 'fullWidth mb1',
        theme: 'secondaryStrokeBasic',
      },
    },
    dropdownProps: {
      'aria-describedby': 'atpnhErrorTooltip',
      className: 'fullWidth mb1',
    },
    onClientError: () => {},
    updateCallToAction: () => {},
    modalATRDidClose: () => {},
    wrapperClassName: 'pb1',
    labelClassName: '',
  };

  constructor(props) {
    super(props);
    this.state = {
      atpnhModalMountedState: false,
      selectedRegistryId: '0',
    };
    this.uid =
      this.props.uniqueKey || uniqueKeys.getStatelessUniqueKey('AddToPNH');
    this.isOutOfStock = false;
    this.isOwnRecommendedListResolved = props.ownRecommendedRegistriesFetched;
    this.setDefaultErrorState();
    this.getPNHDropDownOptions = this.getPNHDropDownOptions.bind(this);
    this.checkForOutOfStock = this.checkForOutOfStock.bind(this);
    this.renderButton = this.renderButton.bind(this);
    this.renderDropdown = this.renderDropdown.bind(this);
    this.toggleATPNHModalState = this.toggleATPNHModalState.bind(this);
    this.addItemToGiftRegistry = this.addItemToGiftRegistry.bind(this);
    this.handleAddToPNH = this.handleAddToPNH.bind(this);
    this.handleSelectedPNH = this.handleSelectedPNH.bind(this);
    this.setMountedState = this.setMountedState.bind(this);
    this.openAtrModal = this.openAtrModal.bind(this);
    this.toggleATREventFiredState = this.toggleATREventFiredState.bind(this);
    this.checkSkuValidations = this.checkSkuValidations.bind(this);
    this.setDefaultErrorState = this.setDefaultErrorState.bind(this);
    this.resetRegistryDropDown = this.resetRegistryDropDown.bind(this);
    this.checkValidations = this.checkValidations.bind(this);
    this.openAtrModalStateChange = this.openAtrModalStateChange.bind(this);
    this.isLTLProduct = this.isLTLProduct.bind(this);
    this.isVDCSkuType = this.isVDCSkuType.bind(this);
    this.isPersonalizedProduct = this.isPersonalizedProduct.bind(this);
  }

  componentWillReceiveProps(newProps) {
    const { data, error, productId, skuId } = this.props.addToRegistryState;
    const isSelectedSku =
      newProps.prodId === productId &&
      newProps.skuId === skuId &&
      newProps.addToRegistryState.uid === this.uid;
    if (isSelectedSku) {
      this.setMountedState(newProps, data, error);
    }
    if (
      !this.isOwnRecommendedListResolved &&
      !this.props.ownRecommendedRegistriesFetched &&
      newProps.ownRecommendedRegistriesFetched
    ) {
      this.isOwnRecommendedListResolved = true;
    }
  }

  getActivePNHList = MemoizeLast(registries => {
    if (registries) {
      const { profilePackAndHoldList = [] } = registries;
      return profilePackAndHoldList.filter(
        list => list.processFlag === ACTIVE_PNH_STATUS
      );
    }
    return [];
  });
  getSuccessContent(isList, labels) {
    let contentVal;
    if (isList === 'PNHChecklist') {
      contentVal = LabelsUtil.getLabel(labels, 'ATPNHsuccessMessage');
    }
    return contentVal;
  }
  getATRModal() {
    const {
      labels,
      enabledGlobalSwitches,
      endpoints,
      validationLabels,
      scene7UrlConfig,
      genericError,
      viewType,
      addToRegistryState,
      calledFromRegistry,
      markFavRegistryItem,
    } = this.props;
    const {
      data,
      error,
      isFetching,
      skuId,
      productId,
      addedSkuAttrs,
      registryId,
      qty,
      categoryId,
    } = addToRegistryState;
    const itemDetailsVO = pathOr([], 'component.itemDetailsVO', data);
    const modalVariation = 'medium';
    const isList = pathOr('', 'checklistType', this.props.addToRegistryState);
    const content =
      error || (itemDetailsVO && !itemDetailsVO.length) // whether ATR API response is successful
        ? {
            status: 'error',
            content: genericError,
          }
        : {
            status: 'success',
            content: this.getSuccessContent(isList, labels),
          };
    const enableATCRelatedCategories = pathOr(
      '',
      'enableATCRelatedCategories',
      enabledGlobalSwitches
    );

    if (!isFetching && this.state.atpnhModalMountedState) {
      return (
        <AsyncModalDialogWithATCModal
          mountedState={this.state.atpnhModalMountedState}
          dialogClass={styles.modal}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'ATPStatusModal')}
          verticallyCenter
          rclModalClass={classnames(styles.addedToPNHModal)}
          variation={modalVariation}
          scrollDisabled={false}
          data={data}
          error={error}
          isFetching={isFetching}
          toggleModalState={() => {
            this.toggleATPNHModalState(false);
          }}
          skuId={skuId}
          itemQty={qty}
          scene7UrlConfig={scene7UrlConfig}
          labels={labels}
          validationLabels={validationLabels}
          endpoints={endpoints}
          parentProductId={setParentProductID(this.props)}
          calledFromRegistry={calledFromRegistry}
          prodId={productId}
          categoryId={categoryId}
          enableATCRelatedCategories={enableATCRelatedCategories}
          registryId={registryId}
          messageContent={content}
          selectedProduct={addedSkuAttrs}
          viewType={viewType}
          pageIdentifier={this.props.pageIdentifier}
          closeNandDModal={() => {}}
          isList={isList}
          isPorchPayloadAvailable={false}
          markFavRegistryItem={markFavRegistryItem}
          addToRegistryState={addToRegistryState}
          enabledGlobalSwitches={enabledGlobalSwitches}
        />
      );
    }
    return '';
  }

  getRegistryById(registryId, registries) {
    const activePNHList = this.getActivePNHList(registries);
    return activePNHList.find(item => registryId === item.registryId);
  }

  getPNHDropDownOptions() {
    const { labels, registries, isATPNHEnabled } = this.props;
    const pnhList = this.getActivePNHList(registries);
    const pnhOptionLabelPrefix = LabelsUtil.getLabel(
      labels,
      'AddToPNHOptionPrefix'
    );
    const pnhListOption = pnhList
      .filter(item => item.fromPage === 'packAndHoldListPage' && isATPNHEnabled)
      .map(item => {
        return {
          key: item.registryId,
          label: `${pnhOptionLabelPrefix} ${item.registryId}`,
          props: {
            value: item.registryId,
            class: 'noIndentation',
          },
        };
      });
    const pnhListHeading = {
      label: LabelsUtil.getLabel(labels, 'AddToPNHDropdownHeading'),
      isHeading: true,
      classToAdd: 'addToRegListHeading',
      props: {
        value: '0',
      },
    };
    const optionsSet = [pnhListHeading, ...pnhListOption];
    return optionsSet;
  }

  setDefaultErrorState() {
    this.error = {};
  }

  setMountedState(newProps, inData, inError) {
    const { addToRegistryState } = newProps;
    const { data, error, qty } = addToRegistryState;
    if ((data && data !== inData) || (error && error !== inError)) {
      const qtyOrig = isEmpty(error) ? 1 : qty;
      if (this.props.onModalHide) this.props.onModalHide();
      this.openAtrModal(qtyOrig);
    }
  }

  resetRegistryDropDown() {
    this.setState({
      selectedRegistryId: '0',
    });
  }

  isLTLProduct(LTL_FLAG) {
    if (LTL_FLAG === 'true') {
      return true;
    }
    return false;
  }

  isVDCSkuType(VDC_SKU_TYPE) {
    if (VDC_SKU_TYPE === VDC_SKU_TYPE_VALUE) {
      return true;
    }

    return false;
  }

  isPersonalizedProduct(CUSTOMIZATION_OFFERED_FLAG, PERSONALIZATION_TYPE) {
    if (
      CUSTOMIZATION_OFFERED_FLAG === CUSTOMIZATION_OFFERED_FLAG_VALUE &&
      PERSONALIZATION_TYPE !== PERSONALIZATION_TYPE_VALUE
    ) {
      return true;
    }
    return false;
  }

  checkIfPNHUnavailable = MemoizeLast(selectedProduct => {
    if (selectedProduct) {
      const isLTL = this.isLTLProduct(selectedProduct.LTL_FLAG);
      const isVDC = this.isVDCSkuType(selectedProduct.VDC_SKU_TYPE);
      const isPersonalizedProduct = this.isPersonalizedProduct(
        selectedProduct.CUSTOMIZATION_OFFERED_FLAG,
        selectedProduct.PERSONALIZATION_TYPE
      );
      return isLTL || isVDC || isPersonalizedProduct;
    }
    return true;
  });

  checkForOutOfStock(selectedProduct, selectedList) {
    const storeId = parseInt(selectedList.pickUpStoreId, 10);
    const { isPNHPLP } = this.props;
    if (isPNHPLP) {
      return false;
    }
    if (
      selectedProduct &&
      isArray(selectedProduct.STORES) &&
      selectedProduct.STORES.indexOf(storeId) > -1
    ) {
      return false;
    }
    return true;
  }

  checkValidations(argsForValidations) {
    const { qty, skuId, size, swatch } = argsForValidations;
    if (qty <= 0) {
      this.error[NO_QTY] = NO_QTY;
    }
    /*
     * no SKU selected | DO NOT USE isEmpty for null check in case of skuId |as isEmpty has a bug for Numeric values | and this component is used on different pages
     * and skuId is getting consumed as Number and String both from different parent components
     */
    if (!skuId) {
      if (isEmpty(size)) this.error[NO_SIZE] = NO_SIZE; // no size
      if (isEmpty(swatch)) this.error[NO_SWATCH] = NO_SWATCH; // no color
    }
  }

  checkSkuValidations() {
    let canBeAdded = true;
    const {
      skuId,
      qty,
      size,
      swatch,
      onClientError,
      updateCallToAction,
      products,
    } = this.props;
    const argsForSKUValidations = products || {
      qty,
      skuId,
      size,
      swatch,
    };
    // check if color/finish/size/dsl selected
    if (Array.isArray(argsForSKUValidations)) {
      argsForSKUValidations.forEach(args => {
        this.checkValidations(args);
      });
    } else {
      this.checkValidations(argsForSKUValidations);
    }
    // if no SKU available, show error
    if (!isEmpty(this.error)) {
      canBeAdded = false;
      onClientError(this.error);
      if (updateCallToAction) {
        updateCallToAction(ACTION_PNH);
      }
      this.resetRegistryDropDown();
      this.setDefaultErrorState();
    }
    return canBeAdded;
  }

  toggleATPNHModalState(value) {
    this.setState({ atpnhModalMountedState: value }, () => {
      if (!value) {
        this.props.modalATRDidClose();
      }
    });
    if (this.props.closeQuickViewModal) {
      this.props.closeQuickViewModal();
    }
  }

  toggleATREventFiredState(addItemToGiftRegistry, activeList) {
    const { registryId, activeRegistry, isPNHPLP } = this.props;
    this.setState(
      {
        isATREventFired: !this.state.isATREventFired,
      },
      () => {
        let selectedList;
        let selectedRegistryId;
        if (registryId) {
          selectedRegistryId = registryId;
        } else if (isPNHPLP && activeRegistry) {
          selectedRegistryId = activeRegistry.registryId;
        }

        if (selectedRegistryId) {
          // will fetch current active registry
          selectedList = this.getRegistryById(
            selectedRegistryId,
            this.props.registries
          );
        } else {
          selectedList = activeList[0];
        }

        if (addItemToGiftRegistry) {
          this.addItemToGiftRegistry(
            false,
            false,
            selectedList.registryId,
            selectedList.eventType,
            selectedList
          );
        }
      }
    );
  }

  handleAddToPNH(evt) {
    evt.preventDefault();
    this.targetName = pathOr('', 'target.name', evt);
    addToRegistryStarted(this.props, this.uid);
    const activeList = this.getActivePNHList(this.props.registries);
    if (this.isOutOfStock || !this.checkSkuValidations()) {
      return;
    }
    this.toggleATREventFiredState(true, activeList);
  }

  handleSelectedPNH(selectedRegistryId) {
    const { registries, selectedProduct } = this.props;
    if (selectedRegistryId) {
      this.selectedRegistryId = selectedRegistryId;
      const selectedRegistry = this.getRegistryById(
        selectedRegistryId,
        registries
      );
      this.isOutOfStock = this.checkForOutOfStock(
        selectedProduct,
        selectedRegistry
      );
      const selectedRegistryName = pathOr('', 'eventType', selectedRegistry);
      const alternatePhoneNumber = pathOr(
        '',
        'alternatePhone',
        selectedRegistry
      );
      addToRegistryStarted(this.props, this.uid);
      this.setState({
        selectedRegistryId,
        selectedRegistryName,
        alternatePhoneNumber,
      });
      if (!this.checkSkuValidations() || this.isOutOfStock) return;
      this.addItemToGiftRegistry(
        undefined,
        false,
        selectedRegistryId,
        selectedRegistryName,
        selectedRegistry
      );
    }
  }

  openAtrModal(qtyOrig) {
    this.setState({ atpnhModalMountedState: true }, () => {
      this.openAtrModalStateChange(
        this.props,
        qtyOrig,
        this.resetRegistryDropDown
      );
    });
  }

  openAtrModalStateChange(props, qtyOrig, resetRegistryDropDown) {
    const { onSuccess } = props;
    resetRegistryDropDown();
    if (onSuccess) {
      onSuccess(qtyOrig);
    }
  }

  addItemToGiftRegistry(
    newProps,
    wasGuestUser = false,
    selectedRegistryId,
    selectedRegistryName,
    selectedRegistry
  ) {
    const { registries } = newProps || this.props;
    const props = this.props;
    const canBeAdded = true;
    addToRegistryUtility({
      newProps,
      wasGuestUser,
      selectedRegistryId,
      selectedRegistryName,
      canBeAdded,
      props,
      selectedRegistry,
      registries,
    });
  }

  renderErrorMessage(labels, isOutOfStock, isPNHUnavailable) {
    if (isOutOfStock || isPNHUnavailable) {
      const messageKey = isOutOfStock
        ? 'pnhOutOfStockMessage'
        : 'pnhNotAvailableMessage';
      return (
        <Paragraph theme="smallLight" variation="errorMessage" className="m0">
          {LabelsUtil.getLabel(labels, messageKey)}
        </Paragraph>
      );
    }

    return null;
  }

  renderButton(selectedList) {
    const {
      buttonProps,
      labels,
      swatchError,
      wrapperClass,
      selectedProduct,
      skuId,
      viewType,
      labelOOS,
      labelUnavailable,
    } = this.props;
    this.isOutOfStock =
      this.isPNHUnavailable || !skuId
        ? false
        : this.checkForOutOfStock(selectedProduct, selectedList);
    let buttonLabel;
    if (this.isOutOfStock && viewType === 'PDP' && labelOOS) {
      buttonLabel = labelOOS;
    } else if (
      this.isPNHUnavailable &&
      viewType === 'PDP' &&
      labelUnavailable
    ) {
      buttonLabel = labelUnavailable;
    } else if (this.isOutOfStock) {
      buttonLabel = LabelsUtil.getLabel(labels, 'pnhOutOfStockCta');
    } else {
      buttonLabel = LabelsUtil.getLabel(labels, 'AddToPNHDropdownHeading');
    }
    const isDisabled = this.isOutOfStock || this.isPNHUnavailable;
    let btnTheme = pathOr('', 'attr.theme', buttonProps);

    if (isDisabled) {
      btnTheme = 'secondaryWhiteDeactivated';
    }

    return (
      <div
        className={classnames(styles.addToPNHButton, wrapperClass)}
        id="atpnh-cta"
      >
        <Button
          onClick={this.handleAddToPNH}
          disabled={isDisabled}
          {...buttonProps.attr}
          theme={btnTheme}
        >
          {buttonLabel}
        </Button>
        {!isTouchDevice() &&
          !isDisabled &&
          swatchError && (
            <CustomTooltip
              className={styles.errorToolTip}
              swatchError={swatchError}
              id={buttonProps.attr && buttonProps.attr['aria-describedby']}
            />
          )}
        {this.props.isSuccessModalShow && this.getATRModal()}
        {viewType !== 'PDP' &&
          this.renderErrorMessage(
            labels,
            this.isOutOfStock,
            this.isPNHUnavailable
          )}
      </div>
    );
  }

  renderDropdown() {
    const {
      swatchError,
      buttonProps,
      dropdownProps,
      labels,
      useLabelClass,
      wrapperClassName,
      labelClassName,
    } = this.props;
    const optionSet = this.getPNHDropDownOptions();
    this.isOutOfStock =
      this.state.selectedRegistryId === '0' || this.isPNHUnavailable
        ? false
        : this.isOutOfStock;
    return (
      <div className={classnames(styles.addToPNHButton)} id="atrpnh-cta">
        <CustomSelect
          optionSet={optionSet}
          variationName="selectPrimary"
          defaultValue={this.state.selectedRegistryId}
          selectOption={this.handleSelectedPNH}
          disabled={this.isPNHUnavailable}
          labelClassName={classnames('inlineBlock', labelClassName, {
            [styles.labelClass]: useLabelClass,
          })}
          wrapperClassName={classnames(wrapperClassName)}
          {...dropdownProps}
        />
        {!isTouchDevice() &&
          swatchError && (
            <CustomTooltip
              className={styles.errorToolTip}
              swatchError={swatchError}
              id={buttonProps.attr['aria-describedby']}
            />
          )}
        {this.renderErrorMessage(
          labels,
          this.isOutOfStock,
          this.isPNHUnavailable
        )}
        {this.props.isSuccessModalShow && this.getATRModal()}
      </div>
    );
  }

  render() {
    const {
      selectedProduct,
      registries,
      isPNHPLP,
      activeRegistry,
      isATPNHEnabled,
    } = this.props;
    if (!isATPNHEnabled || !this.isOwnRecommendedListResolved) {
      return null;
    }
    this.isPNHUnavailable = this.checkIfPNHUnavailable(selectedProduct);
    const activePNHList = this.getActivePNHList(registries);
    if (this.props.registryId) {
      // will fetch current active registry
      return this.renderButton(
        this.getRegistryById(this.props.registryId, registries)
      );
    } else if (isPNHPLP) {
      const isActiveRegistryUnsubmitted =
        activeRegistry && activeRegistry.processFlag === ACTIVE_PNH_STATUS;
      return isActiveRegistryUnsubmitted
        ? this.renderButton(activeRegistry)
        : null;
    } else if (activePNHList.length === 1) {
      return this.renderButton(activePNHList[0]);
    } else if (activePNHList.length > 1) {
      return this.renderDropdown();
    }
    return null;
  }
}

export default AddToPNH;
