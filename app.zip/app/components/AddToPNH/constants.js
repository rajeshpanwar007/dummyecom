export const ACTIVE_PNH_STATUS = 'W';
export const ACTION_PNH = 'atpnh';
export const NO_QTY = 'NO_QTY';
export const NO_SIZE = 'NO_SIZE';
export const NO_SWATCH = 'NO_SWATCH';
export const VDC_SKU_TYPE_VALUE = '121';
export const CUSTOMIZATION_OFFERED_FLAG_VALUE = 'true';
export const PERSONALIZATION_TYPE_VALUE = 'N';
export const DEACTIVE_PNH_STATUS = 'N'; // Used for processFlag in PNH checklist, N = Submitted/Freeze Dashboard, W = Not Submitted
