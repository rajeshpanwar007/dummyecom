import React from 'react';
import classnames from 'classnames';
import { object, func, string, bool } from 'prop-types';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import getCartQuatitySelectorOptions from '@bbb-app/utils/getCartQuantitySelectorOptions';
import FormWrapper from '@bbb-app/forms/containers/FormWrapper/FormWrapper';
import FormInput from '@bbb-app/forms/containers/FormInput/FormInput';
import QuantitySelector from '@bbb-app/quantity-selector/QuantitySelector';
import styles from './RecommendToFriend.css';
/**
 * @static
 * @memberof RecommendToFriend
 */
const propTypes = {
  formWrapperData: object,
  labels: object,
  toggleRecommendModalState: func,
  modalRecommendDidClose: func,
  addToFriendRegistry: func,
  skuId: string.requried,
  registryId: string.required,
  apiResult: bool,
  apiError: string,
};
/**
 * @class RecommendToFriend
 * @extends {PureComponent}
 */
class RecommendToFriend extends React.PureComponent {
  /**
   * constructor
   * @param {*} props
   */
  constructor(props) {
    super(props);
    this.state = { selectedQuantity: 1, errorMessage: '' };
    this.changeQuantity = this.changeQuantity.bind(this);
    this.submitFormHandler = this.submitFormHandler.bind(this);
  }
  /**
   * componentDidUpdate
   * @param {*} prevProps
   */
  componentDidUpdate(prevProps) {
    const {
      apiResult,
      toggleRecommendModalState,
      modalRecommendDidClose,
      apiError,
    } = this.props;
    const condition =
      !apiError &&
      prevProps.apiResult !== apiResult &&
      apiResult &&
      typeof toggleRecommendModalState === 'function';
    if (condition) {
      toggleRecommendModalState();
      modalRecommendDidClose();
    }
  }
  /**
   * form submit handler
   * @param {*} validationStateObj
   */
  submitFormHandler(validationStateObj) {
    const {
      formWrapperData,
      addToFriendRegistry,
      skuId,
      registryId,
    } = this.props;
    const comment = (formWrapperData && formWrapperData.comments.value) || '';
    const hasFormErrors = Object.keys(validationStateObj).length;
    if (!hasFormErrors && typeof addToFriendRegistry === 'function') {
      addToFriendRegistry({
        skuId,
        registryId,
        comment,
        quantity: this.state.selectedQuantity,
      });
    }
  }
  /**
   * quantity select change handler
   * @param {*} value
   */
  changeQuantity(value) {
    const qty = value || 1;
    this.setState({
      selectedQuantity: qty,
    });
  }
  /**
   * renderErrorMessage
   * @param {*} labels
   */
  renderErrorMessage(labels = {}) {
    return (
      <Cell className={classnames('small-12', 'mb1', styles.alignText)}>
        <Paragraph
          className="validationErrorMessage"
          data-locator="recommend-modal-api-error"
        >
          {LabelsUtil.getLabel(labels, 'recommendModalApiError')}
        </Paragraph>
      </Cell>
    );
  }
  /**
   * renderHeading
   * @param {*} labels
   */
  renderHeading(labels = {}) {
    return (
      <Cell className={classnames('small-12', styles.alignText)}>
        <Heading
          level={3}
          styleVariation="h3-sans"
          className={classnames('mb3 sm-mb2')}
          data-locator="recommend-modal-heading"
        >
          {LabelsUtil.getLabel(labels, 'recommendHeading')}
        </Heading>
      </Cell>
    );
  }
  /**
   * renderDescription
   * @param {*} labels
   */
  renderDescription(labels = {}) {
    return (
      <Cell
        className={classnames(
          'small-12',
          'mb3',
          styles.alignText,
          styles.formInstruction
        )}
        data-locator="recommend-modal-description"
      >
        <div>{LabelsUtil.getLabel(labels, 'recommendDescription')}</div>
      </Cell>
    );
  }
  /**
   * renderSubmitButton
   * @param {*} labels
   */
  renderSubmitButton(labels = {}) {
    return (
      <Cell className={classnames('small-12', 'large-6', 'mr2', 'sm-mb2')}>
        <Button
          type="submit"
          theme="primary"
          variation="fullWidth"
          data-locator="recommend-modal-submit-button"
        >
          {LabelsUtil.getLabel(labels, 'recommend')}
        </Button>
      </Cell>
    );
  }
  /**
   * renderCancelButton
   * @param {*} labels
   */
  renderCancelButton(labels = {}) {
    return (
      <Cell className={classnames('small-12', 'large-6')}>
        <Button
          type="button"
          theme="secondary"
          variation="fullWidth"
          onClick={() => {
            this.props.toggleRecommendModalState();
            this.props.modalRecommendDidClose();
          }}
          data-locator="recommend-modal-cancel-button"
        >
          {LabelsUtil.getLabel(labels, 'cancel')}
        </Button>
      </Cell>
    );
  }
  /**
   * renderQuantitySelector
   */
  renderQuantitySelector() {
    return (
      <Cell className="small-12 mb2">
        <QuantitySelector
          fieldName="quantity"
          optionSet={getCartQuatitySelectorOptions()}
          selectedQuantity={this.state.selectedQuantity}
          onChangeQuantity={this.changeQuantity}
          updateQuantity={this.changeQuantity}
          identifier="recommendToFriend"
          buttonProps={{
            theme: 'ghost',
            variation: 'noHorizontalPadding',
          }}
          updateButtonLabel=""
          data-locator="recommend-modal-quantity-selector"
        />
      </Cell>
    );
  }
  /**
   * renderTextArea
   * @param {*} formWrapperData
   * @param {*} labels
   */
  renderTextArea(formWrapperData, labels) {
    return (
      <Cell className="small-12 mb1">
        <FormInput
          id="comments"
          name="comments"
          maxLength="1000"
          className={classnames(styles.comments)}
          type="textarea"
          labelPosition="prepend"
          label={LabelsUtil.getLabel(labels, 'addAMessage')}
          identifier="recommendToFriend"
          value={(formWrapperData && formWrapperData.comments.value) || ''}
          data-locator="recommend-modal-comments"
        />
      </Cell>
    );
  }
  /**
   * render
   */
  render() {
    const { formWrapperData, labels, apiError } = this.props;
    return (
      <ErrorBoundary>
        <FormWrapper
          identifier="recommendToFriend"
          formWrapperData={formWrapperData}
          method="post"
          onSubmit={this.submitFormHandler}
        >
          <GridX className="grid-margin-x">
            {apiError && this.renderErrorMessage(labels)}
            {this.renderHeading(labels)}
            {this.renderDescription(labels)}
            {this.renderQuantitySelector()}
            {this.renderTextArea(formWrapperData, labels)}
            {this.renderSubmitButton(labels)}
            {this.renderCancelButton(labels)}
          </GridX>
        </FormWrapper>
      </ErrorBoundary>
    );
  }
}

// propTypes
RecommendToFriend.propTypes = propTypes;
// export
export default RecommendToFriend;
