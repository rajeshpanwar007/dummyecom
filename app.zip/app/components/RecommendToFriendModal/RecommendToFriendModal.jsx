import React from 'react';
import PropTypes from 'prop-types';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import RecommendToFriend from './RecommendToFriend';

/**
 * @static
 * @memberof RecommendToFriendModal
 */
const propTypes = {
  labels: PropTypes.object,
  recommendModalMountedState: PropTypes.bool,
  toggleRecommendModalState: PropTypes.func,
  modalRecommendDidClose: PropTypes.func,
};

/**
 * @class RecommendToFriendModal
 * @extends {PureComponent}
 */
const RecommendToFriendModal = props => {
  const {
    labels,
    recommendModalMountedState,
    toggleRecommendModalState,
    modalRecommendDidClose,
  } = props;
  return (
    <ErrorBoundary>
      <ModalDialog
        verticallyCenter
        mountedState={recommendModalMountedState}
        toggleModalState={toggleRecommendModalState}
        onModalDidClose={modalRecommendDidClose}
        titleAriaLabel={LabelsUtil.getLabel(labels, 'recommendModalAriaTitle')}
        variation={'medium'}
        scrollDisabled={false}
        initialFocus=".rclModalContent"
      >
        <RecommendToFriend {...props} />
      </ModalDialog>
    </ErrorBoundary>
  );
};

// propTypes
RecommendToFriendModal.propTypes = propTypes;
// export
export default RecommendToFriendModal;
