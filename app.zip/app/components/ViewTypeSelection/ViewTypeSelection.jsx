import React from 'react';
import classnames from 'classnames';
import Button from '@bbb-app/core-ui/button';
import Icon from '@bbb-app/core-ui/icon';
import '../../assets/icons/grid.svg';
import '../../assets/icons/list.svg';
import propTypes, { defaultProps } from './props';
import { GRID_VIEW_TYPE, LIST_VIEW_TYPE } from '../../constants/search';

import styles from './ViewTypeSelection.css';

/**
 * This component selects the type of view to display (e.g., list, grid)
 *
 * @author kmotely
 * @author jgabler
 *
 * @see Button
 *
 * For more information about the component please refer to
 * the README: ./docs/storybook/controls.md
 * @example ./stories/Controls.stories.jsx
 */

class ViewTypeSelection extends React.PureComponent {
  render() {
    const {
      className,
      onButtonClick,
      smallViewTypes,
      selectedViewType,
    } = this.props;

    const altViewType =
      selectedViewType === GRID_VIEW_TYPE ? LIST_VIEW_TYPE : GRID_VIEW_TYPE;
    const mobileSelectedViewType =
      smallViewTypes && smallViewTypes[altViewType];
    if (!mobileSelectedViewType) return null;

    return (
      <Button
        className={classnames(className, styles.button, 'isSelected')}
        type="button"
        name="viewType"
        value={mobileSelectedViewType.value}
        theme="control"
        variation="smallBorderRadius"
        onClick={() => {
          const wrapper = document.getElementById('sortIcon');
          if (wrapper) wrapper.blur();
          onButtonClick();
        }}
        key={mobileSelectedViewType.value}
        id="sortIcon"
      >
        <Icon height="20px" type={mobileSelectedViewType.iconType} />
      </Button>
    );
  }
}

ViewTypeSelection.propTypes = propTypes;
ViewTypeSelection.defaultProps = defaultProps;

export default ViewTypeSelection;
