import { arrayOf, func, shape, string } from 'prop-types';
import { GRID_VIEW_TYPE } from '../../constants/search';

export const defaultProps = {
  onButtonClick: () => {},
  selectedViewType: GRID_VIEW_TYPE,
};

/**
 * @param {string} className additional css classes
 * @param {func}   onButtonClick Callback for when a button is clicked
 * @param {array}  smallViewTypes Array of view type objects for small screens
 * @param {object} smallViewTypes.smallViewType the small view type object
 * @param {string} smallViewTypes.smallViewType.value The value of the view type
 * @param {string} smallViewTypes.smallViewType.iconType The icon type
 * @param {string} selectedViewType The selected view type
 */
export default {
  className: string,
  onButtonClick: func,
  smallViewTypes: arrayOf(
    shape({
      value: string,
      iconType: string,
    })
  ),
  selectedViewType: string,
};
