import React from 'react';
import classnames from 'classnames';
import propTypes, { defaultProps } from './props';
import styles from './ProductBadge.inline.css';

const ProductBadge = ({ className, label, priority, type, ...otherProps }) => (
  <span
    className={classnames(
      styles.base,
      (priority === 'HIGH' || priority === 1) && styles.isHighPriority,
      className,
      styles[type]
    )}
    {...otherProps}
  >
    {label}
  </span>
);

ProductBadge.propTypes = propTypes;

ProductBadge.defaultProps = defaultProps;

export default ProductBadge;
