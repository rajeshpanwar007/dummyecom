export { default as propTypes } from './props';
export { default } from './ProductBadge';
