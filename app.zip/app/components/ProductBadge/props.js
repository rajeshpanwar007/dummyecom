import { oneOf, string } from 'prop-types';

export const defaultProps = {
  priority: 'LOW',
};

export default {
  className: string,
  /** Text label (e.g. Clearance) */
  label: string.isRequired,
  /** Priority value used to determine background color */
  priority: oneOf([0, 1, 'LOW', 'HIGH']),
  /** Type of badge used to determine font-size*/
  type: oneOf(['small', 'large']),
};
