import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Heading from '@bbb-app/core-ui/heading';
import Address from '@bbb-app/core-ui/address';
import getSiteId from '@bbb-app/utils/getSiteId';
import TealiumHandler from '@bbb-app/tealium/TealiumHandler';
import SearchStores from '../../containers/SearchStores/SearchStores';
import styles from './lazy-Appointment.css';
import { APPOINTMENTS, EVENTS, APPOINTMENTSURL, EVENTSURL } from './constants';
/**
 * Appointment - AppModal BookingBug component
 */

export class Appointment extends PureComponent {
  state = {
    registrySearchFlag: false,
  };

  setRegistrySearchFlag = flag => {
    this.setState({
      registrySearchFlag: flag,
    });
  };

  getUrl = (url, reg) => {
    const pageConfig = {
      refID_BRD: '48316',
      refID_BA1: '48342',
      refID_BIR: '48334',
      refID_RET: '48334',
      refID_ANN: '48334',
      refID_HSW: '48334',
      refID_COL: '48338',
      refID_COM: '48316',
      refID_OTH: '48334',
      refID_BBY: '0',
      refID_REG: '0',
    };
    let newUrl = '';
    switch (reg.eventType) {
      case 'Wedding':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_BRD}`;
        break;
      case 'Baby':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_BA1}`;
        break;
      case 'Birthday':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_BIR}`;
        break;
      case 'Retirement':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_RET}`;
        break;
      case 'Anniversary':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_ANN}`;
        break;
      case 'Housewarming':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_HSW}`;
        break;
      case 'College/University':
      case 'University':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_COL}`;
        break;
      case 'Commitment Ceremony':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_COM}`;
        break;
      case 'Other':
        newUrl = `${url}&preselectedServiceRef=${pageConfig.refID_OTH}`;
        break;
      default:
        break;
    }
    return newUrl;
  };

  getCatId = (
    pathname,
    collegeCatId,
    pageConfigGlobal,
    isCollege,
    appointmentRouteCatIdMapping
  ) => {
    if (isCollege) {
      return collegeCatId;
    }
    let catId;
    let index = 0;
    const entries = Object.entries(appointmentRouteCatIdMapping);
    while (!catId && index < entries.length) {
      if (pathname === entries[index][0]) {
        catId = entries[index][1];
      }
      index += 1;
    }
    return catId || pathOr('', 'catId', pageConfigGlobal);
  };

  getTealiumInfo = reg => {
    const { pathname, sourceCTA, isCollege, pageName } = this.props;
    const xpathname = pathname || '';
    const xpageName = String(xpathname).substring(
      String(xpathname).lastIndexOf('/') + 1
    );
    const utag = {
      content_pagetype: 'Registry',
      call_to_actiontype: 'book an appointment modal',
      page_name: 'book an appointment modal',
      registry_id: reg.registryId,
      registry_type: reg.eventType,
      page_function: 'Registry',
      navigation_path: 'Registry',
      subnavigation_path: 'Registry',
      page_type: 'Registry',
      channel: 'Registry',
      pagename_breadcrumb: 'Registry Book an Appointment',
    };

    if (sourceCTA === 'left nav') {
      utag.content_pagetype = 'Guides and Advice';
    }

    if (String(sourceCTA).toLowerCase() === 'college' || isCollege) {
      utag.content_pagetype = 'College';
      utag.page_function = 'College';
      utag.navigation_path = 'College';
      utag.subnavigation_path = 'College';
      utag.page_type = 'College';
      utag.channel = 'College';
      utag.pagename_breadcrumb = 'College Book an Appointment';
    }

    if (!utag.content_pagetype) {
      utag.content_pagetype = sourceCTA || pageName || xpageName;
    }

    return utag;
  };

  startNewSearchHandler = e => {
    if (e) e.preventDefault();
    this.setState({
      registrySearchFlag: false,
    });
    this.props.clearSearchedSkuData();
    this.props.clearStoreData();
  };
  /* eslint complexity: ["error", 15]*/
  render() {
    const {
      appointmentType,
      labels,
      isLoggedIn = false,
      profile,
      favoriteStore,
      activeRegistry,
      thirdPartyDataConfig,
      pageConfig,
      location,
      isCollege,
    } = this.props;

    const siteId = getSiteId();

    const siteIdNumber =
      { BedBathUS: '1', BuyBuyBaby: '2', BedBathCanada: '3' }[siteId] || '1';

    const reg = {
      registryId: '',
      firstName: '',
      lastName: '',
      email: '',
      contactNum: '',
      coRegEmail: '',
      coRegFirstName: '',
      coRegLastName: '',
      eventDate: '',
      eventType: '',
      favStoreId: '',
    };

    const pathname = pathOr('', 'pathname', location);
    const collegeCatId = pathOr(
      '',
      'AppointmentRouteCatIdMapping.collegeCatId',
      pageConfig
    );
    const appointmentRouteCatIdMapping = pathOr(
      {},
      'AppointmentRouteCatIdMapping',
      pageConfig
    );

    if (isLoggedIn && activeRegistry && activeRegistry.registryId) {
      const {
        primaryRegistrantLastName,
        primaryRegistrantEmail,
        coRegistrantLastName,
        primaryRegistrantPrimaryPhoneNum,
        coRegistrantFirstName,
      } = activeRegistry;
      reg.registryId = pathOr('', 'registryId', activeRegistry);
      reg.firstName = pathOr('', 'primaryRegistrantFirstName', activeRegistry);
      reg.lastName =
        primaryRegistrantLastName !== 'masked' && primaryRegistrantLastName;
      reg.email =
        !primaryRegistrantEmail.includes('*') && primaryRegistrantEmail;
      reg.contactNum =
        primaryRegistrantPrimaryPhoneNum !== null &&
        primaryRegistrantPrimaryPhoneNum;
      reg.coRegFirstName =
        coRegistrantFirstName !== null && coRegistrantFirstName;
      reg.coRegLastName =
        coRegistrantLastName !== 'masked' &&
        coRegistrantLastName !== null &&
        coRegistrantLastName;
      reg.coRegEmail = pathOr('', 'coRegEmail', activeRegistry);
      reg.eventDate = pathOr('', 'eventDate', activeRegistry);
      reg.eventType = pathOr('', 'eventType', activeRegistry);
      reg.favStoreId = pathOr('', 'favStoreId', activeRegistry);
    } else if (isLoggedIn && profile && profile.firstName) {
      const { email, lastName } = profile;
      reg.firstName = pathOr('', 'firstName', profile);
      reg.lastName = lastName !== null && lastName;
      reg.email = email && !email.includes('*') && email;
      reg.contactNum = pathOr('', 'phone', profile);
    }

    const favStore = pathOr(
      pathOr(favoriteStore, 'storeDetails[0]', favoriteStore),
      '[0]',
      favoriteStore
    );
    const favStoreId = reg.favStoreId;
    let curStore = favStoreId || favStore;

    const xstore = {
      storeId: '',
      commonName: '',
      address: '',
      city: '',
      state: '',
      latitude: '',
      longitude: '',
      phone: '',
      postalCode: '',
      sundayTimings: '',
      saturdayTimings: '',
      weekdayTimings: '',
      direction: '',
      details: '',
    };

    if (curStore) {
      xstore.storeId = pathOr(favStoreId, 'storeId', curStore);
      xstore.commonName = pathOr('', 'commonName', curStore);
      xstore.address = pathOr('', 'address', curStore);
      xstore.city = pathOr('', 'city', curStore);
      xstore.state = pathOr('', 'state', curStore);
      xstore.phone = pathOr('', 'phone', curStore);
      xstore.postalCode = pathOr('', 'postalCode', curStore);
      xstore.sundayTimings = pathOr('', 'sundayTimings', curStore);
      xstore.saturdayTimings = pathOr('', 'saturdayTimings', curStore);
      xstore.weekdayTimings = pathOr('', 'weekdayTimings', curStore);
      xstore.direction = pathOr('', 'direction', curStore);
      xstore.details = pathOr('', 'details', curStore);
    }
    curStore = curStore || xstore;

    const storeId = xstore.storeId;
    let title = '';
    let url = '';

    const catId = this.getCatId(
      pathname,
      collegeCatId,
      pageConfigGlobal,
      isCollege,
      appointmentRouteCatIdMapping
    );

    if (appointmentType === EVENTS) {
      let eventGroupId = '';
      if (
        pageConfigGlobal !== undefined &&
        pageConfigGlobal.eventGroupId !== undefined
      ) {
        eventGroupId = pageConfigGlobal.eventGroupId;
      }
      let eventId = '';
      if (
        pageConfigGlobal !== undefined &&
        pageConfigGlobal.eventId !== undefined
      ) {
        eventId = pageConfigGlobal.eventId;
      }

      title = LabelsUtil.getLabel(labels, 'eventsTitle');
      url = pathOr(EVENTSURL, 'bookingBug.eventsUrl', thirdPartyDataConfig);
      url = `${url}?abc=1&siteId=${siteIdNumber}&storeId=${storeId}&regFN=${reg.firstName}&regLN=${reg.lastName}&coregFN=${reg.coRegFirstName}&coregLN=${reg.coRegLastName}&email=${reg.email}&coregEmail=${reg.coRegEmail}&contactNum=${reg.contactNum}&registryId=${reg.registryId}&eventDate=${reg.eventDate}&catID=${catId}&eventID=${eventId}&eventGroupID=${eventGroupId}`;
    } else {
      title = LabelsUtil.getLabel(labels, 'appointmentsTitle');
      let BBurl = pathOr(
        APPOINTMENTSURL,
        'bookingBug.appointmentsUrl',
        thirdPartyDataConfig
      );
      BBurl = `${BBurl}?abc=1&siteId=${siteIdNumber}&storeId=${storeId}&regFN=${reg.firstName}&regLN=${reg.lastName}&coregFN=${reg.coRegFirstName}&coregLN=${reg.coRegLastName}&email=${reg.email}&coregEmail=${reg.coRegEmail}&contactNum=${reg.contactNum}&registryId=${reg.registryId}&eventDate=${reg.eventDate}&catID=${catId}`;

      url = this.getUrl(BBurl, reg);
    }

    const stores = pathOr([], 'stores', this.props.siteConfig);
    const storeInfo =
      stores.find(store => store.id === xstore.store_type) || {};
    const address1 = pathOr('', 'label', storeInfo);

    const utag = this.getTealiumInfo(reg);

    const pageConfigGlobal = this.props.pageConfig.Global;
    const StaticStoreNumber = [
      pageConfigGlobal.defaultBedbathStore,
      pageConfigGlobal.defaultBabyStore,
      pageConfigGlobal.defaultCanadaStore,
    ];

    let customEventsModal = false;
    let identifier = 'Book_An_Appointment';
    if (
      this.props.customEventsModal !== undefined &&
      this.props.customEventsModal
    ) {
      customEventsModal = true;
      identifier = '';
    }
    if (storeId && StaticStoreNumber.indexOf(storeId) === -1) {
      return (
        <div className={classnames(styles.outerWrapper)}>
          <ErrorBoundary>
            <TealiumHandler
              utagData={utag}
              identifier={identifier}
              tealiumPageInfoNotAvailable
            />
          </ErrorBoundary>
          <div className={classnames(styles.titleWrapper)}>{title}</div>
          <div
            className={classnames(
              styles.storeDetailsWrapper,
              'xs-hide sm-hide'
            )}
          >
            {xstore.commonName}
            <div className={classnames(styles.storeDetailCell)}>
              <Address
                address1={address1}
                address2={curStore.address}
                city={curStore.city}
                country={curStore.country}
                state={curStore.state}
                postalCode={curStore.postalCode}
                phoneNumber={curStore.phone}
                className={'mb2'}
                isMobile={false}
              />
            </div>
            <div className={classnames(styles.storeDetailCell)} />
          </div>
          <div className={classnames(styles.iframeWrapper)}>
            <iframe src={url} />
          </div>
        </div>
      );
    }

    return (
      <div>
        {!this.state.registrySearchFlag && (
          <Heading level={2}>
            {LabelsUtil.getLabel(labels, 'findAppointmentNearYou')}
          </Heading>
        )}
        {!this.state.registrySearchFlag &&
          !customEventsModal && (
            <div className={classnames(styles.mediumLight)}>
              <p>{LabelsUtil.getLabel(labels, 'findAppointmentText')}</p>
            </div>
          )}

        {!this.state.registrySearchFlag &&
          customEventsModal && (
            <div className={classnames(styles.mediumLight)}>
              <p>{LabelsUtil.getLabel(labels, 'findEventsText')}</p>
            </div>
          )}

        <SearchStores
          onSearchSubmit={this.props.onSearchSubmit}
          findAStoreModal
          isFilterVisible={false}
          isPickupInStore
          customEventsModal={customEventsModal}
          registrySearchFlag={this.state.registrySearchFlag}
          setRegistrySearchFlag={this.setRegistrySearchFlag}
          startNewSearchHandler={this.startNewSearchHandler}
        />
      </div>
    );
  }
}

Appointment.propTypes = {
  appointmentType: PropTypes.string,
  onSearchSubmit: PropTypes.func,
  labels: PropTypes.object,
  isLoggedIn: PropTypes.bool,
  profile: PropTypes.object,
  favoriteStore: PropTypes.object,
  activeRegistry: PropTypes.object,
  siteConfig: PropTypes.object,
  thirdPartyDataConfig: PropTypes.object,
  pageConfig: PropTypes.object,
  clearSearchedSkuData: PropTypes.func,
  clearStoreData: PropTypes.func,
  customEventsModal: PropTypes.bool,
  location: PropTypes.object,
  isCollege: PropTypes.bool,
  sourceCTA: PropTypes.string,
  pathname: PropTypes.string,
  pageName: PropTypes.string,
};

Appointment.defaultProps = {
  appointmentType: APPOINTMENTS,
};

export default Appointment;
