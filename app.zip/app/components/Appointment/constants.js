export const APPOINTMENTS = '1';
export const EVENTS = '2';
export const EVENTSURL =
  'https://bespoke.bookingbug.com/bbb/staging/new_event.html';
export const APPOINTMENTSURL =
  'https://bespoke.bookingbug.com/bbb/staging/new_booking.html';
