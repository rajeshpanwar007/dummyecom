export const RESERVE_IN_STORE = 'reserve in store';
export const RESERVE_INSTORE = 'ReserveInStore_pdp';
export const PAGE_NAME = 'Product Detail';
