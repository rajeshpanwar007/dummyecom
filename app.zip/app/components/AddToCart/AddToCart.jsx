/* eslint max-lines: ["error", 10015]*/
import React, { Fragment } from 'react';
import DeferRender from 'defer-render-hoc';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import qs from 'qs';
import { isEmpty } from 'lodash';
import _merge from 'lodash/merge';
import { pathOr, first } from 'lodash/fp';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { getStoreRef } from '@bbb-app/utils/storeRefUtils';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import CommonUtil from '@bbb-app/utils/commonUtil';
import Heading from '@bbb-app/core-ui/heading';
import uniqueKeys from '@bbb-app/utils/uniqueKeys';
import {
  noop,
  stubTrue,
  isTouchDevice,
  isBrowser,
  getQueryString,
} from '@bbb-app/utils/common';
import Button from '@bbb-app/core-ui/button';
import InputRadio from '@bbb-app/core-ui/input-radio/Input.async';
import Icon from '@bbb-app/core-ui/icon';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import {
  ACCESSORY_PRODUCT,
  COLLECTION_PRODUCT,
} from '@bbb-app/constants/pdpConstants';
import { setGlobalNotificationStatus } from '@bbb-app/actions/appActions';
import ErrorMessage from '@bbb-app/core-ui/focusable-error-message/ErrorMessage';
import { getMaxDayForStandardShipping } from '@bbb-app/estimated-delivery-date/containers/utils';
import CustomTooltip from '@bbb-app/core-ui/custom-tooltip/CustomTooltip';
import { ROUTE_BEYOND_PLUS_REDIRECT } from '@bbb-app/constants/route/checkoutRoute';
import '@bbb-app/assets/icons/checkmark.svg';
import {
  NO_QTY,
  NO_SIZE,
  NO_SWATCH,
  NO_LTL,
  ACTION_CART,
} from '../../constants/CallToAction';
import styles from './AddToCart.css';
import inlineStyles from './AddToCart.inline.css';
import {
  EDD_METRICS_ONE_TO_TWO,
  EDD_METRICS_TWO_TO_THREE,
  EDD_METRICS_THREE_TO_FOUR,
  EDD_METRICS_FOUR_TO_SIX,
  EDD_METRICS_ONE_TO_TWO_ROPIS,
  EDD_METRICS_TWO_TO_THREE_ROPIS,
  EDD_METRICS_THREE_TO_FOUR_ROPIS,
  EDD_METRICS_FOUR_TO_SIX_ROPIS,
} from '../Pages/PDP/constants';
import getParentProductData from '../Pages/PDP/ProductDetails/Utils/getParentProductData';
import AsyncModalDialogWithATCModal from '../../containers/common/ATCATRModal/ATCATRModalWithModalDialog.async';
const DeferredModalDialog = DeferRender(ModalDialog);
let isPdpOrPlpCtaSimulated = false;

const defaultProps = {
  className: null,
  isFetching: false,
  isValid: stubTrue,
  isCollegePage: false,
  onSuccess: noop,
  onError: noop,
  onModalClose: noop,
  addToCart: noop,
  shouldValidate: true,
  skuId: null,
  storeId: null,
  contentVariation: '',
  closeNandDModal: noop,
  displayName: '',
  tealiumPageName: null,
  clearProtectionPlan: noop,
  clickedFromPB: false,
};
/**
 * @param {array} products - An array containing multiple products to be added to cart
 */
const propTypes = {
  url: PropTypes.string,
  imageUrl: PropTypes.string,
  className: PropTypes.string,
  buttonProps: PropTypes.object.isRequired,
  onClientError: PropTypes.func,
  addToCart: PropTypes.func,
  skuId: PropTypes.string,
  scene7UrlConfig: PropTypes.object,
  prodId: PropTypes.string,
  qty: PropTypes.number,
  swatch: PropTypes.object,
  size: PropTypes.any,
  store: PropTypes.object,
  isFetching: PropTypes.bool,
  isProductAvailable: PropTypes.bool,
  isPrimaryATR: PropTypes.bool,
  showMiniCart: PropTypes.func,
  onSuccess: PropTypes.func,
  onError: PropTypes.func,
  enabledGlobalSwitches: PropTypes.object,
  switchConfig: PropTypes.object,
  labels: PropTypes.object,
  validationLabels: PropTypes.object,
  cartEndpoint: PropTypes.string,
  ltlShipMethod: PropTypes.number,
  ltlMethod: PropTypes.string,
  ltlFlag: PropTypes.string,
  parentProductId: PropTypes.string,
  calledFromRegistry: PropTypes.bool,
  closeQuickViewModal: PropTypes.func,
  onModalHide: PropTypes.func,
  onModalClose: PropTypes.func,
  shouldValidate: PropTypes.bool,
  reserveNow: PropTypes.string,
  storeId: PropTypes.string,
  refnum: PropTypes.string,
  updateCallToAction: PropTypes.func,
  registryId: PropTypes.string,
  emptyStoreData: PropTypes.func,
  resetVendorPriceDetails: PropTypes.func,
  isPickupInStoreModalOpen: PropTypes.bool,
  selectedProduct: PropTypes.object,
  price: PropTypes.string,
  tealiumLinkLocation: PropTypes.string,
  tealiumPageName: PropTypes.string,
  registryATCTealiumInfo: PropTypes.object,
  pageIdentifier: PropTypes.string,
  initiateInactivityModal: PropTypes.func,
  navBreakpoints: PropTypes.object,
  deviceBreakpoints: PropTypes.object,
  atcConfig: PropTypes.object,
  updatePickupStoreDisplay: PropTypes.func.isRequired,
  newCart: PropTypes.bool,
  isCollegePage: PropTypes.bool,
  closePickUpInStoreModal: PropTypes.func,
  quickViewMode: PropTypes.bool,
  quickViewTealiumInfo: PropTypes.object,
  quickViewTags: PropTypes.object,
  isPickUpInStoreModal: PropTypes.bool,
  closeNandDModal: PropTypes.func,
  location: PropTypes.object,
  displayName: PropTypes.string,
  tealiumObject: PropTypes.object,
  productVariation: PropTypes.string,
  itemIndex: PropTypes.number,
  swatchError: PropTypes.string,
  redirectTo: PropTypes.func,
  pageConfigGlobal: PropTypes.object,
  skuIdBP: PropTypes.string,
  porchPayload: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  products: PropTypes.array,
  fireSSTrack: PropTypes.func,
  viewType: PropTypes.string,
  track: PropTypes.func,
  eddResponse: PropTypes.object,
  storeDetails: PropTypes.any,
  attribJSON: PropTypes.object,
  inputLabelContent: PropTypes.any,
  clearProtectionPlan: PropTypes.func,
  selectedSKU: PropTypes.object,
  skuDetail: PropTypes.array,
  selectedPlanDetails: PropTypes.object,
  isPdpPersonalizeProduct: PropTypes.bool,
  isRBYRItem: PropTypes.bool,
  isNeedToExcluded: PropTypes.bool,
  enableRBYRFeature: PropTypes.bool,
  subscriptionItem: PropTypes.bool,
  every: PropTypes.string,
  everyPeriod: PropTypes.string,
  frequencyLabel: PropTypes.string,
  fireTealiumAction: PropTypes.func,
  tealiumTagsValue: PropTypes.object,
  skuIdentifier: PropTypes.string,
  contributionAmount: PropTypes.string,
  groupGiftingLabels: PropTypes.object,
  modalNeedToShow: PropTypes.bool,
  hideParentModal: PropTypes.func,
  ggEligibleItem: PropTypes.bool,
  toggleParentModal: PropTypes.func,
  groupGiftItemStatus: PropTypes.func,
  clickedFromPB: PropTypes.bool,
  isGooglePLA: PropTypes.bool,
  clickedOnPickItUp: PropTypes.bool,
  fetchPickupStoreDetails: PropTypes.func,
  storeList: PropTypes.array,
  isShiptSdd: PropTypes.bool,
  sddZipCode: PropTypes.string,
  sddItem: PropTypes.object,
  isChooseOption: PropTypes.bool,
  isfromNandDModal: PropTypes.bool,
  registryUserName: PropTypes.string,
  mockLocationForTestCase: PropTypes.string,
  isPromoteIQProduct: PropTypes.bool,
  sddEddZip: PropTypes.string,
  sddOnly: PropTypes.bool,
  isSelectedStoreAvailable: PropTypes.bool,
  showSDDResults: PropTypes.bool,
  replaceProps: PropTypes.object,
  parentProductData: PropTypes.string,
  quickAddProps: PropTypes.object,
};
export class AddToCart extends React.PureComponent {
  constructor(props) {
    super(props);
    this.error = {};
    this.state = {
      showResponseError: false,
      modalMountedState: false,
      modalMinimizeState: false,
      isStorePickUp: '',
    };
    this.refnum = '';
    this.handleAddToCartClick = this.handleAddToCartClick.bind(this);
    this.handleAddToCart = this.handleAddToCart.bind(this);
    this.handleReserveNow = this.handleReserveNow.bind(this);
    this.checkForError = this.checkForError.bind(this);
    this.key = uniqueKeys.getStatelessUniqueKey('AddToCart');
    this.handleAddToCartfromGooglePla = this.handleAddToCartfromGooglePla.bind(
      this
    );
  }

  componentDidMount() {
    if (isBrowser()) {
      const browserLocation = this.props.mockLocationForTestCase
        ? this.props.mockLocationForTestCase
        : window.location;
      const browserLocationSearch = browserLocation
        ? browserLocation.search
        : '';
      const simulationType = getQueryString('type', browserLocationSearch);
      const pickItUpBtn = document.getElementById('pickItUpBtn');
      if (
        this.props.pageIdentifier === 'PDP' &&
        isPdpOrPlpCtaSimulated === false &&
        pickItUpBtn != null &&
        simulationType === 'pickItUp' &&
        typeof this.props.reserveNow !== 'undefined' &&
        this.props.reserveNow === 'true'
      ) {
        pickItUpBtn.click();
        isPdpOrPlpCtaSimulated = true;
      }
    }
  }

  // eslint-disable-next-line complexity
  componentWillReceiveProps(newProps) {
    const {
      validationLabels,
      onError,
      prodId,
      skuId,
      isPickupInStoreModalOpen,
      isfromNandDModal,
    } = this.props;
    const { data } = this.props.store;
    let storeId =
      pathOr(null, 'store.storeId', this.props) ||
      pathOr(null, 'storeId', this.props);

    const newPropsStoreID = pathOr(null, 'store.storeId', newProps);
    if (isEmpty(storeId) && isEmpty(newPropsStoreID)) {
      storeId = newPropsStoreID;
    }

    if (
      (this.key === newProps.store.key || isfromNandDModal) &&
      prodId === newProps.store.productId &&
      skuId &&
      skuId === newProps.store.skuId &&
      storeId === newPropsStoreID
    ) {
      /* istanbul ignore else */
      if (this.props.onModalHide) this.props.onModalHide();
      /* istanbul ignore else */
      if (newProps.store && newProps.store.data) {
        this.setMountedState(newProps, data);
      }
      /**
       * Error scenarios :
       * 1. find in store modal is close and error in response i.e error on PDP page
       * 2. find in store modal is open and error in response i.e. API error on clicking on Reserve no button*
       * 3. Reserve now from CART page
       */
      /* istanbul ignore else */
      if (newProps.store && newProps.store.error) {
        if (isPickupInStoreModalOpen) {
          this.setState({
            showResponseError: false,
          });
        } else {
          this.checkForError(validationLabels, onError, newProps);
        }
      }
    }
    if (isBrowser()) {
      const browserLocation = this.props.mockLocationForTestCase
        ? this.props.mockLocationForTestCase
        : window.location;
      const browserLocationSearch = browserLocation
        ? browserLocation.search
        : '';
      const browserLocationHash =
        browserLocation && browserLocation.hash
          ? browserLocation.hash.substr(1)
          : '';
      const dataLocator = pathOr(
        '',
        'buttonProps.attr.data-locator',
        this.props
      );
      const isPDP = this.props.pageIdentifier === 'PDP';
      const isPLP =
        this.props.pageIdentifier === 'PLP' ||
        this.props.pageIdentifier === 'BrandLanding' ||
        this.props.pageIdentifier === 'SearchResults';
      let simulateBtnOnPdpOrPlp;
      let doNotSimulate = false;
      if (isPDP) {
        const simulationType = getQueryString('type', browserLocationSearch);
        if (simulationType === 'cart' && this.props.skuId !== null) {
          simulateBtnOnPdpOrPlp = document.getElementById('addToCartBtn');
        } else if (
          simulationType === 'deliverIt' &&
          this.props.sddEddZip &&
          this.props.sddOnly &&
          this.props.isSelectedStoreAvailable
        ) {
          simulateBtnOnPdpOrPlp = document.getElementById('deliverItBtn');
        }
        if (dataLocator === 'pdp-Deliverybutton') {
          doNotSimulate =
            simulationType === 'deliverIt' && this.props.buttonProps.disabled;
        } else if (dataLocator === 'pdp-addtocartbutton') {
          doNotSimulate =
            simulationType === 'cart' && this.props.buttonProps.disabled;
        }
      } else if (isPLP) {
        simulateBtnOnPdpOrPlp = document.getElementById(browserLocationHash);
      }
      if (doNotSimulate) {
        isPdpOrPlpCtaSimulated = true;
      }
      if (simulateBtnOnPdpOrPlp != null && isPdpOrPlpCtaSimulated === false) {
        simulateBtnOnPdpOrPlp.click();
        isPdpOrPlpCtaSimulated = true;
      }
    }
  }
  /**
   * onModalClose
   * calls the onModalClose prop & empties the store
   */
  onModalClose = () => {
    const {
      onModalClose,
      emptyStoreData,
      closePickUpInStoreModal,
      reserveNow,
      closeQuickViewModal,
      buttonProps,
      clearProtectionPlan,
    } = this.props;

    emptyStoreData();
    onModalClose();
    clearProtectionPlan();
    if (reserveNow === 'true' || buttonProps.attr.isReserveNowButton) {
      closePickUpInStoreModal();
      closeQuickViewModal();
    }
  };

  onAddToCartFromCertona = payload => {
    this.props.emptyStoreData();
    this.props.addToCart({ ...payload, key: this.key });
  };

  setDefaultErrorState() {
    this.error = {};
  }

  setMountedState(newProps, data) {
    const { showMiniCart, onSuccess, atcConfig } = this.props;
    if (newProps.store.data && newProps.store.data !== data) {
      if (this.enabledATCModal) {
        this.setState({
          modalMountedState: true,
        });
      } else if (this.isMobile) {
        this.toggleMobileOverlay(atcConfig);
      } else {
        showMiniCart(true);
        if (this.props.resetVendorPriceDetails) {
          this.props.resetVendorPriceDetails();
        }
        setTimeoutCustom(() => showMiniCart(false), 5000); // TODO: Make it configurable from siteconfig TBD when cart flyout will be implemented
      }
      onSuccess(1); // Reset quantity dropdown to 1.
    }
  }
  /**
   * Handle Null check for ltlShipMethod
   * Reduces complexity of handleAddToCartClick method
   * @returns {string}
   */
  getltlShipMethod(ltlFlag, ltlShipMethod) {
    // ltlFlag comes as boolean from Registry Owner and Guest View and as string from PDP and quickview
    if (ltlFlag && ltlFlag.toString() === 'true') {
      return ltlShipMethod;
    }
    return null;
  }

  /**
   * set parent id to product id if product is accessory product.
   */
  setParentProductID = () => {
    const productVariation = pathOr('', 'store.productVariation', this.props);
    const isAccesoryOrCollection =
      productVariation === ACCESSORY_PRODUCT ||
      productVariation === COLLECTION_PRODUCT;
    if (isAccesoryOrCollection) {
      return this.props.store.productId;
    }
    return this.props.store.parentProductId;
  };

  getCategoryId(selectedProduct) {
    const locationSearch = pathOr('', 'search', this.props.location);
    const query = qs.parse(locationSearch, { ignoreQueryPrefix: true });
    if (query.categoryId) {
      return query.categoryId;
    }
    let categoryId = null;
    if (selectedProduct) {
      categoryId = this.filterCategoryId(selectedProduct);
      if (!categoryId) {
        const { location } = this.props;
        // Get category id from PARENT_PROD_INFO if not available for product
        const parentCategory = getParentProductData(selectedProduct, location);
        categoryId = parentCategory.length
          ? this.filterCategoryId(parentCategory[0])
          : null;
      }
    }
    return categoryId;
  }
  getReserveNowEddMetrics(maxDay) {
    if (maxDay >= 1 && maxDay <= 2) {
      return EDD_METRICS_ONE_TO_TWO_ROPIS;
    } else if (maxDay >= 2 && maxDay <= 3) {
      return EDD_METRICS_TWO_TO_THREE_ROPIS;
    } else if (maxDay >= 3 && maxDay <= 4) {
      return EDD_METRICS_THREE_TO_FOUR_ROPIS;
    } else if ((maxDay >= 4 && maxDay <= 6) || maxDay > 6) {
      return EDD_METRICS_FOUR_TO_SIX_ROPIS;
    }
    return null;
  }
  getEddSSMetrics(eddResponse, skuId, reserveNow) {
    const maxDay = getMaxDayForStandardShipping(eddResponse, skuId);
    if (maxDay) {
      if (reserveNow) {
        const reserveNowMetrics = this.getReserveNowEddMetrics(maxDay);
        return reserveNowMetrics;
      }
      if (maxDay >= 1 && maxDay <= 2) {
        return EDD_METRICS_ONE_TO_TWO;
      } else if (maxDay >= 2 && maxDay <= 3) {
        return EDD_METRICS_TWO_TO_THREE;
      } else if (maxDay >= 3 && maxDay <= 4) {
        return EDD_METRICS_THREE_TO_FOUR;
      } else if ((maxDay >= 4 && maxDay <= 6) || maxDay > 6) {
        return EDD_METRICS_FOUR_TO_SIX;
      }
    }
    return null;
  }

  getSelectedProtectionPlan(planInfo, warrantySkuId, productSkuId) {
    let selectedPlan = {};
    const { associatedProductSkuId } = this.props.selectedPlanDetails;
    const WARRANTY_SKU_ID = pathOr(
      '',
      'protectionPlanDetails.SKU_ID',
      planInfo
    );
    // We are considering WARRANTY_SKU_ID while changing the warranty from ATC.
    // On PDP page, warrantySkuId is being considered for sending the param in add to cart api.
    if (!isEmpty(WARRANTY_SKU_ID)) {
      selectedPlan = {
        warrantySkuId:
          WARRANTY_SKU_ID === 'NO_PLAN' ? 'noplan' : WARRANTY_SKU_ID,
        addWarrantyOnly: 'true',
      };
    } else if (!isEmpty(warrantySkuId)) {
      selectedPlan = {
        warrantySkuId: warrantySkuId === 'NO_PLAN' ? '' : warrantySkuId,
      };
    }
    if (associatedProductSkuId && productSkuId !== associatedProductSkuId) {
      selectedPlan = {
        warrantySkuId: '',
      };
    }
    return selectedPlan;
  }

  PickUpHereStoreDetail(storeList, pickUpHerestoreId) {
    if (pickUpHerestoreId !== null && storeList && storeList.length > 0) {
      const pickUpHereStore = storeList.filter(store => {
        return store.storeId === pickUpHerestoreId;
      });
      return pickUpHereStore;
    }
    return null;
  }

  filterCategoryId(selectedProduct) {
    const L1_ID = pathOr(null, 'L1_ID.[0]', selectedProduct);
    const L2_ID = pathOr(null, 'L2_ID.[0]', selectedProduct);
    const L3_ID = pathOr(null, 'L3_ID.[0]', selectedProduct);
    return selectedProduct.PRIMARY_CATEGORY || L3_ID || L2_ID || L1_ID;
  }

  /**
   * @type {boolean}
   */
  get isMobile() {
    return (
      this.props.navBreakpoints &&
      CommonUtil.isMobileScreen(this.props.navBreakpoints.DESKTOP)
    );
  }

  /**
   * @type {boolean}
   */
  get enabledATCModal() {
    return pathOr(true, 'enableATCModal', this.props.enabledGlobalSwitches);
  }

  checkForError(validationLabels, onError, newProps) {
    const { store, atcConfig } = newProps;
    let storeID = null;
    let errorData = LabelsUtil.getLabel(
      validationLabels,
      'err_cart_outOfStockItem'
    );
    if (store.storeId) {
      storeID = this.props.store.storeId;
      errorData = LabelsUtil.getLabel(validationLabels, 'ATCErrMsg');
    }
    if (errorData && !this.state.modalMountedState) {
      if (this.enabledATCModal) {
        this.setState({
          showResponseError: errorData, // TODO: Sunil to handle it in the same way as we handle success. Creative dependency also raised
          modalMountedState: true,
        });
      } else if (this.isMobile) {
        this.toggleMobileOverlay(atcConfig);
      } else {
        const content = {
          status: 'error',
          content: errorData,
        };
        const storeRef = getStoreRef();
        storeRef.dispatch(setGlobalNotificationStatus(content));
      }
      // Added storeID param for handling reverve now API error on find in store modal
      onError(errorData, storeID);
    }
  }

  toggleMobileOverlay = atcConfig => {
    this.setState(
      {
        modalMountedState: true,
      },
      () => {
        const time = (atcConfig && atcConfig.mobileOverlayInterval) || 5000;
        setTimeoutCustom(
          () => this.setState({ modalMountedState: false }),
          time
        );
      }
    );
  };

  /**
   * Gets the fetching or busy state of the component
   * @returns {bool}
   */
  get isFetching() {
    return this.props.isFetching || this.props.store.isFetching;
  }

  reserveNowTealiumObject(
    price,
    prodId,
    skuId,
    qty,
    pageIdentifier,
    displayName
  ) {
    const newlyCreatedCart = this.props.newCart;
    const localVariable = {
      product_id: [prodId],
      product_sku_id: [skuId],
      product_quantity: [qty],
      product_price: [price],
      cart_add_location:
        pageIdentifier === 'PDP' ? 'Product Details Page' : pageIdentifier,
      displayName,
      navigation_path: '',
      search_words_applied: '',
    };

    return _merge(localVariable, {
      newly_created_cart: newlyCreatedCart ? 'true' : 'false',
    });
  }
  // Redirect to BeyondPlus Page for BeyondPlus SkuId, else add to normal cart.
  handleAddToCart(e) {
    console.log("handleAddToCart called >>>>>>>")
    const { skuId, skuIdBP, pageConfigGlobal } = this.props;
    const skuID = first(skuIdBP) || skuId;
    const beyondPlusSKUList = pathOr(
      null,
      'beyondPlusSKUList',
      pageConfigGlobal
    );
    // convert beyondPlusSKUList string to list
    const bpSKUList = beyondPlusSKUList ? beyondPlusSKUList.split(',') : [];
    // redirect if beyondPlusSKUList is not empty and have a valid Beyond Plus skuId
    if (!isEmpty(bpSKUList) && bpSKUList.indexOf(skuID) !== -1) {
      this.props.redirectTo(
        pathOr(ROUTE_BEYOND_PLUS_REDIRECT, 'beyondPlusUrl', pageConfigGlobal)
      );
    } else {
      if (e && typeof e.preventDefault === 'function') {
        e.preventDefault();
      }
      this.handleAddToCartClick();
    }
  }

  fireTealiumActionForShipT = () => {
    const {
      viewType,
      isShiptSdd,
      pageIdentifier,
      fireTealiumAction,
      prodId,
      skuId,
      selectedProduct,
    } = this.props;
    if (isShiptSdd) {
      const actionDetails = {
        product_id: [skuId || prodId],
      };
      const pageInfo = {
        page_type: 'Product Listing Page',
        page_name: 'ProductListing',
      };
      if (viewType === 'PDP') {
        actionDetails.call_to_actiontype = 'PDP Deliver It Click';
        actionDetails.pagename_breadcrumb = `PDP > ${pathOr(
          '',
          'DISPLAY_NAME',
          selectedProduct
        )}`;
        pageInfo.page_type = 'Product Details Page';
        pageInfo.page_name = 'ProductDetails';
      } else if (viewType === 'quickView') {
        actionDetails.pagename_breadcrumb = `PLP > Choose Options > ${pathOr(
          '',
          'DISPLAY_NAME',
          selectedProduct
        )}`;
        actionDetails.call_to_actiontype = 'Choose Options->Deliver It Click';
      } else if (pageIdentifier === 'SearchResults' && !viewType) {
        actionDetails.call_to_actiontype = 'PLP Deliver It Click';
        actionDetails.pagename_breadcrumb = 'PLP > Product Tile';
      }
      fireTealiumAction(true, actionDetails, pageInfo);
    }
    return false;
  };

  handleAddToCartfromGooglePla(tealiumTagsPLA) {
    const TEALIUM_PAGE_INFO = {
      page_type: 'Product Details Page',
      page_name: 'ProductDetails',
    };
    this.props.fireTealiumAction(
      'certona product click',
      tealiumTagsPLA,
      TEALIUM_PAGE_INFO
    );
  }

  // eslint-disable-next-line complexity
  handleAddToCartClick(planInfo) {
    const {
      addToCart,
      swatch,
      size,
      onClientError,
      updateCallToAction,
      ltlFlag,
      qty,
      skuId,
      prodId,
      shouldValidate,
      reserveNow,
      storeId,
      refnum,
      registryId,
      price,
      tealiumLinkLocation,
      tealiumPageName,
      registryATCTealiumInfo,
      ltlShipMethod: shipMethod,
      pageIdentifier,
      initiateInactivityModal,
      isCollegePage,
      selectedProduct,
      updatePickupStoreDisplay,
      imageUrl,
      url,
      parentProductId,
      ltlMethod,
      quickViewMode,
      quickViewTags,
      quickViewTealiumInfo,
      isPickUpInStoreModal,
      displayName,
      tealiumObject,
      productVariation,
      porchPayload,
      products,
      fireSSTrack,
      viewType,
      track,
      eddResponse,
      selectedPlanDetails,
      isRBYRItem,
      isNeedToExcluded,
      enableRBYRFeature,
      subscriptionItem,
      every,
      everyPeriod,
      frequencyLabel,
      skuIdentifier,
      ggEligibleItem,
      contributionAmount,
      clickedFromPB,
      fetchPickupStoreDetails,
      storeList,
      isShiptSdd,
      sddItem,
      sddZipCode,
      tealiumTagsValue,
      isGooglePLA,
      buttonProps,
      isChooseOption,
      isPromoteIQProduct,
      showSDDResults,
    } = this.props;
    const ltlShipMethod = this.getltlShipMethod(ltlFlag, shipMethod);
    const warrantySkuId = pathOr('', 'SKU_ID', selectedPlanDetails);
    this.refnum = refnum || '';
    let tealiumTagsPLA = {};
    if (
      tealiumTagsValue &&
      tealiumTagsValue.strategy === 'pdp_collcav' &&
      isGooglePLA
    ) {
      tealiumTagsPLA = {
        sku: skuId,
        quantity: qty,
        productId: prodId,
        SKUPrice: selectedProduct && selectedProduct.IS_PRICE,
        isGooglePLA,
        ...tealiumTagsValue,
      };
      this.handleAddToCartfromGooglePla(tealiumTagsPLA);
    }
    let reservestoreTealiumObject = {};
    const isReserveNow =
      buttonProps && buttonProps.attr && buttonProps.attr.isReserveNowButton;
    if (reserveNow === 'true' || isReserveNow) {
      reservestoreTealiumObject = this.reserveNowTealiumObject(
        price,
        prodId,
        skuId,
        qty,
        pageIdentifier,
        displayName
      );
      updatePickupStoreDisplay(false);
    }
    /*
     * fire inactivity modal action in case of registry owner addToCart
     */
    if (initiateInactivityModal) {
      initiateInactivityModal(true);
    }
    // Validate that the data format of the product(s) is proper for sending to the API
    this.skuValidation(
      qty,
      ltlFlag,
      skuId,
      ltlShipMethod,
      size,
      swatch,
      products
    );
    if (shouldValidate && !isEmpty(this.error)) {
      updateCallToAction(ACTION_CART);
      onClientError(this.error);
      this.setDefaultErrorState();
      return;
    }
    this.fireTealiumActionForShipT();
    const categoryId = this.getCategoryId(selectedProduct);
    if (viewType && viewType === 'PDP' && track) {
      // EDD SS metrics for PDP add to cart
      const eddSSMetricsString = this.getEddSSMetrics(
        eddResponse,
        skuId,
        reserveNow
      );
      if (eddSSMetricsString) track(eddSSMetricsString);
    }
    // If provided, fire the SiteSpect tracking function now
    if (fireSSTrack) fireSSTrack();
    // selected protection plan from ATC modal
    const selectedPlan = this.getSelectedProtectionPlan(
      planInfo,
      warrantySkuId,
      skuId
    );
    if (clickedFromPB && track) {
      track('click_AddToCartProdBundle');
    }
    if (this.props.modalNeedToShow) this.props.hideParentModal();
    addToCart({
      skuId,
      prodId,
      qty,
      productVariation,
      ltlShipMethod,
      reserveNow: isReserveNow ? 'true' : reserveNow,
      storeId,
      registryId,
      refnum,
      tealiumLinkLocation,
      tealiumPageName,
      registryATCTealiumInfo,
      categoryId,
      key: this.key,
      imageUrl,
      bts: isCollegePage,
      url,
      parentProductId,
      ltlMethod,
      quickViewMode,
      quickViewTealiumInfo,
      quickViewTags,
      isPickUpInStoreModal,
      pageIdentifier,
      reservestoreTealiumObject,
      tealiumObject,
      porchPayload,
      products,
      selectedPlan,
      isRBYRItem,
      isNeedToExcluded,
      enableRBYRFeature,
      subscriptionItem: subscriptionItem ? 'true' : 'false',
      every,
      everyPeriod,
      frequencyLabel,
      skuIdentifier,
      ggEligibleItem,
      contributionAmount,
      clickedFromPB,
      isShiptSdd,
      sddItem,
      sddZipCode,
      tealiumTagsPLA,
      isChooseOption,
      isPromoteIQProduct,
      showSDDResults,
    });
    fetchPickupStoreDetails(this.PickUpHereStoreDetail(storeList, storeId));
  }
  skuValidation = (
    qty,
    ltlFlag,
    skuId,
    ltlShipMethod,
    size,
    swatch,
    products
  ) => {
    if (products) {
      products.forEach(product => {
        if (product.qty <= 0) {
          this.error[NO_QTY] = NO_QTY;
        }
        if (
          product.ltlFlag === 'true' &&
          product.skuId &&
          !product.ltlShipMethod
        )
          this.error[NO_LTL] = NO_LTL;
        if (!product.skuId && !product.size) this.error[NO_SIZE] = NO_SIZE;
        if (!product.skuId && isEmpty(product.swatch))
          this.error[NO_SWATCH] = NO_SWATCH;
      });
    } else {
      if (qty <= 0) {
        this.error[NO_QTY] = NO_QTY;
      }
      if (ltlFlag === 'true' && skuId && !ltlShipMethod)
        this.error[NO_LTL] = NO_LTL;
      if (!skuId && !size) this.error[NO_SIZE] = NO_SIZE;
      if (!skuId && isEmpty(swatch)) this.error[NO_SWATCH] = NO_SWATCH;
    }
  };
  toggleModalState = state => {
    this.setState({ modalMountedState: state });
    if (this.props.toggleParentModal) {
      this.props.toggleParentModal();
    }
    if (this.props.closeQuickViewModal) this.props.closeQuickViewModal();
    if (pathOr(null, 'replaceProps.closeReplaceModal', this.props)) {
      this.props.replaceProps.closeReplaceModal();
    }
    if (pathOr(null, 'quickAddProps.toggleChooseOptionState', this.props))
      this.props.quickAddProps.toggleChooseOptionState();
  };

  toggleMinimizeModal = state => {
    this.setState({ modalMinimizeState: state });
  };
  handleReserveNow(event) {
    this.handleAddToCart();
    this.setState({
      isStorePickUp: event.target.value,
    });
  }
  renderMobileOverlay = () => {
    const {
      labels,
      validationLabels,
      cartEndpoint,
      store,
      deviceBreakpoints,
    } = this.props;
    // Small modal for desktop (>1023) and full modal below that.
    const variation =
      deviceBreakpoints && CommonUtil.isMobileScreen(deviceBreakpoints.DESKTOP)
        ? 'medium'
        : 'small';
    return !this.enabledATCModal && this.isMobile && !this.isFetching ? (
      <DeferredModalDialog
        alert
        mountedState={this.state.modalMountedState}
        toggleModalState={this.toggleModalState}
        dialogClass={styles.atcModal}
        titleAriaLabel={LabelsUtil.getLabel(labels, 'addedToCart')}
        verticallyCenter
        rclModalClass={classnames(styles.atcMobileOverlay)}
        variation={variation}
        onModalClose={this.onModalClose}
        titleId="atc-mobile-overlay-title"
      >
        {store.error ? (
          <ErrorMessage id="atc-mobile-overlay-title">
            {LabelsUtil.getLabel(validationLabels, 'err_cart_outOfStockItem')}
          </ErrorMessage>
        ) : (
          <Fragment>
            <Heading
              id="atc-mobile-overlay-title"
              level={5}
              className="mb3"
              data-locator="atcmodal_addedtocartlabel"
            >
              <Icon
                className="mr1"
                width="16px"
                height="16px"
                type="checkmark"
              />
              {LabelsUtil.getLabel(labels, 'addedToCart')}
            </Heading>
            <Button
              theme="primary"
              href={cartEndpoint}
              data-locator="atcmodal_viewcartandcheckoutctabtn"
            >
              {LabelsUtil.getLabel(labels, 'viewCartAndCheckout')}
            </Button>
          </Fragment>
        )}
      </DeferredModalDialog>
    ) : null;
  };
  /* eslint complexity: ["error", 20]*/
  render() {
    const {
      buttonProps,
      labels,
      validationLabels,
      scene7UrlConfig,
      enabledGlobalSwitches,
      className,
      registryId,
      closePickUpInStoreModal,
      closeQuickViewModal,
      calledFromRegistry,
      closeNandDModal,
      itemIndex,
      isProductAvailable,
      isPrimaryATR,
      viewType,
      swatchError,
      quickViewMode,
      attribJSON,
      inputLabelContent,
      selectedSKU,
      skuDetail,
      reserveNow,
      selectedPlanDetails,
      groupGiftingLabels,
      ggEligibleItem,
      groupGiftItemStatus,
      clickedOnPickItUp,
      isShiptSdd,
      isRBYRItem,
      registryUserName,
      isNeedToExcluded,
      sddOnly,
      switchConfig,
      showSDDResults,
      parentProductData,
    } = this.props;
    if (this.props.store.skuId && this.props.skuId !== this.props.store.skuId) {
      this.refnum = '';
    }
    const enableATCRelatedCategories = pathOr(
      '',
      'enableATCRelatedCategories',
      enabledGlobalSwitches
    );
    const productVariation = pathOr('', 'store.productVariation', this.props);
    const storeIdNumber = pathOr('', 'storeId', this.props.store);
    const { className: btnClass } = { ...buttonProps.attr };
    const isDisabled =
      buttonProps.attr.theme === 'deactivated' ||
      buttonProps.attr.variation === 'deactivated';
    let atcInlineClass = btnClass || '';
    if (viewType === 'PDP') {
      atcInlineClass += ` ${inlineStyles.ctaButtonPDP}`;
      if (isProductAvailable && isPrimaryATR) {
        atcInlineClass += ` ${inlineStyles.secondaryCTAPDP}`;
      } else if (
        typeof isProductAvailable !== 'undefined' &&
        !isProductAvailable
      ) {
        atcInlineClass += ` ${inlineStyles.atcOOSButtonPDP}`;
      } else if (isProductAvailable) {
        atcInlineClass += ` ${inlineStyles.primaryCTAPDP}`;
      }
    }
    let addToCartButtonId = '';
    if (this.props.pageIdentifier === 'PDP') {
      if (sddOnly) {
        addToCartButtonId = `deliverItBtn`;
      } else if (typeof reserveNow !== 'undefined' && reserveNow === 'true') {
        addToCartButtonId = `pickItUpBtn`;
      } else {
        addToCartButtonId = `addToCartBtn`;
      }
    } else if (
      this.props.pageIdentifier === 'PLP' ||
      this.props.pageIdentifier === 'BrandLanding' ||
      this.props.pageIdentifier === 'SearchResults'
    ) {
      addToCartButtonId = isShiptSdd
        ? `${this.props.prodId}_deliverItSimulation`
        : `${this.props.prodId}_pickItUpSimulation`;
    }
    return (
      <div
        className={classnames(className, styles.addToCartButton)}
        id={isShiptSdd ? 'delivery-cta' : 'atc-cta'}
      >
        {attribJSON && attribJSON.renderPdpEdd ? (
          <InputRadio
            id="inStorePickUp_pdpEddVariant"
            name="deliveryOptions_pdpEddVariant"
            onClick={e => this.handleReserveNow(e)}
            labelContent={inputLabelContent}
            value="inStorePickUp"
            className={styles.pickUpInStoreRadio}
            checked={this.state.isStorePickUp === 'inStorePickUp'}
          />
        ) : (
          <Button
            theme={buttonProps.attr.theme}
            onClick={e => this.handleAddToCart(e)}
            disabled={this.isFetching || buttonProps.disabled}
            {...buttonProps.attr}
            className={atcInlineClass}
            id={addToCartButtonId}
          >
            {buttonProps.contentVariation === 'wrap' ? (
              <span className={classnames(styles.wrapContent)}>
                {buttonProps.children}
              </span>
            ) : (
              buttonProps.children
            )}
          </Button>
        )}
        {!isTouchDevice() &&
          !isDisabled &&
          swatchError && (
            <CustomTooltip
              id={buttonProps.attr['aria-describedby']}
              className={styles.errorToolTip}
              swatchError={swatchError}
            />
          )}
        {this.enabledATCModal &&
        !this.isFetching &&
        this.state.modalMountedState ? (
          <AsyncModalDialogWithATCModal
            mountedState={this.state.modalMountedState}
            parentProductData={parentProductData}
            toggleModalState={this.toggleModalState}
            dialogClass={styles.atcModal}
            titleAriaLabel={LabelsUtil.getLabel(labels, 'addedToCart')}
            verticallyCenter
            rclModalClass={classnames(styles.addedTocartModal)}
            variation="medium"
            scrollDisabled={false}
            onModalClose={this.onModalClose}
            hideParent={this.state.modalMinimizeState}
            selectedProduct={this.props.selectedProduct}
            data={this.props.store.data}
            errorObj={this.props.store.error}
            isFetching={this.isFetching}
            skuId={this.props.store.skuId}
            itemQty={this.props.store.cartItemQty}
            refnum={this.refnum}
            scene7UrlConfig={scene7UrlConfig}
            labels={labels}
            validationLabels={validationLabels}
            parentProductId={this.setParentProductID()}
            calledFromRegistry={calledFromRegistry}
            enableCertonaContainerATCATRModal={pathOr(
              '',
              'enableCertonaContainerATCATRModal',
              enabledGlobalSwitches
            )}
            enableCertona={pathOr('', 'enableCertona', enabledGlobalSwitches)}
            enableATCRelatedCategories={enableATCRelatedCategories}
            prodId={this.props.store.productId}
            resetVendorPriceDetails={this.props.resetVendorPriceDetails}
            categoryId={this.props.store.categoryId}
            registryId={registryId}
            showATCSuggestions
            minimizeATCHandler={this.toggleMinimizeModal}
            onAddToCartFromCertona={this.onAddToCartFromCertona}
            viewType="PDP"
            closePickUpInStoreModal={closePickUpInStoreModal}
            closeQuickViewModal={closeQuickViewModal}
            pageIdentifier={this.props.pageIdentifier}
            closeNandDModal={closeNandDModal}
            itemIndex={itemIndex}
            isPorchPayloadAvailable={!!this.props.porchPayload}
            quickViewMode={quickViewMode}
            storeDetails={this.props.storeDetails}
            selectedSKU={selectedSKU}
            skuDetail={skuDetail}
            reserveNow={reserveNow}
            enabledGlobalSwitches={enabledGlobalSwitches}
            handleAddToCartClick={this.handleAddToCartClick}
            selectedPlanDetails={selectedPlanDetails}
            isPdpPersonalizeProduct={this.props.isPdpPersonalizeProduct}
            isCertonaATC={this.props.store.isCertonaATC}
            ggEligibleItem={ggEligibleItem && groupGiftItemStatus(this.props)}
            groupGiftingLabels={groupGiftingLabels}
            storeIdNumber={storeIdNumber}
            buttonIdentifier={buttonProps.children}
            clickedOnPickItUp={clickedOnPickItUp}
            isShiptSdd={isShiptSdd}
            showSOSMessage={isRBYRItem && !isNeedToExcluded}
            registryUserName={registryUserName}
            switchConfig={switchConfig}
            showSDDResults={showSDDResults}
            productVariation={productVariation}
          />
        ) : (
          this.renderMobileOverlay()
        )}
      </div>
    );
  }
}
AddToCart.propTypes = propTypes;
AddToCart.defaultProps = defaultProps;
export default AddToCart;
