export const COLLECTION_PRODUCT = 'COLLECTION';
export const NON_INTERNAL_CAMPAIGN = 'non-internal campaign';
export const PAGE_NAME = 'add to ideaboard from prc';
export const CALL_ACTION_TYPE = 'add to ideaboard from prc';
