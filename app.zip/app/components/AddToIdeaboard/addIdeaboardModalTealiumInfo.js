/* eslint-disable no-console */
import Immutable from 'immutable';
import pathOr from 'lodash/fp/pathOr';
import { isEmpty } from 'lodash';
import { getStoreRef } from '@bbb-app/utils/storeRefUtils';
import { consoleLog } from '@bbb-app/utils/logger';
import { NON_SEARCH } from '@bbb-app/tealium/constants';
import { getBoostEngineSelected } from '@bbb-app/tealium/tagSelectors/page';
import {
  isListingPage,
  getPriceAfterFormatting,
} from '@bbb-app/tealium/tagSelectors/utils';
import {
  CALL_TO_ACTION,
  MY_ACCOUNT,
  BREADCRUMB,
} from '../../containers/ThirdParty/Tealium/Ideaboard/AddToIdeaBoardModalTealiumHandler/constants';
import { getFacetOrderData } from '../../containers/ThirdParty/Tealium/TagSelectors/facetsOrder';
import { deleteTealiumTagsByLocation } from '../AddToRegistry/ATRUtilMethods';

const getItemIndex = (itemIndexPosition, start) => {
  const itemIndex =
    itemIndexPosition !== undefined && typeof itemIndexPosition === 'number'
      ? start + (itemIndexPosition + 1)
      : '';
  return itemIndex;
};

function getAppliedFacetsMap(orderedSet) {
  const appliedFacetMap = {};
  orderedSet.forEach(element => {
    let value = element.id === 'LOW_PRICE' ? element.label : element.value;
    value = element.id === 'RATINGS' ? value.slice(0, 1) : value;
    let tempArray = [];
    if (
      Object.keys(appliedFacetMap).length > 0 &&
      Object.keys(appliedFacetMap).includes(element.id)
    ) {
      tempArray = appliedFacetMap[element.id];
      tempArray.push(value);
      appliedFacetMap[element.id] = tempArray;
    } else {
      tempArray.push(value);
      appliedFacetMap[element.id] = tempArray;
    }
  });
  return appliedFacetMap;
}

const getSearchDataTags = (
  search,
  currentURL,
  itemIndexPosition,
  pdpFacetApplied
) => {
  const {
    searchTerm = '',
    brandNameOriginal = '',
    params = {},
    selectedFilters = {},
    appliedFiltersOrderedSet = [],
    searchWithinSearchTerms = '',
  } = search;
  const appliedFacets = getAppliedFacetsMap(appliedFiltersOrderedSet);

  /** Search Words Applied start **/
  const facetOrderData = getFacetOrderData(search);
  const { facetOrder = '', correctedSearchTerm = '' } = facetOrderData;

  let searchWordsApplied = correctedSearchTerm || searchTerm;
  if (currentURL.includes('/store/brand/')) {
    searchWordsApplied = brandNameOriginal;
  }
  /** Search Words Applied end **/

  const { start = 0, sort = '' } = params;
  /** Get Sort Value start **/
  let sortValue = sort;
  if (sort === '-1') {
    sortValue = '';
  }
  sortValue = sortValue ? sortValue.replace('_', ' ') : '';
  /** Get Sort Value end **/
  const itemPostion = getItemIndex(itemIndexPosition, start);
  const internalSearchTerm = currentURL.includes('/store/s/')
    ? searchTerm
    : NON_SEARCH;
  /** get facets applied start**/
  let facetApplied = '';

  if (currentURL.includes('/store/product/')) {
    facetApplied = pdpFacetApplied;
  } else if (!isEmpty(selectedFilters)) {
    facetApplied = Object.keys(selectedFilters)
      .map(k => `${k}:${appliedFacets[k]}-`)
      .toString()
      .replace(new RegExp(/-,/gi), '|');
    facetApplied = facetApplied.slice(0, -1);
  }

  const formattedFacetApplied = getAllFacets(facetApplied);

  /** get facets applied end**/

  const sws = Array.isArray(searchWithinSearchTerms)
    ? searchWithinSearchTerms.toString()
    : '';
  return {
    searchWordsApplied,
    internalSearchTerm,
    facetOrder,
    itemPostion,
    sortValue,
    formattedFacetApplied,
    sws,
  };
};

export function getAllFacets(allFacets) {
  try {
    const splitFacets = allFacets && allFacets.split('|');
    const priceString =
      splitFacets && splitFacets.find(value => value.includes('LOW_PRICE'));
    if (
      priceString &&
      !priceString.includes('$') &&
      priceString.split(':').length > 1
    ) {
      const index = splitFacets.indexOf(priceString);
      const price = priceString.split(':')[1];
      const newPrice = getFormattedPriceString(price);
      splitFacets[index] = newPrice;
      const formattedPriceString = splitFacets.join('|');
      return getFormattedFacetAppliedString(formattedPriceString);
    }
  } catch (err) {
    consoleLog.error(err);
  }
  return getFormattedFacetAppliedString(allFacets);
}

const populatePriceFacetArray = priceSplitArray => {
  if (priceSplitArray) {
    return [`$${priceSplitArray[0]}`, `$${priceSplitArray[1]}`];
  }
  return '';
};

function getFormattedPriceString(price) {
  let newPriceString;
  // If multiple price facets are applied
  if (price.includes(',')) {
    const multiplePriceSplitArray = price && price.split(',');
    const multiplePriceArray = [];
    multiplePriceSplitArray.forEach(item => {
      const priceSplitArray = item.split('-');
      const newArray = populatePriceFacetArray(priceSplitArray);
      multiplePriceArray.push(newArray.join('-'));
      newPriceString = `LOW_PRICE:${multiplePriceArray.join(',')}`;
    });
  } else {
    // If single price facet is applied
    const priceSplitArray = price && price.split('-');
    const newArray = populatePriceFacetArray(priceSplitArray);
    newPriceString = `LOW_PRICE:${newArray.join('-')}`;
  }
  return newPriceString;
}

function getFormattedFacetAppliedString(formattedPriceString) {
  const formattedFacets = [];
  const formattedPriceArray =
    formattedPriceString && formattedPriceString.split('|');
  if (formattedPriceArray) {
    formattedPriceArray.forEach(item => {
      formattedFacets.push(item);
    });
  }
  return formattedFacets.join('|');
}

const getStaticData = (addToIdeaboardParams, apolloURLData) => {
  const boostedSearchEngine = getBoostEngineSelected(apolloURLData);
  let price;
  if (addToIdeaboardParams) {
    price =
      addToIdeaboardParams.productPrice ||
      addToIdeaboardParams.tealiumProductPrice;
    price = getPriceAfterFormatting(price);
  }
  const tealiumData = {
    boosted_search_engine: boostedSearchEngine,
    call_to_actiontype: CALL_TO_ACTION,
    channel: MY_ACCOUNT,
    content_pagetype: '',
    crossell_page: '',
    crossell_product: '',
    ideaboard_name: '',
    navigation_path: MY_ACCOUNT,
    page_function: MY_ACCOUNT,
    pagename_breadcrumb: BREADCRUMB,
    product_finding_method: '',
    product_pagetype: '',
    subnavigation_path: MY_ACCOUNT,
    product_price: [price],
    product_id: addToIdeaboardParams ? [addToIdeaboardParams.productId] : [],
    internal_search_term: '',
    facet_order: '',
    sort_value: '',
    search_words_applied: '',
    facets_applied: '',
    product_position_clicked: '',
  };
  return tealiumData;
};

export const getTealiumTags = params => {
  const {
    currentURL = '',
    addToIdeaboardParams = {},
    searchData = {},
    apolloURLData,
    pdpFacetApplied = '',
    typeAheadSearchTerm = '',
  } = params;
  const isPDP = currentURL.includes('/store/product/');
  const isValidTypeAhead = typeAheadSearchTerm && isPDP;

  const tealiumData = getStaticData(addToIdeaboardParams, apolloURLData);
  if (isPDP || isListingPage(currentURL)) {
    if (isValidTypeAhead) {
      tealiumData.search_words_applied = typeAheadSearchTerm;
      tealiumData.product_position_clicked = getItemIndex(
        params.itemIndexPosition,
        0
      );
      tealiumData.search_within_search = '';
    } else {
      const search =
        searchData && Immutable.Iterable.isIterable(searchData)
          ? searchData.toJS()
          : {};
      if (!isEmpty(search)) {
        const searchDataTags = getSearchDataTags(
          search,
          currentURL,
          params.itemIndexPosition,
          pdpFacetApplied
        );
        const {
          searchWordsApplied = '',
          internalSearchTerm = '',
          facetOrder = '',
          itemPostion = 0,
          sortValue = '',
          formattedFacetApplied = '',
          sws = '',
        } = searchDataTags;
        tealiumData.search_words_applied = searchWordsApplied;
        tealiumData.internal_search_term = internalSearchTerm;
        tealiumData.facet_order = facetOrder;
        tealiumData.product_position_clicked = itemPostion;
        tealiumData.sort_value = sortValue;
        tealiumData.facets_applied = formattedFacetApplied;
        tealiumData.search_within_search = sws;
        tealiumData.category_id = search.categoryId;
        tealiumData.brand_id = search.categoryId;
      }
    }
  }
  const updatedTealiumData = deleteTealiumTagsByLocation(
    window.location,
    tealiumData
  );
  return updatedTealiumData;
};

export const addIdeaboardModalTealiumInfo = args => {
  const {
    addToIdeaboardParams = {},
    routeData = {},
    quickViewMode = false,
  } = args;
  const defaultPathname = pathOr(
    '',
    'locationBeforeTransitions.pathname',
    routeData
  );
  const currentURL = pathOr(
    defaultPathname,
    'locationBeforeTransitions.location.pathname',
    routeData
  );
  const defaultPrvsPathname = pathOr(
    '',
    'previousLocationBeforeTransitions.pathname',
    routeData
  );
  const reffererURL = pathOr(
    defaultPrvsPathname,
    'previousLocationBeforeTransitions.location.pathname',
    routeData
  );
  const store = getStoreRef();
  const state = store && store.getState();
  const apolloURLData = state.getIn(['viewportConfig', 'siteConfig', 'apollo']);
  let searchData;
  if (isListingPage(currentURL) || isListingPage(reffererURL)) {
    searchData = state.getIn(['search']);
  }
  let itemIndexPosition = args.itemIndex;
  let pdpFacetApplied;
  let typeAheadSearchTerm;
  if (currentURL.includes('/store/product/')) {
    itemIndexPosition = state.getIn(['primarylink', 'itemIndexFromPLP']);
    typeAheadSearchTerm = state.getIn(['primarylink', 'typeAheadSearchTerm']);
    pdpFacetApplied = state.getIn(['tealium', 'facetsApplied']);
  }
  if (quickViewMode) {
    itemIndexPosition = state.getIn(['primarylink', 'itemIndexFromPLP']);
  }

  const params = {
    searchData,
    apolloURLData,
    currentURL,
    itemIndexPosition,
    addToIdeaboardParams,
    pdpFacetApplied,
    typeAheadSearchTerm,
  };

  const tealiumData = getTealiumTags(params);

  return Object.assign({}, tealiumData);
};

export default [addIdeaboardModalTealiumInfo, getAllFacets];
