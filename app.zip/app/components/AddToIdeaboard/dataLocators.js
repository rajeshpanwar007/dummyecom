export const LOCATOR_HEADING_LABEL =
  'addToIdeaboard-ideaboardaddtoIdeaboradheadinglabel';
export const LOCATOR_CREATE_LINK =
  'addToIdeaboard-ideaboardcreatenewideaboradlink';
export const LOCATOR_PRODUCT_IMAGE = 'addToIdeaboard-ideaboardproductimage';
export const LOCATOR_PRODUCT_TITLE = 'addToIdeaboard-ideaboardproducttitle';
export const LOCATOR_SELECTED_IDEABOARD_LABEL =
  'addToIdeaboard-ideaboardselectideaboardlabel';
export const LOCATOR_IDEABOARD_NAME = 'addToIdeaboard-ideaboardnamelabel';
export const LOCATOR_IDEABOARD_COPY_BUTTON =
  'addToIdeaboard-ideaboardcopyctabtn';
export const LOCATOR_IDEABOARD_PUBLIC_LINK =
  'addToIdeaboard-ideaboardpubliclink';
export const LOCATOR_IDEABOARD_PRIVATE_LINK =
  'addToIdeaboard-ideaboardprivatelink';
export const LOCATOR_IDEABOARD_DONE_BUTTON =
  'addToIdeaboard-ideaboardonboardctabtn';
export const LOCATOR_IDEABOARD_BACK_BUTTON = 'addToIdeaboard-Ideaboardbacklink';
export const LOCATOR_IDEABOARD_ADD_BUTTON = 'addToIdeaboard-ideaboardaddctabtn';
export const LOCATOR_CREATE_NEW_IDEABOARD =
  'addToIdeaboard-ideaboardcreatenewideaboardctabtn';
export const LOCATOR_CANCEL_LINK = 'addToIdeaboard-ideaboardcancellink';
export const LOCATOR_LOGIN_LINK = 'addToIdeaboard-ideaboardloginlink';
export const LOCATOR_GUEST_CREATE_HEADING_LABEL =
  'addToIdeaboard-ideaboardcreatenewideaboardheadinglabel';
export const LOCATOR_GUEST_USER_HEADING_LABEL =
  'addToIdeaboard-ideaBoardguestuserheadinglabel';
export const LOCATOR_CREATE_ACCOUNT_LINK =
  'addToIdeaboard-ideaBoardloginorcreateaccountlink';
export const LOCATOR_DONE_BUTTON = 'addToIdeaboard-ideaBoard_donectabtn';
