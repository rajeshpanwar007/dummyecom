import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { toast } from 'react-toastify';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import Heading from '@bbb-app/core-ui/heading';
import { isTouchDevice } from '@bbb-app/utils/common';
import Button from '@bbb-app/core-ui/button';
import IconButton from '@bbb-app/core-ui/icon-button';
import Icon from '@bbb-app/core-ui/icon';
import '@bbb-app/styles/thirdparty/toast.css';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import {
  NON_SEARCH,
  NON_BROWSE,
  NON_CROSSELL_PRODUCT,
} from '@bbb-app/tealium/constants';
import '@bbb-app/assets/icons/inline/heart.svg';
import SelectedIdeaboard from '../Pages/IdeaBoardCommon/SelectedIdeaboard';
import SelectIdeaboardList from './SelectIdeaboardList';
import styles from './AddToIdeaboard.css';
import Skeleton from './Skeleton';
import {
  LOCATOR_CANCEL_LINK,
  LOCATOR_HEADING_LABEL,
  LOCATOR_DONE_BUTTON,
  LOCATOR_CREATE_LINK,
} from './dataLocators';
import CreateIdeaBoard from './CreateIdeaBoard';
import AddToIdeaBoardModalTealiumHandler from '../../containers/ThirdParty/Tealium/Ideaboard/AddToIdeaBoardModalTealiumHandler';
import {
  MY_ACCOUNT,
  BREADCRUMB,
} from '../../containers/ThirdParty/Tealium/Ideaboard/AddToIdeaBoardModalTealiumHandler/constants';
import AccountSignInButton from '../../containers/AccountSignInButton/AccountSignInButton';
import {
  COLLECTION_PRODUCT,
  NON_INTERNAL_CAMPAIGN,
  PAGE_NAME,
} from './constants';
import { addIdeaboardModalTealiumInfo } from './addIdeaboardModalTealiumInfo';

// eslint-disable-next-line react/prefer-stateless-function
export class AddToIdeaboard extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    onSelectModalOpen: PropTypes.func,
    productName: PropTypes.string.isRequired,
    productImageId: PropTypes.string,
    productImageUrl: PropTypes.string,
    selectedIdeaboards: PropTypes.array,
    scene7Config: PropTypes.object,
    isFetching: PropTypes.bool,
    labels: PropTypes.object,
    isLoggedIn: PropTypes.bool,
    onSelectModalClose: PropTypes.func,
    copyToIdeaboardHandler: PropTypes.func.isRequired,
    onCopyModalClose: PropTypes.func,
    copyError: PropTypes.any,
    addToIdeaboardParams: PropTypes.object,
    isCopying: PropTypes.bool,
    fireTealiumAction: PropTypes.func,
    contextPath: PropTypes.string,
    quickViewMode: PropTypes.bool,
    parentProductData: PropTypes.string,
    endPoints: PropTypes.object,
    page: PropTypes.string,
    productFindingMethod: PropTypes.string,
    renderCustomToolTip: PropTypes.bool,
    routeData: PropTypes.object,
    itemIndex: PropTypes.number,
    toolTipClassName: PropTypes.object,
    ideaboardIconId: PropTypes.string,
    onProductTile: PropTypes.bool,
    isMobileOnly: PropTypes.bool,
  };

  constructor(props) {
    super(props);
    this.state = {
      openSelectIdeaboarModal: false,
      isMinimisedDialogClass: false,
    };
    this.handleSelectModal = this.handleSelectModal.bind(this);
    this.handleModalClose = this.handleModalClose.bind(this);
    this.handleCopySuccessModal = this.handleCopySuccessModal.bind(this);
    this.minimiseAddToIdeaboardHandler = this.minimiseAddToIdeaboardHandler.bind(
      this
    );
    this.maximizeAddToIdeaboardHandler = this.maximizeAddToIdeaboardHandler.bind(
      this
    );
    this.openCopySuccessModal = this.openCopySuccessModal.bind(this);
    this.getTealiumParams = this.getTealiumParams.bind(this);
  }

  componentWillUnmount() {
    if (this.timer) clearTimeout(this.timer);
  }

  /**
   * @method getTealiumParams to set tealium params for load event
   */
  getTealiumParams() {
    const {
      addToIdeaboardParams,
      page,
      productFindingMethod,
      routeData,
      quickViewMode,
    } = this.props;
    if (page === 'certona') {
      return {
        call_to_actiontype: '',
        channel: MY_ACCOUNT,
        crossell_product: NON_CROSSELL_PRODUCT,
        feo_site_indicator: '',
        ideaboard_name: '',
        ideaboard_status: '',
        page_function: MY_ACCOUNT,
        pagename_breadcrumb: BREADCRUMB,
        product_finding_method: productFindingMethod,
        internal_search_term: NON_SEARCH,
        internal_campaign: NON_INTERNAL_CAMPAIGN,
        merchandising_main_level: NON_BROWSE,
        merchandising_category: NON_BROWSE,
        merchandising_subcategory: NON_BROWSE,
        crossell_page: NON_CROSSELL_PRODUCT,
        page_name: PAGE_NAME,
        navigation_path: MY_ACCOUNT,
        subnavigation_path: MY_ACCOUNT,
        product_id: addToIdeaboardParams
          ? [addToIdeaboardParams.productId]
          : [],
        product_sku_id: [],
      };
    }

    const args = {
      addToIdeaboardParams,
      routeData,
      itemIndex: this.props.itemIndex,
      quickViewMode,
    };
    const tealiumData = addIdeaboardModalTealiumInfo(args);
    return tealiumData;
  }

  handleSelectModal() {
    this.props.onSelectModalOpen();
    this.setState({
      openSelectIdeaboarModal: true,
    });
    const tealiumData = this.getTealiumParams();
    tealiumData.call_to_actiontype = 'add to ideaboard_snowplow';
    this.props.fireTealiumAction('', tealiumData, '');
  }

  handleModalClose(ideaboardIconId) {
    if (ideaboardIconId) {
      this.timer = setTimeoutCustom(() => {
        document.getElementById(ideaboardIconId).focus();
      }, 0);
    }
    this.props.onSelectModalClose();
    this.setState({
      openSelectIdeaboarModal: false,
    });
  }

  openCopySuccessModal(params) {
    const addedItemName = params.ideaBoardName || '';
    toast(
      LabelsUtil.getLabel(this.props.labels, 'addToIdeaboardSuccessMessage', [
        addedItemName,
      ])
    );
    this.props.copyToIdeaboardHandler(params);
    this.props.onCopyModalClose();
    const ideaboardIconId = pathOr('', 'ideaboardIconId', params);
    this.handleModalClose(ideaboardIconId);
  }

  handleCopySuccessModal() {
    this.props.onSelectModalClose(false);
    this.setState({
      openSelectIdeaboarModal: false,
    });
  }

  minimiseAddToIdeaboardHandler() {
    this.setState({
      minimiseModal: true,
    });
  }

  maximizeAddToIdeaboardHandler() {
    this.setState({
      minimiseModal: false,
    });
  }

  render() {
    const {
      className,
      productName,
      productImageId,
      productImageUrl,
      selectedIdeaboards,
      scene7Config,
      isFetching,
      labels,
      isLoggedIn,
      copyError,
      isCopying,
      addToIdeaboardParams,
      fireTealiumAction,
      contextPath,
      quickViewMode,
      parentProductData,
      endPoints,
      renderCustomToolTip,
      toolTipClassName,
      ideaboardIconId,
      onProductTile,
      isMobileOnly,
    } = this.props;
    const isAnonymousUserMaxLimit =
      !isLoggedIn &&
      selectedIdeaboards &&
      selectedIdeaboards.length === 1 &&
      selectedIdeaboards[0].itemCount >= 4;

    const redirectLocation = {
      pathname: pathOr('', 'ideaboardLanding', endPoints),
      search: '',
    };

    const DangerousHTML = dangerousHTML(DangerousHTML);

    const ideaboardLabel = 'modalHeading';

    return (
      <React.Fragment>
        <IconButton
          aria-label={LabelsUtil.getLabel(labels, 'modalHeading')}
          id={ideaboardIconId || ''}
          size="small"
          appearance="circular"
          className={classnames(
            className,
            onProductTile && isMobileOnly
              ? styles.ideaBoardIconForPLP
              : styles.ideaBoardIcon,
            'hideOnPrint',
            quickViewMode && parentProductData === COLLECTION_PRODUCT
              ? styles.ideaBoardIconCollectionModal
              : ''
          )}
          data-locator={LOCATOR_CANCEL_LINK}
          onClick={this.handleSelectModal}
        >
          <Icon height="40" type="heart" />
        </IconButton>
        {!isTouchDevice() &&
          renderCustomToolTip && (
            <span
              className={classnames(
                toolTipClassName,
                styles.customTooltip,
                'type-dark',
                'center',
                'hide'
              )}
              role="tooltip"
            >
              {LabelsUtil.getLabel(labels, ideaboardLabel)}
            </span>
          )}
        {this.state.openSelectIdeaboarModal && (
          <AddToIdeaBoardModalTealiumHandler
            utagData={this.getTealiumParams()}
          />
        )}
        <ModalDialog
          mountedState={this.state.openSelectIdeaboarModal}
          toggleModalState={() => this.handleModalClose(ideaboardIconId)}
          titleAriaLabel={LabelsUtil.getLabel(labels, 'modalHeading')}
          variation="small"
          verticallyCenter
          scrollDisabled={false}
          hideParent={this.state.minimiseModal}
        >
          {!isFetching ? (
            <React.Fragment>
              <div className="md-flex lg-flex mb2">
                <Heading
                  level={3}
                  className={styles.selectIdeaboardModalTitle}
                  data-laocator={LOCATOR_HEADING_LABEL}
                >
                  {LabelsUtil.getLabel(labels, 'modalHeading')}
                </Heading>

                {selectedIdeaboards &&
                  selectedIdeaboards[0] &&
                  !isAnonymousUserMaxLimit && (
                    <React.Fragment>
                      <PrimaryLink
                        href="/store/ideaboard/landingPage"
                        className={styles.allBoardLink}
                      >
                        View All Boards
                      </PrimaryLink>
                      <CreateIdeaBoard
                        buttonTheme="link"
                        labels={labels}
                        dataLocator={LOCATOR_CREATE_LINK}
                        buttonClassName={classnames(
                          styles.createIdeaBoardLinkButton
                        )}
                        minimiseAddToIdeaboardHandler={
                          this.minimiseAddToIdeaboardHandler
                        }
                        maximizeAddToIdeaboardHandler={
                          this.maximizeAddToIdeaboardHandler
                        }
                        closeAddToIdeaboard={this.handleModalClose}
                        isLoggedIn={isLoggedIn}
                        ideaboardsList={selectedIdeaboards}
                        addToIdeaboardParams={addToIdeaboardParams}
                        fireTealiumAction={fireTealiumAction}
                        routeData={this.props.routeData}
                        itemIndex={this.props.itemIndex}
                        quickViewMode={quickViewMode}
                        ideaboardIconId={ideaboardIconId}
                      />
                    </React.Fragment>
                  )}
              </div>
              {isAnonymousUserMaxLimit ? (
                <React.Fragment>
                  <div className={styles.anonymousUserMaxLimitText}>
                    <AccountSignInButton
                      renderBefore={LabelsUtil.getLabel(
                        labels,
                        'anonymousUserMaxLimitText'
                      )}
                      location={redirectLocation}
                      className={classnames(styles.loginButton)}
                    >
                      {LabelsUtil.getLabel(
                        labels,
                        'ideaboardGuestCreateAccountLink'
                      )}
                    </AccountSignInButton>
                  </div>

                  <Button
                    theme="primary"
                    className={classnames(styles.doneButton, 'block', 'my1')}
                    onClick={() => {
                      this.handleModalClose();
                    }}
                    data-locator={LOCATOR_DONE_BUTTON}
                  >
                    {LabelsUtil.getLabel(labels, 'ideaboardDoneButton')}
                  </Button>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <SelectedIdeaboard
                    className="mb3"
                    displayName={productName}
                    imageId={productImageId}
                    ImageUrl={productImageUrl}
                    scene7Config={scene7Config}
                  />
                  <SelectIdeaboardList
                    scene7Config={scene7Config}
                    selectedIdeaboards={selectedIdeaboards}
                    labels={labels}
                    copyToIdeaboardHandler={this.openCopySuccessModal}
                    copyError={copyError}
                    isLoggedIn={isLoggedIn}
                    minimiseAddToIdeaboardHandler={
                      this.minimiseAddToIdeaboardHandler
                    }
                    maximizeAddToIdeaboardHandler={
                      this.maximizeAddToIdeaboardHandler
                    }
                    closeAddToIdeaboard={this.handleModalClose}
                    addToIdeaboardParams={addToIdeaboardParams}
                    dataLocator={LOCATOR_CREATE_LINK}
                    isCopying={isCopying}
                    fireTealiumAction={fireTealiumAction}
                    contextPath={contextPath}
                    ideaboardCTA="copyIdeaboardButtonText"
                    endPoints={endPoints}
                    routeData={this.props.routeData}
                    itemIndex={this.props.itemIndex}
                    quickViewMode={quickViewMode}
                    ideaboardIconId={ideaboardIconId}
                  />
                </React.Fragment>
              )}
            </React.Fragment>
          ) : (
            <Skeleton />
          )}
        </ModalDialog>
      </React.Fragment>
    );
  }
}

export default AddToIdeaboard;
