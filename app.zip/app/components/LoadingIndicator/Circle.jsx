import React from 'react';
import PropTypes from 'prop-types';
import styles from './LoadingIndicator.css';

const Circle = props => {
  return (
    <div
      className={styles.circle}
      style={{
        transform: `rotate(${props.rotate}deg)`,
        '--delay': `${props.delay}s`,
      }}
    />
  );
};

Circle.propTypes = {
  delay: PropTypes.number,
  rotate: PropTypes.number,
};

Circle.defaultProps = {
  delay: 0,
  rotate: 0,
};

export default Circle;
