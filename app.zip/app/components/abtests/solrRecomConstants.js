// Solr Recommendation container Experiment
const SOLR_RECOM_VARIANT_A = 'SolrRecomAPI-A';
const SOLR_RECOM_VARIANT_B = 'SolrRecomAPI-B';
const SOLR_RECOM_VARIANT_C = 'SolrRecomAPI-C';
const SOLR_RECOM_VARIANT_D = 'SolrRecomAPI-D';
const SOLR_RECOM_VARIANT_E = 'SolrRecomAPI-E';
const SOLR_RECOM_VARIANT_Z = 'SolrRecomAPI-Z';

export const SOLR_RECOM_VARIANTS = {
  [SOLR_RECOM_VARIANT_A]:
    '/api/apps/recommendations/query/r1?web3feo=abc&_cookie=false',
  [SOLR_RECOM_VARIANT_B]:
    '/api/apps/recommendations/query/r2?web3feo=abc&_cookie=false',
  [SOLR_RECOM_VARIANT_C]:
    '/api/apps/recommendations/query/r3?web3feo=abc&_cookie=false',
  [SOLR_RECOM_VARIANT_D]:
    '/api/apps/recommendations/query/r4?web3feo=abc&_cookie=false',
  [SOLR_RECOM_VARIANT_E]:
    '/api/apps/recommendations/query/r5?web3feo=abc&_cookie=false',
  [SOLR_RECOM_VARIANT_Z]: '/api/apps/recommendations/query/r1?web3feo=abc',
};
export const SOLR_RECOM_ARGUMENTS = [
  SOLR_RECOM_VARIANT_A,
  SOLR_RECOM_VARIANT_B,
  SOLR_RECOM_VARIANT_C,
  SOLR_RECOM_VARIANT_D,
  SOLR_RECOM_VARIANT_E,
  SOLR_RECOM_VARIANT_Z,
];
