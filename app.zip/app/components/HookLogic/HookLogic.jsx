import React from 'react';
import PropTypes from 'prop-types';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import './HookLogic.css';

export const HookLogic = ({ pageIdentifier }) => {
  const HookLogigMap = {
    SearchResults: 'viewSearchResult-SearchListing',
    PLP: 'viewCategory-BrowseListing',
    CLP: 'viewCategory-BrowseListing',
    PDP: 'viewItem-PDP',
  };

  if (
    pageIdentifier &&
    HookLogigMap[pageIdentifier] &&
    !isInternationalUser()
  ) {
    return <div id={HookLogigMap[pageIdentifier]} className="hideOnPrint" />;
  }
  return null;
};

HookLogic.propTypes = {
  pageIdentifier: PropTypes.string,
};

HookLogic.defaultProps = {
  pageIdentifier: '',
};

export default HookLogic;
