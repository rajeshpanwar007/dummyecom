import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Image from '@bbb-app/core-ui/image';
import Icon from '@bbb-app/core-ui/icon';
import '@bbb-app/assets/icons/arrow.svg';
import '@bbb-app/assets/icons/inline/heart.svg';
import styles from './RegistryInsights.css';
import regInData from './regInData';
import Skeleton from './Skeleton';

const arr = [0, 1, 2, 3];
const shuffle = arr.sort(() => Math.random() - 0.5);

const defaultProps = {
  data: regInData,
};

const propTypes = {
  data: PropTypes.any,
  registryData: PropTypes.any,
};

const RegistryInsights = props => {
  if (
    !props.registryData ||
    !props.registryData.registryResVO ||
    !props.registryData.registryResVO.registrySummaryVO
  ) {
    return <Skeleton />;
  }

  return (
    <GridX
      className={classnames(styles.regInCont, props.data[shuffle[0]].direction)}
    >
      <div
        className={classnames(styles.regInTopBox)}
        style={{
          border: `3px solid`,
          borderColor: props.data[shuffle[0]].titleBorderColor,
        }}
      >
        <Icon
          type={props.data[shuffle[0]].icon}
          className={classnames(styles.regInTopBoxIcon)}
          height="20px"
          width="20px"
        />

        <span>{props.data[shuffle[0]].title}</span>
      </div>

      <Cell className={classnames(styles.regInImg, 'medium-4 small-12')}>
        <Image
          src={props.data[shuffle[0]].image.url}
          alt={props.data[shuffle[0]].image.alt}
        />
      </Cell>

      <Cell className={classnames(styles.regInText, 'medium-8 small-12')}>
        <Heading level={1} className={classnames(styles.regInDiscount)}>
          {props.data[shuffle[0]].discount}
        </Heading>
        <Heading level={3}>{props.data[shuffle[0]].copy}</Heading>
        <Button
          theme="ghost"
          className="HyperLink__textDecorationNone___OYBSz"
          href={
            props.data[shuffle[0]].cta.url
              ? props.data[shuffle[0]].cta.url
              : `${props.data[shuffle[0]].cta.dynamicUrl}/${props.registryData
                  .registryResVO.registrySummaryVO.registryId}`
          }
          isIconAfterContent="true"
          iconProps={{
            type: 'arrow',
            width: `${props.data[shuffle[0]].cta.showIcon}`,
            height: `${props.data[shuffle[0]].cta.showIcon}`,
          }}
          aria-label={`${props.data[shuffle[0]].copy} ${props.data[shuffle[0]]
            .cta.linkText}`}
        >
          {props.data[shuffle[0]].cta.linkText}
        </Button>
      </Cell>
    </GridX>
  );
};

RegistryInsights.propTypes = propTypes;
RegistryInsights.defaultProps = defaultProps;

export default RegistryInsights;
