const regInData = [
  {
    direction: '',
    title: 'Tip Alert!',
    discount: '',
    copy:
      'Balance your registry with items at a variety of prices, so friends, family - even coworkers - can find you the perfect gift.',
    titleBorderColor: '#d6d6d6',
    icon: 'heart',
    image: {
      url:
        '//s7d9.scene7.com/is/image/BedBathandBeyond/07%5F18%5Ftip%5Fregistry%5Fanalyzer%402x?$other$',
      alt: 'Manage your registry on-the-go',
    },
    cta: {
      url: '',
      linkText: '',
      showIcon: '0',
    },
  },
  {
    direction: 'reverseContent',
    title: 'Tip Alert!',
    discount: '',
    copy:
      'Use our online Thank You List tool to track gifts easily, so you can send thank you notes later.',
    titleBorderColor: '#d6d6d6',
    icon: 'heart',
    image: {
      url:
        '//s7d9.scene7.com/is/image/BedBathandBeyond/07%5F18%5Ftip%5Fthank%5Fyou%5Fmanager%402x?$other$',
      alt: 'Thank You List Tool',
    },
    cta: {
      url: null,
      dynamicUrl: '/store/giftRegistry/viewRegistryOwner/tym',
      linkText: 'See Your Thank You List',
      showIcon: '20px',
    },
  },
  {
    direction: '',
    title: 'Tip Alert!',
    discount: '',
    copy:
      'Sneak a peek at what new moms love in registry Favorites, which highlights our most popular items.',
    titleBorderColor: '#d6d6d6',
    icon: 'heart',
    image: {
      url:
        '//s7d9.scene7.com/is/image/BedBathandBeyond/07%5F18%5Ftip%5Fregistry%5Ffavorites%402x?$other$',
      alt:
        'Sneak a peek at what new moms love in registry Favorites, which highlights our most popular items.',
    },
    cta: {
      url: '/store/s/registry-favorites',
      linkText: 'See Our Registry Favorites',
      showIcon: '20px',
    },
  },
  {
    direction: 'reverseContent',
    title: 'Tip Alert!',
    discount: '',
    copy:
      'Get a quick glance of the categories you have already registered for and easily add products you may want and need with our interactive checklist!',
    titleBorderColor: '#d6d6d6',
    icon: 'heart',
    image: {
      url:
        '//s7d9.scene7.com/is/image/BedBathandBeyond/07%5F18%5Ftip%5Finteractive%5Fchecklist%402x?$other$',
      alt: 'interactive checklist',
    },
    cta: {
      url: '',
      linkText: '',
      showIcon: '0',
    },
  },
];

export default regInData;
