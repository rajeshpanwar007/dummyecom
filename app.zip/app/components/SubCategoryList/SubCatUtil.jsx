import isBrowser from '@bbb-app/utils/isBrowser';
import {
  DEFAULT_THRESHOLD_DESKTOP,
  THRESHOLD_14,
  THRESHOLD_12,
  THRESHOLD_18,
  THRESHOLD_6,
  THRESHOLD_10,
  DEFAULT_THRESHOLD_MOBILE,
} from './constants';

/* eslint complexity: ["error", 12] */

/**
 * alterMaxItemCount - Function to determine max number of visual facets to show before
 * adding the "show more" button
 *
 * @param {number} currentCount - original max count
 *
 * @return {number} - Returns the max number of facets to show based on window size
 */

/* eslint complexity: ["error", 14]*/
export const alterMaxItemCount = (currentCount, limitToOneLine) => {
  let innerWidth;
  let threshold;
  if (isBrowser()) {
    innerWidth = window.innerWidth;
  }
  /**
   *  Inner widths are determined based on the size of images
   *  at the different window widths and how many viusal facets are fitting
   *  on one line at a time.
   */
  if (
    (innerWidth >= 1190 && innerWidth < 1360) ||
    (innerWidth <= 871 && innerWidth > 762)
  ) {
    threshold = THRESHOLD_14;
  }
  if (
    (innerWidth <= 1189 && innerWidth > 1023) ||
    (innerWidth <= 762 && innerWidth > 653)
  )
    threshold = THRESHOLD_12;

  if (innerWidth <= 1023 && innerWidth > 979) threshold = THRESHOLD_18;

  if ((innerWidth <= 979 && innerWidth > 871) || innerWidth >= 1360)
    threshold = DEFAULT_THRESHOLD_DESKTOP;

  if (innerWidth <= 471) threshold = THRESHOLD_6;
  if (innerWidth <= 653 && innerWidth > 544) threshold = THRESHOLD_10;
  if (innerWidth <= 544 && innerWidth > 471)
    threshold = DEFAULT_THRESHOLD_MOBILE;

  if (limitToOneLine && threshold) threshold /= 2;

  return threshold || currentCount;
};
