import React, { Fragment } from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper/SkeletonWrapper';
import ShowMore from '@bbb-app/core-ui/show-more/ShowMore';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import CategoryListItem from '@bbb-app/styled-image-list/StyledImageList';
import {
  CHANNELTYPE_DESKTOP,
  CHANNELTYPE_MOBILE,
} from '@bbb-app/constants/appConstants';
import Styles from './SubCategoryList.inline.css';
import {
  DEFAULT_THRESHOLD_MOBILE,
  DEFAULT_THRESHOLD_DESKTOP,
} from './constants';
/**
 * @param {string} className - wrapper className
 * @param {array} categories - list of categories to be rendered
 * @param {bool} loading - flag to show skeleton
 * @param {string} channelType - Desktop View or Mobile View
 * @param {string} type - type to be passed to StyledImageList (round, square, etc.)
 * @param {object} overflowVariation - variation for mob + desktop on how to handle overflow of list items - stack or scroll
 * @param {object} compressedView - config to show compressed view with Show More button (only works if overflowVariation is "stack")
 *                  - {object} enable - flag to show the button
 *                  - {object} threshold - count after which show more button will be visible
 */
const propTypes = {
  className: PropTypes.string,
  categories: PropTypes.array,
  loading: PropTypes.bool,
  channelType: PropTypes.string,
  type: PropTypes.string,
  fireTealiumAction: PropTypes.func,
  breadcrumbs: PropTypes.array,
  overflowVariation: PropTypes.shape({
    [CHANNELTYPE_MOBILE]: PropTypes.oneOf(['stack', 'scroll']),
    [CHANNELTYPE_DESKTOP]: PropTypes.oneOf(['stack', 'scroll']),
  }),
  compressedViewEnable: PropTypes.shape({
    [CHANNELTYPE_MOBILE]: PropTypes.bool,
    [CHANNELTYPE_DESKTOP]: PropTypes.bool,
  }),
  compressedViewThreshold: PropTypes.shape({
    [CHANNELTYPE_MOBILE]: PropTypes.number,
    [CHANNELTYPE_DESKTOP]: PropTypes.number,
  }),
};

const defaultProps = {
  loading: false,
  channelType: CHANNELTYPE_MOBILE,
  overflowVariation: {
    [CHANNELTYPE_MOBILE]: 'stack',
    [CHANNELTYPE_DESKTOP]: 'stack',
  },
  compressedViewEnable: {
    [CHANNELTYPE_MOBILE]: false,
    [CHANNELTYPE_DESKTOP]: false,
  },
  compressedViewThreshold: {
    [CHANNELTYPE_MOBILE]: DEFAULT_THRESHOLD_MOBILE,
    [CHANNELTYPE_DESKTOP]: DEFAULT_THRESHOLD_DESKTOP,
  },
};

export class SubCategoryList extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      isDesktop: false,
    };
    this.handleFireTealium = this.handleFireTealium.bind(this);
  }

  componentDidMount() {
    // eslint-disable-next-line react/no-did-mount-set-state
    this.setState({
      isDesktop: this.props.channelType === CHANNELTYPE_DESKTOP,
    });
  }

  componentDidUpdate(prevProps) {
    if (prevProps.channelType !== this.props.channelType) {
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({
        isDesktop: this.props.channelType === CHANNELTYPE_DESKTOP,
      });
    }
  }

  handleFireTealium(categoryName) {
    const { fireTealiumAction, breadcrumbs } = this.props;

    if (fireTealiumAction) {
      let pageNameBreadCrumb = '';
      if (breadcrumbs && breadcrumbs.length !== 0) {
        const level = breadcrumbs.length;
        const l1Name = breadcrumbs[0] ? breadcrumbs[0].name : '';
        const l2Name = breadcrumbs[1] ? breadcrumbs[1].name : '';
        const l3Name = breadcrumbs[2] ? breadcrumbs[2].name : '';

        pageNameBreadCrumb = l1Name;
        if (level === 2) {
          pageNameBreadCrumb = `${l1Name}>${l2Name}>ALL`;
        } else if (level === 3) {
          pageNameBreadCrumb = `${l1Name}>${l2Name}>${l3Name}`;
        }
      }

      const tealiumConstants = {
        pagename_breadcrumb: `${pageNameBreadCrumb}`,
        event_breadcrumb: `${pageNameBreadCrumb}>Related Categories>${categoryName.text
          ? categoryName.text
          : ''}`,
      };
      const TEALIM_PAGE_INFO = {
        page_type: 'PLP',
        page_name: 'popular category click',
      };
      this.props.fireTealiumAction(
        'popular category click',
        tealiumConstants,
        TEALIM_PAGE_INFO
      );
    }
  }

  renderListItems(categories, compressedViewEnable, otherProps) {
    const { type } = this.props;
    const categoryList = categories.map((category, index) => {
      try {
        if (isEmpty(category)) {
          return null;
        }
        let url = category.url.toLowerCase();
        if (url.includes('store/category/shop-by-room')) {
          const urlArray = url.split('/');
          const catID =
            urlArray[urlArray.length - 1] !== ''
              ? urlArray[urlArray.length - 1]
              : urlArray[urlArray.length - 2];
          url += `?customCategory=true&ruleId=${catID}`;
        }

        return (
          <li key={index} className={classnames(Styles.catLi, Styles[type])}>
            <PrimaryLink
              href={url}
              onClick={() => this.handleFireTealium(category)}
            >
              <CategoryListItem
                imageDetail={category}
                hasHover
                copyText={category.text}
                {...otherProps}
              />
            </PrimaryLink>
          </li>
        );
      } catch (e) {
        /* istanbul ignore next */
        return null;
      }
    });
    return categoryList;
  }

  render() {
    const {
      categories = [],
      className,
      loading,
      overflowVariation,
      compressedViewEnable,
      channelType,
      ...otherProps
    } = this.props;
    const { isDesktop } = this.state;

    const categoryList = this.renderListItems(
      categories,
      compressedViewEnable,
      otherProps
    );

    if (loading) {
      return (
        <div className={classnames(Styles.categories, className, 'mt3')}>
          <SkeletonWrapper
            viewPort={{
              height: isDesktop ? 202 : 280, // Dimensions need to be specified
              width: isDesktop ? '1034px' : '100%', // Dimensions need to be specified
            }}
            rectContainerHeight="100%"
            rectContainerWidth="100%"
            preserveAspectRatio="xMaxYMin meet"
            svgProps={{ viewBox: null }}
          >
            {isDesktop && (
              <Fragment>
                <rect width="200" height="150" x="0" y="0" rx="10" ry="10" />
                <rect width="200" height="150" x="208" y="0" rx="10" ry="10" />
                <rect width="200" height="150" x="416" y="0" rx="10" ry="10" />
                <rect width="200" height="150" x="624" y="0" rx="10" ry="10" />
                <rect width="200" height="150" x="832" y="0" rx="10" ry="10" />
              </Fragment>
            )}
            {channelType === CHANNELTYPE_MOBILE && (
              <Fragment>
                <rect width="49%" height="66" x="0" y="0" rx="10" ry="10" />
                <rect width="49%" height="66" x="51%" y="0" rx="10" ry="10" />
                <rect width="49%" height="66" x="0" y="106" rx="10" ry="10" />
                <rect width="49%" height="66" x="51%" y="106" rx="10" ry="10" />
                <rect width="49%" height="66" x="0" y="212" rx="10" ry="10" />
              </Fragment>
            )}
          </SkeletonWrapper>
        </div>
      );
    } else if (!isEmpty(categoryList)) {
      return (
        <div className={classnames(Styles.categories, className)}>
          <ShowMore
            containerHeight={220}
            buttonProps={{
              isIconAfterContent: true,
              theme: 'secondaryStrokeBasic',
              variation: 'fullWidth',
            }}
            hideShowLessBtn
            defaultText={'Show More'}
            toggleText={'Show Less'}
            addGradient={!isDesktop}
          >
            <ul
              className={classnames(
                Styles.catList,
                Styles[overflowVariation[channelType]]
              )}
            >
              {categoryList}
            </ul>
          </ShowMore>
        </div>
      );
    }
    return null;
  }
}

SubCategoryList.propTypes = propTypes;
SubCategoryList.defaultProps = defaultProps;
export default SubCategoryList;
