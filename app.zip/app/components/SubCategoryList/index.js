export { default } from './SubCategoryList';
