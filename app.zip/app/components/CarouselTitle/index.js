export { default } from './CarouselTitle';
