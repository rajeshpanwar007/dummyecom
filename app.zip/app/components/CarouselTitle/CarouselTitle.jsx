import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Heading from '@bbb-app/core-ui/heading';
import HyperLink from '@bbb-app/core-ui/hyper-link';
import styles from './CarouselTitle.css';
const CarouselTitle = ({
  superScriptDetails,
  linkProps,
  children,
  ...props
}) => {
  const createSuperText = () => {
    if (superScriptDetails && superScriptDetails.text) {
      return (
        <sup className={superScriptDetails.className}>
          {superScriptDetails.text}
        </sup>
      );
    }
    return null;
  };
  const createLink = () => {
    if (linkProps && linkProps.text && linkProps.attrs) {
      return <HyperLink {...linkProps.attrs}>{linkProps.text}</HyperLink>;
    }
    return null;
  };
  if (linkProps || superScriptDetails) {
    return (
      <div className={classnames(styles.carouselTitleWrapper)}>
        <Heading {...props}>
          {children}
          {createSuperText()}
        </Heading>
        {createLink()}
      </div>
    );
  }
  return <Heading {...props}>{children}</Heading>;
};

CarouselTitle.propTypes = {
  superScriptDetails: PropTypes.object,
  linkProps: PropTypes.object,
  children: PropTypes.node,
  level: PropTypes.number,
};

CarouselTitle.defaultProps = {
  level: 2,
};
export default CarouselTitle;
