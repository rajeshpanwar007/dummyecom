import React from 'react';
import { getSiteSpectAssignment } from '@bbb-app/utils/siteSpectUtil';
import Button from '@bbb-app/core-ui/button';
import getConcatenatedScene7URLWithImageURL from '@bbb-app/utils/getConcatenatedScene7URLWithImageURL';
import {
  generateSrcSetAttribute,
  generateSrcAttribute,
} from '@bbb-app/core-ui/image-src-set/ImageSrcSet';
import Icon from '@bbb-app/core-ui/icon';
import PLPRelatedCategoriesFlyout from '../../components/PLPRelatedCategoriesFlyout/PLPRelatedCategoriesFlyout';
import TileButton from './Button';

export const showAlternateImageOnHover = (
  tileProps,
  e,
  srcSet,
  scene7imageID,
  selectedVariant,
  imageSrc
) => {
  const onlyDefaultImage = shouldRenderThumbnail(tileProps, selectedVariant);
  if (onlyDefaultImage) {
    return;
  }
  const url = scene7imageID
    ? `${getConcatenatedScene7URLWithImageURL(scene7imageID)}`
    : '';
  const element = e.target;
  /* istanbul ignore else */
  if (element) {
    element.src = generateSrcAttribute(url, imageSrc);
    element.srcset = generateSrcSetAttribute(url, srcSet);
  }
};

export const shouldRenderThumbnail = (tileProps, selectedVariant) => {
  const { channelType } = tileProps;
  const isMobile = channelType === 'MobileWeb';
  return isMobile || selectedVariant;
};

export const checkSiteSpectVariantRelatedCategories = () => {
  const PLP_RELATED_CATEGORIES_VARIANT = {
    'PLP-RELATED-CATEGORIES-1': true,
  };
  const PLP_RELATED_CATEGORIES_ENABLED = ['PLP-RELATED-CATEGORIES-1'];
  const relatedCatPLPSiteSpectVariants = {
    fallback: false,
    tests: PLP_RELATED_CATEGORIES_VARIANT,
  };
  const isrelatedCatPLPEnabled = getSiteSpectAssignment(
    null,
    relatedCatPLPSiteSpectVariants,
    false,
    PLP_RELATED_CATEGORIES_ENABLED
  );
  return isrelatedCatPLPEnabled;
};

export const getRelatedCategories = tileProps => {
  const {
    title,
    relatedCategoriesLabel,
    track,
    relatedCategories,
    DISPLAY_NAME,
    isGroupbyActive,
  } = tileProps;
  const isrelatedCatPLPEnabled = checkSiteSpectVariantRelatedCategories();
  if (
    isrelatedCatPLPEnabled &&
    Array.isArray(relatedCategories) &&
    relatedCategories.length > 0
  ) {
    return (
      <PLPRelatedCategoriesFlyout
        flyoutProps={relatedCategories}
        relatedCategoriesLabel={relatedCategoriesLabel}
        track={track}
        displayName={isGroupbyActive ? DISPLAY_NAME : title}
      />
    );
  }
  return null;
};

/* eslint-disable no-unused-vars */
/**
 * Helper component for IconButtons
 * @param {object} props props for the icon button
 * @param {string} props.className className attribute for the inner button
 * @param {string} props.tooltip tooltip text for the inner button
 * @param {function} props.onClick click handler of the inner button
 * @param {string} props.icon type attribute of the inner icon
 */
/* eslint-disable react/prop-types */
export const IconButton = ({ className, tooltip, onClick, icon }) => (
  <TileButton
    className={className}
    appearance="circular"
    tooltip={tooltip}
    onClick={onClick}
    aria-label={tooltip}
  >
    <Icon height="16px" type={icon} />
  </TileButton>
);
/**
 * Helper component for ActionButtons
 * @param {object} props props for the action button
 * @param {string} props.label label for the button
 * @param {string} props.theme style theme for the button
 * @param {string} props.variation style variation for the button
 * @param {function} props.onClick click handler of the button
 * @param {string} props.icon type attribute of the optional icon
 */
export const ActionButton = ({
  label,
  className,
  theme,
  variation,
  onClick,
  iconType,
  href,
  selectedItemIndex,
}) => {
  const iconProps =
    (iconType && {
      label,
      type: iconType,
      height: '16px',
    }) ||
    null;
  return (
    <Button
      className={className}
      theme={theme}
      variation={variation}
      onClick={onClick}
      iconProps={iconProps}
      href={href}
      selectedItemIndex={selectedItemIndex}
    >
      {label}
    </Button>
  );
};
