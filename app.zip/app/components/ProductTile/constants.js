import {
  BREAKPOINT_GRID_MIN_DESKTOP,
  BREAKPOINT_GRID_MIN_PHONE,
  BREAKPOINT_GRID_MIN_LG_PHONE,
  BREAKPOINT_GRID_MIN_TABLET,
} from '../../constants/breakpoints';
/**
 * Vertical offset for lazy loading option
 * max tile height (345 - iPhone 7 Plus) + padding (20)
 */
export const LAZY_LOAD_OFFSET = 1500;

/**
 * Number of tiles to bypass when applying lazy-load flag
 * in a collection iteration
 */
export const LAZY_LOAD_SKIP = 4;

/**
 * The <ProductTile /> <Price/> component accepts a max number of characters before the title font size decreases ,
 * this is that constant for max characters
 */
export const PRICE_MAX_CHARS = 27;

/**
 * The <Price/> component has conditions based on codes in the json response
 * these are those codes
 */
export const LABELCODE_WAS = 'WAS';
export const LABELCODE_ORIGINAL = 'ORIG';

export const NORMAL = 'NORMAL';
export const COLLECTION = 'COLLECTION';

export const ENABLE_COMPARE_KEY = 'enableProductComparison';

export const GLOBAL_SWITCH = 'Global';
export const PLP = 'PLP';
/**
 * The <PrimaryCta/> component has conditions based on codes in the json response
 * these are those codes
 */

export const CUSTOMIZABLE = 'Customization';
export const PERSONALIZABLE = 'Personalization';
export const LTL = 'attrib-ltl';
export const YES = 'Yes';

/* param to send to pdp for customize and personalize options*/
export const WITH_MODAL = 'personalize=true';
export const WITH_REVIEWS_DESKTOP = '#reviews';

/**
 * Breakpoints for Thumbnail Component
 * Used by Picture Component internally
 */

export const PRODUCT_TILE_BREAKPOINTS = [
  {
    defaultFallback: false,
    breakpoint: BREAKPOINT_GRID_MIN_DESKTOP,
    mediaquery: 'min-width',
    imageWidth: 260,
    imageHeight: 260,
    preset: '478',
    pixelRatios: [1, 1.5],
  },
  {
    defaultFallback: false,
    breakpoint: BREAKPOINT_GRID_MIN_TABLET,
    mediaquery: 'min-width',
    imageWidth: 215,
    imageHeight: 215,
    preset: '478',
    pixelRatios: [1, 1.5],
  },
  {
    defaultFallback: false,
    breakpoint: BREAKPOINT_GRID_MIN_PHONE,
    mediaquery: 'min-width',
    imageWidth: 151,
    imageHeight: 151,
    preset: '478',
    pixelRatios: [1, 1.5],
  },
];

export const PRODUCT_TILE_SINGLE_COL_BREAKPOINTS = [
  {
    defaultFallback: false,
    breakpoint: BREAKPOINT_GRID_MIN_LG_PHONE,
    mediaquery: 'min-width',
    imageWidth: 768,
    imageHeight: 768,
    preset: '478',
    pixelRatios: [1, 1.5],
  },
  {
    defaultFallback: false,
    breakpoint: BREAKPOINT_GRID_MIN_PHONE,
    mediaquery: 'min-width',
    imageWidth: 480,
    imageHeight: 480,
    preset: '478',
    pixelRatios: [1, 1.5],
  },
];

export const PRODUCT_TILE_TITLE = 'product_tile_title';
export const PRODUCT_TILE_IMAGE = 'product_tile_image';
export const PRODUCT_TILE_PRICE = 'product_tile_price';
export const PRODUCT_TILE_RATING = 'product_tile_rating';
export const ENABLE_ATC_BUTTON = 'enableATCButton';
export const SCENE7URL = 'https://b3h2.scene7.com/is/image/BedBathandBeyond/';
export const SDD_ATTRIBUTE = 'sddZip-';
