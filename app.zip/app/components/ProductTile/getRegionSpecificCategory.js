import { isEmpty, pathOr } from 'lodash/fp';

/** @return {array} returns the Array of Categories that are local
   * favorite for a category / search page, configured in CMS
   * @param {string} searchTerm Search Term if Search Page
   * @param {string} categoryId categoryId if PLP page
   * @param {object} contentData experience content Data
   */
export const getRegionSpecificCategories = (
  searchTerm,
  categoryId,
  contentData,
  maxLocalFavLimit
) => {
  let regionSpecificCategories = [];
  if (!isEmpty(searchTerm) && !isEmpty(contentData)) {
    regionSpecificCategories = pathOr(
      [],
      'visual_filter_region.components',
      contentData
    );
  }
  if (categoryId && !isEmpty(contentData)) {
    regionSpecificCategories = pathOr(
      [],
      `${categoryId}_visual_facet_region.components`,
      contentData
    );
  }
  return regionSpecificCategories.slice(0, maxLocalFavLimit);
};
