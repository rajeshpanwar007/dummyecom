import React from 'react';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { isBrowser } from '@bbb-app/utils/common';
import { addMark } from '@bbb-app/utils/mPulse';
import Instrumentation from '@bbb-app/core-ui/instrumentation';
import { RATING_MAX } from '@bbb-app/constants/searchConstants';
import ProductTile from './ProductTile';
import { LAZY_LOAD_SKIP } from './constants';

const onImgLoadFunc = () => {
  /* istanbul ignore else */
  if (isBrowser()) {
    addMark(
      'ux-primary-content-displayed',
      `ux-image-primary-content-prod-onload`
    );
  }
};

const imgBeforeLoadFunc = (items, currentIndex) => {
  /* istanbul ignore else */
  if (isBrowser()) {
    addMark(
      'ux-primary-content-displayed',
      `ux-text-prod${currentIndex}-price`
    );
    addMark(
      'ux-primary-content-displayed',
      `ux-text-prod${currentIndex}-rating`
    );
    addMark(
      'ux-primary-content-displayed',
      `ux-text-prod${currentIndex}-title`
    );
    if (isFirstRow(items, currentIndex)) {
      addMark(
        'ux-primary-content-displayed',
        `ux-image-primary-content-prod-inline`
      );
    }
  }
};

const isFirstRow = (totalItems, currentIndex) => {
  let firstRow = false;
  if (
    (totalItems > 4 && currentIndex === 3) ||
    (totalItems < 4 && currentIndex === totalItems - 1)
  )
    firstRow = true;
  return firstRow;
};

const getLabels = (item, labels, isGroupbyActive) => {
  const productTileLabels = {
    ratingTitle: LabelsUtil.getLabel(labels, 'productTile.ratingTitle', [
      item.rating,
      RATING_MAX,
    ]),
    internationalShippingRestrictedMsg: LabelsUtil.getLabel(
      labels,
      'productTile.internationalShippingRestrictedMsg'
    ),
    beyondPlusSubscriptionMessage: LabelsUtil.getLabel(
      labels,
      'productTile.beyondPlusSubscription'
    ),

    swatchOptions: LabelsUtil.getLabel(
      labels,
      'productTile.moreOptionsAvailable'
    ),
    chooseOptions: isGroupbyActive
      ? `${item.DISPLAY_NAME} ${LabelsUtil.getLabel(
          labels,
          'productTile.colorOptions'
        )}`
      : `${item.title} ${LabelsUtil.getLabel(
          labels,
          'productTile.colorOptions'
        )}`,
    shippingLabels: {
      someSkusFreeShippingMessage: LabelsUtil.getLabel(
        labels,
        'productTile.someSkusFreeShippingMessage'
      ),
      freeShippingMessage: LabelsUtil.getLabel(
        labels,
        'productTile.freeShippingMessage'
      ),
      eddPlpMessage: LabelsUtil.getLabel(labels, 'productTile.eddPlpMessage'),
    },
    priceLabels: {
      priceVariations: LabelsUtil.getLabel(
        labels,
        'productTile.priceVariations'
      ),
      was: LabelsUtil.getLabel(labels, 'productTile.priceWas'),
      discountedInCart: LabelsUtil.getLabel(
        labels,
        'productTile.discountedInCart'
      ),
      fullPriceInCart: LabelsUtil.getLabel(
        labels,
        'productTile.fullPriceInCart'
      ),
      pricetbd: LabelsUtil.getLabel(labels, 'productTile.priceTBD'),
      customizePrice: LabelsUtil.getLabel(labels, 'productTile.customizePrice'),
    },
    reviewsLabel: item.reviews
      ? LabelsUtil.replacePlaceholderValues(
          LabelsUtil.getLabel(labels, 'productTile.reviewsTitle'),
          [item.reviews]
        )
      : '',
    productNotAvailableLabel: LabelsUtil.getLabel(
      labels,
      'productTile.productNotAvailable'
    ),
    localFavoriteLabel: LabelsUtil.getLabel(
      labels,
      'productTile.localFavorite'
    ),
    minimumQtyLabels: {
      message: LabelsUtil.getLabel(
        labels,
        'productTile.minimumQuantityMessage',
        [item.minimumQuantity]
      ),
      tooltip: LabelsUtil.getLabel(
        labels,
        'productTile.minimumQuantityTooltip',
        [item.minimumQuantity]
      ),
      ariaLabel: LabelsUtil.getLabel(
        labels,
        'productTile.minimumQuantityAriaLabel',
        [item.minimumQuantity]
      ),
    },
    relatedCategoriesLabel: LabelsUtil.getLabel(
      labels,
      'productTile.relatedCategoriesLabel'
    ),
    bopusLabels: {
      available: LabelsUtil.getLabel(
        labels,
        'productTile.pickUpStoreAvailableLbl'
      ),
      ready: LabelsUtil.getLabel(labels, 'productTile.pickUpStoreReadyLbl'),
      notAvailable: LabelsUtil.getLabel(labels, 'productTile.notAvailable'),
    },
    shipTLabel: LabelsUtil.getLabel(labels, 'productTile.orderMsg'),
    shipTLabelTmrw: LabelsUtil.getLabel(labels, 'productTile.orderMsgTmrw'),

    shiptNotAvailable: LabelsUtil.getLabel(
      labels,
      'productTile.shiptNotAvailable'
    ),

    freeShipping: LabelsUtil.getLabel(labels, 'productTile.freeShipping'),
    shippingNotAvailable: LabelsUtil.getLabel(
      labels,
      'productTile.shippingNotAvailable'
    ),
    sddBopis: LabelsUtil.getLabel(labels, 'productTile.sddBopis'),
    notifyMeLabel: {
      stockNotificationLabel: LabelsUtil.getLabel(
        labels,
        'productTile.stockNotificationLabel'
      ),
      stockNotificationDescription: LabelsUtil.getLabel(
        labels,
        'productTile.stockNotificationDescription'
      ),
      customMessage: LabelsUtil.getLabel(labels, 'productTile.customMessage'),
      nameLabel: LabelsUtil.getLabel(labels, 'productTile.nameLabel'),
      emailLabel: LabelsUtil.getLabel(labels, 'productTile.emailLabel'),
      confirmEmailLabel: LabelsUtil.getLabel(
        labels,
        'productTile.confirmEmailLabel'
      ),
      cancelButton: LabelsUtil.getLabel(labels, 'productTile.cancelButton'),
      submitButton: LabelsUtil.getLabel(labels, 'productTile.submitButton'),
      OOSEmailSuccessHeading: LabelsUtil.getLabel(
        labels,
        'productTile.OOSEmailSuccessHeading'
      ),
      OOSEmailSuccessContent: LabelsUtil.getLabel(
        labels,
        'productTile.OOSEmailSuccessContent'
      ),
      OOSEmailSuccessInStore: LabelsUtil.getLabel(
        labels,
        'productTile.OOSEmailSuccessInStore'
      ),
    },
  };
  return productTileLabels;
};

export const renderProductTile = (item, index, itemProps) => {
  const {
    tileActions,
    dynamicPrice,
    contextPath,
    categoryId,
    searchTerm,
    labels,
    writeReview,
    reviews,
    lazyLoad,
    channelType,
    profileHasRegistries,
    switchConfig,
    pageConfig,
    sddOptions,
    isAvailableInStore,
    isGridView,
    isCollegePage,
    isBrandPage,
    items,
    imageSrcSet,
    sizes,
    srcSet,
    imageSrc,
    filterSize,
    productCompareData,
    isInternationalUser,
    anchorToProductIdOnPLP,
    setProductIdForAnchor,
    resetProductIdAfterAnchor,
    isMobileOnly,
    filterColor,
    isPNHPLP,
    storeId,
    data,
    location,
    selectedPnhList,
    showOutOfStockMsg,
    oosProductTileLabel,
    setPlpEddLoaded,
    isPlpEddLoaded,
    sddOptionSelected,
    isPlpEddExperimentOn,
    isPlpMobileExperiment,
    searchPipeline,
    storeDetails,
    isStoreAvailable,
    isSizePricePLP,
    specificAvailabilityMsgLabel,
    isStoreTempUnavailable,
    isTbs,
    isATRModalHide,
    onPickupInStoreButtonClick,
    isNearbyStoresTestActive,
    storeName,
    navigationViewportSize,
    nearestStores,
    isSddEligible,
    route,
    sddMarketData,
    isShiptSdd,
    bopisMsg,
    isGroupbyActive,
    runClickTracker,
    pageIdentifier,
    clickTracker,
    impressionTracker,
    sponsored,
    PromoteIQprice,
    isClientMetricsCookie,
    isShopInStore,
    storeAvailability,
    disableSddCheckBox,
    bpData,
    scene7UrlConfig,
    formWrapperData,
  } = itemProps;
  const tileLabels = getLabels(item, labels, isGroupbyActive);

  // SW-3598
  const oosMessageProps = {
    showOutOfStockMsg,
    oosProductTileLabel,
    specificAvailabilityMsgLabel,
  };

  return (
    <React.Fragment>
      <ProductTile
        {...item}
        badge={item.badge}
        actions={tileActions}
        filterSize={filterSize}
        contextPath={contextPath}
        bopisSavingMsg={bopisMsg}
        categoryId={categoryId && categoryId[categoryId.length - 1]}
        searchTerm={searchTerm}
        writeReview={writeReview}
        reviewsLink={reviews}
        itemIndex={index}
        isUnavailable={
          item.price
            ? item.price.lowValue === 0 || item.price.lowValue === undefined
            : false
        }
        rating={item.rating ? item.rating / RATING_MAX : null}
        RATINGS={item.RATINGS ? item.RATINGS / RATING_MAX : null}
        profileHasRegistries={profileHasRegistries}
        channelType={channelType}
        navigationViewportSize={navigationViewportSize}
        switchConfig={switchConfig}
        pageConfig={pageConfig}
        sddOptions={sddOptions}
        isAvailableInStore={isAvailableInStore}
        isGridView={isGridView}
        isCollegePage={isCollegePage}
        isBrandPage={isBrandPage}
        ratingTitle={tileLabels.ratingTitle}
        swatchOptions={tileLabels.swatchOptions}
        shippingLabels={tileLabels.shippingLabels}
        priceLabels={tileLabels.priceLabels}
        reviewsLabel={tileLabels.reviewsLabel}
        sddOptionSelected={sddOptionSelected}
        chooseOptionsLabel={tileLabels.chooseOptions}
        internationalShippingRestrictedMsg={
          tileLabels.internationalShippingRestrictedMsg
        }
        productNotAvailableLabel={tileLabels.productNotAvailableLabel}
        localFavoriteLabel={tileLabels.localFavoriteLabel}
        beyondPlusSubscriptionMessage={tileLabels.beyondPlusSubscriptionMessage}
        lazyLoad={lazyLoad || index >= LAZY_LOAD_SKIP}
        dynamicPrice={dynamicPrice}
        imgBeforeLoad={index < 4 ? imgBeforeLoadFunc(items, index) : null}
        titleMark={
          isFirstRow(items, index) && (
            <Instrumentation
              markName={'ux-text-prod-title'}
              zoneName={'ux-primary-action-available'}
            />
          )
        }
        gridMark={
          isFirstRow(items, index) && (
            <Instrumentation
              markName={'ux-text-product-grid'}
              zoneName={'ux-primary-action-available'}
            />
          )
        }
        isLTL={item.isLTL}
        imageSrcSet={imageSrcSet}
        sizes={sizes}
        srcSet={srcSet}
        imageSrc={imageSrc}
        onImgLoad={isFirstRow(items, index) ? onImgLoadFunc() : null}
        productCompareData={productCompareData}
        isMobileOnly={isMobileOnly}
        intlRestricted={item.intlRestricted && isInternationalUser}
        isInternationalUser={isInternationalUser}
        anchorToProductIdOnPLP={anchorToProductIdOnPLP}
        setProductIdForAnchor={setProductIdForAnchor}
        resetProductIdAfterAnchor={resetProductIdAfterAnchor}
        filterColor={filterColor}
        minimumQtyLabels={tileLabels.minimumQtyLabels}
        isPNHPLP={isPNHPLP}
        storeId={storeId}
        contentData={data}
        relatedCategoriesLabel={tileLabels.relatedCategoriesLabel}
        selectedPnhList={selectedPnhList}
        {...oosMessageProps}
        location={location}
        setPlpEddLoaded={setPlpEddLoaded}
        isPlpEddLoaded={isPlpEddLoaded}
        isPlpEddExperimentOn={isPlpEddExperimentOn}
        isPlpMobileExperiment={isPlpMobileExperiment}
        searchPipeline={searchPipeline}
        bopusLabels={tileLabels.bopusLabels}
        storeDetails={storeDetails}
        isStoreAvailable={isStoreAvailable}
        isSizePricePLP={isSizePricePLP}
        isStoreTempUnavailable={isStoreTempUnavailable}
        isTbs={isTbs}
        isATRModalHide={isATRModalHide}
        onPickupInStoreButtonClick={onPickupInStoreButtonClick}
        isNearbyStoresTestActive={isNearbyStoresTestActive}
        storeName={storeName}
        isSddEligible={isSddEligible}
        nearestStores={nearestStores}
        route={route}
        sddMarketData={sddMarketData}
        isShiptSdd={isShiptSdd}
        shipTLabel={tileLabels.shipTLabel}
        shipTLabelTmrw={tileLabels.shipTLabelTmrw}
        isGroupbyActive={isGroupbyActive}
        runClickTracker={runClickTracker}
        pageIdentifier={pageIdentifier}
        clickTracker={clickTracker}
        impressionTracker={impressionTracker}
        sponsored={sponsored}
        PromoteIQprice={PromoteIQprice}
        isClientMetricsCookie={isClientMetricsCookie}
        isShopInStore={isShopInStore}
        storeAvailability={storeAvailability}
        disableSddCheckBox={disableSddCheckBox}
        bpData={bpData}
        shippingNotAvailable={tileLabels.shippingNotAvailable}
        sddBopis={tileLabels.sddBopis}
        freeShipping={tileLabels.freeShipping}
        shiptNotAvailable={tileLabels.shiptNotAvailable}
        notifyMeLabel={tileLabels.notifyMeLabel}
        scene7UrlConfig={scene7UrlConfig}
        formWrapperData={formWrapperData}
      />
    </React.Fragment>
  );
};
