export { default } from './ProductTile';
