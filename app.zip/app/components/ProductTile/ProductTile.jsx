/* eslint max-lines: ["error", 3000]*/
import React, { PureComponent } from 'react';
import classnames from 'classnames';
import { get, uniqueId, isEmpty, isArray, findIndex } from 'lodash';
import { orderBy, kebabCase } from 'lodash/fp';
import { stringify } from 'qs';
import getOr from 'lodash/fp/getOr';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import truncate from '@bbb-app/utils/truncate';
import Card from '@bbb-app/core-ui/card';
import { isSDDTimeUp } from '@bbb-app/utils/isSDDTimeUp';
import setPdpTransitionData from '@bbb-app/utils/setPdpTransitionData';
import {
  isBrowser,
  decodeHtmlEntities,
  unescape,
  isBedBathCanada,
} from '@bbb-app/utils/common';
import LazyLoad from '@bbb-app/core-ui/lazy-load';
import Button from '@bbb-app/core-ui/button';
import Icon from '@bbb-app/core-ui/icon/Icon';
import { withSiteSpectTracker } from '@bbb-app/site-spect/Experiment';
import getConcatenatedScene7URLWithImageURL from '@bbb-app/utils/getConcatenatedScene7URLWithImageURL';
import sanitizeSearchTerm from '@bbb-app/utils/sanitizeSearchTerm';
import { LocalStorageUtil } from '@bbb-app/utils/localStorage';
import { getBadgeConfig } from '@bbb-app/utils/getBadgeConfig';
import PrimaryLinkContainer from '@bbb-app/plp-primary-link/containers/PrimaryLink';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import {
  CLICK_IMAGE,
  CLICK_TITLE,
  CLICK_REVIEWS,
} from '@bbb-app/plp-primary-link/containers/constants';
import Rating from '@bbb-app/rating/Rating';
import { PRODUCT_IMAGE_PLACEHOLDER } from '@bbb-app/constants/appConstants';
import '@bbb-app/assets/icons/checkmarkgreen.svg';
import '@bbb-app/assets/icons/helpIcon.svg';
import { shouldAttributeRender } from '@bbb-app/utils/sddUtils';
import '../../assets/icons/cross.svg';
import styles from './ProductTile.inline.css';
import stylesProductTile from './ProductTile.css';
import propTypes, { defaultProps } from './props';
import isMultiSkufunc from '../../utils/isMultiSku';
import getRollupCode from '../../utils/getRollupCode';
import SwatchMenu from '../common/SwatchMenu';
import PrimaryCta from '../../containers/Pages/Category/PrimaryCta/PrimaryCta.async';
import Price from './Price';
import Thumbnail from '../Thumbnail';
import AddToIdeaboard from '../../containers/AddToIdeaboard/AddToIdeaboard.async';
import stylesPrice from '../ProductTile/Price/Price.css';
import {
  LAZY_LOAD_OFFSET,
  PRICE_MAX_CHARS,
  NORMAL,
  COLLECTION,
  PERSONALIZABLE,
  CUSTOMIZABLE,
  YES,
  WITH_REVIEWS_DESKTOP,
  PRODUCT_TILE_BREAKPOINTS,
  PRODUCT_TILE_SINGLE_COL_BREAKPOINTS,
  PRODUCT_TILE_TITLE,
  PRODUCT_TILE_IMAGE,
  PRODUCT_TILE_PRICE,
  PRODUCT_TILE_RATING,
  ENABLE_COMPARE_KEY,
  ENABLE_ATC_BUTTON,
  SDD_ATTRIBUTE,
} from './constants';
import {
  GLOBAL_SWITCH,
  SDD_GLOBAL_FEATURE_FLAG,
} from '../../containers/SDD/constants';
import { ATTRIBUTE_LIMIT } from '../../constants/search';
import CompareButton from '../../containers/Pages/Compare/CompareButton/CompareButton.async';
import OutOfStock from '../Pages/PDP/ProductDetails/Components/OutOfStock/OutOfStock.async';
import {
  getRelatedCategories,
  showAlternateImageOnHover,
  ActionButton,
} from './ExtendedProductTile';
import MinimumQuantityMessage from '../common/MinimumQuantityMessage/MinimumQuantityMessage';
import { getRegionSpecificCategories } from './getRegionSpecificCategory';
import PLPEDDMessaging from '../../containers/abtests/PLPEDDMessagesExperiment/PLPEDDMessaging/PLPEDDMessaging.async';
import FreeShippingAttribute from '../common/FreeShippingAttribute/FreeShippingAttribute';
import FindStoreLink from '../common/FindStoreLink/FindStoreLink.async';
import FindStoreLinkPLP from '../abtests/FindStoreLinkPLP/FindStoreLinkPLP';
import { parseNearestStoresFromLocation } from '../../utils/parseNearestStores';
import ClientMetrics from '../PreviewMetrics/ClientMetrics.async';

const lazyLoadOptions = {
  offset: LAZY_LOAD_OFFSET,
  placeholder: PRODUCT_IMAGE_PLACEHOLDER,
};

/* eslint-enable react/prop-types */
class ProductTile extends PureComponent {
  static propTypes = propTypes;
  static defaultProps = defaultProps;
  constructor(props) {
    super(props);
    this.state = {
      variantIndex: -1, // varientIndex is the currently selected swatch
      productListUpdated: false,
      isClient: false,
      setDataForTransition: {
        price: '',
        productVariation: '',
        skuId: '',
        isUnavailable: '',
        rating: '',
        reviews: '',
        imgSelector: '',
        productId: '',
        productTitle: '',
        rollupTypeCode: '',
        isLTL: false,
        scene7imageUrl: '',
        // beyondPlusPrice: '',
      },
      swatchChange: false,
    };
    const {
      rollupTypeCode,
      collectionFlag,
      categoryId,
      isSkuCreated,
      searchTerm,
      switchConfig,
      eligibleCustomizationDescrip,
      customizationOfferedFlag,
      isCollegePage,
      isBrandPage,
      inventoryStatus,
      ROLLUP_TYPE_CODE,
      COLLECTION_FLAG,
      CUSTOMIZATION_OFFERED_FLAG,
    } = this.props;
    const currentCollectionFlag = this.groupByProp(
      COLLECTION_FLAG,
      collectionFlag
    );
    const isCollection =
      currentCollectionFlag && currentCollectionFlag.toString() === '1';
    const customizationFlag = this.groupByProp(
      CUSTOMIZATION_OFFERED_FLAG,
      customizationOfferedFlag
    );
    this.isCustomizable =
      !isCollection &&
      !isEmpty(eligibleCustomizationDescrip) &&
      eligibleCustomizationDescrip.includes(CUSTOMIZABLE) &&
      customizationFlag &&
      customizationFlag.includes(YES);
    this.isPersonalizable =
      !isCollection &&
      !isEmpty(eligibleCustomizationDescrip) &&
      eligibleCustomizationDescrip.includes(PERSONALIZABLE) &&
      customizationFlag &&
      customizationFlag.includes(YES);
    this.tileTitleId = uniqueId('tileTitleId');
    this.cardAriaAttr = {
      role: 'region',
      'aria-describedby': this.tileTitleId,
    };
    this.isSkuCreated = getRollupCode(
      this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode),
      this.groupByProp(COLLECTION_FLAG, collectionFlag)
    );
    this.href = this.getProductUrl({
      categoryId,
      isSkuCreated,
      searchTerm,
      isCollegePage,
      isBrandPage,
    });
    this.hasCompare = pathOr(
      false,
      `${GLOBAL_SWITCH}.${ENABLE_COMPARE_KEY}`,
      switchConfig
    );
    this.localStorageUtil = new LocalStorageUtil(isBrowser());
    this.updateState = this.updateState.bind(this);
    this.pushReference = this.pushReference.bind(this);
    this.onQuickViewButtonClick = this.onQuickViewButtonClick.bind(this);
    this.renderProductPrice = this.renderProductPrice.bind(this);
    this.OOS = inventoryStatus && inventoryStatus !== 'Positive';
    this.delayProcess = undefined;
  }
  componentDidMount() {
    const {
      itemIndex,
      productId,
      price,
      isUnavailable,
      rating,
      reviews,
      skuId,
      title,
      rollupTypeCode,
      productVariation,
      isLtlFlag,
      customizationOfferedFlag,
      collectionFlag,
      scene7imageUrl,
      searchPipeline,
      DISPLAY_NAME,
      ROLLUP_TYPE_CODE,
      COLLECTION_FLAG,
      PRODUCT_ID,
      CUSTOMIZATION_OFFERED_FLAG,
      LTL_FLAG,
      PRODUCT_VARIATION,
      RATINGS,
      REVIEWS,
      SKU_ID,
      BEYOND_PLUS_FLAG,
      BEYOND_PLUS_PRICE_RANGE_STR,
    } = this.props;
    const customFlag = this.groupByProp(
      CUSTOMIZATION_OFFERED_FLAG,
      customizationOfferedFlag
    );
    const customizationFlag =
      Array.isArray(customFlag) && customFlag[0] === 'Yes' ? 'true' : 'false';
    const prodVariation = this.groupByProp(PRODUCT_VARIATION, productVariation);

    let priceNormal = '';
    if (price) {
      const { normal, IS_PRICE } = price;
      priceNormal = this.groupByProp(IS_PRICE, normal);
    }

    const sku = this.groupByProp(SKU_ID, skuId);
    // eslint-disable-next-line react/no-did-mount-set-state
    this.setState({
      isClient: true,
      setDataForTransition: {
        price: priceNormal,
        beyondPlusPrice: BEYOND_PLUS_FLAG ? BEYOND_PLUS_PRICE_RANGE_STR : null,
        productVariation:
          typeof prodVariation !== 'undefined' ? prodVariation : 'NORMAL',
        skuId: sku ? sku[0] : null,
        isUnavailable,
        rating: Math.round(this.groupByProp(RATINGS, rating) * 79) || 0,
        reviews: this.groupByProp(REVIEWS, reviews),
        imgSelector: `a[itemindexfromplp="${itemIndex}"] div img`,
        productId: this.groupByProp(PRODUCT_ID, productId),
        productTitle: this.groupByProp(DISPLAY_NAME, title),
        rollupTypeCode: this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode),
        isLtlFlag: this.groupByProp(LTL_FLAG, isLtlFlag),
        customizationFlag,
        collectionFlag: this.groupByProp(COLLECTION_FLAG, collectionFlag),
        scene7imageUrl,
      },
    });
    this.selectVariant(searchPipeline);
  }
  componentWillReceiveProps(nextProps) {
    const { anchorToProductIdOnPLP } = nextProps;
    const prodId = this.groupByProp(nextProps.PRODUCT_ID, nextProps.productId);
    if (anchorToProductIdOnPLP && anchorToProductIdOnPLP === prodId) {
      const anchorElement = document.getElementById(anchorToProductIdOnPLP);
      if (this.delayProcess !== undefined) {
        clearTimeout(this.delayProcess);
      }
      /* istanbul ignore next */
      this.delayProcess = setTimeoutCustom(() => {
        anchorElement.scrollIntoView(false);
        this.props.resetProductIdAfterAnchor();
      }, 0);
      this.selectVariant(this.props.searchPipeline);
    }
  }
  componentWillUnmount() {
    clearTimeout(this.delayProcess);
  }

  onQuickViewButtonClick = compare => {
    let color = null;
    let skuId = null;
    let scene7ID = null;
    let size = null;
    const {
      selectedColor,
      searchPipeline,
      nearestStoreAvailabilty,
      sponsored,
      runClickTracker,
      clickTracker,
      isGroupbyActive,
      color: colorSelected,
      skuSize,
      skuSelected,
    } = this.props;
    if (typeof runClickTracker === 'function' && sponsored)
      runClickTracker(clickTracker);
    if (isGroupbyActive) {
      if (colorSelected) color = colorSelected;
      if (skuSize) size = kebabCase(skuSize).toUpperCase();
      if (skuSelected) skuId = skuSelected;
    } else if (
      searchPipeline === 's8' &&
      selectedColor &&
      !this.state.swatchChange
    ) {
      color = selectedColor;
    } else if (this.selectedVariant) {
      if (this.isSkuCreated) {
        color = this.selectedVariant.label;
        scene7ID = this.selectedVariant.swatchScene7ID;
      } else {
        color = this.selectedVariant.label;
        skuId = this.selectedVariant.skuId;
        scene7ID = this.selectedVariant.swatchScene7ID;
      }
      size = pathOr(false, 'props.filterSize', this);
    }
    const collectionFlag = this.groupByProp(
      this.props.COLLECTION_FLAG,
      this.props.collectionFlag
    );
    const productVariation =
      collectionFlag && collectionFlag.toString() === '0' ? NORMAL : COLLECTION;
    if (productVariation === NORMAL) {
      setPdpTransitionData(this.state.setDataForTransition, 'quickViewMode');
    }
    const swatchDetails = {
      color,
      skuId,
      scene7ID,
      size,
    };
    const prodId = this.groupByProp(
      this.props.PRODUCT_ID,
      this.props.productId
    );
    this.props.actions.quickView.handler(
      prodId,
      productVariation,
      this.props.url,
      null,
      swatchDetails,
      this.props.itemIndex,
      compare === 'productCompare',
      nearestStoreAvailabilty,
      '',
      '',
      sponsored
    );
  };

  onColorSizeClick = e => {
    e.preventDefault();
    const swatchDetails = {};
    const {
      skuSize,
      color,
      skuSelected,
      collectionFlag,
      COLLECTION_FLAG,
      nearestStoreAvailabilty,
      productId,
      PRODUCT_ID,
    } = this.props;
    if (skuSize) swatchDetails.size = skuSize;
    if (color) swatchDetails.color = color;
    if (skuSelected) swatchDetails.skuId = skuSelected;
    const collection = this.groupByProp(COLLECTION_FLAG, collectionFlag);
    const productVariation =
      collection && collection.toString() === '0' ? NORMAL : COLLECTION;
    this.props.actions.chooseOptions.handler(
      this.groupByProp(PRODUCT_ID, productId),
      productVariation,
      this.props.url,
      null,
      swatchDetails,
      this.props.itemIndex,
      '',
      nearestStoreAvailabilty,
      true,
      ''
    );
  };

  /* istanbul ignore next: global dependency */
  getDangerouslyLoadedImg(title, srcInfo) {
    let url =
      this.state.variantIndex === -1
        ? this.props.scene7imageUrl ||
          getConcatenatedScene7URLWithImageURL(this.props.scene7imageID)
        : getConcatenatedScene7URLWithImageURL(this.currentImage);
    url = url || '';
    const src = srcInfo.preset
      ? `${url}?$${srcInfo.preset}$&wid=${srcInfo.width}&hei=${srcInfo.height}`
      : `${url}?wid=${srcInfo.width}&hei=${srcInfo.height}`;
    const imageMarkUp = `<img
    class='hide'
    alt=${JSON.stringify(decodeHtmlEntities(title))}
    src=${JSON.stringify(src)}
    onLoad={instrumentingLoadingMark('ux-primary-content-displayed','ux-image-primary-content-prod-onload')}
  /><script>instrumentingLoadingMark('ux-primary-content-displayed','ux-image-primary-content-prod-inline')</script>`;
    const DangerousText = dangerousHTML(DangerousText);
    return <DangerousText>{imageMarkUp}</DangerousText>;
  }
  getFreeShippingAttribute(listKey, label) {
    return (
      <p
        key={listKey}
        className={classnames(styles.attribute, 'fol', 'my0')}
        tabIndex={0}
      >
        <FreeShippingAttribute
          freeShippingLabel={label}
          inventoryStatus={this.props.inventoryStatus}
          isTbs={this.props.isTbs}
        />
      </p>
    );
  }
  getStoreFlag = () => {
    const nearestStoresFromUrl = parseNearestStoresFromLocation(
      this.props.route.locationBeforeTransitions
    );
    return this.props.isStoreAvailable || nearestStoresFromUrl;
  };

  getIcon = iconFlag => {
    if (iconFlag === true || iconFlag === 'Positive')
      return (
        <Icon
          className={styles.getIcon}
          width="10px"
          height="10px"
          type="checkmarkgreen"
        />
      );
    return (
      <Icon
        className={styles.getIcon}
        width="10px"
        height="10px"
        type="cross"
      />
    );
  };

  getSddBopisAttribute = DangerousText => {
    const {
      availableInStore,
      sddEligibleFlag,
      sddBopis,
      isShiptSdd,
      isShopInStore,
      sddOptionSelected,
      storeAvailability,
    } = this.props;
    const sddBopisCheck = !availableInStore && !sddEligibleFlag;
    return sddBopisCheck &&
      !isShiptSdd &&
      !isShopInStore &&
      !sddOptionSelected &&
      !storeAvailability ? (
      <p
        key={-1}
        className={classnames(styles.attribute, 'fol', 'my0')}
        tabIndex={0}
      >
        {this.getIcon(!sddBopisCheck)}
        <DangerousText className={stylesProductTile.bopus}>
          {sddBopis}
        </DangerousText>
      </p>
    ) : null;
  };

  getBopusAttributes(labelObj, DangerousText, href) {
    const {
      storeDetails,
      availableInStore,
      nearestStoreAvailabilty,
      nearestStores,
      bopusLabels,
      isShiptSdd,
      storeId,
      scene7imageID,
      DISPLAY_NAME,
      PRODUCT_ID,
      SKU_ID,
      ROLLUP_TYPE_CODE,
      COLLECTION_FLAG,
    } = this.props;
    const selectedProduct = {
      DISPLAY_NAME,
      SKU_SCENE7_URL: scene7imageID,
      PRODUCT_ID,
      STORES: [storeId],
    };
    let storeName = storeDetails.commonName || storeDetails.city;
    const isMultiSku = isMultiSkufunc(ROLLUP_TYPE_CODE, COLLECTION_FLAG);
    const selectedSku = SKU_ID && SKU_ID.length === 1 && SKU_ID[0];
    const storeFlag = availableInStore || nearestStoreAvailabilty;
    const label = storeFlag ? labelObj.ready : labelObj.available;
    if (!availableInStore) {
      if (nearestStoreAvailabilty && nearestStores && nearestStores.length) {
        nearestStores.forEach(store => {
          if (nearestStoreAvailabilty === store.storeId)
            storeName = store.storeName;
        });
      }
    }
    let message = null;
    if (storeFlag) {
      message = (
        <React.Fragment>
          {this.getIcon(storeFlag)}
          <DangerousText className={stylesProductTile.bopus}>
            {LabelsUtil.replacePlaceholderValues(label, [storeName])}
          </DangerousText>
        </React.Fragment>
      );
    } else if (!isShiptSdd && !isMultiSku && selectedSku && !availableInStore) {
      message = (
        <React.Fragment>
          {this.getIcon(availableInStore)}
          <DangerousText className={stylesProductTile.bopus}>
            {LabelsUtil.replacePlaceholderValues(bopusLabels.notAvailable, [
              storeName,
            ])}
          </DangerousText>
          {this.getFindInStoreLink(
            this.props,
            'Check other stores',
            selectedProduct,
            selectedSku,
            'link'
          )}
        </React.Fragment>
      );
    } else if (!isShiptSdd && isMultiSku && !availableInStore) {
      message = (
        <React.Fragment>
          {this.getIcon(availableInStore)}
          <DangerousText className={stylesProductTile.bopus}>
            {LabelsUtil.replacePlaceholderValues(bopusLabels.notAvailable, [
              storeName,
            ])}
          </DangerousText>
          {this.getChooseOptionModal(href)}
        </React.Fragment>
      );
    }
    return message ? (
      <p
        key={-1}
        className={classnames(styles.attribute, 'fol', 'my0')}
        tabIndex={0}
      >
        {message}
      </p>
    ) : null;
  }

  getSDDAttributes = DangerousText => {
    const {
      shipTLabel,
      sddMarketData,
      switchConfig,
      shipTLabelTmrw,
      disableSddCheckBox,
      isShiptSdd,
      sddEligibleFlag,
      shiptNotAvailable,
      availableInStore,
    } = this.props;
    let displayCutOffTime;
    let displayGetByTime;
    let sddAttributeLabel;
    let sddFlag;
    const isDynamicSDDTimer = pathOr(
      false,
      'Global.enableDynamicSddMessage',
      switchConfig
    );

    if (sddMarketData && sddMarketData.marketData) {
      displayCutOffTime = sddMarketData.marketData.displayCutOffTime;
      displayGetByTime = sddMarketData.marketData.displayGetByTime;
      sddFlag = sddMarketData.marketData.sddFlag;
    }
    const isSDDTodayAvailable =
      displayCutOffTime && !isSDDTimeUp(displayCutOffTime);
    if (isDynamicSDDTimer && availableInStore) {
      sddAttributeLabel = isSDDTodayAvailable ? shipTLabel : shipTLabelTmrw;
    }
    if (!isDynamicSDDTimer && availableInStore) {
      sddAttributeLabel = shipTLabel;
    }
    if (!sddEligibleFlag && availableInStore) {
      sddAttributeLabel = shiptNotAvailable;
    }

    return (
      <React.Fragment>
        {!this.props.isShopInStore &&
        (!this.props.storeAvailability || isShiptSdd) &&
        !disableSddCheckBox &&
        sddFlag &&
        displayCutOffTime &&
        !this.props.notAvailableForSDD &&
        availableInStore ? (
          <p
            key={-1}
            className={classnames(styles.attribute, 'fol', 'my0')}
            tabIndex={0}
          >
            {this.getIcon(sddEligibleFlag)}
            <DangerousText className={stylesProductTile.bopus}>
              {LabelsUtil.replacePlaceholderValues(sddAttributeLabel, [
                displayCutOffTime,
                displayGetByTime,
              ])}
            </DangerousText>
          </p>
        ) : null}
      </React.Fragment>
    );
  };

  getProductUrl({
    categoryId,
    isSkuCreated,
    searchTerm,
    isCollegePage,
    isBrandPage,
    filterSize,
    isShiptSdd,
    isShopInStore,
  }) {
    const {
      selectedColor,
      nearestStoreAvailabilty,
      color,
      skuSize,
      isGroupbyActive,
      skuSelected,
    } = this.props;
    const href = `${this.props.contextPath}${this.props.url}`;
    let queryString = href;
    const keyword = sanitizeSearchTerm(searchTerm);
    /* istanbul ignore else */
    if (isBrandPage && categoryId) {
      queryString = `${href}?brandId=${categoryId}`;
    } else if (categoryId) {
      queryString = `${href}?categoryId=${categoryId}`;
    } else if (keyword) {
      queryString = `${href}?keyword=${keyword}`;
    }

    if (isGroupbyActive) {
      const obj = {};
      if (color) obj.color = color;
      if (skuSize) obj.size = kebabCase(skuSize).toUpperCase();
      if (skuSelected) obj.skuId = skuSelected;
      if (!isEmpty(obj)) {
        queryString += `&${stringify(obj, { sort: false })}`;
      }
    } else {
      if (selectedColor && !this.state.swatchChange) {
        queryString += `&${stringify(
          {
            color: selectedColor,
          },
          { sort: false }
        )}`;
      } else if (this.selectedVariant) {
        if (isSkuCreated) {
          queryString += `&${stringify(
            {
              color: this.selectedVariant.label,
            },
            { sort: false }
          )}`;
        } else {
          queryString += `&${stringify(
            {
              color: this.selectedVariant.label,
              skuId: this.selectedVariant.skuId,
            },
            { sort: false }
          )}`;
        }
      }
      if (filterSize) {
        queryString += `&${stringify(
          {
            size: filterSize,
          },
          { sort: false }
        )}`;
      }
    }

    // SHOP-21507: Also append query param on regular PLPs with checkboxes checked
    const pathname = pathOr(
      '',
      'locationBeforeTransitions.location.pathname',
      this.props.route
    );
    const sddShipt = pathOr(false, 'Global.sddShipt', this.props.switchConfig);
    const shopInLocalStore = pathOr(
      false,
      'Global.shopInLocalStore',
      this.props.switchConfig
    );

    /* istanbul ignore else */
    if (isCollegePage) {
      queryString += `&fromCollege=true`;
    }
    if (nearestStoreAvailabilty)
      queryString += `&nearestStore=${nearestStoreAvailabilty}`;
    if (isShiptSdd || (sddShipt && pathname.includes(SDD_ATTRIBUTE)))
      queryString += '&sdd=true';
    if (isShopInStore || (shopInLocalStore && pathname.match(/store-[0-9]+/g)))
      queryString += '&pickup=true';
    return `${queryString}`;
  }
  getSwatchImage() {
    // Get the swatch image id when the color filter is selected.Setting the index of the swatch in the state
    let imageID = '';
    let count = 0;
    let changeIndex = -1;
    const { filterColor, variants } = this.props;
    if (filterColor && variants.length > 0) {
      const orderedVariants = orderBy('label', 'asc', variants);
      orderedVariants.forEach((varient, index) => {
        // checks if the swatch and color group is same as filterColor
        const { colorGroup, label, swatchScene7ID } = varient;
        if (
          (filterColor === colorGroup.toLowerCase() &&
            filterColor === label.toLowerCase()) ||
          (filterColor === colorGroup.toLowerCase() && count === 0)
        ) {
          imageID = swatchScene7ID;
          changeIndex = index;
          count += 1;
        }
      });
    }
    if (changeIndex !== -1 && this.state.variantIndex === -1) {
      this.handleSwatchChange(changeIndex);
    }
    return imageID;
  }

  getSkuIdForIdeaboard() {
    let skuId = '';
    if (this.selectedVariant && !this.isSkuCreated) {
      skuId = this.selectedVariant.skuId;
    }
    return skuId;
  }

  getChooseOptionModal(href) {
    return (
      <div className={styles.findInstoreCta}>
        <Button
          className={styles.fontsize}
          theme="link"
          onClick={this.onColorSizeClick}
          href={href}
        >
          Check other stores
        </Button>
      </div>
    );
  }

  getFindInStoreLink(props, labels, selectedProduct, skuSelected, theme) {
    const { onPickupInStoreButtonClick } = props;
    const selectedSKU = {
      skuId: skuSelected,
    };
    return (
      <div className={styles.findInstoreCta}>
        <FindStoreLink
          variation="fullWidth"
          theme={theme}
          type="bold"
          isPdpTrue
          className={classnames(
            styles.fontsize,
            theme !== 'link' && 'fullWidth'
          )}
          selectedProduct={selectedProduct}
          selectedSKU={selectedSKU}
          onPickupInStoreButtonClick={onPickupInStoreButtonClick}
          viewType={'PDP'}
          skuDetail={selectedSKU}
        >
          {labels}
        </FindStoreLink>
      </div>
    );
  }

  isOutOfStock = () => {
    const {
      notifyMeLabel,
      onPickupInStoreButtonClick,
      inventoryStatus,
      scene7UrlConfig,
      availableInStore,
      sddEligibleFlag,
      formWrapperData,
      DISPLAY_NAME,
      RATINGS,
      REVIEWS,
      SEO_URL,
      SCENE7_URL,
      price,
      normal,
      WAS_PRICE_RANGE_STRING,
    } = this.props;
    const isOutOfStock = isBedBathCanada()
      ? inventoryStatus !== 'Positive' && !availableInStore
      : inventoryStatus !== 'Positive' && !availableInStore && !sddEligibleFlag;
    const showNotifyFlag = isOutOfStock;

    const selectedProduct = {
      WAS_PRICE:
        price && price.pricingLabelCode === null
          ? null
          : WAS_PRICE_RANGE_STRING,
      IS_PRICE: price && price.isPriceRangeStr ? price.isPriceRangeStr : normal,
      PRICING_LABEL_CODE:
        price && price.pricingLabelCode ? price.pricingLabelCode : '',
      DISPLAY_NAME,
      RATINGS,
      REVIEWS,
      SEO_URL,
      SKU_DISPLAY_NAME: DISPLAY_NAME,
      SCENE7_URL,
    };
    const reviews = '#reviews';

    return isOutOfStock ? (
      <OutOfStock
        isOutOfStock={isOutOfStock}
        showNotifyFlag={showNotifyFlag}
        labels={notifyMeLabel}
        scene7UrlConfig={scene7UrlConfig}
        selectedProduct={selectedProduct}
        formWrapperData={formWrapperData}
        findInStoreHandler={onPickupInStoreButtonClick}
        getIcon={isOutOfStock}
        endpoints={reviews}
      />
    ) : null;
  };

  newFreeShippingAttribute = DangerousText => {
    let freeShippingLabel;
    const {
      inventoryStatus,
      isShiptSdd,
      isShopInStore,
      sddOptionSelected,
      storeAvailability,
      shippingNotAvailable,
      freeShipping,
    } = this.props;
    if (inventoryStatus === 'Positive') {
      freeShippingLabel = freeShipping;
    } else freeShippingLabel = shippingNotAvailable;

    return (
      <React.Fragment>
        {!isShiptSdd &&
        !isShopInStore &&
        !sddOptionSelected &&
        !storeAvailability ? (
          <p
            key={-1}
            className={classnames(styles.attribute, 'fol', 'my0')}
            tabIndex={0}
          >
            {this.getIcon(inventoryStatus)}
            <DangerousText className={stylesProductTile.bopus}>
              {freeShippingLabel}
            </DangerousText>
          </p>
        ) : null}
      </React.Fragment>
    );
  };

  groupByProp = (groupByKey, solrKey) => {
    return this.props.isGroupbyActive || this.props.sponsored
      ? groupByKey
      : solrKey;
  };

  selectVariant = searchPipeline => {
    if (searchPipeline === 's8') {
      const { selectedColor, variants } = this.props;
      const orderedVariants = orderBy('label', 'asc', variants);
      let changeIndex = -1;
      orderedVariants.forEach((varient, index) => {
        // checks if the swatch and color group is same as filterColor
        if (selectedColor === varient.label) {
          changeIndex = index;
        }
      });
      if (selectedColor && changeIndex !== -1) {
        this.handleSwatchChange(changeIndex);
      }
    }
  };
  pushReference(href) {
    const { runClickTracker, sponsored, PRODUCT_ID, productId } = this.props;
    this.props.setProductIdForAnchor(this.groupByProp(PRODUCT_ID, productId));
    if (typeof runClickTracker === 'function' && sponsored)
      runClickTracker(this.props.clickTracker, href);
  }
  /**
   * This function check and add the intl restriction message to the message list
   *
   * @param {string} list list to which intl restriction message needs to be added if applicable
   * @param {string} internationalShippingRestrictedMsg
   * @param {boolean} intlRestricted if product is internationally restricted
   */
  checkAndUpdateIntlRestrictedMessage(
    list,
    internationalShippingRestrictedMsg,
    intlRestricted
  ) {
    /* istanbul ignore else */
    if (intlRestricted && internationalShippingRestrictedMsg) {
      list.push(
        <p
          key="intlRestricted"
          className={classnames(
            styles.attribute,
            styles.IntlRestrictedMsg,
            'fol',
            'my0'
          )}
          tabIndex={0}
        >
          {internationalShippingRestrictedMsg}
        </p>
      );
    }
    return list;
  }
  updateState = data => {
    if (data.isCollection) {
      this.onQuickViewButtonClick('productCompare');
    } else {
      this.setState(data);
    }
  };
  /**
   * Gets the selected variant
   * @returns {object} object with all data for the selected variant
   */
  get selectedVariant() {
    // variants are ordered by swatch color names
    const orderedVariants = orderBy('label', 'asc', this.props.variants);
    return orderedVariants[this.state.variantIndex];
  }
  /**
   * @returns {string} scene7ID of the selected swatch image
   */
  get currentImage() {
    return get(this.selectedVariant, 'swatchScene7ID');
  }
  /**
   * Gets the truncated product title to be a maximum of 100 characters
   * @returns {string} product title truncated
   */
  get displayTitle() {
    return truncate(
      this.groupByProp(this.props.DISPLAY_NAME, this.props.title),
      100
    );
  }
  /**
   * Updates the state when a new swatch is selected
   */
  handleSwatchChange = (index, swatchChangeFlag) => {
    this.setState({
      variantIndex: index,
      swatchChange: swatchChangeFlag,
    });
  };
  findInAttributes = attribute => {
    // finds data in attributes response
    const { attributes } = this.props;
    return isArray(attributes)
      ? attributes.find(({ text }) => text && text.indexOf(attribute) > -1)
      : false;
  };

  reorderAttributes = (label, list = []) => {
    const { switchConfig, isAvailableInStore } = this.props;
    let newList = [];
    // return list as is if free shipping is the last one in the list
    /* istanbul ignore else */
    if (get(list, [list.length - 1, 'props', 'children']) === label) {
      return list;
    }
    // if not, push the free shipping attribute to end of list
    const freeShipping = list.filter(attr => {
      return get(attr, ['props', 'children']) === label;
    });
    newList = list.filter(attr => {
      return (
        (attr.props && !attr.props.children) || attr.props.children !== label
      );
    });
    /* istanbul ignore else  */
    if (
      freeShipping.length &&
      (!this.props.isStoreAvailable ||
        !(
          pathOr(true, 'PLP.enableBopusAttributes', switchConfig) &&
          isAvailableInStore
        ))
    ) {
      newList.push(freeShipping);
    }
    if (
      pathOr(false, 'Global.enableBopusSavingEvent', switchConfig) &&
      this.props.availableInStore &&
      this.props.bopisSavingMsg
    ) {
      newList = newList.filter(el => el.key !== 'singleFreeShippingMessage');
    }
    // prioritize bopus attribute on store selection.
    if (
      pathOr(true, 'PLP.enableBopusAttributes', switchConfig) &&
      !pathOr(false, 'Global.enableBopusSavingEvent', switchConfig) &&
      isAvailableInStore &&
      !this.props.bopisSavingMsg
    ) {
      return newList.sort(sList => sList.key);
    }
    return newList;
  };

  configDrivenAttributes = (bopusLabels, list, href) => {
    const {
      storeDetails,
      isShiptSdd,
      sddOptionSelected,
      pageConfig,
      switchConfig,
      isAvailableInStore,
    } = this.props;
    const DangerousText = dangerousHTML(DangerousText);
    const newList = list;
    const attributesOrder = pathOr(
      `SHIPPING,BOPIS,SDD`,
      'PLP.attributesOrder',
      pageConfig
    );
    const freeShippingAttribute = this.newFreeShippingAttribute(DangerousText);
    const bopusAttribute = this.getBopusAttributes(
      bopusLabels,
      DangerousText,
      href
    );
    const SddAttribute = this.getSDDAttributes(DangerousText);
    const sddBopisAttribute = this.getSddBopisAttribute(DangerousText);
    if (freeShippingAttribute && sddBopisAttribute !== null) {
      if (
        pathOr(true, 'PLP.enableNewShippingAttribute', switchConfig) &&
        !isAvailableInStore
      ) {
        newList.push(freeShippingAttribute, sddBopisAttribute);
      }
    } else {
      attributesOrder.split(',').map(item => {
        if (item === 'SHIPPING') {
          if (
            pathOr(true, 'PLP.enableNewShippingAttribute', switchConfig) &&
            !isAvailableInStore
          ) {
            newList.push(freeShippingAttribute);
          }
        }
        if (item === 'BOPIS') {
          if (
            this.getStoreFlag() &&
            pathOr(true, 'PLP.enableBopusAttributes', switchConfig) &&
            !isEmpty(storeDetails) &&
            !isShiptSdd &&
            !sddOptionSelected &&
            bopusAttribute !== null
          ) {
            newList.push(bopusAttribute);
          }
        } else if (item === 'SDD') {
          if (SddAttribute !== null) return newList.push(SddAttribute);
        }
        return newList;
      });
    }
    return newList;
  };

  /**
   * check if attributes is supposed to render free shipping label if it hasn't yet
   * and skip over current attribute if it does not have free shipping label
   */
  checkAttributesForShipping = (
    attributes,
    freeShippingLabel,
    renderedFreeShipping
  ) => {
    /* istanbul ignore else */
    if (!renderedFreeShipping) {
      return (
        isEmpty(freeShippingLabel) &&
        attributes.find(attr => attr.freeShippingLabel)
      );
    }
    return false;
  };

  checkActiveBadges = (attribute, badge) => {
    const { ProductBadging } = this.props.switchConfig;
    const globalProductBadgingFlag = pathOr(
      false,
      `enableProductBadge`,
      ProductBadging
    );
    const badgeConfig = badge ? getBadgeConfig(badge) : null;
    const isBadgeKeyEnable = pathOr(true, [badgeConfig], ProductBadging);
    if (globalProductBadgingFlag && badge === attribute && isBadgeKeyEnable)
      return true;
    return false;
  };

  conditionalClickableWrapper = (children, href, itemIndex, isClickableTile) =>
    isClickableTile ? (
      <section
        className={classnames(stylesProductTile.noDecoration, {
          [stylesProductTile.displyFlexRow]: this.props.isMobileOnly,
        })}
      >
        <PrimaryLinkContainer
          onClick={this.pushReference}
          href={href}
          itemIndexFromPLP={itemIndex}
          elementClicked={CLICK_IMAGE}
          setDataForTransition={this.state.setDataForTransition}
          useDefaultClass={!isClickableTile}
          onlyDirectClick={isClickableTile}
        >
          {children}
        </PrimaryLinkContainer>
      </section>
    ) : (
      children
    );

  IsComingSoon() {
    const { attributes } = this.props;
    const isComingSoon = (attributes || []).some(attr => {
      const skuAttributeId = pathOr('', 'skuAttributeId', attr);
      return skuAttributeId === '1_215';
    });
    return isComingSoon;
  }
  /**
   * Returning the no. of swatches to show in count button according to desktop amd mobile
   * For desktop , we are showing 8 colored swatches and others will go in  + count btn
   * For Mobile , we are showing 6 colored swatches and others will go in  + count btn
   * @param {*} variants
   * @param {*} href
   * @param {*} isMobile
   */
  swatchCount(variants, href, swatchCount) {
    const { isGroupbyActive } = this.props;

    const variantsToShow =
      variants.length > swatchCount ? variants.length - swatchCount : '';
    if (isGroupbyActive) {
      return (
        <span
          aria-label={`${variantsToShow} more color swatch`}
        >{`+ ${variantsToShow}`}</span>
      );
    }
    return (
      <React.Fragment>
        <PrimaryLinkContainer
          onClick={this.pushReference}
          href={href}
          itemIndexFromPLP={this.props.itemIndex}
          setDataForTransition={this.state.setDataForTransition}
          data-locator="color-swatch-PDP"
          className={stylesProductTile.swatchText}
          aria-label={`${variantsToShow} more color swatch`}
        >
          {`+`}
          {variantsToShow}
        </PrimaryLinkContainer>
      </React.Fragment>
    );
  }
  productNotAvailable = (isUnavailable, productNotAvailableLabel) => {
    return (
      <React.Fragment>
        {isUnavailable && (
          <div className={classnames(styles.productNotAvailable, 'mb2')}>
            {productNotAvailableLabel}
          </div>
        )}
      </React.Fragment>
    );
  };

  renderCouponMsg = (isCouponExcluded, couponInEligibleMsg) => {
    return isCouponExcluded ? (
      <p
        className={classnames(
          styles.attribute,
          styles.excludeCouponMargin,
          'fol',
          'my0'
        )}
        tabIndex={0}
      >
        {this.props.actions.excludedCouponLabel.label}
        <Button
          data-tooltip={couponInEligibleMsg}
          theme="ghost"
          variation="noPadding"
          iconProps={{
            type: 'helpIcon',
            height: '12px',
            width: '12px',
          }}
          className={classnames('ml1', 'tooltip-top', styles.tooltip)}
        />
      </p>
    ) : (
      ''
    );
  };

  // eslint-disable-next-line max-params
  renderPlaceHolderMinQtyPrimaryCta = (
    isSSDPLP,
    switchConfig,
    isMultiSku,
    isUnavailable,
    isMobile,
    href,
    intlRestricted
  ) => {
    const { inventoryStatus, availableInStore, sddEligibleFlag } = this.props;
    const isOutOfStock = isBedBathCanada()
      ? inventoryStatus !== 'Positive' && !availableInStore
      : inventoryStatus !== 'Positive' && !availableInStore && !sddEligibleFlag;
    return (
      <React.Fragment>
        {pathOr(false, 'Global.enableMinimumQuantity', switchConfig) &&
          !isMultiSku &&
          this.renderMinimuQtyMessage()}
        {pathOr(true, 'PLP.productTilePrimaryCTA', switchConfig) &&
          !isUnavailable &&
          !isOutOfStock &&
          this.renderPrimaryCta(isMobile, href, intlRestricted)}
      </React.Fragment>
    );
  };
  // eslint-disable-next-line max-params
  renderFindStorePLP = (
    isNearbyStoresTestActive,
    isShiptSdd,
    PRODUCT_ID,
    productId,
    scene7imageID,
    SKU_ID,
    skuId,
    availableInStore,
    onPickupInStoreButtonClick,
    PRODUCT_VARIATION,
    productVariation,
    track,
    storeName,
    ROLLUP_TYPE_CODE,
    rollupTypeCode
  ) => {
    return (
      <React.Fragment>
        {isNearbyStoresTestActive &&
          !isShiptSdd && (
            <FindStoreLinkPLP
              productId={this.groupByProp(PRODUCT_ID, productId)}
              scene7imageID={scene7imageID}
              skuId={this.groupByProp(SKU_ID, skuId)}
              availableInStore={availableInStore}
              onPickupInStoreButtonClick={onPickupInStoreButtonClick}
              productVariation={this.groupByProp(
                PRODUCT_VARIATION,
                productVariation
              )}
              displayTitle={this.displayTitle}
              isLTL={this.state.isLTL}
              track={track}
              storeName={storeName}
              rollupTypeCode={this.groupByProp(
                ROLLUP_TYPE_CODE,
                rollupTypeCode
              )}
            />
          )}
      </React.Fragment>
    );
  };
  // eslint-disable-next-line max-params
  renderAttributeAccordion = (
    isPlpMobileExperiment,
    isMobileOnly,
    renderSwatchSS,
    switchConfig,
    isGridView,
    variants,
    isMobile,
    actions,
    href,
    intlRestricted,
    swatchOptions,
    PRODUCT_ID,
    productId,
    chooseOptionsLabel,
    COLLECTION_FLAG,
    collectionFlag,
    url
  ) => {
    return (
      <React.Fragment>
        {pathOr(true, 'PLP.productTileColorSwatches', switchConfig) &&
          this.renderSwatch({
            variants,
            isMobile,
            actions,
            href,
            intlRestricted,
            swatchOptions,
            productId: this.groupByProp(PRODUCT_ID, productId),
            chooseOptionsLabel,
            collectionFlag: this.groupByProp(COLLECTION_FLAG, collectionFlag),
            url,
          })}

        {this.renderProductPrice()}
        {this.isOutOfStock()}
        {/* two pass rendering for fixing hydrate issue on SSR */}
        {this.state.isClient &&
          pathOr(true, 'PLP.productTileAttributes', switchConfig) &&
          this.renderAttributes(href)}
        {!this.state.isClient &&
          pathOr(true, 'PLP.productTileAttributes', switchConfig) &&
          this.renderAttributes(href)}
      </React.Fragment>
    );
  };

  renderRegularPrice = () => {
    const {
      isUnavailable,
      price,
      inCart,
      dynamicPrice,
      priceLabels,
      inCartMX,
      isSizePricePLP,
      sponsored,
      PromoteIQprice,
      isGroupbyActive,
      variants,
      sizeCount,
    } = this.props;
    const promoteIQPrice = sponsored && PromoteIQprice;
    const priceObj = promoteIQPrice || price;
    return (
      <Price
        className={
          inCart
            ? classnames(styles.price, styles.discountPrice)
            : classnames(styles.price)
        }
        {...priceObj}
        inCart={inCart}
        dynamicPrice={dynamicPrice}
        priceLabels={priceLabels}
        maxChars={PRICE_MAX_CHARS}
        isCustomizable
        isPersonalizable={this.isPersonalizable}
        dataLocator={PRODUCT_TILE_PRICE}
        isUnavailable={isUnavailable}
        inCartMX={inCartMX}
        isSizePricePLP={isSizePricePLP}
        onProductTile
        isMobileOnly
        isGroupbyActive={isGroupbyActive}
        variants={variants}
        sizeCount={sizeCount}
      />
    );
  };

  renderBeyondPlusPrice = () => {
    const { BEYOND_PLUS_PRICE_RANGE_STR, price } = this.props;
    return (
      <React.Fragment>
        <div className={classnames(styles.priceText, 'mt025')}>
          BEYOND+ MEMBER PRICE
        </div>
        <span className={classnames(styles.beyondPrice)}>
          {!isEmpty(price.BEYOND_PLUS_PRICE_SKU)
            ? price.BEYOND_PLUS_PRICE_SKU
            : BEYOND_PLUS_PRICE_RANGE_STR}
        </span>
      </React.Fragment>
    );
  };
  renderProductPrice = () => {
    const {
      isUnavailable,
      beyondPlusProductCheck,
      beyondPlusSubscriptionMessage,
      switchConfig,
      noWrap,
      BEYOND_PLUS_FLAG,
      inCart,
      COUPON_INELIGIBILITY_FLAG,
      COUPON_INELIGIBILITY_MESSAGE,
      bpData,
    } = this.props;
    const wrapStyle = noWrap ? stylesPrice.singleline : stylesPrice.multiline;
    const beyondPlusPrice = pathOr(
      false,
      'PLP.enableBeyondPlusPrice',
      switchConfig
    );
    const isBeyondPlusMember = bpData === 'A';
    const isCouponExcluded =
      pathOr(false, 'PLP.enableCouponExclusion', switchConfig) &&
      (COUPON_INELIGIBILITY_FLAG === true ||
        COUPON_INELIGIBILITY_FLAG === 'true');
    if (beyondPlusPrice) {
      if (!isBeyondPlusMember && BEYOND_PLUS_FLAG && !inCart) {
        return (
          <React.Fragment>
            <div
              className={classnames(styles.priceText, 'md-mb0 md-mt0 sm-mb1')}
            >
              NON-MEMBER PRICE
            </div>
            {this.renderRegularPrice()}
            {this.renderCouponMsg(
              isCouponExcluded,
              COUPON_INELIGIBILITY_MESSAGE
            )}
            {BEYOND_PLUS_FLAG && this.renderBeyondPlusPrice()}
          </React.Fragment>
        );
      } else if (isBeyondPlusMember && BEYOND_PLUS_FLAG && !inCart) {
        return (
          <React.Fragment>
            {BEYOND_PLUS_FLAG && this.renderBeyondPlusPrice()}
            {this.renderCouponMsg(
              isCouponExcluded,
              COUPON_INELIGIBILITY_MESSAGE
            )}
          </React.Fragment>
        );
      } else if (isBeyondPlusMember && inCart) {
        return (
          <React.Fragment>
            <div className={classnames(styles.priceText, 'mt025')}>
              BEYOND+ MEMBER PRICE
            </div>
            {this.renderRegularPrice()}
          </React.Fragment>
        );
      }
      return (
        <React.Fragment>
          {this.renderRegularPrice()}
          {this.renderCouponMsg(isCouponExcluded, COUPON_INELIGIBILITY_MESSAGE)}
        </React.Fragment>
      );
    }
    return (
      !isUnavailable &&
      (String(beyondPlusProductCheck) !== '1' ? (
        <React.Fragment>
          {this.renderRegularPrice()}
          {this.renderCouponMsg(isCouponExcluded, COUPON_INELIGIBILITY_MESSAGE)}
        </React.Fragment>
      ) : (
        <span
          className={classnames(wrapStyle, stylesPrice.beyondPlusFontStyle)}
          tabIndex="0"
        >
          {decodeHtmlEntities(beyondPlusSubscriptionMessage)}
        </span>
      ))
    );
  };
  // eslint-disable-next-line max-params
  renderTitle = (
    switchConfig,
    isPlpMobileExperiment,
    isMobileOnly,
    DISPLAY_NAME,
    title,
    itemIndex,
    href,
    titleMark
  ) => {
    return (
      <React.Fragment>
        {pathOr(true, 'PLP.productTileTitle', switchConfig) && (
          <div
            className={classnames(
              `tealium-product-title`,
              {
                mobilePLPTileSS: isPlpMobileExperiment && isMobileOnly,
              },
              !isEmpty(this.props.badge) && isMobileOnly
                ? [styles.titlePLPBadge]
                : [styles.titlePLP]
            )}
            title={decodeHtmlEntities(this.groupByProp(DISPLAY_NAME, title))}
            id={this.tileTitleId}
            data-locator={PRODUCT_TILE_TITLE}
            index={itemIndex}
          >
            <PrimaryLinkContainer
              onClick={this.pushReference}
              href={href}
              itemIndexFromPLP={itemIndex}
              elementClicked={CLICK_TITLE}
              setDataForTransition={this.state.setDataForTransition}
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{
                __html: this.displayTitle,
              }}
            />
            {titleMark}
          </div>
        )}
      </React.Fragment>
    );
  };

  // eslint-disable-next-line max-params
  renderRating = (
    switchConfig,
    review,
    href,
    isMobile,
    itemIndex,
    RATINGS,
    rating,
    ratingTitle,
    reviewsLabel
  ) => {
    return (
      <React.Fragment>
        {pathOr(true, 'PLP.productTileRating', switchConfig) &&
          review > 0 && (
            <PrimaryLinkContainer
              href={`${href}${WITH_REVIEWS_DESKTOP}`}
              itemIndexFromPLP={itemIndex}
              elementClicked={CLICK_REVIEWS}
              className={classnames(styles.ratingReview, 'fol')}
              setDataForTransition={this.state.setDataForTransition}
            >
              <Rating
                className={styles.rating}
                total={review}
                value={this.groupByProp(RATINGS, rating)}
                title={ratingTitle}
                reviewsLabel={reviewsLabel}
                dataLocator={PRODUCT_TILE_RATING}
                isNavigable={false}
              />
            </PrimaryLinkContainer>
          )}
      </React.Fragment>
    );
  };
  /**
   * Returning Swatch Count
   */
  renderSwatchCount = (variants, href, swatchCount) => {
    const { isGroupbyActive } = this.props;
    return (
      <React.Fragment>
        <span
          id="colorswatch"
          aria-label="colorswatch-submit"
          className={classnames({
            [stylesProductTile.swatchColor]: !isGroupbyActive,
            [stylesProductTile.swatchGroupBy]: isGroupbyActive,
          })}
        >
          {this.swatchCount(variants, href, swatchCount)}
        </span>
      </React.Fragment>
    );
  };
  renderColorAndSize = (
    variants,
    productId,
    chooseOptionsLabel,
    href,
    intlRestricted
  ) => {
    const {
      skuSize,
      isGroupbyActive,
      sizeCount,
      color,
      DISPLAY_NAME,
      title,
    } = this.props;
    let variantsObj = variants;
    let labelToBeAdded = `Color and Size Selection`;
    if (color) {
      variantsObj = variants.filter(elem => elem.label === color);
      labelToBeAdded += `: Selected option is ${color}`;
    }
    if (skuSize && color) {
      labelToBeAdded += ` and ${skuSize}`;
    }
    if (skuSize && !color) {
      labelToBeAdded += `: Selected option is ${skuSize}`;
    }
    let swatchCount = 5;
    if (sizeCount && sizeCount > 1) swatchCount = 2;
    return (
      <LazyLoad threshold={100}>
        <div className={classnames(stylesProductTile.container)}>
          {(variants && variants.length) || sizeCount > 1 ? (
            <a
              className={classnames(stylesProductTile.renderDropdown)}
              onClick={this.onColorSizeClick}
              href={href}
              aria-label={labelToBeAdded}
            >
              <span className={classnames(stylesProductTile.dropdownIcon)}>
                <Icon
                  type="caret"
                  height="8px"
                  width="16px"
                  focusable="false"
                />
              </span>
              <span>
                <SwatchMenu
                  className={styles.swatches}
                  items={variantsObj}
                  intlRestricted={intlRestricted}
                  name={`product_${productId}_swatches`}
                  chooseOptionsLabel={chooseOptionsLabel}
                  onProductTile
                  href={href}
                  renderSwatchCount={this.renderSwatchCount}
                  isGroupbyActive={isGroupbyActive}
                  skuSize={skuSize}
                  sizeCount={sizeCount}
                  color={color}
                  productTitle={this.groupByProp(DISPLAY_NAME, title)}
                  swatchCount={swatchCount}
                />
              </span>
            </a>
          ) : null}
          <div className={classnames(stylesProductTile.cb)} />
        </div>
      </LazyLoad>
    );
  };

  /**
   * render the Swatch component depending on isMobile
   * if there are more than 16 swatches, render "more options available" button
   */
  renderSwatch({
    variants,
    isMobile,
    actions,
    intlRestricted,
    productId,
    chooseOptionsLabel,
    href,
  }) {
    const { isGroupbyActive } = this.props;
    if (isGroupbyActive)
      return this.renderColorAndSize(
        variants,
        productId,
        chooseOptionsLabel,
        href,
        intlRestricted
      );
    return (
      <React.Fragment>
        {variants.length > 0 &&
          !isMobile && (
            <LazyLoad threshold={100}>
              <SwatchMenu
                className={styles.swatches}
                items={variants}
                intlRestricted={intlRestricted}
                actions={actions}
                selectedIndex={this.state.variantIndex}
                onChange={this.handleSwatchChange}
                name={`product_${productId}_swatches`}
                chooseOptionsLabel={chooseOptionsLabel}
                isClickableTile={isMobile}
                onProductTile
                renderSwatchCount={this.renderSwatchCount}
                href={href}
              />
            </LazyLoad>
          )}
        {variants.length > 0 &&
          isMobile && (
            <LazyLoad threshold={100}>
              <SwatchMenu
                className={styles.swatches}
                items={variants}
                intlRestricted={intlRestricted}
                actions={actions}
                selectedIndex={this.state.variantIndex}
                onChange={this.handleSwatchChange}
                name={`product_${productId}_swatches`}
                chooseOptionsLabel={chooseOptionsLabel}
                isMobile={isMobile}
                onProductTile
                renderSwatchCount={this.renderSwatchCount}
                href={href}
              />
            </LazyLoad>
          )}
      </React.Fragment>
    );
  }

  renderEDDMessage(defaultFreeShippingMessage, listkey) {
    const {
      setPlpEddLoaded,
      isPlpEddLoaded,
      productId,
      shippingLabels,
      PRODUCT_ID,
    } = this.props;
    return (
      <LazyLoad
        threshold={300}
        placeholder={
          <React.Fragment>{defaultFreeShippingMessage}</React.Fragment>
        }
      >
        <PLPEDDMessaging
          productId={this.groupByProp(PRODUCT_ID, productId)}
          isPlpEddLoaded={isPlpEddLoaded}
          setPlpEddLoaded={setPlpEddLoaded}
          defaultFreeShippingMessage={defaultFreeShippingMessage}
          listKey={listkey}
          shippingLabels={shippingLabels}
          onAfter={({ isSync, isMount }) => {
            if (!isSync && isMount) {
              setPlpEddLoaded(true);
            }
          }}
        />
      </LazyLoad>
    );
  }
  /* eslint complexity: ["error", 29]*/
  renderAttributes(href, getShippingAttr = false) {
    const {
      attributes: attrProps,
      variants,
      shippingLabels,
      sddOptions = [],
      switchConfig,
      intlRestricted,
      internationalShippingRestrictedMsg,
      isInternationalUser,
      isPlpEddExperimentOn,
      badge,
      isAvailableInStore,
      bopusLabels,
      isStoreAvailable,
      isSddEligible,
      isShiptSdd,
    } = this.props;
    const attributes = attrProps || [];
    const sddGlobalFeatureFlag = pathOr(
      false,
      `${GLOBAL_SWITCH}.${SDD_GLOBAL_FEATURE_FLAG}`,
      switchConfig
    );
    const needAttributesRendered = attributes.length > 0 || variants.length > 0;
    if (needAttributesRendered) {
      let attributesList = [];
      let attributeCount = 0;
      let freeShipping = '';
      let renderedFreeShipping = false;
      if (
        pathOr(false, 'Global.enableBopusSavingEvent', switchConfig) &&
        this.props.availableInStore &&
        this.props.bopisSavingMsg
      ) {
        const bopisEventMsg = (
          <p
            key={-1}
            className={classnames(styles.attribute, 'fol my0')}
            tabIndex={0}
          >
            <span> {this.props.bopisSavingMsg} </span>
          </p>
        );
        attributesList.push(bopisEventMsg);
      }

      for (let i = 0, len = attributes.length; i < len; i += 1) {
        const {
          text,
          freeShippingLabel,
          skuAttributeId,
          intlFlag,
          key,
        } = attributes[i];
        /* istanbul ignore else */
        if (
          attributeCount === ATTRIBUTE_LIMIT - 1 &&
          !this.props.isInternationalUser &&
          this.checkAttributesForShipping(
            attributes,
            freeShippingLabel,
            renderedFreeShipping
          )
        ) {
          /* eslint no-continue:0 */
          continue;
        }
        /* istanbul ignore else */
        if (attributeCount === ATTRIBUTE_LIMIT) {
          break;
        }
        const renderAttribute = shouldAttributeRender(
          skuAttributeId,
          sddGlobalFeatureFlag,
          sddOptions,
          isSddEligible,
          isShiptSdd
        );
        const listKey = skuAttributeId || key || i;
        const attributeRender = !!(
          renderAttribute &&
          (!this.props.isInternationalUser || intlFlag !== 'N')
        );

        /* istanbul ignore else */
        if (!isEmpty(freeShippingLabel)) {
          // if label isn't available or if international user, return nothing
          const isLabel = getOr(null, freeShippingLabel, shippingLabels);
          /* istanbul ignore else */
          if (!isInternationalUser && isLabel !== null) {
            // the string passed via attributes is the placeholder, not the label
            const shippingLabel = LabelsUtil.getLabel(
              shippingLabels,
              freeShippingLabel
            );
            const label = LabelsUtil.replacePlaceholderValues(text, [
              shippingLabel,
            ]);
            freeShipping = label;
            attributeCount += 1;

            if (getShippingAttr && this.props.isPlpMobileExperiment) {
              return this.getFreeShippingAttribute(listKey, label);
            }

            if (
              this.props.isPlpMobileExperiment &&
              (!this.props.isGridView || !this.props.isMobileOnly)
            ) {
              // will push rest of attributes into []
              attributesList.push(
                this.getFreeShippingAttribute(listKey, label)
              );
            }
            if (
              !this.props.isPlpMobileExperiment &&
              isPlpEddExperimentOn &&
              (!isStoreAvailable ||
                !(
                  pathOr(true, 'PLP.enableBopusAttributes', switchConfig) &&
                  isAvailableInStore
                ))
            ) {
              // render control
              attributesList.push(
                this.getFreeShippingAttribute(listKey, label)
              );
            } else if (isPlpEddExperimentOn && !isAvailableInStore) {
              // render EDD test case
              attributesList.push(
                <React.Fragment>
                  {this.renderEDDMessage(
                    this.getFreeShippingAttribute(listKey, label),
                    listKey
                  )}
                </React.Fragment>
              );
            }
            renderedFreeShipping = true;
          }
        } else if (attributeRender && text) {
          if (!this.checkActiveBadges(text, badge)) {
            attributeCount += 1;
            attributesList.push(
              <p
                key={listKey}
                className={classnames(styles.attribute, 'my0', {
                  targetAccordionAttrSS:
                    this.props.isPlpMobileExperiment && this.props.isMobileOnly,
                })}
                /**
                 * This is required because the product annotations coming
                 * from the API response contain HTML markup. Once that
                 * data is cleanup and we get back pure text instead,
                 * this should be changed to output just {text}.
                 */
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{
                  __html: text,
                }}
                tabIndex={0}
              />
            );
          }
        }
      }

      attributesList = this.checkAndUpdateIntlRestrictedMessage(
        attributesList,
        internationalShippingRestrictedMsg,
        intlRestricted
      );
      let list = attributesList;
      if (freeShipping) {
        list = this.reorderAttributes(freeShipping, attributesList);
      }
      const isOutOfStock = this.isOutOfStock();
      if (isOutOfStock === null) {
        list = this.configDrivenAttributes(bopusLabels, list, href);
      }
      return (
        <div
          className={
            this.props.isMobileOnly ? styles.attributesMob : styles.attributes
          }
        >
          {list}
        </div>
      );
    } else if (intlRestricted) {
      return (
        <div
          className={
            this.props.isMobileOnly ? styles.attributesMob : styles.attributes
          }
        >
          {this.checkAndUpdateIntlRestrictedMessage(
            [],
            internationalShippingRestrictedMsg,
            intlRestricted
          )}
        </div>
      );
    }
    return null;
  }
  renderLocalFavorite = () => {
    const {
      brand,
      localFavoriteLabel,
      searchTerm,
      categoryId,
      contentData,
      pageConfig,
    } = this.props;
    const maxLocalFavLimit = pathOr(3, 'PLP.maxLocalFavLimit', pageConfig);
    const regionSpecificCategories = getRegionSpecificCategories(
      searchTerm,
      categoryId,
      contentData,
      maxLocalFavLimit
    );
    const brandValArray = findIndex(regionSpecificCategories, visualFacet => {
      const brandName = new RegExp(
        pathOr('', 'cta.linkText', visualFacet),
        'i'
      );
      return brandName.test(brand ? unescape(brand) : brand);
    });
    if (brandValArray > -1) {
      return (
        <span className={stylesProductTile.localFavorite}>
          {localFavoriteLabel}
        </span>
      );
    }
    return null;
  };
  renderMinimuQtyMessage = () => {
    const minimumQuantity = this.props.minimumQuantity || 0;
    const message = pathOr('', 'minimumQtyLabels.message', this.props);
    const tooltip = pathOr('', 'minimumQtyLabels.tooltip', this.props);
    const ariaLabel = pathOr('', 'minimumQtyLabels.ariaLabel', this.props);
    return (
      <MinimumQuantityMessage
        minimumQtyThreshold={minimumQuantity}
        message={message}
        tooltipMessage={tooltip}
        className={styles.minimumQtyMessage}
        ariaLabel={ariaLabel}
      />
    );
  };
  /**
   * Render the Primary CTA
   */
  renderPrimaryCta = (isMobile, href, intlRestricted) => {
    const {
      actions,
      collectionFlag,
      productId,
      profileHasRegistries,
      rollupTypeCode,
      isAvailableInStore,
      url,
      image,
      itemIndex,
      isUnavailable,
      isInternationalUser,
      switchConfig,
      skuId,
      title,
      price,
      scene7imageID,
      filterSize,
      pageConfig,
      isPNHPLP,
      storeId,
      selectedPnhList,
      location,
      isATRModalHide,
      nearestStoreAvailabilty,
      isShiptSdd,
      DISPLAY_NAME,
      ROLLUP_TYPE_CODE,
      COLLECTION_FLAG,
      PRODUCT_ID,
      SKU_ID,
      pageIdentifier,
      sponsored,
      runClickTracker,
      clickTracker,
      isGroupbyActive,
      color,
      skuSize,
      skuSelected,
      storeAvailability,
      notAvailableWithStore,
      storeInventoryStatus,
      isShopInStore,
      onPickupInStoreButtonClick,
    } = this.props;
    /* miniQuickViewMode flag to diffrenciate the common flow of quick view and choose option */
    const isMultiSku = isMultiSkufunc(
      this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode),
      this.groupByProp(COLLECTION_FLAG, collectionFlag)
    );
    const miniQuickViewMode = !!isMultiSku;
    const selectedVariant = this.selectedVariant;
    const priceLow = pathOr(undefined, 'low', price);
    let priceNormal = '';
    if (price) {
      const { normal, IS_PRICE } = price;
      priceNormal = this.groupByProp(IS_PRICE || normal, normal);
    }
    const enableATCButton = pathOr(
      true,
      `${GLOBAL_SWITCH}.${ENABLE_ATC_BUTTON}`,
      switchConfig
    );
    return (
      <LazyLoad threshold={1000}>
        <PrimaryCta
          imageUrl={image}
          actions={actions}
          collectionFlag={this.groupByProp(COLLECTION_FLAG, collectionFlag)}
          href={href}
          isCustomizable={this.isCustomizable}
          isMobile={isMobile}
          isPersonalizable={this.isPersonalizable}
          isLtl={this.groupByProp(this.props.LTL_FLAG, this.props.isLtlFlag)}
          productId={this.groupByProp(PRODUCT_ID, productId)}
          profileHasRegistries={profileHasRegistries}
          rollupTypeCode={this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode)}
          isAvailableInStore={isAvailableInStore}
          url={url}
          filterSize={filterSize}
          selectedVariant={selectedVariant}
          itemIndexFromPLP={itemIndex}
          isSkuCreated={this.isSkuCreated}
          intlRestricted={intlRestricted}
          isUnavailable={isUnavailable}
          isInternationalUser={isInternationalUser}
          miniQuickViewMode={miniQuickViewMode}
          switchConfig={switchConfig}
          pageConfig={pageConfig}
          skuIdBP={this.groupByProp(SKU_ID, skuId)}
          title={this.groupByProp(DISPLAY_NAME, title)}
          price={priceLow || priceNormal}
          scene7imageID={scene7imageID}
          renderATCWithATR
          renderATCWithATRAsLink={false}
          setDataForTransition={this.state.setDataForTransition}
          notAvailableForSDD={this.props.notAvailableForSDD}
          inventoryStatus={this.props.inventoryStatus}
          isPNHPLP={isPNHPLP}
          selectedPnhList={selectedPnhList}
          storeId={storeId}
          enableATCButton={enableATCButton}
          location={location}
          isATRModalHide={isATRModalHide}
          nearestStoreAvailabilty={nearestStoreAvailabilty}
          className={classnames(
            {
              [styles.optionBtnMob]: this.props.isMobileOnly,
            },
            styles.optionBtnDsk,
            'choose-options'
          )}
          isShiptSdd={isShiptSdd}
          pageIdentifier={pageIdentifier}
          sponsored={sponsored}
          runClickTracker={runClickTracker}
          clickTracker={clickTracker}
          isGroupbyActive={isGroupbyActive}
          color={color}
          skuSize={skuSize}
          skuSelected={skuSelected}
          storeAvailability={storeAvailability}
          notAvailableWithStore={notAvailableWithStore}
          storeInventoryStatus={storeInventoryStatus}
          isShopInStore={isShopInStore}
          onPickupInStoreButtonClick={onPickupInStoreButtonClick}
          getFindInStoreLink={this.getFindInStoreLink}
        />
      </LazyLoad>
    );
  };

  // eslint-disable-next-line max-params
  renderProductDetail(
    switchConfig,
    isPlpMobileExperiment,
    isMobileOnly,
    DISPLAY_NAME,
    title,
    itemIndex,
    href,
    titleMark,
    review,
    isMobile,
    RATINGS,
    rating,
    ratingTitle,
    reviewsLabel,
    isUnavailable,
    productNotAvailableLabel,
    renderSwatchSS,
    isGridView,
    variants,
    actions,
    intlRestricted,
    swatchOptions,
    PRODUCT_ID,
    productId,
    chooseOptionsLabel,
    COLLECTION_FLAG,
    collectionFlag,
    url,
    isNearbyStoresTestActive,
    isShiptSdd,
    scene7imageID,
    SKU_ID,
    skuId,
    availableInStore,
    onPickupInStoreButtonClick,
    PRODUCT_VARIATION,
    productVariation,
    track,
    storeName,
    ROLLUP_TYPE_CODE,
    rollupTypeCode,
    isSSDPLP,
    isMultiSku,
    isGroupbyActive,
    isClientMetricsCookie
  ) {
    return (
      <React.Fragment>
        {this.renderTitle(
          switchConfig,
          isPlpMobileExperiment,
          isMobileOnly,
          DISPLAY_NAME,
          title,
          itemIndex,
          href,
          titleMark
        )}
        <div className={styles.productInfo}>
          {this.renderRating(
            switchConfig,
            review,
            href,
            isMobile,
            itemIndex,
            RATINGS,
            rating,
            ratingTitle,
            reviewsLabel
          )}
          {this.productNotAvailable(isUnavailable, productNotAvailableLabel)}
          {this.renderAttributeAccordion(
            isPlpMobileExperiment,
            isMobileOnly,
            renderSwatchSS,
            switchConfig,
            isGridView,
            variants,
            isMobile,
            actions,
            href,
            intlRestricted,
            swatchOptions,
            PRODUCT_ID,
            productId,
            chooseOptionsLabel,
            COLLECTION_FLAG,
            collectionFlag,
            url
          )}
        </div>
        {this.renderFindStorePLP(
          isNearbyStoresTestActive,
          isShiptSdd,
          PRODUCT_ID,
          productId,
          scene7imageID,
          SKU_ID,
          skuId,
          availableInStore,
          onPickupInStoreButtonClick,
          PRODUCT_VARIATION,
          productVariation,
          track,
          storeName,
          ROLLUP_TYPE_CODE,
          rollupTypeCode
        )}
        {this.renderPlaceHolderMinQtyPrimaryCta(
          isSSDPLP,
          switchConfig,
          isMultiSku,
          isUnavailable,
          isMobile,
          href,
          intlRestricted
        )}
        {isClientMetricsCookie === 'true' &&
          isGroupbyActive && <ClientMetrics clientMetrics={this.props} />}
      </React.Fragment>
    );
  }
  /* eslint-disable complexity */
  render() {
    const {
      actions,
      badge,
      className,
      disabled,
      isCollegePage,
      isBrandPage,
      price,
      productId,
      rating,
      ratingTitle,
      reviews,
      title,
      variants,
      reviewsLabel,
      chooseOptionsLabel,
      lazyLoad,
      channelType,
      imgBeforeLoad,
      isGridView,
      onImgLoad,
      titleMark,
      gridMark,
      categoryId,
      searchTerm,
      rollupTypeCode,
      collectionFlag,
      imageSrcSet,
      sizes,
      srcSet,
      imageSrc,
      itemIndex,
      isUnavailable,
      intlRestricted,
      swatchOptions,
      url,
      isMobileOnly,
      productNotAvailableLabel,
      switchConfig,
      filterSize,
      selectedColor,
      isPlpMobileExperiment,
      scene7imageID,
      altImages,
      skuId,
      availableInStore,
      onPickupInStoreButtonClick,
      productVariation,
      isNearbyStoresTestActive,
      track,
      storeName,
      navigationViewportSize,
      sddMarketData,
      isShiptSdd,
      DISPLAY_NAME,
      ROLLUP_TYPE_CODE,
      COLLECTION_FLAG,
      PRODUCT_ID,
      PRODUCT_VARIATION,
      RATINGS,
      REVIEWS,
      SKU_ID,
      sponsored,
      impressionTracker,
      isGroupbyActive,
      isClientMetricsCookie,
      isShopInStore,
    } = this.props;
    const isMobile = channelType === 'MobileWeb';
    const isSponsored = 'Sponsored';
    // navigationViewportSize comes as mobile even on ipad pro devices unlike channelType which comes as desktop
    const isClickableTile = navigationViewportSize === 'mobile';
    const productCompare = pathOr(
      false,
      ['productCompareData', 'productCompare'],
      this.props
    );
    const marketData = sddMarketData && sddMarketData.marketData;
    const isSSDPLP = isShiptSdd && marketData && marketData.sddFlag;
    const isCompareClicked =
      productCompare &&
      !isMobileOnly &&
      parseInt(this.groupByProp(COLLECTION_FLAG, collectionFlag), 10) === 0
        ? findIndex(productCompare, {
            productId: this.groupByProp(PRODUCT_ID, productId),
          })
        : -1;
    const renderableImageOnServer =
      gridMark && !isBrowser()
        ? this.getDangerouslyLoadedImg(
            this.groupByProp(DISPLAY_NAME, title),
            imageSrc
          )
        : null;
    const rootStyles = {
      [styles.withBadge]: badge,
      [styles.isDisabled]: disabled,
      [className]: className,
    };
    let cardId = '';
    const prodId = this.groupByProp(PRODUCT_ID, productId);
    /* istanbul ignore else */
    if (prodId) {
      rootStyles[`js-product-id-${prodId}`] = `js-product-id-${prodId}`;
      cardId = prodId;
    }
    const isSkuCreated = getRollupCode(
      this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode),
      this.groupByProp(COLLECTION_FLAG, collectionFlag)
    );
    const href = this.getProductUrl({
      categoryId,
      isSkuCreated,
      searchTerm,
      isCollegePage,
      isBrandPage,
      filterSize,
      isShiptSdd,
      isShopInStore,
    });
    const skuIdforIdeaboard = this.getSkuIdForIdeaboard();
    const swatchImage = !isGroupbyActive ? this.getSwatchImage() : '';
    const review = this.groupByProp(REVIEWS, reviews);
    let mainImageId;
    if (selectedColor && !this.state.swatchChange) {
      mainImageId = this.props.scene7imageID;
    } else {
      const scene7imageIDwithColor =
        swatchImage !== '' ? swatchImage : this.props.scene7imageID;
      mainImageId =
        this.state.variantIndex === -1
          ? scene7imageIDwithColor
          : this.currentImage;
    }
    const isMultiSku = isMultiSkufunc(
      this.groupByProp(ROLLUP_TYPE_CODE, rollupTypeCode),
      this.groupByProp(COLLECTION_FLAG, collectionFlag)
    );

    // This function is not calling from anywhere. Check weather we can remove it or not.
    /* istanbul ignore next */
    const renderSwatchSS = () =>
      this.renderSwatch({
        variants,
        isMobile,
        actions,
        href,
        intlRestricted,
        swatchOptions,
        productId: this.groupByProp(PRODUCT_ID, productId),
        chooseOptionsLabel,
        collectionFlag: this.groupByProp(COLLECTION_FLAG, collectionFlag),
        url,
      });
    // groupby api does not have altImage need to create for alt image on hover
    let altImage = null;
    if (altImages && altImages.length >= 1) {
      altImage = altImages[0];
    }
    this.renderProductPrice();
    return this.conditionalClickableWrapper(
      <Card
        className={classnames(
          isCompareClicked > -1
            ? /* istanbul ignore next: path cause test failure elsewhere */ styles.compareProductSelected
            : styles.compareProductNotSelected,
          rootStyles,
          `${isClickableTile ? 'fullHeight ' : ''}tealium-product-card`,
          {
            'grid-x': isPlpMobileExperiment && isGridView && isMobileOnly,
          }
        )}
        id={cardId}
        index={itemIndex}
        ariaAttributes={this.cardAriaAttr}
        data-locator="product-compare-highlighted-Tile"
        isMobileOnly={isMobileOnly}
        onProductTile
      >
        <div
          className={classnames(
            styles.thumbnailWrapper,
            'tealium-product-tile',
            {
              'small-4': isPlpMobileExperiment && isMobileOnly && isGridView,
            },
            {
              [styles.thumbnailWrapperForProductTile]: isMobileOnly,
              [styles.thumbnailWrapperWithBadge]:
                !isEmpty(this.props.badge) && isMobileOnly,
            }
          )}
        >
          <PrimaryLinkContainer
            onClick={() => this.pushReference(href)}
            href={href}
            className={classnames(
              'absolute top-0 right-0 bottom-0 left-0 activeAnchorHeight fol'
            )}
            itemIndexFromPLP={itemIndex}
            elementClicked={CLICK_IMAGE}
            setDataForTransition={this.state.setDataForTransition}
          >
            <Thumbnail
              className={classnames(styles.thumbnail, 'activeAnchorImage')}
              alt={this.groupByProp(DISPLAY_NAME, title)}
              lazyLoad={lazyLoad}
              lazyLoadOptions={lazyLoadOptions}
              scene7imageID={mainImageId}
              breakpoints={
                isGridView
                  ? PRODUCT_TILE_BREAKPOINTS
                  : PRODUCT_TILE_SINGLE_COL_BREAKPOINTS
              }
              imgBeforeLoad={imgBeforeLoad}
              onImgLoad={onImgLoad}
              scene7imageUrl={
                this.selectedVariant && this.selectedVariant.image
              }
              imageSrcSet={imageSrcSet}
              sizes={sizes}
              srcSet={srcSet}
              imageSrc={imageSrc}
              dataLocator={PRODUCT_TILE_IMAGE}
              onMouseEnter={e =>
                altImage
                  ? showAlternateImageOnHover(
                      this.props,
                      e,
                      srcSet,
                      altImage,
                      this.selectedVariant,
                      imageSrc
                    )
                  : ''}
              onMouseLeave={e =>
                showAlternateImageOnHover(
                  this.props,
                  e,
                  srcSet,
                  mainImageId,
                  this.selectedVariant,
                  imageSrc
                )}
            />
            {sponsored && (
              <img
                className={styles.impressionTracker}
                alt=""
                src={impressionTracker}
              />
            )}
          </PrimaryLinkContainer>
          {this.renderLocalFavorite()}
          <LazyLoad threshold={1000}>
            {pathOr(true, 'PLP.productTileIdeaboard', switchConfig) && (
              <AddToIdeaboard
                className={classnames(styles.ideaBoardIcon)}
                productName={this.groupByProp(DISPLAY_NAME, title)}
                productId={this.groupByProp(PRODUCT_ID, productId)}
                skuId={skuIdforIdeaboard}
                renderCustomToolTip
                productImageId={
                  this.state.variantIndex === -1
                    ? scene7imageID
                    : this.currentImage
                }
                itemIndex={itemIndex}
                toolTipClassName={styles.customTooltip}
                tealiumProductPrice={
                  price && price.lowValue ? price.lowValue.toString() : ''
                }
                skuIdentity={this.groupByProp(SKU_ID, skuId)}
                ideaboardIconId={`pdp-ideaboard-icon${itemIndex}`}
                onProductTile
                isMobileOnly={isMobileOnly}
              />
            )}
          </LazyLoad>
          {pathOr(true, 'PLP.productTileQuickView', switchConfig) && (
            <div className={styles.quickViewWrapper}>
              <LazyLoad threshold={1000}>
                <ActionButton
                  className={styles.quickViewButton}
                  label={actions.quickView.label}
                  onClick={this.onQuickViewButtonClick}
                  theme="secondaryStrokeBasic"
                  selectedItemIndex={itemIndex}
                />
              </LazyLoad>
            </div>
          )}
        </div>
        <React.Fragment>
          {isMobileOnly ? (
            <div
              className={classnames({
                [styles.productTileInfo]: this.props.isMobileOnly,
              })}
            >
              {this.renderProductDetail(
                switchConfig,
                isPlpMobileExperiment,
                isMobileOnly,
                DISPLAY_NAME,
                title,
                itemIndex,
                href,
                titleMark,
                review,
                isMobile,
                RATINGS,
                rating,
                ratingTitle,
                reviewsLabel,
                isUnavailable,
                productNotAvailableLabel,
                renderSwatchSS,
                isGridView,
                variants,
                actions,
                intlRestricted,
                swatchOptions,
                PRODUCT_ID,
                productId,
                chooseOptionsLabel,
                COLLECTION_FLAG,
                collectionFlag,
                url,
                isNearbyStoresTestActive,
                isShiptSdd,
                scene7imageID,
                SKU_ID,
                skuId,
                availableInStore,
                onPickupInStoreButtonClick,
                PRODUCT_VARIATION,
                productVariation,
                track,
                storeName,
                ROLLUP_TYPE_CODE,
                rollupTypeCode,
                isSSDPLP,
                isMultiSku,
                isGroupbyActive,
                isClientMetricsCookie
              )}
            </div>
          ) : (
            this.renderProductDetail(
              switchConfig,
              isPlpMobileExperiment,
              isMobileOnly,
              DISPLAY_NAME,
              title,
              itemIndex,
              href,
              titleMark,
              review,
              isMobile,
              RATINGS,
              rating,
              ratingTitle,
              reviewsLabel,
              isUnavailable,
              productNotAvailableLabel,
              renderSwatchSS,
              isGridView,
              variants,
              actions,
              intlRestricted,
              swatchOptions,
              PRODUCT_ID,
              productId,
              chooseOptionsLabel,
              COLLECTION_FLAG,
              collectionFlag,
              url,
              isNearbyStoresTestActive,
              isShiptSdd,
              scene7imageID,
              SKU_ID,
              skuId,
              availableInStore,
              onPickupInStoreButtonClick,
              PRODUCT_VARIATION,
              productVariation,
              track,
              storeName,
              ROLLUP_TYPE_CODE,
              rollupTypeCode,
              isSSDPLP,
              isMultiSku,
              isGroupbyActive,
              isClientMetricsCookie
            )
          )}
          <LazyLoad threshold={1000}>
            <div className="flex">
              {this.hasCompare &&
                !isMobileOnly && (
                  /* istanbul ignore next: path cause test failure elsewhere */
                  <CompareButton
                    className={classnames(
                      styles.compareButton,
                      isCompareClicked > -1
                        ? /* istanbul ignore next: path cause test failure elsewhere */ styles.compareButtonSelected
                        : ''
                    )}
                    productId={this.groupByProp(PRODUCT_ID, productId)}
                    skuId={this.groupByProp(SKU_ID, skuId)}
                    productName={this.groupByProp(DISPLAY_NAME, title)}
                    scene7imageID={scene7imageID}
                    collectionFlag={this.groupByProp(
                      COLLECTION_FLAG,
                      collectionFlag
                    )}
                    label={actions.compare.label}
                    rollupTypeCode={this.groupByProp(
                      ROLLUP_TYPE_CODE,
                      rollupTypeCode
                    )}
                    updateState={data => this.updateState(data)}
                    dataLocator="compareLink"
                    productIsUnavailable={isUnavailable}
                  />
                )}
              {(!isGridView || !isMobileOnly) &&
                getRelatedCategories(this.props)}
            </div>
          </LazyLoad>
          {gridMark}
          {renderableImageOnServer}
          {sponsored && <span className={styles.sponsored}>{isSponsored}</span>}
        </React.Fragment>
      </Card>,
      href,
      itemIndex,
      isClickableTile
    );
  }
}
export default withSiteSpectTracker(ProductTile);
export { ProductTile as PureProductTile }; // Used for testing purposes
