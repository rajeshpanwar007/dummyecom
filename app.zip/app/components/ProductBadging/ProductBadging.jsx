import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import { getBadgeConfig } from '@bbb-app/utils/getBadgeConfig';
import styles from './ProductBadging.css';
import inlineStyles from './ProductBadging.inline.css';
const propTypes = {
  badge: PropTypes.object.isRequired,
  className: PropTypes.string,
};

const getBadge = badge => {
  try {
    return JSON.parse(badge);
  } catch (e) {
    if (typeof badge === 'string') {
      return { IMG: '', TEXT: badge };
    }
  }
  return { IMG: '', TEXT: '' };
};
/**
 * Component to display Product Badging
 * @param {object} badge to display badge label
 * @param {string} className to style the element
 */
export const ProductBadging = ({ badge, className }) => {
  const badgeObj = getBadge(badge);
  const DangerousText = dangerousHTML(DangerousText);
  if (badgeObj.IMG && badgeObj.IMG.length > 0) {
    return (
      <img
        src={badgeObj.IMG}
        alt={badgeObj.TEXT}
        className={classnames(
          styles.badgeStyle,
          inlineStyles.badgeImageStyle,
          className
        )}
      />
    );
  }
  return (
    <React.Fragment>
      {badgeObj && (
        <span
          tabIndex="0"
          className={classnames(
            styles.badgeStyle,
            inlineStyles.badgeStyle,
            className
          )}
        >
          <DangerousText>{badgeObj.TEXT}</DangerousText>
        </span>
      )}
    </React.Fragment>
  );
};

/**
 * Function to pass the badge to be displayed to ProductBadging Function above
 * @param {array} exppBadges contains all badges in an array
 * @param {string} attributeId Attributeid of enabled badge
 */
export const ProductBadgingComponent = props => {
  const { badge, productBadgingConfig, isNewArrival } = props;
  if (isNewArrival) return null;
  const badgeConfig = getBadgeConfig(badge);
  const isBadgeKeyEnable = pathOr(true, [badgeConfig], productBadgingConfig);
  if (badge && isBadgeKeyEnable) {
    return ProductBadging({ badge });
  }
  return null;
};
ProductBadging.propTypes = propTypes;
