/**
 * Returns all instances of matching array entries with a particular entry in array
 * @param {array} arrayOfElements
 * @param {string} arrayKey
 * @return {string} valueToBeCheckedWith
 */
export const returnMatchingArrayElement = (
  arrayOfElements,
  arrayKey,
  valueToBeCheckedWith
) => {
  return arrayOfElements
    ? arrayOfElements.filter(elm => elm[arrayKey] === valueToBeCheckedWith)
    : null;
};
export default returnMatchingArrayElement;
