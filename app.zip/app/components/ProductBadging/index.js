export { default } from './ProductBadging';
