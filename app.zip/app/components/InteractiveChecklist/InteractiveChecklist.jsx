import React from 'react';
import PropTypes from 'prop-types';
import { setTimeoutCustom } from '@bbb-app/utils/timers';
import { windowScroll, isBrowser } from '@bbb-app/utils/common';
import SlideOutOverlay from '@bbb-app/slideout-overlay/containers/SlideoutOverlay';

import ICLayOut from './ICLayOut';
import {
  focusableElement,
  icTabButton,
  icTabButtonSelected,
  icContainerId,
} from './constant';

export class InteractiveChecklist extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isButtonClicked: false,
      defaultSelectedIndex: 1,
      showWlcmScreen: false,
    };
    this.icInnerheight = window.innerHeight;
    this.enableScrollingEvent = false;
    this.setButtonClicked = this.setButtonClicked.bind(this);
    this.openOnClickOfButton = this.openOnClickOfButton.bind(this);
    this.handleTabFirstElement = this.handleTabFirstElement.bind(this);
    this.handleTabLastElement = this.handleTabLastElement.bind(this);
    this.removeBindEvent = this.removeBindEvent.bind(this);
    this.getFocusableElement = this.getFocusableElement.bind(this);
    this.setFocusOnSelectedCOne = this.setFocusOnSelectedCOne.bind(this);
    this.putFocusOnClickNext = this.putFocusOnClickNext.bind(this);
    this.putFocusForC2 = this.putFocusForC2.bind(this);
    this.putFocusForC3 = this.putFocusForC3.bind(this);
    this.setFocus = this.setFocus.bind(this);
    this.getDefaultSelectedIndex = this.getDefaultSelectedIndex.bind(this);
    this.clickOnOverlay = this.clickOnOverlay.bind(this);
    this.handleWlcmScreenState = this.handleWlcmScreenState.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    const defaultSelectedIndex = this.state.defaultSelectedIndex;
    const index =
      nextProps.selectedIndex === -1
        ? defaultSelectedIndex
        : nextProps.selectedIndex;
    const isOpen = this.props.isInMenu
      ? this.props.menuState
      : this.state.isButtonClicked;
    const willOpen = nextProps.isInMenu
      ? nextProps.menuState
      : this.state.isButtonClicked;

    if (
      this.props.locationChange !== nextProps.locationChange &&
      this.state.isButtonClicked
    ) {
      this.setState({
        isButtonClicked: false,
      });
    }
    if (isOpen === false && willOpen === true) {
      this.setFocusOnSelectedCOne(index);
    }
  }

  componentDidUpdate() {
    if (this.state.isButtonClicked || this.props.menuState) {
      windowScroll.disable();
      this.enableScrollingEvent = true;
      if (this.props.menuState || this.state.isButtonClicked) {
        this.isScrolledIntoView();
      }
    } else if (
      this.enableScrollingEvent &&
      (!this.state.isButtonClicked && !this.props.menuState)
    ) {
      windowScroll.enable();
      this.enableScrollingEvent = false;
    }
    if (!this.state.isButtonClicked) {
      this.removeBindEvent();
    }
  }

  componentWillUnmount() {
    windowScroll.enable();
  }

  getDefaultSelectedIndex(value) {
    if (value !== this.state.defaultSelectedIndex) {
      this.setState({
        defaultSelectedIndex: value,
      });
    }
  }

  setFocusOnSelectedCOne(index) {
    setTimeoutCustom(() => {
      const element = document.getElementById(`${icTabButton}${index}`);
      if (isBrowser() && element) {
        element.focus();
      }
    }, 500);
  }

  setButtonClicked(closeIcOnESC = false, showWlcmScreen = false) {
    const flagForButtonClicked = this.props.isInMenu
      ? this.props.menuState
      : this.state.isButtonClicked;
    const willICOpen = !this.state.isButtonClicked || this.props.menuState;
    this.setState({
      isButtonClicked: !flagForButtonClicked,
    });
    if (flagForButtonClicked && this.props.isMobile) {
      windowScroll.enable();
    }
    if (this.props.isInMenu) this.props.menuOnClick();
    if (willICOpen) {
      const defaultSelectedIndex = this.state.defaultSelectedIndex;
      const index =
        this.props.selectedIndex === -1
          ? defaultSelectedIndex
          : this.props.selectedIndex;
      this.setFocusOnSelectedCOne(index);
    } else {
      this.props.clearCreateRegistry();
    }

    if (closeIcOnESC && typeof this.props.menuOnClick === 'function') {
      this.setState({
        isButtonClicked: false,
      });
      this.props.menuOnClick(true);
    }
    if (!showWlcmScreen) {
      this.setState({
        showWlcmScreen: false,
      });
    }
    this.bindEvent();
  }

  /**
   * Find the last and First focusable element
  */
  getFocusableElement() {
    const containerId = document.getElementById(icContainerId);
    const focusable =
      containerId && containerId.querySelectorAll(focusableElement);
    const C1Focusable =
      containerId && containerId.getElementsByClassName(icTabButton);
    const firstFocusable = focusable && focusable[0];
    const lastC2Focusable = focusable && focusable[focusable.length - 1];
    const lastC1Focusable = C1Focusable && C1Focusable[C1Focusable.length - 1];
    return { containerId, firstFocusable, lastC2Focusable, lastC1Focusable };
  }

  setFocus(elementToBeFocused) {
    setTimeoutCustom(() => {
      elementToBeFocused.focus();
      elementToBeFocused.scrollIntoView();
    }, 0);
  }

  handleWlcmScreenState(value) {
    this.setState({
      showWlcmScreen: value,
    });
  }

  clickOnOverlay() {
    const closeOnESC = false;
    const showWlcmScreen = true;
    this.setButtonClicked(closeOnESC, showWlcmScreen);
  }

  putFocusForC3(currentElement) {
    let element = currentElement;
    let parentElement = {};
    while (
      parentElement &&
      ((parentElement.id && parentElement.id.indexOf('menupanel') === -1) ||
        !parentElement.id)
    ) {
      parentElement = element && element.parentElement;
      element = parentElement;
    }

    const c3AnchorElement =
      parentElement && parentElement.querySelectorAll('a')[0];
    if (c3AnchorElement) {
      this.setFocus(c3AnchorElement);
    }
  }

  putFocusForC2(currentElement) {
    const toolTipButton = currentElement;
    let currentLi = toolTipButton && toolTipButton.parentElement;
    while (currentLi.nodeName !== 'LI') {
      currentLi = currentLi.parentElement;
    }
    const nextC2 = currentLi && currentLi.nextElementSibling;
    const c2AnchorElement = nextC2 && nextC2.querySelectorAll('a')[0];
    if (c2AnchorElement) {
      this.setFocus(c2AnchorElement);
    }
  }

  putFocusOnClickNext(level, e) {
    if (level === 2) {
      this.putFocusForC3(e.target);
    } else {
      this.putFocusForC2(e.target);
    }
  }

  isScrolledIntoView() {
    const containerId = document.getElementById(icContainerId);
    const elem =
      containerId && containerId.getElementsByClassName(icTabButtonSelected);
    const selectedElement = elem && elem[0] && elem[0].parentElement;
    if (
      selectedElement &&
      (this.icInnerheight <= selectedElement.offsetTop ||
        selectedElement.getBoundingClientRect().top <= 0)
    ) {
      selectedElement.scrollIntoView();
    }
  }
  /**
   * bind Event listeners to trap focus inside IC
  */
  bindEvent() {
    const {
      firstFocusable,
      lastC2Focusable,
      lastC1Focusable,
    } = this.getFocusableElement();
    if (firstFocusable) {
      firstFocusable.addEventListener('keydown', this.handleTabFirstElement);
    }
    if (lastC2Focusable) {
      lastC2Focusable.addEventListener('keydown', this.handleTabLastElement);
    }
    if (lastC1Focusable) {
      lastC1Focusable.addEventListener('keydown', this.handleTabLastElement);
    }
  }

  /**
   * Remove Event Listeners
  */
  removeBindEvent() {
    const {
      firstFocusable,
      lastC2Focusable,
      lastC1Focusable,
    } = this.getFocusableElement();
    if (firstFocusable) {
      firstFocusable.removeEventListener(
        'keydown',
        this.handleTabFirstElements
      );
    }
    if (lastC2Focusable) {
      lastC2Focusable.removeEventListener('keydown', this.handleTabLastElement);
    }
    if (lastC1Focusable) {
      lastC1Focusable.removeEventListener('keydown', this.handleTabLastElement);
    }
  }

  /**
   * Handle Tab on las focusable element
   * @param {*} e
   */
  handleTabLastElement(e) {
    const { firstFocusable } = this.getFocusableElement();
    let selected = false;
    if (
      e.target.parentElement.parentElement.classList.contains(
        icTabButtonSelected
      )
    ) {
      selected = true;
    }
    if (e.keyCode === 9 && !e.shiftKey && !selected) {
      firstFocusable.focus();
    }
  }

  /**
   * Handle shift + Tab on First focusable Element
   * @param {*} e
   */
  handleTabFirstElement(e) {
    const { containerId } = this.getFocusableElement();
    const selectedElement = containerId.getElementsByClassName(
      icTabButtonSelected
    )[0].parentElement;
    const focusable = selectedElement.querySelectorAll(focusableElement);
    const lastFocusable = focusable[focusable.length - 1];
    if (e.keyCode === 9 && e.shiftKey) {
      setTimeoutCustom(() => {
        lastFocusable.focus();
      }, 0);
    }
  }

  openOnClickOfButton() {
    if (!this.state.isButtonClicked) {
      this.setState({
        isButtonClicked: true,
      });
      this.bindEvent();
    }
  }

  render() {
    const {
      isMobile,
      interactiveCheckListData,
      selectScrollFlag,
      labelsForICList,
      isInMenu,
      menuState,
      isMoverListEnable,
      ...otherProps
    } = this.props;
    return (
      <div>
        <ICLayOut
          isMobile={isMobile}
          interactiveCheckListData={interactiveCheckListData}
          selectScrollFlag={selectScrollFlag}
          setButtonClicked={this.setButtonClicked}
          isOpen={isInMenu ? menuState : this.state.isButtonClicked}
          isInMenu={isInMenu}
          openOnClickOfButton={this.openOnClickOfButton}
          labels={labelsForICList}
          updateManualCheck={this.props.updateManualCheck}
          putFocusOnClickNext={this.putFocusOnClickNext}
          isMoverListEnable={isMoverListEnable}
          getDefaultSelectedIndex={this.getDefaultSelectedIndex}
          handleTealiumEvent={this.props.handleTealiumEvent}
          handleWlcmScreenState={this.handleWlcmScreenState}
          showWlcmScreen={this.state.showWlcmScreen}
          {...otherProps}
        />
        {!isMobile && this.state.isButtonClicked ? (
          <SlideOutOverlay
            onOverlayClick={this.clickOnOverlay}
            show={this.state.isButtonClicked}
            direction="right"
            panelWidth="100%"
            panelStyles={{
              overflowX: 'hidden',
              overflowY: 'auto',
              WebkitOverflowScrolling: 'touch',
              height: '100%',
            }}
            id="IC-slide-out-overlay-dekstop"
            iCList
          />
        ) : null}
      </div>
    );
  }
}

InteractiveChecklist.propTypes = {
  isMobile: PropTypes.bool,
  interactiveCheckListData: PropTypes.object,
  selectScrollFlag: PropTypes.any,
  labelsForICList: PropTypes.object,
  locationChange: PropTypes.bool,
  isInMenu: PropTypes.bool,
  menuState: PropTypes.bool,
  menuOnClick: PropTypes.func,
  updateManualCheck: PropTypes.func,
  selectedIndex: PropTypes.number,
  isMoverListEnable: PropTypes.bool,
  handleTealiumEvent: PropTypes.func,
  isPNHChecklistEnabledIC: PropTypes.bool,
  isPNHChecklistEnabledSFooter: PropTypes.bool,
  clearCreateRegistry: PropTypes.func,
};

export default InteractiveChecklist;
