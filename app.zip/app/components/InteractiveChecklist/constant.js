export const firstLIID = 'icFirstLi';
export const ADD_CLASS = 'addClass';
export const REMOVE_CLASS = 'removeClass';
export const focusableElement =
  'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
export const icContainerId = 'icContainer';
export const icTabButtonSelected = 'icTabButtonSelected';
export const icTabButton = 'icTabButton';
