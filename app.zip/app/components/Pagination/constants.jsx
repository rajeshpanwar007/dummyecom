export default {
  DISPLAY_ELLIPSES: -1,
  DISPLAY_VIEW_ALL: 0,
  PAGINATION_PREVBUTTON: 'pagination_prevbutton',
  PAGINATION_NEXTBUTTON: 'pagination_nextbutton',
  PAGINATION_BOX: 'pagination_boxsection',
  PAGINATION_PREVBUTTON_LABEL: 'Back:',
  PAGINATION_NEXTBUTTON_LABEL: 'Next:',
};
