import pathOr from 'lodash/fp/pathOr';
import { isGroupByPLPActive } from '@bbb-app/utils/groupBy';
import consoleLog from '@bbb-app/utils/logger';
import { getSearchWithinSearchInfo } from '@bbb-app/tealium/tagSelectors/searchWithinSearchWords';
import {
  NON_SEARCH,
  TEALIUM_PAGE_INFO_L2,
  TEALIUM_PAGE_INFO_L3,
  TEALIUM_PAGE_INFO_BRAND_PLP,
  TEALIUM_PAGE_INFO_SR_PLP,
} from '@bbb-app/tealium/constants';
import { getBrowseRefine } from '@bbb-app/tealium/tagSelectors/facets';

import removeElementFromArray from '../../utils/removeElementFromArray';
import getAccountDetails from './utils/getAccountDetails';

const PAGE_NAME = 'pagination';

export const getPageNameBreadCrumbPLP = breadcrumbs => {
  let pagebreadCrumb = '';
  let pageTypeName = '';
  if (breadcrumbs && breadcrumbs.length !== 0) {
    const level = breadcrumbs.length;

    const l1Name = breadcrumbs[0] ? breadcrumbs[0].name : '';
    const l2Name = breadcrumbs[1] ? breadcrumbs[1].name : '';
    const l3Name = breadcrumbs[2] ? breadcrumbs[2].name : '';

    pagebreadCrumb = l1Name;
    pageTypeName = {
      page_type: 'PLP',
      page_name: 'DepartmentLandingDetails',
    };
    if (level === 2) {
      pagebreadCrumb = `${l1Name}>${l2Name}`;
      pageTypeName = TEALIUM_PAGE_INFO_L2;
    } else if (level === 3) {
      pagebreadCrumb = `${l1Name}>${l2Name}>${l3Name}`;
      pageTypeName = TEALIUM_PAGE_INFO_L3;
    } else {
      pagebreadCrumb = l1Name;
      pageTypeName = {
        page_type: 'PLP',
        page_name: 'DepartmentLandingDetails',
      };
    }
  }
  return {
    pagebreadCrumb,
    pageTypeName,
  };
};

export const getPageNameBreadCrumbTag = tealiumData => {
  let pageNameBreadCrumb;
  let pageType;
  let names = {};
  if (tealiumData.pageId === 'PLP') {
    const breadcrumbs = pathOr('', 'breadcrumbs', tealiumData);
    names = getPageNameBreadCrumbPLP(breadcrumbs);
  }

  switch (tealiumData.pageId) {
    case 'BrandLanding':
      pageNameBreadCrumb = `Brand>${tealiumData.brandNameOriginal || ''}`;
      pageType = TEALIUM_PAGE_INFO_BRAND_PLP;
      break;
    case 'PLP':
      pageNameBreadCrumb = names.pagebreadCrumb;
      pageType = names.pageTypeName;
      break;
    case 'SearchResults':
      pageNameBreadCrumb = 'Search';
      pageType = TEALIUM_PAGE_INFO_SR_PLP;
      break;
    default:
      pageNameBreadCrumb = '';
      pageType = '';
  }
  return {
    pagename_breadcrumb: pageNameBreadCrumb,
    PAGE_NAME: pageType,
  };
};

export const getFacetsTags = (
  facetsData = {},
  selectedFilters = [],
  pageId
) => {
  if (facetsData && selectedFilters) {
    try {
      const val = Object.keys(facetsData).map(k => facetsData[k]);
      /** Object.values for IE11 */
      const facets = val.map(f => {
        const id = f.id;
        const name = f.displayName;
        const data = selectedFilters[id];
        return { id, name, data };
      });
      const args = {
        facets,
        formattedSelectedFilter: selectedFilters,
      };
      const facetTags = getBrowseRefine(args, pageId, '', false);
      /* istanbul ignore else */
      if (facetTags) {
        return {
          browse_refine_order: facetTags.browse_refine_order,
          browse_refine_type: facetTags.browse_refine_type,
          browse_refine_value: facetTags.browse_refine_value,
          facets_applied: facetTags.all_facets_applied,
        };
      }
    } catch (ex) {
      /* istanbul ignore next */
      consoleLog.error(ex);
    }
  }
  return {};
};

/* eslint complexity: ["error", 13]*/
export const paginationTealiumTags = (
  tealiumData,
  sort,
  pageNumber,
  currentPage,
  numFound,
  perPage,
  refineSearchTealiumTag
) => {
  if (tealiumData) {
    const searchTerm = pathOr('', 'searchTerm', tealiumData);
    const facetsTags = getFacetsTags(
      tealiumData.facetsData,
      tealiumData.selectedFilters,
      tealiumData.pageId
    );
    const breabcrumbTags = getPageNameBreadCrumbTag(tealiumData);
    const commonTags = tealiumData.paginationTealiumData;
    const categoryId = pathOr('', 'categoryId', tealiumData);
    const items = pathOr([], 'items', tealiumData);
    const groupbySearchId = pathOr('', 'groupbySearchId', tealiumData);
    let boostedSearchEngineTag = {};

    let productPerPage = perPage;
    if (currentPage === Math.ceil(numFound / perPage)) {
      productPerPage = numFound % perPage;
    }
    if (numFound < perPage) {
      productPerPage = numFound;
    }

    if (tealiumData.boostedSearchEngine) {
      boostedSearchEngineTag = {
        boosted_search_engine: tealiumData.boostedSearchEngine,
      };
    }
    const accountDetails = getAccountDetails();
    const tealiumTags = {
      internal_search_term: searchTerm || NON_SEARCH,
      page_name: PAGE_NAME,
      page_number: pageNumber,
      sort_value: sort,
      products_per_page: productPerPage,
      search_within_search: getSearchWithinSearchInfo(),
      search_results: numFound,
      ...boostedSearchEngineTag,
      groupbySearchId,
    };
    let globalVars = [
      'country_code',
      'customer_city ',
      'customer_email',
      'customer_email_md5_hash',
      'customer_email_sha256_hash',
      'customer_name',
      'customer_state',
      'language_code',
    ];
    /* istanbul ignore next */
    if (accountDetails) {
      const isLoggedIn = accountDetails.get('isLoggedIn') || '';
      const profile = accountDetails.get('profile') || '';
      if (isLoggedIn && profile) {
        const email = profile.get('email');
        tealiumTags.customer_email = email;
        globalVars = removeElementFromArray(globalVars, 'customer_email');
      }
    }
    tealiumTags.remove_global_vars = globalVars;
    if (tealiumData.pageId === 'BrandLanding')
      tealiumTags.brand_id = categoryId;
    else if (tealiumData.pageId === 'PLP') tealiumTags.category_id = categoryId;
    const productId = [];
    items.forEach(p => {
      const itemId = isGroupByPLPActive() ? p.PRODUCT_ID : p.productId;
      productId.push(itemId);
    });
    tealiumTags.product_id = productId;

    return Object.assign(
      {},
      commonTags,
      facetsTags,
      tealiumTags,
      breabcrumbTags,
      refineSearchTealiumTag
    );
  }
  return null;
};
