/**
 * Exports a Pagination component used on Product Grid
 *
 * @author hreid
 */
import React from 'react';
import { number, func, shape, string, object } from 'prop-types';
import classnames from 'classnames';
import LabelUtils from '@bbb-app/utils/labelsUtil';
import { keyboardEventFocusNavigator } from '@bbb-app/utils/accessibility';
import { getCurrentPage } from '@bbb-app/utils/filterUtils';
import Icon from '@bbb-app/core-ui/icon';
import '../../assets/icons/buttonarrow.svg';
import styles from './Pagination.css';
import PAGINATION_CONSTANTS from './constants';
import { paginationTealiumTags } from './paginationTealiumTags';

let tealiumVariables = {};

const getPaginationUrl = (start, getPaginationHref) => {
  return getPaginationHref(start) ? getPaginationHref(start) : '#';
};
/**
 *
 * @param {number} numFound
 * @param {number} perPage Items to show in a page
 * @return {number} Computes the number of pages
 */
const getNumberOfPages = ({ numFound, perPage }) =>
  perPage > 0 ? Math.ceil(numFound / perPage) : 0;

/**
 *
 * @param {number} currentPage
 * @param {number} perPage Items to show in a page
 * @return {object} An object representing the start and per page values
 */
const getStartAndEnd = (currentPage, perPage) => ({
  start: (currentPage - 1) * perPage,
  perPage,
});

/** Method for triggering pagination click tealium event */
const triggerTealiumAction = (tealiumVars, fromNext, fromPrevious, label) => {
  /* istanbul ignore else */
  if (tealiumVars && tealiumVars.handlePaginationTealiumEvent) {
    let pageNumber = tealiumVars.currentPage;
    if (fromNext) {
      pageNumber = tealiumVars.currentPage + 1;
    } else if (fromPrevious) {
      pageNumber = tealiumVars.currentPage - 1;
    } else {
      pageNumber = label;
    }
    const tealiumTags = paginationTealiumTags(
      tealiumVars.tealiumData,
      tealiumVars.sort,
      pageNumber,
      tealiumVars.currentPage,
      tealiumVars.numFound,
      tealiumVars.perPage
    );
    /* istanbul ignore next */
    const TEALIUM_PAGE_INFO = tealiumTags ? tealiumTags.PAGE_NAME : '';
    delete tealiumTags.PAGE_NAME;
    tealiumVars.handlePaginationTealiumEvent(
      'pagination',
      tealiumTags,
      TEALIUM_PAGE_INFO
    );
  }
};

/**
 *
 * @param {number} perPage Items to show in a page
 * @param {number} numFound
 * @param {number} currentPage
 * @return {Array} Returns an computed array of page values. E.g. [ 1,2,3,-1,10]
 */
export const getPagesInView = ({ perPage, numFound, currentPage }) => {
  const numPages = getNumberOfPages({ numFound, perPage });
  const threshold = 4;
  let pages = [];
  if (numPages > threshold) {
    const firstPage = 1;
    if (currentPage < threshold - 1) {
      pages = [
        firstPage,
        firstPage + 1,
        firstPage + 2,
        PAGINATION_CONSTANTS.DISPLAY_ELLIPSES,
        numPages,
      ];
    } else if (numPages - currentPage < threshold - 1) {
      pages = [
        firstPage,
        PAGINATION_CONSTANTS.DISPLAY_ELLIPSES,
        numPages - 2,
        numPages - 1,
        numPages,
      ];
    } else {
      pages = [
        firstPage,
        PAGINATION_CONSTANTS.DISPLAY_ELLIPSES,
        currentPage - 1,
        currentPage,
        currentPage + 1,
        PAGINATION_CONSTANTS.DISPLAY_ELLIPSES,
        numPages,
      ];
    }
  } else {
    for (let i = 1; i <= numPages; i += 1) {
      pages.push(i);
    }
  }
  return pages;
};

const keydownEventHandler = e => {
  const options = {
    parent: `.${styles.pagination}`,
  };
  return keyboardEventFocusNavigator(options)(e);
};

/**
 *
 * @param {object} label The labels to display
 * @param {number} page The page this component will represent
 * @param {bool} disabled Indicates that component is selectable.
 * @param {func} onPageClick Callback to handle page request events.
 * @param {function} getPaginationHref Helper function to generate the href in links.
 * @return {node} Returns a component representing the page.
 *
 */
const getPageButton = (
  label,
  page,
  disabled,
  onPageClick,
  getPaginationHref,
  ariaLabels
) => (
  <a
    className={classnames(
      styles.pageButton,
      'Pagination__btnPage fol',
      disabled ? styles.disabled : '',
      label >= 416 ? styles.blur : ''
    )}
    onClick={e => {
      e.preventDefault();
      if (label <= 416) {
        onPageClick(page, e);
        triggerTealiumAction(tealiumVariables, false, false, label);
      }
    }}
    href={label <= 416 ? getPaginationUrl(page.start, getPaginationHref) : null}
    {...ariaLabels}
    onKeyDown={keydownEventHandler}
    data-locator={`pagination_btn_${label}`}
  >
    {label}
  </a>
);

/**
 * The previous Button
 *
 * @param {object} label The labels to display
 * @param {number} page The page this component will represent
 * @param {bool} disabled Indicates that component is selectable.
 * @param {func} onPageClick Callback to handle page request events.
 * @param {function} getPaginationHref Helper function to generate the href in links.
 * @param {number} numPages total number of pages
 * @return {node} Returns a component representing the page.
 *
 */
const getPrevButton = (
  label,
  page,
  disabled,
  onPageClick,
  getPaginationHref,
  switchToMobileStyle,
  ariaLabels
) => (
  <a
    className={classnames(
      switchToMobileStyle
        ? styles.mobileStyleButton
        : styles.paginationOvalButton,
      'Pagination__btnPrev fol',
      disabled ? styles.disabled : ''
    )}
    onClick={e => {
      e.preventDefault();
      /* istanbul ignore else */
      if (typeof window !== 'undefined') {
        const sectionId = document.querySelector('#mainSectionBegins');
        /* istanbul ignore if: above selector will not included in test */
        if (sectionId) {
          sectionId.focus();
        }
      }
      /* istanbul ignore else */
      if (!disabled) {
        onPageClick(page, e);
        triggerTealiumAction(tealiumVariables, false, true, '');
      }
    }}
    href={disabled ? null : getPaginationUrl(page.start, getPaginationHref)}
    disabled={disabled ? 'true' : null}
    {...ariaLabels}
    onKeyDown={keydownEventHandler}
    data-locator={PAGINATION_CONSTANTS.PAGINATION_PREVBUTTON}
  >
    <Icon
      type="buttonarrow"
      alt="buttonarrow"
      className={classnames(styles.buttonIcon, styles.prevNavButtonCaret)}
    />
    <span>{label}</span>
  </a>
);

/**
 * The next Button
 *
 * @param {object} label The labels to display
 * @param {number} page The page this component will represent
 * @param {bool} disabled Indicates that component is selectable.
 * @param {func} onPageClick Callback to handle page request events.
 * @param {function} getPaginationHref Helper function to generate the href in links.
 * @param {number} numPages total number of pages
 * @return {node} Returns a component representing the page.
 *
 */
const getNextButton = (
  label,
  page,
  disabled,
  onPageClick,
  getPaginationHref,
  switchToMobileStyle,
  ariaLabels
) => (
  <a
    className={classnames(
      switchToMobileStyle
        ? styles.mobileStyleButton
        : styles.paginationOvalButton,
      disabled ? styles.disabled : '',
      'Pagination__btnNext fol'
    )}
    disabled={disabled ? 'true' : null}
    href={!disabled ? getPaginationUrl(page.start, getPaginationHref) : null}
    onClick={e => {
      e.preventDefault();
      /* istanbul ignore else */
      if (typeof window !== 'undefined') {
        const sectionId = document.querySelector('#mainSectionBegins');
        /* istanbul ignore if: above selector will not included in test */
        if (sectionId) {
          sectionId.focus();
        }
      }
      /* istanbul ignore else */
      if (!disabled) {
        onPageClick(page, e);
        triggerTealiumAction(tealiumVariables, true, false, '');
      }
    }}
    {...ariaLabels}
    onKeyDown={keydownEventHandler}
    data-locator={PAGINATION_CONSTANTS.PAGINATION_NEXTBUTTON}
  >
    <span>{label}</span>
    <Icon
      type="buttonarrow"
      alt="buttonarrow"
      className={classnames(styles.buttonIcon, styles.nextNavButtonCaret)}
    />
  </a>
);

const getButtonArrowAriaTags = (labels, page, labelText) => {
  const val = LabelUtils.replacePlaceholderValues(labels.ariaLinkLabel, [page]);
  return {
    'aria-label': `${labelText}${val}`,
  };
};

const getButtonNumberAriaTags = (labels, page, currentPage) => {
  if (currentPage === page) {
    return {
      'aria-label': LabelUtils.replacePlaceholderValues(
        labels.ariaCurrentLabel,
        [currentPage]
      ),
      'aria-current': true,
    };
  }
  return {
    'aria-label': LabelUtils.replacePlaceholderValues(labels.ariaLinkLabel, [
      page,
    ]),
  };
};

/**
 * the Page Box displayed when device is mobile or numPages is > 999
 * @param {number} currentPage current Page user is on
 * @param {number} numPages total number of pages
 * @param {boolean} switchToMobileStyle true when numPages >999 and device is desktop
 */
const mobilePageBox = (
  currentPage,
  numPages,
  switchToMobileStyle,
  paginationScreenReaderText
) => {
  return (
    <li
      className={classnames(
        switchToMobileStyle ? styles.displayPageBox : styles.pageBox
      )}
      data-locator={PAGINATION_CONSTANTS.PAGINATION_BOX}
    >
      <ul>
        <li>
          <div aria-hidden="true">
            {currentPage} / {numPages}
          </div>
          <span className="visuallyhidden">
            {LabelUtils.replacePlaceholderValues(paginationScreenReaderText, [
              currentPage,
              numPages,
            ])}
          </span>
        </li>
      </ul>
    </li>
  );
};

/**
 * Displays set of pages ex: 1 2 3 4 ... 24
 *
 * @param {boolean} switchToMobileStyle true when numPages >999 and device is desktop
 * @param {array} pagesInView array of pages to display
 * @param {number} currentPage current Page user is on
 * @param {number} perPage Items to show in a page
 * @param {func} onPageClick Called when page change is requested.
 * @param {func} getPaginationHref Helper function to generate the href in links.
 * @param {object} buttonLabels Labels used on the next and prev buttons.
 */
const linkSet = (
  switchToMobileStyle,
  pagesInView,
  currentPage,
  perPage,
  onPageClick,
  getPaginationHref,
  buttonLabels
) => {
  return (
    <ul
      className={classnames(
        switchToMobileStyle ? styles.disableLinkSet : styles.pageLinkSet
      )}
    >
      {pagesInView.map((val, index) => (
        <li
          key={`pagin-instance-key-${index}`}
          className={classnames(
            styles.pageLink,
            val === PAGINATION_CONSTANTS.DISPLAY_ELLIPSES ? 'ellipses' : '',
            val === currentPage ? styles.inView : ''
          )}
        >
          <div className={classnames(styles.pageLink)}>
            {val === PAGINATION_CONSTANTS.DISPLAY_ELLIPSES
              ? '...'
              : getPageButton(
                  val,
                  getStartAndEnd(val, perPage),
                  val === currentPage,
                  onPageClick,
                  getPaginationHref,
                  getButtonNumberAriaTags(buttonLabels, val, currentPage)
                )}
          </div>
        </li>
      ))}
    </ul>
  );
};

/**
 * Stateless function for rendering Pagination Component
 */
const Pagination = ({
  start,
  onPageClick,
  perPage,
  numFound,
  getPaginationHref,
  buttonLabels,
  channelType,
  className,
  handlePaginationTealiumEvent,
  tealiumData,
  sort,
}) => {
  if (start < 0) {
    throw Error(`Invalid argument Error: start=${start}`);
  }
  if (perPage < 0) {
    throw Error(`Invalid argument Error: perPage=${perPage}`);
  }
  if (numFound < 0) {
    throw Error(`Invalid argument Error: numFound=${numFound}`);
  }
  if (start > numFound) {
    return null;
  }

  const numPages = getNumberOfPages({ numFound, perPage });
  const currentPage = getCurrentPage({ start, perPage });
  const pagesInView = getPagesInView({ numFound, perPage, currentPage });
  const disablePrevButton = currentPage <= 1;
  const disableNextButton = currentPage >= numPages;
  tealiumVariables = {};
  tealiumVariables = {
    handlePaginationTealiumEvent,
    tealiumData,
    sort,
    currentPage,
    numFound,
    perPage,
  };

  /* switch to mobile styling when num of total pages is 1000+ and resolution is
  desktop resolution to prevent pagination from breaking*/
  const switchToMobileStyle = numPages > 999 && channelType === 'desktop';

  if (pagesInView < 2) {
    return null;
  }
  return (
    <div className={className}>
      <ul className={styles.pagination}>
        <li>
          {getPrevButton(
            buttonLabels.back,
            getStartAndEnd(currentPage - 1, perPage),
            disablePrevButton,
            onPageClick,
            getPaginationHref,
            switchToMobileStyle,
            getButtonArrowAriaTags(
              buttonLabels,
              currentPage - 1,
              PAGINATION_CONSTANTS.PAGINATION_PREVBUTTON_LABEL
            )
          )}
        </li>
        <li>
          {linkSet(
            switchToMobileStyle,
            pagesInView,
            currentPage,
            perPage,
            onPageClick,
            getPaginationHref,
            buttonLabels
          )}
        </li>
        {mobilePageBox(
          currentPage,
          numPages,
          switchToMobileStyle,
          buttonLabels.pageNumberScreenReaderText
        )}
        <li>
          {getNextButton(
            buttonLabels.next,
            getStartAndEnd(currentPage + 1, perPage),
            disableNextButton,
            onPageClick,
            getPaginationHref,
            switchToMobileStyle,
            getButtonArrowAriaTags(
              buttonLabels,
              currentPage + 1,
              PAGINATION_CONSTANTS.PAGINATION_NEXTBUTTON_LABEL
            )
          )}
        </li>
      </ul>
    </div>
  );
};

/**
 * @param {number} start Start index for items to paginate
 * @param {number} numFound Total number of items found.
 * @param {number} perPage Items to show in a page
 * @param {func} onPageClick Called when page change is requested.
 * @param {func} getPaginationHref Helper function to generate the href in links.
 * @param {object} buttonLabels Labels used on the next and prev buttons.
 * @param {string} channelType determines whether 'mobile' or 'desktop'
 */
Pagination.propTypes = {
  start: number,
  numFound: number,
  perPage: number,
  onPageClick: func,
  getPaginationHref: func,
  buttonLabels: shape({
    back: string,
    next: string,
    ariaNavLabel: string,
    ariaLinkLabel: string,
    ariaCurrentLabel: string,
  }),
  channelType: string,
  className: string,
  handlePaginationTealiumEvent: func,
  tealiumData: object,
  sort: string,
};

Pagination.defaultProps = {
  perPage: 48,
  start: 0,
  numFound: 0,
  onFilterUpdate: () => null, // Sonar hack
  getPaginationHref: () => null,
  buttonLabels: {
    next: 'Next',
    back: 'Back',
    ariaNavLabel: 'Products Pagination Navigation',
    ariaLinkLabel: 'Go to Page {0}',
    ariaCurrentLabel: 'Current Page, Page {0}',
    pageNumberScreenReaderText: 'Page {0} out of {1}',
  },
};

export default Pagination;
