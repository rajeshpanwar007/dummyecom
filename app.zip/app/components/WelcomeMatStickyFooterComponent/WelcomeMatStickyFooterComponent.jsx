import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import '@bbb-app/styles/thirdparty/flags.css';
import { getCookieValue } from '@bbb-app/utils/countryCurrencyUtils';
import Button from '@bbb-app/core-ui/button';
import Styles from './WelcomeMatStickyFooterComponent.css';

export class WelcomeMatStickyFooterComponent extends React.PureComponent {
  constructor(props) {
    super(props);
    this.openWelcomeMatModal = this.openWelcomeMatModal.bind(this);
    this.getShippingLabel = this.getShippingLabel.bind(this);
  }

  componentDidMount() {
    if (this.props.setWelcomeMatRenderedStatus) {
      this.props.setWelcomeMatRenderedStatus();
    }
  }

  getShippingLabel() {
    const { labels } = this.props;
    const shipInternationalLabel = LabelsUtil.getLabel(
      labels,
      'Global.welMatInternationShipping'
    );
    return shipInternationalLabel;
  }

  openWelcomeMatModal() {
    if (this.props.setRenderWelcomeMatBtnClicked) {
      this.props.applyModalCss(true);
      this.props.setRenderWelcomeMatBtnClicked(true);
    }
  }
  render() {
    const countryCookie = getCookieValue();
    if (countryCookie) {
      this.country = countryCookie.country.toLowerCase();
    }
    const countryFlagClass = this.country ? `flag${this.country}` : null;
    const flagClassNames = `flag ${countryFlagClass}`;
    return (
      <div className={classnames(Styles.welcomeMatStickyFooter)}>
        <div className={Styles.welcomeMatStickyFooterContent}>
          <span className={classnames(flagClassNames, 'ml2 mr1')} />
          <Button
            className={Styles.shippingLabel}
            onClick={this.openWelcomeMatModal}
            theme="link"
            variation="blacklink"
            isIconAfterContent
            iconProps={{
              className: classnames(Styles.iconTop, 'ml1'),
              height: '10',
              type: 'caret',
              width: '10',
            }}
          >
            {this.getShippingLabel()}
          </Button>
        </div>
      </div>
    );
  }
}

WelcomeMatStickyFooterComponent.propTypes = {
  labels: PropTypes.object,
  setWelcomeMatRenderedStatus: PropTypes.func,
  setRenderWelcomeMatBtnClicked: PropTypes.func,
  applyModalCss: PropTypes.func,
};

export default WelcomeMatStickyFooterComponent;
