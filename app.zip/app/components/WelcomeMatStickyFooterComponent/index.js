export { default } from './WelcomeMatStickyFooterComponent';
