// eslint-disable-next-line max-lines

import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import _, { find } from 'lodash';
import { pathOr, isEmpty } from 'lodash/fp';
import { Redirect } from 'react-router';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import Checkbox from '@bbb-app/core-ui/checkbox';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import Icon from '@bbb-app/core-ui/icon';
import QasValidation from '@bbb-app/qas-validation/containers/QasValidation.async';
import getEncodedValue from '@bbb-app/utils/getEncodedValue';
import dangerousHTML from '@bbb-app/hoc/dangerousHTML';
import InputRadio from '@bbb-app/core-ui/input-radio';
import PrimaryLink from '@bbb-app/core-ui/primary-link';
import ModalDialog from '@bbb-app/modal-dialog/containers/ModalDialog';
import Notification from '@bbb-app/core-ui/notification';
import '@bbb-app/assets/icons/plus.svg';
import { ifStateRequiresDoubleOptin } from '@bbb-app/utils/checkoutUtils/checkoutStoreUtil';
import styles from './BeyondPlus.css';
import CreditCardTile from '../Pages/CreditCardList/Tile';
import {
  RENEW_MEMBERSHIP,
  AUTO_RENEW,
  DO_NOT_RENEW,
  TERMS_AND_CONDITIONS_DOUBLE_OPTIN,
} from './BeyondPlusConstants';
import ManageAddCreditCard from '../Pages/CreditCardList/ManageAddCreditCard';
import Skeleton from './Skeleton';
import ContentFullWidthContentBlock from '../../containers/PureContent/ContentFullWidthContentBlock';
import BeyondPlusGiftWidget from './BeyondPlusGiftWidget.async';
import { BPLUS_GIFT_CHECKOUTPAGE_URL, RENEWAL, SITEID } from './constants';
export class BeyondPlus extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      bPAutoRenewIndicator: 'N',
      radioOptions: DO_NOT_RENEW,
      disableUpdateBtn: true,
      disableRadioBtns: true,
      disableCancelLink: true,
      navigateToBeyondPlusSubsciption: false,
      addMountedState: false,
      creditCardData: null,
      editCard: false,
      shouldShowNotification: true,
      doubleOptinCheckBoxState: false,
      infoModalMountedState: false,
    };
    this.getAddCreditCard = this.getAddCreditCard.bind(this);
    this.getCreditCardTile = this.getCreditCardTile.bind(this);
    this.getRenewCreditCardSection = this.getRenewCreditCardSection.bind(this);
    this.changeRenewOption = this.changeRenewOption.bind(this);
    this.updateSetting = this.updateSetting.bind(this);
    this.resetRenewOptions = this.resetRenewOptions.bind(this);
    this.onSubscribeBeyondPlusClick = this.onSubscribeBeyondPlusClick.bind(
      this
    );
    this.getAutoRenewMsg = this.getAutoRenewMsg.bind(this);
    this.addModalClickHandler = this.addModalClickHandler.bind(this);
    this.toggleAddModalState = this.toggleAddModalState.bind(this);
    this.addToCart = this.addToCart.bind(this);
    this.doubleOptinHandler = this.doubleOptinHandler.bind(this);
    this.toggleCancelInfoModalState = this.toggleCancelInfoModalState.bind(
      this
    );
    this.isdoubleOptinRequired = false;
    this.showOptinCheckbox = false;
  }

  componentWillReceiveProps(newProps) {
    const bpData = pathOr(null, 'accData', newProps.bpAccDetails);
    if (bpData) {
      this.addNotificationMsgEvents();
      const {
        creditCardInfo,
        bPAutoRenewIndicator,
        cardExpired,
        bPStatus,
      } = bpData;
      const autoRenewValue = this.getAutoRenewValue(
        newProps.bpAccDetails.isRenewFetching,
        newProps.bpAccDetails.isAccDetailsFetching,
        bPAutoRenewIndicator,
        creditCardInfo
      );
      const disableAutoRenewRadioBtn =
        newProps.bpAccDetails.isRenewFetching ||
        !creditCardInfo ||
        !creditCardInfo.creditCardNumber ||
        cardExpired === 'true' ||
        bPStatus === 'C' ||
        bPStatus === 'E' ||
        bPStatus === 'R';
      this.setState({
        bPAutoRenewIndicator,
        radioOptions: autoRenewValue,
        disableRadioBtns: disableAutoRenewRadioBtn,
      });
    }
  }

  onSubscribeBeyondPlusClick = () => {
    if (this.props.isUserWithINGracePeriod) {
      this.addToCart({
        cohortEvent: RENEWAL,
      });
    } else {
      this.setState({
        navigateToBeyondPlusSubsciption: true,
      });
    }
  };

  getAutoRenewValue = (
    isRenewFetching,
    isAccDetailsFetching,
    bPAutoRenewIndicator,
    creditCardInfo
  ) => {
    let autoRenewValue = this.state.radioOptions;

    if (
      (this.props.bpAccDetails.isAccDetailsFetching && !isAccDetailsFetching) ||
      (this.props.bpAccDetails.isRenewFetching && !isRenewFetching)
    ) {
      autoRenewValue = bPAutoRenewIndicator === 'Y' ? AUTO_RENEW : DO_NOT_RENEW;
    }
    if (!creditCardInfo || !creditCardInfo.creditCardNumber) {
      autoRenewValue = DO_NOT_RENEW;
    }
    return autoRenewValue;
  };

  /**
   * @function getBillingAddress
   * this function fetches the billing address for the credit card tile component.
   */
  getBillingAddress = addresses => {
    let billingAddress = {};
    const linkedCreditCardAddress = pathOr(
      {},
      'defaultCreditCard.billingAddress',
      this.props.data
    );
    const preferredBillingAddress = pathOr({}, 'billingAddress', addresses);
    const secondaryAddresses = pathOr({}, 'secondaryAddresses', addresses);
    if (!isEmpty(linkedCreditCardAddress) && linkedCreditCardAddress.address1) {
      /* If address is present linked to credit card, then it is set as default address */
      billingAddress = linkedCreditCardAddress;
    } else if (!isEmpty(preferredBillingAddress)) {
      let billingAddressExists = false;
      Object.keys(secondaryAddresses).forEach(key => {
        if (
          secondaryAddresses[key].repositoryId ===
          preferredBillingAddress.repositoryId
        ) {
          billingAddressExists = true;
        }
      });
      if (billingAddressExists) {
        /* If preferred billing address is present in the list of secondary addresses, then it is set as default address */
        billingAddress = preferredBillingAddress;
      } else if (!isEmpty(secondaryAddresses)) {
        /* If preferred billing address is not present in the list of secondary addresses, then first secondary address is set as default address */
        const firstKey = Object.keys(secondaryAddresses)[0];
        billingAddress = secondaryAddresses[firstKey];
      }
    } else if (!isEmpty(secondaryAddresses)) {
      /* If linked credit card address is not present and preferred billing address is not present in the list of secondary addresses, then first secondary address is set as default address */
      const firstKey = Object.keys(secondaryAddresses)[0];
      billingAddress = secondaryAddresses[firstKey];
    } else {
      /* If no default address is present, then the default address is set empty */
      billingAddress = {};
    }
    return billingAddress;
  };

  getAddCreditCard() {
    return (
      <Cell
        className={classnames(
          'small-12 medium-4 large-3 center-align mr2 sm-mb2',
          styles.addnewTileParent
        )}
      >
        <PrimaryLink
          className={classnames(styles.addnewTile)}
          href={pathOr('#', 'endpoints.creditCards', this.props)}
        >
          <div>
            <Icon type="plus" width="14" height="14" className="block" />
            {LabelsUtil.getLabel(
              this.props.labels,
              'beyondPlus.bPAddCreditCard'
            )}
          </div>
        </PrimaryLink>
      </Cell>
    );
  }
  getCreditCardTile(creditCardInfo, disableEditLink, cardNickName) {
    const {
      labels,
      customerId,
      deleteCreditCard,
      addresses,
      isPLCCEnabled,
      isUPLCCEnabled,
    } = this.props;
    const data = {
      creditCardNumber: creditCardInfo.creditCardNumber,
      creditCardType: creditCardInfo.creditCardType,
      subCreditCardType: creditCardInfo.subCreditCardType,
      expirationDayOfMonth: creditCardInfo.expirationDayOfMonth,
      expirationMonth: creditCardInfo.expirationMonth,
      expirationYear: creditCardInfo.expirationYear,
      nameOnCard: creditCardInfo.nameOnCard,
      billingAddress: this.getBillingAddress(addresses),
      repositoryId: creditCardInfo.creditCardId,
    };
    const addressTypeLabel = LabelsUtil.getLabel(labels, 'billingAddressLbl');
    return (
      <CreditCardTile
        data={data}
        isBeyondPlusPage
        labels={labels}
        disableEditLink={disableEditLink}
        addressTypeLabel={addressTypeLabel}
        addModalClickHandler={this.addModalClickHandler}
        customerId={customerId}
        isPLCCEnabled={isPLCCEnabled}
        isUPLCCEnabled={isUPLCCEnabled}
        deleteCreditCard={deleteCreditCard}
        cardNickName={cardNickName}
      />
    );
  }

  getLearnMoreMsg = () => {
    const learnMorePreLabel = LabelsUtil.getLabel(
      this.props.labels,
      'beyondPlus.learnMorePreLabel'
    );
    const learnMorePostLabel = LabelsUtil.getLabel(
      this.props.labels,
      'beyondPlus.learnMorePostLabel'
    );
    const hereLabel = LabelsUtil.getLabel(
      this.props.labels,
      'beyondPlus.clickEventName'
    );
    return (
      <Paragraph className={classnames(styles.learnMorePara)}>
        <span>{learnMorePreLabel}</span>
        <Button
          className={classnames(styles.hereLink)}
          onClick={this.toggleCancelInfoModalState}
          theme={'link'}
          variation={'bluelink'}
        >
          {hereLabel}
        </Button>
        <span>{learnMorePostLabel}</span>
      </Paragraph>
    );
  };
  getAutoRenewMsg(bPStatus) {
    const cohortCode = pathOr(
      '',
      'accData.cohortDetails.cohortCode',
      this.props.bpAccDetails
    );
    const cohortBPAutoRenewMsg = LabelsUtil.getLabel(
      this.props.labels,
      'beyondPlus.newBplusAutoRenewalMsg'
    );

    if (bPStatus !== 'E' && bPStatus !== 'C' && bPStatus !== 'R') {
      const bpAutoRenewMsg = LabelsUtil.replacePlaceholderValues(
        cohortBPAutoRenewMsg,
        [
          LabelsUtil.getLabel(
            this.props.cohortLabels,
            `${cohortCode}_tncCTALink`
          ),
        ]
      );

      const DangerousText = dangerousHTML(DangerousText);
      return (
        <DangerousText className={styles.autoRenewMsg}>
          {bpAutoRenewMsg}
        </DangerousText>
      );
    }
    return null;
  }
  getUserOptedState = () => {
    const bPDoubleOptinDate = pathOr(
      null,
      'component.profile.userSiteItems.bPDoubleOptinDate',
      this.props.selectBpRenewalData
    );
    const profileOptinDate = pathOr(
      null,
      'userSiteItems.bPDoubleOptinDate',
      this.props.profile
    );
    return Boolean(bPDoubleOptinDate || profileOptinDate);
  };
  getRenewCreditCardSection(creditCardInfo, renewalDate, bPStatus) {
    const {
      labels,
      isUserWithINGracePeriod,
      isDoubleOptinEnabled,
    } = this.props;
    const doubleOptinCheckboxText = this.getBeyondPlusDoubleOptinText();
    const termsLabelDoubleOptin = isEmpty(doubleOptinCheckboxText)
      ? TERMS_AND_CONDITIONS_DOUBLE_OPTIN
      : doubleOptinCheckboxText;

    const shouldDisableCheckbox =
      this.optinCheckboxHandler() || this.getUserOptedState();
    this.showOptinCheckbox =
      this.isdoubleOptinRequired && this.state.radioOptions === AUTO_RENEW;
    return (
      <Cell
        className={classnames(
          'small-12 medium-7 large-9 center-align sm-mb2',
          !creditCardInfo ? 'disabled' : '',
          styles.renewSection
        )}
      >
        <Heading
          level={6}
          className={classnames(
            styles.renewHeader,
            styles.marginBottom,
            'mb15',
            'pb1'
          )}
        >
          {isUserWithINGracePeriod ? (
            <React.Fragment>
              {LabelsUtil.getLabel(labels, 'beyondPlus.bPlusNotRenewedMessage')}
            </React.Fragment>
          ) : (
            <React.Fragment>
              {this.state.radioOptions === AUTO_RENEW ? (
                <React.Fragment>
                  {LabelsUtil.getLabel(labels, 'beyondPlus.bPlusRenewalDate')}:
                </React.Fragment>
              ) : (
                <React.Fragment>
                  {LabelsUtil.getLabel(labels, 'beyondPlus.beyondPlusExpDate')}
                </React.Fragment>
              )}
              <span className="md-ml1 sm-right xs-right">
                {renewalDate && renewalDate.time ? renewalDate.time : ''}
              </span>
            </React.Fragment>
          )}
        </Heading>
        <GridX className={classnames(styles.renewRadioBtns, 'mb2 pb2')}>
          <Cell className="small-12 large-8 sm-mb3">
            <div className="mb2">
              <InputRadio
                id={AUTO_RENEW}
                name={RENEW_MEMBERSHIP}
                labelContent={LabelsUtil.getLabel(
                  labels,
                  'beyondPlus.autoRenewLabel'
                )}
                value={AUTO_RENEW}
                checked={this.state.radioOptions === AUTO_RENEW}
                onClick={this.changeRenewOption}
                disabled={this.state.disableRadioBtns === true}
                deactivated={this.state.disableRadioBtns === true}
              />
            </div>
            <InputRadio
              id={DO_NOT_RENEW}
              name={RENEW_MEMBERSHIP}
              labelContent={LabelsUtil.getLabel(
                labels,
                'beyondPlus.doNotRenewLabel'
              )}
              value={DO_NOT_RENEW}
              checked={this.state.radioOptions === DO_NOT_RENEW}
              onClick={this.changeRenewOption}
              disabled={this.state.disableRadioBtns === true}
              deactivated={this.state.disableRadioBtns === true}
            />
          </Cell>
          <Cell className={classnames('small-12 large-4 center')}>
            <Button
              theme={
                this.state.disableUpdateBtn === true ? 'deactivated' : 'primary'
              }
              data-locator="account_beyond_subscription"
              onClick={this.updateSetting}
              className="block mb1 fullWidth md-mb02"
              disabled={this.state.disableUpdateBtn === true}
            >
              {LabelsUtil.getLabel(labels, 'beyondPlus.bPlusSettings')}
            </Button>
          </Cell>
          {isDoubleOptinEnabled &&
            this.showOptinCheckbox && (
              <Cell className="mt2">
                <Checkbox
                  disabled={shouldDisableCheckbox}
                  checked={
                    shouldDisableCheckbox || this.state.doubleOptinCheckBoxState
                  }
                  label={termsLabelDoubleOptin}
                  onSelect={this.doubleOptinHandler}
                  className={styles.checkboxTnc}
                  variation="multiline"
                  name={termsLabelDoubleOptin}
                  data-locator="bpLanding-Optincheckbox"
                />
              </Cell>
            )}
        </GridX>
        {this.getLearnMoreMsg()}
        {this.getAutoRenewMsg(bPStatus)}
      </Cell>
    );
  }
  getComponent = contentToShow => {
    const dataToShow = {};
    const content = LabelsUtil.replacePlaceholderValues(contentToShow, [
      pathOr(
        '',
        'accData.cohortDetails.cohortGracePeriodDate',
        this.props.bpAccDetails
      ),
    ]);

    if (content && content.includes('[SUBSCRIBE]')) {
      const contentArray = content.split('[SUBSCRIBE]');
      if (contentArray.length >= 2) {
        dataToShow.component = (
          <React.Fragment>
            {contentArray[0]}
            {/* eslint-disable */}
            <a
              className="bpSubscipPageNotifyMsg"
              onClick={() =>
                this.addToCart({
                  cohortEvent: RENEWAL,
                })}
            >
              {LabelsUtil.getLabel(
                this.props.labels,
                "beyondPlus.clickEventName"
              )}
            </a>
            {/* eslint-enable */}
            {contentArray[1]}
          </React.Fragment>
        );
      }
    } else {
      dataToShow.content = content;
    }

    return dataToShow;
  };

  getNotificationContent = () => {
    let contentToShow = {};
    const bpData = this.props.bpAccDetails.accData;
    const { isUserWithINGracePeriod, labels } = this.props;
    const { labelKey, status } = this.getLabelKey(bpData);

    if (labelKey) {
      contentToShow.content = LabelsUtil.getLabel(labels, labelKey);
    }
    if (isUserWithINGracePeriod) {
      contentToShow = this.getComponent(contentToShow.content);
    }
    return {
      status,
      contentToShow,
    };
  };

  /**
  getLegacyLabelKey = bpData => {
    let labelKey = null;
    let status = null;

    if (bpData.bPStatus === 'C') {
      status = 'success';
      labelKey = 'beyondPlus.bpOfferCancelled';
    } else if (bpData.bPStatus === 'E') {
      status = 'error';
      labelKey = 'beyondPlus.bpOfferExpired';
    } else if (bpData.bPStatus === 'R') {
      status = 'error';
      labelKey = 'beyondPlus.bpOfferRevoked';
    } else if (
      !bpData.creditCardInfo ||
      !bpData.creditCardInfo.creditCardNumber
    ) {
      status = 'success';
      labelKey = 'beyondPlus.bpCardAbsent';
    } else if (bpData.cardExpired) {
      status = 'error';
      labelKey = 'beyondPlus.bpCardExpired';
    } else if (bpData.cardExpiringSoon) {
      status = 'alert';
      labelKey = 'beyondPlus.bpCardExpiring';
    }

    return {
      status,
      labelKey,
    };
  };
  */

  getLabelKey = bpData => {
    let labelKey = null;
    let status = null;
    if (bpData.bPStatus === 'C') {
      status = 'alert';
      labelKey = 'beyondPlus.bpOfferCancelled';
    } else if (bpData.bPStatus === 'E' && this.props.isUserWithINGracePeriod) {
      status = 'alert';
      labelKey = 'beyondPlus.bpGracePeriod';
    } else if (bpData.bPStatus === 'E') {
      status = 'alert';
      labelKey = 'beyondPlus.bpOfferExpired';
    } else if (bpData.bPStatus === 'R') {
      status = 'alert';
      labelKey = 'beyondPlus.bpOfferRevoked';
    } else if (
      !bpData.creditCardInfo ||
      !bpData.creditCardInfo.creditCardNumber
    ) {
      status = 'success';
      labelKey = 'beyondPlus.bpCardAbsent';
    } else if (bpData.cardExpired) {
      status = 'error';
      labelKey = 'beyondPlus.bpCardExpired';
    } else if (bpData.cardExpiringSoon) {
      status = 'alert';
      labelKey = 'beyondPlus.bpCardExpiring';
    }
    return {
      labelKey,
      status,
    };
  };

  getNotificationMessage = () => {
    const { status, contentToShow } = this.getNotificationContent();
    if (isEmpty(contentToShow) || !this.state.shouldShowNotification) {
      return null;
    }
    return (
      <div className={styles.notificationContainer}>
        {this.getNotificationContainer(status, contentToShow)}
      </div>
    );
  };
  getNotificationContainer = (status, contentToShow) => {
    return (
      <Notification
        status={status}
        {...contentToShow}
        hasCloseButton
        hasStatusIcon
        closeClick={this.closeClick}
        wrapperClass="mt2"
      />
    );
  };
  /**
  getLegacyNotificationMessage = (status, content) => {
    return (
      <div className={styles.notificationContainer}>
        <Notification
          status={status}
          content={content}
          hasCloseButton={false}
          wrapperClass="mt2"
        />
      </div>
    );
  };
  */
  getSubscriptionTile = () => {
    const { bpAccDetails, labels } = this.props;
    const bpData = bpAccDetails.accData;
    return bpData.bPStatus === 'E' || bpData.bPStatus === 'C' ? (
      <Cell
        className={classnames(
          'small-12 medium-11 large-12 center-align mt3',
          styles.renewSection
        )}
      >
        <GridX>
          <Cell className={classnames('small-12 large-12 mb2')}>
            <span className={styles.subscribeText}>
              {LabelsUtil.getLabel(labels, 'beyondPlus.subscribeText')}
            </span>
          </Cell>
          <Cell className={classnames('small-12 large-4')}>
            <Button
              theme="primary"
              variation="fullWidth"
              onClick={this.onSubscribeBeyondPlusClick}
            >
              {LabelsUtil.getLabel(labels, 'beyondPlus.subscribeBtnLabel')}
            </Button>
          </Cell>
        </GridX>
      </Cell>
    ) : (
      ''
    );
  };
  getBeyondPlusDoubleOptinText() {
    const { referredContent, doubleOptinContent } = this.props;
    let doubleOptinCheckboxText = '';
    let id = null;
    let referredItem;
    if (!isEmpty(doubleOptinContent)) {
      referredItem = find(doubleOptinContent, {
        key: 'doubleOptinCheckbox',
      });
    }
    if (!isEmpty(referredItem)) {
      id = referredItem.id;
    }
    if (!isEmpty(id) && pathOr(false, `content[${id}]`, referredContent)) {
      doubleOptinCheckboxText = referredContent.content[id].content;
    }
    return doubleOptinCheckboxText;
  }
  getCancelInfoModal = renewalDate => {
    const { labels } = this.props;
    const renewDate = pathOr('', 'time', renewalDate);
    const modalContent = LabelsUtil.getLabel(
      labels,
      'beyondPlus.cancellnfoModalContent'
    );
    const cancellnfoModalContent = LabelsUtil.replacePlaceholderValues(
      modalContent,
      [renewDate]
    );
    return (
      <ModalDialog
        mountedState={this.state.infoModalMountedState}
        toggleModalState={this.toggleCancelInfoModalState}
        titleAriaLabel="aria-label"
        verticallyCenter
        variation="small"
        scrollDisabled={false}
      >
        <Cell className={classnames(styles.cancelMembershipModal, 'pb2 pt1')}>
          <Heading
            className={classnames(styles.cancelMembershipHeading, 'mb2')}
          >
            {LabelsUtil.getLabel(labels, 'beyondPlus.cancelMembershipHeading')}
          </Heading>
          <Paragraph>{cancellnfoModalContent}</Paragraph>
        </Cell>
      </ModalDialog>
    );
  };
  doubleOptinHandler(selected) {
    if (this.state.bPAutoRenewIndicator === 'N') {
      if (!selected && this.state.doubleOptinCheckBoxState) {
        this.setState({
          doubleOptinCheckBoxState: false,
          disableUpdateBtn: true,
        });
      } else if (selected && !this.state.doubleOptinCheckBoxState) {
        this.setState({
          doubleOptinCheckBoxState: true,
          disableUpdateBtn: false,
          disableCancelLink: false,
        });
      }
    }
  }
  toggleCancelInfoModalState = () => {
    this.setState({ infoModalMountedState: !this.state.infoModalMountedState });
  };
  optinCheckboxHandler() {
    const bPAutoRenewIndicator = pathOr(
      '',
      'bPAutoRenewIndicator',
      this.props.selectBpRenewalIndicator
    );
    return bPAutoRenewIndicator === 'Y';
  }
  addToCart = args => {
    const params = { ...args };
    if (!params.cohortCode) {
      params.cohortCode = pathOr(
        '',
        'accData.cohortDetails.cohortCode',
        this.props.bpAccDetails
      );
    }
    this.props.addBeyondPlusToCart(params);
  };

  closeClick = () => {
    this.setState({
      shouldShowNotification: false,
    });
  };

  addModalClickHandler(e, data) {
    e.preventDefault();
    if (data) {
      this.setState(
        {
          creditCardData: Object.assign({}, data),
          editCard: true,
        },
        this.toggleAddModalState(true)
      );
    } else {
      this.setState(
        {
          creditCardData: {},
          editCard: false,
        },
        this.toggleAddModalState(true)
      );
    }
  }

  toggleAddAddressQasState = qasState => {
    this.props.updateAddAddressModalQasVisibility(qasState);
    this.props.emptyQasData();
  };

  toggleAddModalState = state => {
    this.props.resetState(null);
    this.setState({ addMountedState: state });
  };

  checkAddEditAddress = data => {
    this.child.checkAddEditAddress(data);
  };

  addNotificationMsgEvents = () => {
    const notificationAnchor = document.querySelector(
      '.bpSubscipPageNotifyMsg'
    );
    if (notificationAnchor) {
      notificationAnchor.addEventListener(
        'click',
        this.handleNotificationMsgClick
      );
    }
  };
  handleNotificationMsgClick = e => {
    e.preventDefault();
    const path = e.target.getAttribute('href');
    this.props.redirectTo(path);
  };

  changeRenewOption(event) {
    let disableBtn = false;
    if (this.props.isDoubleOptinEnabled) {
      if (event.target.value === AUTO_RENEW) {
        this.showOptinCheckbox = true;
      } else {
        this.showOptinCheckbox = false;
      }
    }
    if (this.props.isDoubleOptinEnabled) {
      this.isdoubleOptinRequired = ifStateRequiresDoubleOptin(
        this.getBillingAddress(this.props.addresses),
        this.props.bpCheckoutPageConfig
      );
      disableBtn =
        this.isdoubleOptinRequired &&
        this.showOptinCheckbox &&
        !this.getUserOptedState() &&
        this.state.bPAutoRenewIndicator === 'N' &&
        event.target.value === AUTO_RENEW &&
        !this.state.doubleOptinCheckBoxState;
    }

    const disableButton =
      (this.state.bPAutoRenewIndicator === 'Y' &&
        event.target.value === AUTO_RENEW) ||
      (this.state.bPAutoRenewIndicator === 'N' &&
        event.target.value === DO_NOT_RENEW) ||
      disableBtn;
    this.setState({
      radioOptions: event.target.value,
      disableUpdateBtn: disableButton,
      disableCancelLink: disableButton,
    });
  }
  createOptinData = () => {
    const { profile } = this.props;
    const email = pathOr('', 'email', profile);
    const repositoryId = pathOr('', 'repositoryId', profile);
    return {
      Profile_Id: repositoryId,
      EmailOptin: {
        Optin: {
          [SITEID]: true,
        },
        Email: getEncodedValue(email),
      },
    };
  };
  updateSetting() {
    const toRenew = this.state.radioOptions === AUTO_RENEW;
    this.props.updateRenewStatus(toRenew, this.state.doubleOptinCheckBoxState);
    if (toRenew) {
      const optinData = this.createOptinData();
      this.props.setPreferenceCommunication(optinData);
    }
    this.setState({
      disableUpdateBtn: true,
      disableCancelLink: true,
    });
  }
  resetRenewOptions() {
    this.setState({
      radioOptions:
        this.state.bPAutoRenewIndicator === 'Y' ? AUTO_RENEW : DO_NOT_RENEW,
      disableCancelLink: true,
      disableUpdateBtn: true,
    });
  }
  redirectToCheckoutIfRequired = () => {
    const {
      isBeyondPlusItemAddedToCart,
      isBeyondPlusGiftAddedToCart,
      beyondPlusCheckout,
    } = this.props;
    if (isBeyondPlusItemAddedToCart) {
      window.location.href = beyondPlusCheckout || '/store/beyondPlusCheckout';
    } else if (isBeyondPlusGiftAddedToCart) {
      window.location.href = BPLUS_GIFT_CHECKOUTPAGE_URL;
    }
    return null;
  };
  renderBenifitContent = () => {
    return (
      <div className={styles.benefitContainer}>
        <div>
          <span className={'md-ml2 sm-ml1'}>
            {LabelsUtil.getLabel(
              this.props.labels,
              'beyondPlus.benifitmessage'
            )}
          </span>
          <hr className={styles.line} />
        </div>
        <div className={'mt2'}>
          <ContentFullWidthContentBlock
            params={this.props.params}
            styleVariation="V2"
            contentId={`${pathOr(
              '',
              'accData.cohortDetails.cohortCode',
              this.props.bpAccDetails
            )}_beyond_plus_tools_service_module`}
          />
        </div>
      </div>
    );
  };
  render() {
    if (
      this.props.bpAccDetails.isAccDetailsFetching ||
      !this.props.bpAccDetails.accData
    )
      return <Skeleton />;
    const { navigateToBeyondPlusSubsciption } = this.state;
    const { beyondPlus } = this.props.endpoints;
    if (navigateToBeyondPlusSubsciption) return <Redirect to={beyondPlus} />;
    const {
      creditCardInfo,
      renewalDate,
      bPStatus,
    } = this.props.bpAccDetails.accData;
    const disableEditLink =
      bPStatus === 'E' || bPStatus === 'C' || bPStatus === 'R';

    const creditCardList = pathOr([], 'creditCards', this.props.data);
    let defaultCardNickName = '';
    const defaultCreditCardId = pathOr(
      null,
      'defaultCreditCard.id',
      this.props.data
    );
    _.forOwn(creditCardList, (value, key) => {
      if (value.id === defaultCreditCardId) {
        defaultCardNickName = key;
      }
    });

    const creditTile = !creditCardInfo
      ? this.getAddCreditCard()
      : this.getCreditCardTile(
          creditCardInfo,
          disableEditLink,
          defaultCardNickName
        );
    this.isdoubleOptinRequired = ifStateRequiresDoubleOptin(
      this.getBillingAddress(this.props.addresses),
      this.props.bpCheckoutPageConfig
    );
    return (
      <React.Fragment>
        {this.redirectToCheckoutIfRequired()}
        {this.getNotificationMessage()}
        <GridX className="mt15 grid-margin-x grid-margin-y">
          {creditTile}
          {this.getRenewCreditCardSection(
            creditCardInfo,
            renewalDate,
            bPStatus
          )}
          {this.getSubscriptionTile()}
        </GridX>
        <ModalDialog
          mountedState={this.state.addMountedState}
          toggleModalState={this.toggleAddModalState}
          titleAriaLabel="Add credit card"
          variation="medium"
          verticallyCenter
        >
          <ManageAddCreditCard
            onCancelLinkClick={this.toggleAddModalState}
            onSubmitLinkClick={this.toggleAddModalState}
            creditCardData={this.state.creditCardData}
            editCard={this.state.editCard}
            isBeyondPlusPage
            ref={instance => {
              this.child = instance;
            }}
            {...this.props}
          />
        </ModalDialog>
        {this.props.enableQAS ? (
          <QasValidation
            submitAddress={submitAddressData => {
              this.checkAddEditAddress(submitAddressData);
            }}
            qasData={this.props.qasData}
            modalMountedState={pathOr(
              false,
              'isAddAddressQasModalVisible',
              this.props.addressModalState
            )}
            updateModalState={this.toggleAddAddressQasState}
          />
        ) : null}
        {this.renderBenifitContent()}
        <Cell className="mt3">
          <BeyondPlusGiftWidget
            labels={this.props.labels}
            addBPlusGiftToCart={this.addToCart}
            defaultCohortType={this.props.defaultCohortType}
            bPAddToCartError={this.props.bPAddToCartError}
          />
        </Cell>
        {this.getCancelInfoModal(renewalDate)}
      </React.Fragment>
    );
  }
}

BeyondPlus.propTypes = {
  creditCardInfo: PropTypes.object,
  bpAccDetails: PropTypes.object,
  labels: PropTypes.object,
  updateRenewStatus: PropTypes.func,
  endpoints: PropTypes.object,
  redirectTo: PropTypes.func,
  data: PropTypes.object,
  addresses: PropTypes.object,
  customerId: PropTypes.string,
  deleteCreditCard: PropTypes.func,
  enableQAS: PropTypes.bool,
  qasData: PropTypes.object,
  addressModalState: PropTypes.object,
  updateAddAddressModalQasVisibility: PropTypes.func,
  emptyQasData: PropTypes.func,
  resetState: PropTypes.func,
  params: PropTypes.object,
  addBeyondPlusToCart: PropTypes.func,
  setPreferenceCommunication: PropTypes.func,
  isBeyondPlusItemAddedToCart: PropTypes.bool,
  isBeyondPlusGiftAddedToCart: PropTypes.bool,
  beyondPlusCheckout: PropTypes.bool,
  isPLCCEnabled: PropTypes.bool,
  isUPLCCEnabled: PropTypes.bool,
  isUserWithINGracePeriod: PropTypes.bool,
  cohortLabels: PropTypes.object,
  defaultCohortType: PropTypes.string,
  profile: PropTypes.object,
  bpCheckoutPageConfig: PropTypes.object,
  isDoubleOptinEnabled: PropTypes.bool,
  referredContent: PropTypes.object,
  doubleOptinContent: PropTypes.object,
  selectBpRenewalIndicator: PropTypes.object,
  selectBpRenewalData: PropTypes.object,
  bPAddToCartError: PropTypes.object,
};

export default BeyondPlus;
