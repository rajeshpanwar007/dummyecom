export const getBeyondPlusTeamliumInfo = isSubscribed => {
  const pageSpecificBeyondPlusTeamliumTags = {
    channel: 'My Account',
    content_pagetype: '',
    product_pagetype: '',
    navigation_path: 'My Account',
    subnavigation_path: 'My Account',
    page_name: 'MyAccount: Beyond+',
    page_function: 'My Account',
    page_type: 'My Account',
    pagename_breadcrumb: isSubscribed
      ? 'My Account >Beyond Plus status'
      : 'My Account>Create Account, Beyond Plus',
  };
  return pageSpecificBeyondPlusTeamliumTags;
};
