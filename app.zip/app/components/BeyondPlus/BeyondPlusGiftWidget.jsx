import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import pathOr from 'lodash/fp/pathOr';
import LabelsUtil from '@bbb-app/utils/labelsUtil';
import Cell from '@bbb-app/core-ui/cell';
import GridX from '@bbb-app/core-ui/grid-x';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import Heading from '@bbb-app/core-ui/heading';
import Button from '@bbb-app/core-ui/button';
import Paragraph from '@bbb-app/core-ui/paragraph';
import ModalDialog from '@bbb-app/modal-dialog/components/ModalDialog';
import BaseWidget from '@bbb-app/dashboard/components/base-widget/BaseWidget';
import WidgetBodyText from '@bbb-app/dashboard/components/widget-body-text';
import WidgetHeading from '@bbb-app/dashboard/components/widget-heading';
import {
  BPLUS_GIFTINGPAGE_URL,
  BPLUS_GIFT_CHECKOUTPAGE_URL,
  GIFT,
} from './constants';
import styles from './BeyondPlus.css';
class BeyondPlusGiftWidget extends React.PureComponent {
  static propTypes = {
    labels: PropTypes.object.isRequired,
    addBPlusGiftToCart: PropTypes.func,
    defaultCohortType: PropTypes.string,
    bPAddToCartError: PropTypes.object,
  };

  constructor(props) {
    super(props);
    this.state = {
      mountedState: false,
    };
    this.addBeyondPlusToCart = this.addBeyondPlusToCart.bind(this);
    this.toggleAddModalState = this.toggleAddModalState.bind(this);
    this.onOkBtnClick = this.onOkBtnClick.bind(this);
    this.isInternationalUser = isInternationalUser();
  }
  componentWillReceiveProps(newProps) {
    if (newProps.bPAddToCartError !== this.props.bPAddToCartError) {
      const isbpATCError =
        newProps.bPAddToCartError !== null &&
        newProps.bPAddToCartError !== undefined &&
        newProps.bPAddToCartError.response.data &&
        newProps.bPAddToCartError.response.data.errorMessages[0] !== '';
      this.setState({ mountedState: isbpATCError });
    }
  }
  onOkBtnClick() {
    this.toggleAddModalState(false);
  }
  toggleAddModalState = state => {
    this.setState({ mountedState: state });
  };
  addBeyondPlusToCart(event) {
    event.preventDefault();
    if (!this.isInternationalUser) {
      this.props.addBPlusGiftToCart({
        cohortCode: this.props.defaultCohortType,
        isGift: true,
        cohortEvent: GIFT,
      });
    }
  }
  renderDetails = () => {
    const { labels } = this.props;
    return (
      <GridX className="grid-margin-x">
        <React.Fragment>
          <Cell className="large-12 mb1">
            <WidgetBodyText data-locator="beyondPlusLanding-giftWidgetText">
              {LabelsUtil.getLabel(
                labels,
                'beyondPlus.bPlusGiftDescriptionLabel'
              )}
            </WidgetBodyText>
          </Cell>
          <Cell className="large-12 mt15">
            <Button
              theme={!this.isInternationalUser ? 'primary' : 'deactivated'}
              className={classnames('md-mb15 sm-mb2 fol')}
              href={BPLUS_GIFT_CHECKOUTPAGE_URL}
              onClick={this.addBeyondPlusToCart}
              data-locator="bp-Giftsignupcta"
            >
              <span>
                {LabelsUtil.getLabel(labels, 'beyondPlus.bPlusGiftTodayBtn')}
              </span>
            </Button>
          </Cell>
        </React.Fragment>
      </GridX>
    );
  };

  renderModalContent(errorCode, bPLabels) {
    return (
      <React.Fragment>
        <Heading
          level={3}
          className={classnames(
            'block mb1 ',
            styles.headingTextModal,
            styles.headingTextColor
          )}
          styleVariation="h3-sans"
        >
          {LabelsUtil.getLabel(bPLabels, 'beyondPlus.accountBPlusHeading')}
        </Heading>
        <Paragraph className={classnames('m0', styles.modalDescription)}>
          {LabelsUtil.getLabel(bPLabels, `beyondPlus.bPlus_${errorCode}`)}
        </Paragraph>
        <Button
          theme="primary"
          className={classnames('block mt35', styles.ctaBtn)}
          onClick={this.onOkBtnClick}
        >
          <span>{LabelsUtil.getLabel(bPLabels, 'beyondPlus.bpOKLabel')}</span>
        </Button>
      </React.Fragment>
    );
  }
  renderErrorModal() {
    const { labels, bPAddToCartError } = this.props;
    const errMsgCode = pathOr(
      null,
      'response.data.errorMessages.0.code',
      bPAddToCartError
    );
    return (
      <ModalDialog
        mountedState={this.state.mountedState}
        toggleModalState={this.toggleAddModalState}
        titleAriaLabel={LabelsUtil.getLabel(labels, 'beyondPlus.bpAtcError')}
        verticallyCenter
        variation="small"
        titleId="bp-overlay-title"
      >
        {this.renderModalContent(errMsgCode, labels)}
      </ModalDialog>
    );
  }
  render() {
    const { labels } = this.props;

    return (
      <BaseWidget>
        <WidgetHeading
          link={BPLUS_GIFTINGPAGE_URL}
          button={LabelsUtil.getLabel(labels, 'beyondPlus.bPlusGiftLearnMore')}
          heading={LabelsUtil.getLabel(labels, 'beyondPlus.bPlusGiftHeading')}
          headingDataLocatorValue="beyondPlusLanding-giftWidgetHeading"
          linkDataLocatorValue="beyondPlusLanding-giftWidgetLink"
        />
        {this.renderDetails()}
        {this.renderErrorModal()}
      </BaseWidget>
    );
  }
}

export default BeyondPlusGiftWidget;
