/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';
import { options } from '@bbb-app/universal-component/options';

const BeyondPlusGiftWidget = universal(
  import(/* webpackChunkName: "BeyondPlus-GiftWidget" */ './BeyondPlusGiftWidget'),
  options
);

export default BeyondPlusGiftWidget;
/* eslint-enable extra-rules/no-commented-out-code */
