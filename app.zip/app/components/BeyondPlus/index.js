export { default as BeyondPlusComponent } from './BeyondPlus';
