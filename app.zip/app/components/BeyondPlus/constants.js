export const BPLUS_GIFTINGPAGE_URL = '/store/loyalty/beyondPlusGift';
export const BPLUS_GIFT_CHECKOUTPAGE_URL = '/store/beyondPlusGiftCheckout';
export const RENEWAL = 'renewal';
export const GIFT = 'gift';
export const SITEID = 'BedBathUS';
