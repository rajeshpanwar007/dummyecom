export const RENEW_MEMBERSHIP = 'renewMembership';
export const AUTO_RENEW = 'autoRenew';
export const DO_NOT_RENEW = 'doNotRenew';
export const TERMS_AND_CONDITIONS_DOUBLE_OPTIN =
  'I acknowledge and agree that my membership will automatically renew for additional 1 year terms at the current membership fee (currently $29 plus applicable taxes, but subject to change) unless I notify you of my desire not to renew by calling customer service at 1-866-532-6826 or through My Account..';
