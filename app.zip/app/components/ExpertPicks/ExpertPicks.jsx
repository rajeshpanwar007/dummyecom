import React from 'react';
import { array, string, object, func, bool } from 'prop-types';
import classnames from 'classnames';
import { decodeHtmlEntities } from '@bbb-app/utils/common';
import GridX from '@bbb-app/core-ui/grid-x';
import inlineStyles from './ExpertPicks.inline.css';
import ProductDetailTile from './ProductDetailTile';
import { HeaderSkeleton, ExpertPickSkeletonUnit } from './Skeletons';
import { GBB_PRODUCT_COUNT } from '../../containers/PureContent/ExpertPicks/constants';

const dummyArr = Array.from(new Array(GBB_PRODUCT_COUNT)); // Array of length GBB_PRODUCT_COUNT

const getProductUrl = (seoUrl, categoryId) =>
  `/store${seoUrl}?categoryId=${categoryId}`;

const ExpertPicks = ({
  ExpertPicksHeading,
  ExpertPicksSubHeading,
  items,
  shopNowLbl,
  priceLabels,
  categoryId,
  fireTealiumAction,
  pageTags,
  breadcrumbs,
  showSkeleton,
}) => (
  <GridX className={classnames(inlineStyles.base)}>
    {showSkeleton ? (
      <HeaderSkeleton />
    ) : (
      <header className={inlineStyles.title}>{ExpertPicksHeading}</header>
    )}
    <p className={classnames(inlineStyles.subTitle, 'm0')}>
      {ExpertPicksSubHeading}
    </p>
    <div className={inlineStyles.productGrid}>
      {!showSkeleton
        ? items &&
          items.map((item, index) => {
            return (
              <ProductDetailTile
                key={item.product_id}
                productId={item.product_id}
                seoUrl={getProductUrl(item.seo_url, categoryId)}
                displayName={decodeHtmlEntities(item.display_name)}
                scene7Url={item.scene7_id}
                skuId={item.sku_id.toString()}
                normal={item.normal}
                low={item.low}
                lowValue={item.lowValue}
                priceRangeDescription={item.priceRangeDescription}
                inCart={item.inCart}
                sellingPoint={item.selling_point}
                shopNowLbl={shopNowLbl}
                priceLabels={priceLabels}
                fireTealiumAction={fireTealiumAction}
                pageTags={pageTags}
                breadcrumbs={breadcrumbs}
                itemIndex={index}
              />
            );
          })
        : dummyArr.map((item, index) => <ExpertPickSkeletonUnit key={index} />)}
    </div>
  </GridX>
);

ExpertPicks.propTypes = {
  ExpertPicksHeading: string,
  ExpertPicksSubHeading: string,
  items: array,
  shopNowLbl: string,
  priceLabels: object,
  categoryId: string,
  fireTealiumAction: func,
  pageTags: object,
  breadcrumbs: object,
  showSkeleton: bool,
};
export default ExpertPicks;
