export const SIZES = [
  {
    breakpoint: 'max-width 768px',
    viewportWidth: '32vw',
  },
  {
    breakpoint: 'max-width 1023px',
    viewportWidth: '18vw',
  },
  {
    breakpoint: 'max-width 1024px',
    viewportWidth: '15vw',
  },
];

export const IMAGE_SRC = {
  preset: 'content',
  width: '832',
  height: '520',
};

export const SRC_SET = [
  {
    preset: 'content',
    width: '832',
    height: '520',
    sourceWidth: '832w',
  },
];

export const EXPERT_PICKS_GOOD = 'Good';
export const EXPERT_PICKS_BETTER = 'Better';
export const EXPERT_PICKS_BEST = 'Best';
export const TEALIUM_PAGE_INFO = {
  page_type: 'product',
  page_name: 'good better best click',
};
