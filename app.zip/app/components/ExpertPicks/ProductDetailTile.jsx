import React from 'react';
import { string, boolean, object, func, number } from 'prop-types';
import { pathOr } from 'lodash/fp';
import classnames from 'classnames';
import Cell from '@bbb-app/core-ui/cell';
import LazyLoad from '@bbb-app/core-ui/lazy-load';
import Button from '@bbb-app/core-ui/button';
import ImageSrcSet from '@bbb-app/core-ui/image-src-set';
import primeStyles from '@bbb-app/core-ui/primary-link/PrimaryLink.css';
import PrimaryLinkContainer from '@bbb-app/plp-primary-link/containers/PrimaryLink';
import inlineStyles from './ExpertPicks.inline.css';
import styles from './ExpertPicks.css';
import Price from '../ProductTile/Price';
import AddToIdeaboard from '../../containers/AddToIdeaboard/AddToIdeaboard.async';
import { SRC_SET, SIZES, IMAGE_SRC, TEALIUM_PAGE_INFO } from './constants';
import { getExpertPicksSpotName } from './expertPicksUtil';

const ProductDetailTile = ({
  productId,
  seoUrl,
  displayName,
  scene7Url,
  skuId,
  normal,
  low,
  lowValue,
  priceRangeDescription,
  inCart,
  sellingPoint,
  shopNowLbl,
  priceLabels,
  fireTealiumAction,
  breadcrumbs,
  itemIndex,
}) => {
  const setTealiumTags = () => {
    const tealiumTags = {
      product_id: [productId],
      spot_name: getExpertPicksSpotName(itemIndex),
      pagename_breadcrumb: pathOr('', 'pagename_breadcrumb', breadcrumbs),
    };
    fireTealiumAction('good better best click', tealiumTags, TEALIUM_PAGE_INFO);
  };
  return (
    <Cell className={inlineStyles.cell}>
      <div className={styles.thumbnailWrapper}>
        <PrimaryLinkContainer
          href={seoUrl}
          className={classnames(
            styles.fitContent,
            'top-0 right-0 bottom-0 left-0'
          )}
          onClick={() => setTealiumTags()}
          itemIndexFromPLP={Number(productId)}
        >
          <ImageSrcSet
            className={inlineStyles.teaserTileContainer}
            alt={displayName}
            title={displayName}
            scene7imageID={scene7Url}
            isScene7UrlPrefix
            srcSet={SRC_SET}
            sizes={SIZES}
            imageSrc={IMAGE_SRC}
          />
        </PrimaryLinkContainer>
        <LazyLoad threshold={1000}>
          <AddToIdeaboard
            className={styles.addIdeaBtn}
            productName={displayName}
            productId={productId}
            skuId={skuId}
            renderCustomToolTip
            productImageId={scene7Url}
            itemIndex={Number(productId)}
            toolTipClassName={styles.customTooltip}
            isExpertPicks
          />
        </LazyLoad>
      </div>
      <Price
        className={styles.price}
        normal={normal}
        low={low}
        lowValue={lowValue}
        priceLabels={priceLabels}
        priceRangeDescription={priceRangeDescription}
        inCart={inCart}
      />
      <header className={styles.boldText}>
        <span
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: displayName,
          }}
        />
      </header>
      <p className={classnames(styles.wrapper, styles.sellingPoint, 'mb2')}>
        <span
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: sellingPoint,
          }}
        />
      </p>
      <div className={styles.wrapper}>
        <Button
          theme="ghost"
          className={classnames(
            primeStyles.primaryWithArrow,
            styles.arrowButton,
            'textStyle '
          )}
          href={seoUrl}
          isIconAfterContent
          iconProps={{
            type: 'arrow',
            width: '20px',
            height: '20px',
          }}
          onClick={() => setTealiumTags()}
        >
          {shopNowLbl}
        </Button>
      </div>
    </Cell>
  );
};
ProductDetailTile.propTypes = {
  productId: string,
  seoUrl: string,
  displayName: string,
  scene7Url: string,
  skuId: string,
  normal: string,
  low: string,
  lowValue: string,
  priceRangeDescription: string,
  inCart: boolean,
  sellingPoint: string,
  shopNowLbl: string,
  priceLabels: object,
  fireTealiumAction: func,
  breadcrumbs: object,
  itemIndex: number,
};

export default ProductDetailTile;
