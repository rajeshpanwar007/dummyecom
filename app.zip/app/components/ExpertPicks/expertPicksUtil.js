import {
  EXPERT_PICKS_GOOD,
  EXPERT_PICKS_BETTER,
  EXPERT_PICKS_BEST,
} from './constants';

export const getExpertPicksSpotName = index => {
  let spotName = '';
  switch (index) {
    case 0:
      spotName = EXPERT_PICKS_GOOD;
      break;

    case 1:
      spotName = EXPERT_PICKS_BETTER;
      break;

    case 2:
      spotName = EXPERT_PICKS_BEST;
      break;

    default:
      break;
  }
  return spotName;
};
