import React from 'react';
import Cell from '@bbb-app/core-ui/cell';
import SkeletonWrapper from '@bbb-app/core-ui/skeleton-wrapper/SkeletonWrapper';
import inlineStyles from './ExpertPicks.inline.css';

export const HeaderSkeleton = () => (
  <SkeletonWrapper
    viewPort={{ height: '100%', width: '100%' }}
    rectContainerHeight="100%"
    rectContainerWidth="100%"
    preserveAspectRatio="xMaxYMin meet"
    className={inlineStyles.headerSkeleton}
    svgProps={{ viewBox: null }}
  >
    <rect x="0" y="0" rx="15" ry="15" width="100%" height="100%" />
  </SkeletonWrapper>
);

export const ExpertPickSkeletonUnit = () => {
  return (
    <Cell className={inlineStyles.cell}>
      <SkeletonWrapper
        viewPort={{ height: '100%', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        preserveAspectRatio="xMaxYMin meet"
        className={inlineStyles.teaserTileContainer}
        svgProps={{ viewBox: null }}
      >
        <rect x="0" y="0" width="100%" height="100%" />
      </SkeletonWrapper>
      <SkeletonWrapper
        viewPort={{ height: '100%', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        className={`${inlineStyles.priceTagSkeleton} mt2`}
        preserveAspectRatio="xMaxYMin meet"
        svgProps={{ viewBox: null }}
      >
        <rect x="0" y="0" rx="12" ry="12" width="30%" height="100%" />
      </SkeletonWrapper>
      <SkeletonWrapper
        viewPort={{ height: '19px', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        className="my1"
        preserveAspectRatio="xMaxYMin meet"
        svgProps={{ viewBox: null }}
      >
        <rect x="0" y="0" rx="8" ry="8" width="100%" height="100%" />
      </SkeletonWrapper>
      <SkeletonWrapper
        viewPort={{ height: '100%', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        className={`${inlineStyles.textContainerSkeleton} mb2`}
        preserveAspectRatio="xMaxYMin meet"
        svgProps={{ viewBox: null }}
      >
        <rect x="0" y="0" rx="8" ry="8" width="100%" height="100%" />
      </SkeletonWrapper>
      <SkeletonWrapper
        viewPort={{ height: '36px', width: '100%' }}
        rectContainerHeight="100%"
        rectContainerWidth="100%"
        className={`${inlineStyles.shopNowSkeleton} mb1`}
        preserveAspectRatio="xMaxYMin meet"
        svgProps={{ viewBox: null }}
      >
        <rect x="10%" y="10%" rx="8" ry="8" width="40%" height="80%" />
      </SkeletonWrapper>
    </Cell>
  );
};
