/* eslint-disable max-lines */
/* eslint-disable */
import {
  updateFetchContentActionWithContentIds,
  updateFetchContentActionWithContentIdsForSearch,
  updateFetchContentActionWithContentIdsForNoResults,
  updateCategoryId,
} from "@bbb-app/utils/experience";

import {
  PAGE_NAME_CATEGORY,
  PAGE_NAME_PRODUCT_SEARCH,
  PAGE_NAME_REGISTRY_SEARCH_RESULTS,
  PAGE_NAME_CREATE_REGISTRY,
  PAGE_NAME_GIFT_GIVER,
  PAGE_NAME_SOCIAL_RECOMMENDATION,
  PAGE_NAME_TYM,
  PAGE_NAME_MY_ITEMS_REGISTRYOWNER,
  PAGE_NAME_REGISTRY_OWNER_PARENT,
  PAGE_NAME_REGISTRY_OWNER_HOME,
  HOME_PAGE,
  CUSTOM_ORDERS_PAGE,
  PAGE_NAME_REGISTRY_QUICK_PICKS_LANDING,
  ROUTE_REGISTRY_QUICK_PICKS_LANDING,
  PAGE_NAME_REGISTRY_QUICK_PICKS_COLLECTION,
  ROUTE_REGISTRY_QUICK_PICKS_COLLECTION,
  ROUTE_REGISTRY_OWNER_PARENT,
  ROUTE_REGISTRY_OWNER_HOME,
  ROUTE_REGISTRY_OWNNER,
  ROUTE_REGISTRY_OWNER_RECOMMENDATION,
  ROUTE_REGISTRY_OWNER_TYM,
  ROUTE_REGISTRY_QUICK_PICKS_LANDING_KICKSTARTERS,
  ROUTE_INSTANT_CREDIT_LANDING,
  ROUTE_PDP,
  PAGE_NAME_BRAND_PLP,
  PAGE_NAME_HIGHAPR_REASONS,
  LOGIN_IDENTIFIER_KEY,
  GEN_LOGIN_IDENTIFIER_KEY,
  GEN_LOGOUT_IDENTIFIER_KEY,
  GEN_CREATE_ACCT_IDENTIFIER_KEY,
  GEN_ERROR_IDENTIFIER_KEY,
  ROUTE_GENERIC_LOGIN,
  ROUTE_GENERIC_LOGOUT,
  ROUTE_GENERIC_CREATE_ACCT,
  ROUTE_GENERIC_ERROR,
  REGISTRATION_IDENTIFIER_KEY,
  TRACK_ORDER_GUEST_IDENTIFIER_KEY,
  TRACK_ORDER_IDENTIFIER_KEY,
  WALLET_LANDING_IDENTIFIER_KEY,
  WALLET_REGISTRATION_IDENTIFIER_KEY,
  ERROR_PAGE_LABELS,
  TRACK_INTERNATIONAL_ORDER,
  PAGE_NAME_PRODUCT_DETAILS,
  RESET_PASSWORD_PAGE,
  EASY_RETURNS_PAGE,
  PRINTIC_PAGE_KEY,
  FIND_A_STORE_PAGE,
  SDDPage,
  PRODUCT_COMPARE_PAGE,
  PAGE_NAME_PRODUCT_COMPARE_PAGE,
  ROUTE_CHECKLIST_OWNER,
  ROUTE_CHECKLIST_HOME,
  PAGE_NAME_MY_ITEMS_CHECKLIST,
  PAGE_NAME_CHECKLIST_OWNER_HOME,
  CUSTOMER_SURVEY,
  BEYOND_PLUS_PAGE,
  BEYOND_PLUS_GIFTING_PAGE,
  BRAND_LISTING,
  LIST_OWNER_VIEW,
  REVIEW_YOUR_PRODUCTS,
  PAGE_NAME_ARTICLE_GROUP,
  PAGE_NAME_ARTICLE_TAGS,
  TBS_ORDER_INQUIRY_PAGE,
  TBS_MIE_SEARCH_PAGE,
  PAGE_NAME_ARTICLE_STATIC,
  ROUTE_REGISTRY_FLIP_FLOP,
  PAGE_NAME_FLIP_FLOP,
  TBS_RECOMMEND_ITEMS_PAGE,
  ROUTE_RECOMMENDER_LANDING_PAGE,
  PAGE_NAME_RECOMMENDER_LANDING_PAGE,
  ROUTE_MOVERS_CHECKLIST_OWNER,
  MOVERS_LIST_OWNER_VIEW,
  ROUTE_PNH_CHECKLIST_OWNER,
  ROUTE_PNH_CHECKLIST_PARENT,
  ROUTE_PNH_CHECKLIST_HOME,
  PNH_LIST_OWNER_VIEW,
  PNH_LIST_OWNER_SHOP,
  PNH_LIST_OWNER_MANAGE_RESERVE,
  MOVERS_MY_ITEMS_CHECKLIST,
  ROUTE_TBS_ORDER_DETAIL,
  PAGENAME_TBS_ORDER_DETAIL,
  ROUTE_CREATE_PNH_CHECKLIST,
  PAGE_NAME_COLLEGE_LOOK_BOOK_PAGE,
  ROUTE_COLLEGE_LOOK_BOOK_PAGE,
  PAGENAME_PRINT_REGISTRY,
  PAGENAME_PRINT_CHECKLIST,
  ROUTE_PRINT_REGISTRY,
  ROUTE_PRINT_CHECKLIST,
  PAGE_NAME_REGISTRY_INCENTIVE,
  CUSTOMER_FACING_FORM,
  PAGE_NAME_CUSTOMER_FACING_FORM,
  DELETE_ACCOUNT_OF_CUSTOMER,
  PAGE_NAME_DELETE_ACCOUNT_OF_CUSTOMER,
  ROUTE_BEYOND_PLUS,
  BUYING_GUIDE_L2_PAGE,
  BUYING_GUIDE_L3_PAGE,
  PAGE_NAME_BUYING_GUIDE_GROUP,
  PAGE_NAME_BUYING_GUIDE_STATIC,
  ROUTE_REGISTRY_SEARCH_PATH,
  ROUTE_REGISTRY_SEARCH_PATH_OLD_SITE,
  CURBSIDE_PICKUP_REDIRECTION,
  CURBSIDE_EDIT_PICKUP_REDIRECTION,
  ProductNotFoundErrorPath,
  UnauthorizedHttpErrorPath,
  ForbiddenHttpErrorPath,
  InternalServerHttpErrorPath,
  NotFoundHttpErrorPath,
} from "@bbb-app/constants/route/route";
import {
  PRODUCTS_EXPERIENCE_KEY,
  CATEGORIES_EXPERIENCE_KEY,
  CONTENTHUB_EXPERIENCE_KEY,
  STATICPAGES_EXPERIENCE_KEY,
  COLLEGE_EXPERIENCE_KEY,
  ORGANIZATION_EXPERIENCE_KEY,
  BUYING_GUIDE_EXPERIENCE_KEY,
  CLP_IDENTIFIER_KEY,
  IDEABOARD_DETAIL_IDENTIFIER_KEY,
  IDEABOARD_LANDINGPAGE_IDENTIFIER_KEY,
  BUYINGGUIDE_PAGES_KEY,
  EXPERIENCE_KEY_CHECKLIST_CATEGORY,
} from '@bbb-app/constants/experienceConstants';
import UnauthorizedHttpErrorPage from '@bbb-app/error-pages/containers/http-error-pages/UnauthorizedPage';
import InternalServerHttpErrorPage from '@bbb-app/error-pages/containers/http-error-pages/InternalServerErrorPage';
import {
  CONTACT_US,
  COLLEGE_CHECK_LIST,
  MOVER_CHECK_LIST,
  PNH_CHECK_LIST,
} from "@bbb-app/constants/label-keys/labelsConstant";
import {
  ROUTE_PRODUCT_SEARCH_PATH,
  ROUTE_CATEGORY_PATH,
  ROUTE_BRAND_PATH,
  ROUTE_CATEGORY_L1_AS_L2_PATH,
  ROUTE_CHECKLIST_CATEGORY_PATH,
  ROUTE_BOPIS_PATH,
  ROUTE_SDD_PATH,
} from '@bbb-app/constants/route/searchRoute';
import { fetchCollegeChecklistReferredData } from "./containers/Pages/CollegeChecklist/pageTransitionActions";
import { fetchMoverChecklistReferredData } from "./containers/Pages/MoverChecklist/actions";
import { fetchBrandListings } from "./containers/Pages/BrandListing/actions";
import { fetchOrganizationSEOMapData } from "./containers/Pages/OrganizationLanding/actions";
import myAccountRoutes from "./myAccountRoutes";

import {
  fetchProductDetails,
  fetchSkuDetails,
} from "./containers/Pages/PDP/ProductDetails/ProductDetailsActions";
import { fetchPageExperience } from "./containers/Experience/actions";
import {
  ROUTE_CATEGORY_L1_PATH,
  CHECKLIST_CATEGORY_IDENTIFIER,
  CATEGORY_IDENTIFIER,
} from "./constants/search";

/* Define all the async routes corresponding to the exports defined under asyncRoutes */
import {
  /* Define all the async routes corresponding to the exports defined under asyncRoutes */
  Account,
  AccountRegistration,
  BrandListing,
  Brand,
  Category,
  ChecklistCategory,
  CreateRegistry,
  EasyReturns,
  EasySignIn,
  ExperiencePage,
  FindAStore,
  GiftCard,
  GuestViewer,
  IdeaboardDetail,
  IdeaBoardLanding,
  Links,
  StaticExperiencePage,
  PDP,
  PrintIC,
  ProductSearch,
  RegistryOwner,
  RegistryOwnerHome,
  RegistryOwnerMain,
  RegistryQuickPicksCollection,
  RegistryQuickPicksLanding,
  RegistrySearchResults,
  RedirectToRegistrySearch,
  RegistryTools,
  ResetYourPassword,
  SignIn,
  GenericSignIn,
  GenericSignOut,
  GenericAccountRegistration,
  SignUpForOffers,
  EmailCouponRedirect,
  SocialAnnexGallery,
  SocialRecommendation,
  ThankYouManager,
  TrackInternationalOrder,
  WalletRegistration,
  SessionExpiryPage,
  HighAPRReasons,
  CollegeLanding,
  BeyondPlusHandRaiser,
  CustomerSurvey,
  InstantCreditExperiencePage,
  ComparePage,
  CollegeChecklist,
  MoverChecklist,
  PNHChecklist,
  ListOwnerView,
  CheckListHome,
  ChecklistOwner,
  PNHCheckListHome,
  ReviewYourProducts,
  ArticlePage,
  CustomOrders,
  Weblinks,
  OrderSearch,
  OrganizationWeblink,
  OrganizationLanding,
  MieSearch,
  FlipFlop,
  RecommendItems,
  OrderDetail,
  RecommenderLandingPage,
  MoversListOwnerView,
  AccountVersionComponentWrapper,
  PNHListOwnerView,
  PNHChecklistOwner,
  BeyondPlusPage,
  Collegelookbook,
  PrintRegistry,
  PrintChecklist,
  EventsPage,
  RegistryIncentive,
  CustomerFacingForm,
  DeleteAccountOfCustomer,
  BuyingGuidePage,
  CurbsidePickupRedirection,
  GenericErrorPageX,
  ForbiddenHttpErrorPage,
  CurbsideEditPickupRedirection,
  PageNotFound,
  SeoExperience
} from "./asyncRoutes";
import { fetchRelatedSearchTopics } from "./containers/RelatedSearchTopics/actions";
import { fetchMetaTag } from './containers/SlotMachineDetails/SeoExperience/actions';

/**
 * returns array of Route objects
 * @param {Redux Store}
 * We require store as an argument here because we wish to get
 * state from the store after it has been authenticated.
 * @returns {{Route}[]} Array of Route objects
 */
export default function createRoutes() {
  return [
    /**
     * @typedef {Object} Route
     * @property {string} path url path which will be matched against current browser page Request
     * @property {React} component component to be rendered when this route match, Controller for Matched Route
     * @property {bool} exact when true, will match only if the path matches the location exactly
     * @property {object} routeData This Object will be passed to all the Actions for current Route,
     * any data can be sent as key to this object
     * @property {string} routeData.experienceIdentifier Key Name to be used to find experience mapping,
     * in experience mapping object.
     * @property {Array} routeData.fetchData array of actions to be dispatched when this route is rendered,
     * These actions will get triggered Universally at Server/Client side.
     * @property {string} routeData.multipleAction if true then separate actions to be dispatched for each experience component id
     * @property {string} routeData.pageName page name for current route, this pageName will be same which will be used
     * in SiteConfig and Label Objects by CMS.
     */
    {
      path: "/",
      component: ExperiencePage,
      exact: true,
      routeData: {
        pageName: HOME_PAGE,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/pie_redirect",
      component: ReviewYourProducts,
      exact: true,
      routeData: {
        pageName: REVIEW_YOUR_PRODUCTS,
      },
    },
    {
      path: "/session-expired",
      component: SessionExpiryPage,
      exact: true,
      routeData: {
        pageName: ERROR_PAGE_LABELS,
      },
    },
    {
      path: "/store",
      component: ExperiencePage,
      exact: true,
      routeData: {
        pageName: HOME_PAGE,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/links",
      component: Links,
      exact: true,
    },
    {
      path: "/store/customOrders",
      component: CustomOrders,
      exact: true,
      routeData: {
        pageName: CUSTOM_ORDERS_PAGE,
      },
    },
    {
      path: "/store/couponWallet/walletLanding",
      component: SignUpForOffers,
      exact: true,
      routeData: {
        pageName: WALLET_LANDING_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/couponWallet/click",
      component: EmailCouponRedirect,
      exact: true,
    },
    {
      path: "/store/ideaboard/landingPage",
      component: IdeaBoardLanding,
      exact: true,
      routeData: {
        pageName: IDEABOARD_LANDINGPAGE_IDENTIFIER_KEY,
      },
    },
    {
    path: UnauthorizedHttpErrorPath,
      component: UnauthorizedHttpErrorPage,
    },
    {
      path: ForbiddenHttpErrorPath,
      component: ForbiddenHttpErrorPage,
    },
    {
      path: InternalServerHttpErrorPath,
      component: InternalServerHttpErrorPage,
    },
    {
      path: "/store/images/:Gallery",
      component: SocialAnnexGallery,
      exact: true,
    },
    {
      path: "/store/giftregistry/createRegistryForm",
      component: CreateRegistry,
      exact: true,
      routeData: {
        multipleAction: false,
        pageName: PAGE_NAME_CREATE_REGISTRY,
      },
    },
    {
      path: "/store/category/college/10017", // Added route to redirect to college landing page from search result. (BBBWP-1777)
      component: Weblinks,
      routeData: {
        experienceIdentifier: COLLEGE_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: COLLEGE_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/store/registryIncentives",
      component: RegistryIncentive,
      exact: true,
      routeData: {
        multipleAction: false,
        pageName: PAGE_NAME_REGISTRY_INCENTIVE,
      },
    },
    {
      path: "/store/category/custom/:name/:id/",
      component: ExperiencePage,
      exact: true,
    },
    {
      path: "/store/static/looklove",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/registryIncentives",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/static/content/beyondplustnc",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/giftnotonregistry",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/mover",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/couponWallet/walletRegistration",
      component: WalletRegistration,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: WALLET_REGISTRATION_IDENTIFIER_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/GiftCardHomePage",
      component: GiftCard,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/account/international_order_summary",
      component: TrackInternationalOrder,
      exact: true,
      routeData: {
        pageName: TRACK_INTERNATIONAL_ORDER,
      },
    },
    {
      path: "/store/selfservice/survey",
      component: CustomerSurvey,
      routeData: {
        pageName: CUSTOMER_SURVEY,
      },
      exact: true,
    },
    /**
     * for L1s that should use an L2 template
     */
    {
      path: ROUTE_CATEGORY_L1_AS_L2_PATH,
      component: Category,
      routeData: {
        experienceIdentifier: CATEGORIES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_CATEGORY,
        uniqueIdentifier: CATEGORY_IDENTIFIER,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
          updateFetchContentActionWithContentIdsForNoResults,
          fetchRelatedSearchTopics,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_CATEGORY_PATH,
      component: Category,
      routeData: {
        experienceIdentifier: CATEGORIES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_CATEGORY,
        uniqueIdentifier: CATEGORY_IDENTIFIER,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
          updateFetchContentActionWithContentIdsForNoResults,
          fetchRelatedSearchTopics,
        ],
      },
      exact: true,
    },
    {
      path: "/blogs",
      component: ArticlePage,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_ARTICLE_STATIC,
        experienceIdentifier: CONTENTHUB_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/blogs/story/:url",
      component: ArticlePage,
      routeData: {
        experienceIdentifier: CONTENTHUB_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_ARTICLE_GROUP,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/blogs/recipe/:url",
      component: ArticlePage,
      routeData: {
        experienceIdentifier: CONTENTHUB_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_ARTICLE_GROUP,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/blogs/tag/:tagName/:tagId/:pageNumber?",
      component: ArticlePage,
      routeData: {
        experienceIdentifier: CONTENTHUB_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_ARTICLE_TAGS,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/blogs/section/:sectionName/:pageNumber?",
      component: ArticlePage,
      routeData: {
        experienceIdentifier: CONTENTHUB_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_ARTICLE_STATIC,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_CATEGORY_L1_PATH,
      component: ExperiencePage,
      routeData: {
        pageName: CLP_IDENTIFIER_KEY,
        experienceIdentifier: CATEGORIES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
          updateCategoryId,
        ],
      },
      exact: true,
    },
    /**
     * Checklist Category will match the following:
     * /store/checklist/:checklistName/:c1CategoryName/:c2CategoryName/:c3CategoryName/:c3categoryID/:checklistID
     * /store/checklist/:checklistName/:c1CategoryName/:c2CategoryName/:c2categoryID/:checklistID
     * checklistName: checklist semantic name
     * c1CategoryName: c1 semantic name
     * c2CategoryName: c2 semantic name
     * c3CategoryName: c3 semantic name
     * c3categoryID: The unique id of the c3
     * checklistID: The unique id of the user's checklist
     */
    {
      path: ROUTE_CHECKLIST_CATEGORY_PATH,
      component: ChecklistCategory,
      routeData: {
        pageName: PAGE_NAME_CATEGORY,
        experienceIdentifier: EXPERIENCE_KEY_CHECKLIST_CATEGORY,
        uniqueIdentifier: CHECKLIST_CATEGORY_IDENTIFIER,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    /**
     * Product Search will match the following:
     *  '/store/s/:term/:startPerPage(\\d+-\\d+)?/:store(store-\\d+)?/:facets?';
     * term: URI encoded Search Term (REQUIRED)
     * startPerPage: start and perPage.  E.g. 1-48 === start: 1, perPage: 48
     * store: Store number
     * facets: Based64 encoded facets
     */
    {
      path: ROUTE_PRODUCT_SEARCH_PATH,
      component: ProductSearch,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        pageName: PAGE_NAME_PRODUCT_SEARCH,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIdsForSearch,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_PDP,
      component: PDP,
      routeData: {
        experienceIdentifier: PRODUCTS_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_PRODUCT_DETAILS,
        isFromRouter: true,
        fetchData: [
          fetchProductDetails,
          fetchSkuDetails,
          fetchRelatedSearchTopics,
        ],
      },
    },
    {
      path: "/store/page/college",
      component: CollegeLanding,
      routeData: {
        experienceIdentifier: COLLEGE_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: COLLEGE_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/university/:collegeSEOID",
      component: Weblinks,
      routeData: {
        experienceIdentifier: COLLEGE_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: COLLEGE_EXPERIENCE_KEY,
      },
      exact: true,
    },
    {
      path: "/store/university/",
      component: Weblinks,
      routeData: {
        experienceIdentifier: COLLEGE_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: COLLEGE_EXPERIENCE_KEY,
      },
      exact: true,
    },
    {
      path: "/store/page/organization",
      component: OrganizationLanding,
      routeData: {
        experienceIdentifier: ORGANIZATION_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: "organizationPages",
        fetchData: [fetchPageExperience],
      },
      exact: true,
    },
    {
      path: "/store/page/organization/:orgType/:orgName?",
      component: OrganizationWeblink,
      routeData: {
        experienceIdentifier: ORGANIZATION_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: "organizationPages",
        fetchData: [fetchOrganizationSEOMapData],
      },
    },
    {
      path:
        "/store/ideaboard/:ideaboardName/:ideaboardId/:startPerPage(\\d+-\\d+)?",
      component: IdeaboardDetail,
      routeData: {
        multipleAction: false,
        pageName: IDEABOARD_DETAIL_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/account/Login",
      component: SignIn,
      exact: true,
      routeData: {
        pageName: LOGIN_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/account/LoginRedirect",
      component: EasySignIn,
      exact: true,
      routeData: {
        pageName: LOGIN_IDENTIFIER_KEY,
      },
    },
    {
      path: ROUTE_GENERIC_LOGIN,
      component: GenericSignIn,
      routeData: {
        pageName: GEN_LOGIN_IDENTIFIER_KEY,
      },
    },
    {
      path: ROUTE_GENERIC_LOGOUT,
      component: GenericSignOut,
      routeData: {
        pageName: GEN_LOGOUT_IDENTIFIER_KEY,
      },
    },
    {
      path: ROUTE_GENERIC_CREATE_ACCT,
      component: GenericAccountRegistration,
      routeData: {
        pageName: GEN_CREATE_ACCT_IDENTIFIER_KEY,
      },
    },
    {
      path: ROUTE_GENERIC_ERROR,
      component: GenericErrorPageX,
      routeData: {
        pageName: GEN_ERROR_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/account/TrackOrder",
      component: AccountVersionComponentWrapper,
      exact: true,
      routeData: {
        pageName: TRACK_ORDER_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/account/track_order_guest",
      component: AccountVersionComponentWrapper,
      routeData: {
        pageName: TRACK_ORDER_GUEST_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/account/frags/changePwdAfterResetmodel",
      component: ResetYourPassword,
      routeData: {
        pageName: RESET_PASSWORD_PAGE,
      },
    },
    {
      path: "/store/account/curbside_pickup/:orderData",
      component: CurbsidePickupRedirection,
      exact: true,
      routeData: {
        pageName: CURBSIDE_PICKUP_REDIRECTION,
      },
    },
    {
      path: "/store/account/order/details/:orderData",
      component: CurbsideEditPickupRedirection,
      exact: true,
      routeData: {
        pageName: CURBSIDE_EDIT_PICKUP_REDIRECTION,
      },
    },
    {
      path: "/store/account/Registration",
      component: AccountRegistration,
      exact: true,
      routeData: {
        pageName: REGISTRATION_IDENTIFIER_KEY,
      },
    },
    {
      path: "/store/selfservice/ContactUs",
      component: StaticExperiencePage,
      exact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: CONTACT_US,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/account",
      component: Account,
      routes: myAccountRoutes,
    },
    {
      path: "/store/guide/:pageName?/:id?",
      component: ExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        pageName: BUYINGGUIDE_PAGES_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/selfservice/EasyReturns",
      component: EasyReturns,
      routeData: {
        pageName: EASY_RETURNS_PAGE,
      },
      exact: true,
    },
    {
      path: ROUTE_INSTANT_CREDIT_LANDING,
      component: InstantCreditExperiencePage,
      extact: true,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: true,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/events(/)?",
      component: EventsPage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/static/:pageName?/:id?",
      component: ExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/our-brands/:brandName?",
      component: ExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: ROUTE_REGISTRY_SEARCH_PATH,
      component: RegistrySearchResults,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_REGISTRY_SEARCH_RESULTS,
      },
    },
    {
      path: ROUTE_REGISTRY_SEARCH_PATH_OLD_SITE,
      component: RedirectToRegistrySearch,
    },
    {
      path: "/store/page/BabyRegistry",
      component: ExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/page/Registry",
      component: ExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: true,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/registry/:pageName?",
      component: RegistryTools,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: true,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/gift-registry/:registryType",
      exact: true,
      component: StaticExperiencePage,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: ROUTE_REGISTRY_OWNER_PARENT,
      component: RegistryOwnerMain,
      routeData: {
        pageName: PAGE_NAME_REGISTRY_OWNER_PARENT,
      },
      routes: [
        {
          path: ROUTE_REGISTRY_OWNER_HOME,
          component: RegistryOwnerHome,
          exact: true,
          routeData: {
            experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
            multipleAction: false,
            pageName: PAGE_NAME_REGISTRY_OWNER_HOME,
            fetchData: [fetchPageExperience],
          },
        },
        {
          path: ROUTE_REGISTRY_OWNNER,
          component: RegistryOwner,
          exact: true,
          routeData: {
            pageName: PAGE_NAME_MY_ITEMS_REGISTRYOWNER,
          },
        },
        {
          path: ROUTE_REGISTRY_OWNER_TYM,
          component: ThankYouManager,
          exact: true,
          routeData: {
            pageName: PAGE_NAME_TYM,
          },
        },
        {
          path: ROUTE_REGISTRY_OWNER_RECOMMENDATION,
          component: SocialRecommendation,
          exact: true,
          routeData: {
            experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
            multipleAction: false,
            pageName: PAGE_NAME_SOCIAL_RECOMMENDATION,
            fetchData: [fetchPageExperience],
          },
        },
      ],
    },
    {
      path: ROUTE_REGISTRY_FLIP_FLOP,
      component: FlipFlop,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_FLIP_FLOP,
      },
    },
    {
      path: "/store/giftRegistry/printIC",
      component: PrintIC,
      routeData: {
        pageName: PRINTIC_PAGE_KEY,
      },
    },
    {
      path: "/store/giftregistry/viewregistryguest/:id?",
      component: GuestViewer,
      routeData: {
        pageName: PAGE_NAME_GIFT_GIVER,
      },
    },
    {
      path: ROUTE_PRINT_REGISTRY,
      component: PrintRegistry,
      exact: true,
      routeData: {
        pageName: PAGENAME_PRINT_REGISTRY,
      },
    },
    {
      path: ROUTE_PRINT_CHECKLIST,
      component: PrintChecklist,
      exact: true,
      routeData: {
        pageName: PAGENAME_PRINT_CHECKLIST,
      },
    },
    {
      path: "/store/page/brands",
      component: BrandListing,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        pageName: BRAND_LISTING,
        fetchData: [
          fetchBrandListings,
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: ROUTE_BRAND_PATH,
      component: Brand,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: PAGE_NAME_BRAND_PLP,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
          fetchRelatedSearchTopics,
        ],
      },
      exact: true,
    },
    {
      path: "/store/selfservice/FindStore",
      component: FindAStore,
      routeData: {
        pageName: FIND_A_STORE_PAGE,
      },
      exact: true,
    },
    {
      path: "/store/selfservice/CanadaStoreLocator",
      component: FindAStore,
      routeData: {
        pageName: FIND_A_STORE_PAGE,
      },
      exact: true,
    },
    {
      path: "/store/buyOffLandingPage",
    },
    {
      path: ROUTE_REGISTRY_QUICK_PICKS_LANDING,
      component: RegistryQuickPicksLanding,
      routeData: {
        pageName: PAGE_NAME_REGISTRY_QUICK_PICKS_LANDING,
      },
    },
    {
      path: ROUTE_REGISTRY_QUICK_PICKS_LANDING_KICKSTARTERS,
      component: RegistryQuickPicksLanding,
      routeData: {
        pageName: PAGE_NAME_REGISTRY_QUICK_PICKS_LANDING,
      },
    },
    {
      path: ROUTE_REGISTRY_QUICK_PICKS_COLLECTION,
      component: RegistryQuickPicksCollection,
      routeData: {
        pageName: PAGE_NAME_REGISTRY_QUICK_PICKS_COLLECTION,
      },
    },
    {
      path: "/store/SameDayDelivery/",
      component: ExperiencePage,
      routeData: {
        pageName: SDDPage,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: ProductNotFoundErrorPath,
      component: PageNotFound,
      routeData: {
        pageName: STATICPAGES_EXPERIENCE_KEY,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [updateFetchContentActionWithContentIds],
      },
      exact: true,
    },
    {
      path: NotFoundHttpErrorPath,
      component: PageNotFound,
      routeData: {
        pageName: STATICPAGES_EXPERIENCE_KEY,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    /*
       {
         path: "/store/loyalty/beyondplus",
         component: ExperiencePage,
         routeData: {
           pageName: BEYOND_PLUS_PAGE,
           experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
           multipleAction: false,
           fetchData: [
             fetchPageExperience,
             updateFetchContentActionWithContentIds,
           ],
         },
         exact: true,
       },*/
    {
      path: ROUTE_BEYOND_PLUS,
      component: BeyondPlusPage,
      routeData: {
        pageName: BEYOND_PLUS_PAGE,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/store/loyalty/beyondPlusGift",
      component: BeyondPlusPage,
      routeData: {
        pageName: BEYOND_PLUS_GIFTING_PAGE,
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/static/content/beyondplushandraiser",
      component: BeyondPlusHandRaiser,
      routeData: {
        experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
        multipleAction: false,
        pageName: STATICPAGES_EXPERIENCE_KEY,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
      exact: true,
    },
    {
      path: "/store/highAPRReasons",
      component: HighAPRReasons,
      routeData: {
        pageName: PAGE_NAME_HIGHAPR_REASONS,
      },
      exact: true,
    },
    {
      path: PRODUCT_COMPARE_PAGE,
      component: ComparePage,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_PRODUCT_COMPARE_PAGE,
      },
    },
    {
      path: "/store/giftregistry/customisedChecklistForm",
      component: CollegeChecklist,
      exact: true,
      routeData: {
        pageName: COLLEGE_CHECK_LIST,
        fetchData: [fetchCollegeChecklistReferredData],
      },
    },
    {
      path: "/store/giftregistry/customisedMoverChecklistForm",
      component: MoverChecklist,
      exact: true,
      routeData: {
        pageName: MOVER_CHECK_LIST,
        fetchData: [fetchMoverChecklistReferredData],
      },
    },
    {
      path: ROUTE_CREATE_PNH_CHECKLIST,
      component: PNHChecklist,
      exact: true,
      routeData: {
        pageName: PNH_CHECK_LIST,
      },
    },

    {
      path: "/store/search/track_order",
      component: OrderSearch,
      exact: true,
      routeData: {
        pageName: TBS_ORDER_INQUIRY_PAGE,
      },
    },
    {
      path: "/store/recommendations",
      component: RecommendItems,
      exact: true,
      routeData: {
        pageName: TBS_RECOMMEND_ITEMS_PAGE,
      },
    },
    {
      path: "/store/search/upcresults",
      component: MieSearch,
      exact: true,
      routeData: {
        pageName: TBS_MIE_SEARCH_PAGE,
      },
    },
    {
      path: ROUTE_TBS_ORDER_DETAIL,
      component: OrderDetail,
      exact: true,
      routeData: {
        pageName: PAGENAME_TBS_ORDER_DETAIL,
      },
    },
    {
      path: ROUTE_CHECKLIST_HOME,
      component: ListOwnerView,
      exact: true,
      routeData: {
        pageName: LIST_OWNER_VIEW,
      },
      routes: [
        {
          path: ROUTE_CHECKLIST_HOME,
          component: CheckListHome,
          exact: true,
          routeData: {
            experienceIdentifier: STATICPAGES_EXPERIENCE_KEY,
            multipleAction: false,
            pageName: PAGE_NAME_CHECKLIST_OWNER_HOME,
          },
        },
      ],
    },
    {
      path: ROUTE_CHECKLIST_OWNER,
      component: ListOwnerView,
      exact: true,
      routeData: {
        pageName: LIST_OWNER_VIEW,
      },
      routes: [
        {
          path: ROUTE_CHECKLIST_OWNER,
          component: ChecklistOwner,
          exact: true,
          routeData: {
            pageName: PAGE_NAME_MY_ITEMS_CHECKLIST,
          },
        },
      ],
    },
    {
      path: ROUTE_MOVERS_CHECKLIST_OWNER,
      component: MoversListOwnerView,
      exact: true,
      routeData: {
        pageName: MOVERS_LIST_OWNER_VIEW,
      },
      routes: [
        {
          path: ROUTE_MOVERS_CHECKLIST_OWNER,
          component: ChecklistOwner,
          exact: true,
          routeData: {
            pageName: MOVERS_MY_ITEMS_CHECKLIST,
          },
        },
      ],
    },
    {
      path: ROUTE_PNH_CHECKLIST_PARENT,
      component: PNHListOwnerView,
      routeData: {
        pageName: PNH_LIST_OWNER_VIEW,
      },
      routes: [
        {
          path: ROUTE_PNH_CHECKLIST_HOME,
          component: PNHCheckListHome,
          exact: true,
          routeData: {
            pageName: PNH_LIST_OWNER_SHOP,
          },
        },
        {
          path: ROUTE_PNH_CHECKLIST_OWNER,
          component: PNHChecklistOwner,
          exact: true,
          routeData: {
            pageName: PNH_LIST_OWNER_MANAGE_RESERVE,
          },
        },
      ],
    },
    /**
     * Path for search page in case of early input or JS disabled
     */
    {
      path: "/store/s",
      component: ProductSearch,
      routeData: {
        pageName: PAGE_NAME_PRODUCT_SEARCH,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIdsForSearch,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_BOPIS_PATH,
      component: ProductSearch,
      routeData: {
        pageName: PAGE_NAME_PRODUCT_SEARCH,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIdsForSearch,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_SDD_PATH,
      component: ProductSearch,
      routeData: {
        pageName: PAGE_NAME_PRODUCT_SEARCH,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIdsForSearch,
        ],
      },
      exact: true,
    },
    {
      path: ROUTE_RECOMMENDER_LANDING_PAGE,
      component: RecommenderLandingPage,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_RECOMMENDER_LANDING_PAGE,
      },
    },
    {
      path: ROUTE_COLLEGE_LOOK_BOOK_PAGE,
      component: Collegelookbook,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_COLLEGE_LOOK_BOOK_PAGE,
      },
    },
    {
      path: CUSTOMER_FACING_FORM,
      component: CustomerFacingForm,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_CUSTOMER_FACING_FORM,
      },
    },
    {
      path: DELETE_ACCOUNT_OF_CUSTOMER,
      component: DeleteAccountOfCustomer,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_DELETE_ACCOUNT_OF_CUSTOMER,
      },
    },
    {
      path: BUYING_GUIDE_L2_PAGE,
      component: BuyingGuidePage,
      exact: true,
      routeData: {
        pageName: PAGE_NAME_BUYING_GUIDE_STATIC,
        experienceIdentifier: BUYING_GUIDE_EXPERIENCE_KEY,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: BUYING_GUIDE_L3_PAGE,
      component: BuyingGuidePage,
      exact: true,
      routeData: {
        experienceIdentifier: BUYING_GUIDE_EXPERIENCE_KEY,
        pageName: PAGE_NAME_BUYING_GUIDE_GROUP,
        multipleAction: false,
        fetchData: [
          fetchPageExperience,
          updateFetchContentActionWithContentIds,
        ],
      },
    },
    {
      path: "/store/seoExperience/:id",
      component: SeoExperience,
      routeData: {
        pageName: 'SeoExperience',
        fetchData: [
          fetchMetaTag,
        ]
      },
      exact: true,
    },
  ];
}
/* eslint-enable max-lines */
