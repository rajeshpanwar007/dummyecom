/* eslint-disable import/extensions, import/no-unresolved */
/**
 * Async CSS Loading via loadCSS
 * https://github.com/filamentgroup/loadCSS
 *
 * These are imported with script-loader because they are not
 * proper module definitions.
 *
 * TODO: There seems to be da known double-request issue seen when
 * "disable cache" is enabled in dev tools.
 * https://github.com/filamentgroup/loadCSS/issues/110
 */

import 'script-loader!fg-loadcss';
import 'script-loader!fg-loadcss/src/cssrelpreload';
