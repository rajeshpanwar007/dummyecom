import React from 'react';
import universal from 'react-universal-component';
import classedWrapper from '@bbb-app/hoc/classedWrapper';
import { isBrowser } from '@bbb-app/utils/common';
import { logErrorsToService } from '@bbb-app/utils/serviceUtil';
import consoleLog from '@bbb-app/utils/logger';
import InternalServerHttpErrorPage from '@bbb-app/error-pages/containers/http-error-pages/InternalServerErrorPage';

const AsyncLoader = classedWrapper({
  wrapperName: 'AsyncLoader',
  wrapperClassName: 'asyncComponentLoader',
});
const options = {
  loading: <AsyncLoader />,
  loadingTransition: false,
  error: <InternalServerHttpErrorPage />,
  onError: error => {
    /* istanbul ignore next */
    if (isBrowser()) {
      logErrorsToService(error.message);
      window.location.reload(true);
    }

    consoleLog.error(`${error.message}`);
  },
  timeout: 180000,
};

/* eslint-disable extra-rules/no-commented-out-code */
export const Account = universal(
  import(/* webpackChunkName: "account" */ './containers/Account/Account'),
  options
);

export const AccountFavoriteStore = universal(
  import(/* webpackChunkName: "account-fav-store" */ './containers/Pages/AccountFavoriteStore/AccountFavoriteStore'),
  options
);

export const AccountVersionComponentWrapper = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/MyAccountDashboard/AccountVersionComponentWrapper'),
  options
);

export const AccountOrders = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/AccountOrders/AccountOrders'),
  options
);

export const AccountPreferences = universal(
  import(/* webpackChunkName: "account-preferences" */ './containers/Pages/AccountPreferences/AccountPreferences'),
  options
);

export const AccountRegistration = universal(
  import(/* webpackChunkName: "registration" */ './containers/Pages/AccountRegistration/AccountRegistration'),
  options
);

export const AccountAddressBook = universal(
  import(/* webpackChunkName: "account-addressBook" */ './containers/Pages/AccountAddressBook/AccountAddressBook'),
  options
);

export const Brand = universal(
  import(/* webpackChunkName: "product-listing" */ './containers/Pages/Brand/Brand'),
  options
);

export const BrandListing = universal(
  import(/* webpackChunkName: "brand-listing" */ './containers/Pages/BrandListing/BrandListing'),
  options
);

export const Category = universal(
  import(/* webpackChunkName: "product-listing" */ './containers/Pages/Category/Category'),
  options
);

export const ChecklistCategory = universal(
  import(/* webpackChunkName: "Checklist-Category" */ './containers/Pages/ChecklistCategory/ChecklistCategory'),
  options
);

export const CreateRegistry = universal(
  import(/* webpackChunkName: "registry" */ './containers/Pages/Registry/CreateRegistry/CreateRegistry'),
  options
);

export const RegistryIncentive = universal(
  import(/* webpackChunkName: "registry-incentive" */ './containers/Pages/Registry/RegistryIncentive/RegistryIncentive'),
  options
);

export const EasyReturns = universal(
  import(/* webpackChunkName: "easyReturns" */ './containers/Pages/EasyReturns/EasyReturns'),
  options
);

export const EasySignIn = universal(
  import(/* webpackChunkName: "easy-signIn" */ './containers/Pages/EasySignIn/EasySignIn'),
  options
);

export const ExperiencePage = universal(
  import(/* webpackChunkName: "experience" */ './containers/Pages/ExperiencePage/ExperiencePage'),
  options
);

export const PageNotFound = universal(
  import(/* webpackChunkName: "experience" */ './containers/Pages/ErrorPage/HttpErrorPages/PageNotFound'),
  options
);

export const FindAStore = universal(
  import(/* webpackChunkName: "findAStore" */ './containers/Pages/FindAStore/FindAStore'),
  options
);

export const GiftCard = universal(
  import(/* webpackChunkName: "gift-card" */ './containers/Pages/GiftCard/GiftCard'),
  options
);

export const GuestViewer = universal(
  import(/* webpackChunkName: "Guest-viewer" */ './containers/Pages/Registry/GuestViewer/GuestViewer'),
  options
);

export const IdeaboardDetail = universal(
  import(/* webpackChunkName: "ideaBoard" */ './containers/Pages/IdeaboardDetail/IdeaboardDetail'),
  options
);

export const IdeaBoardLanding = universal(
  import(/* webpackChunkName: "ideaBoard" */ './containers/Pages/IdeaBoardLandingPage/IdeaBoardLanding/IdeaBoardLanding'),
  options
);

export const Links = universal(
  import(/* webpackChunkName: "links" */ './containers/Pages/Links/index'),
  options
);

export const MyAccountDashboard = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/MyAccountDashboard/MyAccountDashboard'),
  options
);

export const MyOffers = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/MyOffers/MyOffers'),
  options
);

export const RegistryNotifications = universal(
  import(/* webpackChunkName: "account-registry-notifications" */ './containers/Pages/RegistryNotifications/RegistryNotifications'),
  options
);

export const MyRegistries = universal(
  import(/* webpackChunkName: "account-my-registries" */ './containers/Pages/MyRegistries/MyRegistries'),
  options
);

export const PDP = universal(
  import(/* webpackChunkName: "product-details" */ './containers/Pages/PDP/PDP'),
  options
);

export const PersonalInfo = universal(
  import(/* webpackChunkName: "personal-info" */ './containers/Pages/PersonalInfo/PersonalInfo'),
  options
);

export const PrintIC = universal(
  import(/* webpackChunkName: "registry-printIC" */ './containers/InteractiveChecklist/PrintIC/PrintIc'),
  options
);

/* To avoid the empty white space after a user search, we need to load the chunk sooner than later. */
export const ProductSearch = universal(
  import(/* webpackChunkName: "product-search" */ './containers/Pages/ProductSearch/ProductSearch'),
  options
);

export const RegistryOwner = universal(
  import(/* webpackChunkName: "registry-viewer" */ './containers/Pages/Registry/RegistryOwner/RegistryOwner'),
  options
);

export const FlipFlop = universal(
  import(/* webpackChunkName: "registry-flip-flop-viewer" */ './containers/Pages/Registry/RegistryOwner/FlipFlop/FlipFlop'),
  options
);

export const RegistryOwnerHome = universal(
  import(/* webpackChunkName: "registry-home" */ './containers/Pages/Registry/RegistryOwnerHome/RegistryOwnerHome'),
  options
);

export const RegistryTools = universal(
  import(/* webpackChunkName: "registry-tools" */ './containers/Pages/RegistryTools/RegistryTools'),
  options
);

export const RegistryQuickPicksCollection = universal(
  import(/* webpackChunkName: "registry-quickpicks" */ './containers/Pages/Registry/QuickPicks/Collection/QuickPicksCollection'),
  options
);

export const RegistryQuickPicksLanding = universal(
  import(/* webpackChunkName: "registry-quickpicks" */ './containers/Pages/Registry/QuickPicks/Landing/QuickPicksLanding'),
  options
);

export const RegistrySearchResults = universal(
  import(/* webpackChunkName: "registry-search" */ './containers/Pages/Registry/SearchResults/SearchResults'),
  options
);

export const RedirectToRegistrySearch = universal(
  import(/* webpackChunkName: "RedirectToRegistrySearch" */ './containers/Pages/Registry/SearchResults/RedirectToRegistrySearch'),
  options
);

export const ResetYourPassword = universal(
  import(/* webpackChunkName: "account-reset-your-password" */ './containers/Pages/ResetYourPassword/ResetYourPassword'),
  options
);

export const ReviewYourProducts = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/ReviewYourProducts/ReviewYourProducts'),
  options
);

export const RegistryOwnerMain = universal(
  import(/* webpackChunkName: "registry-ownerMain" */ './containers/Pages/Registry/RegistryOwnerMain/RegistryOwnerMain'),
  options
);

export const SignIn = universal(
  import(/* webpackChunkName: "account-signIn" */ './containers/Pages/SignIn/SignIn'),
  options
);

export const GenericSignIn = universal(
  import(/* webpackChunkName: "generic-login" */ './containers/Pages/SignIn/GenericSignIn'),
  options
);

export const GenericSignOut = universal(
  import(/* webpackChunkName: "generic-logout" */ './containers/Pages/SignIn/GenericSignOut'),
  options
);

export const GenericAccountRegistration = universal(
  import(/* webpackChunkName: "generic-create-acct" */ './containers/Pages/AccountRegistration/GenericAccountRegistration'),
  options
);

export const SignUpForOffers = universal(
  import(/* webpackChunkName: "account" */ './containers/Pages/SignUpForOffers/SignUpForOffers'),
  options
);

export const SocialAnnexGallery = universal(
  import(/* webpackChunkName: "socialAnnexGallery" */ './containers/Pages/SocialAnnexGallery/SocialAnnexGallery'),
  options
);

export const SocialRecommendation = universal(
  import(/* webpackChunkName: "SocialRecommendation" */ './containers/Pages/Registry/Recommendations/Recommendations'),
  options
);

export const StaticExperiencePage = universal(
  import(/* webpackChunkName: "static-experience" */ './containers/Pages/ExperiencePage/StaticExperiencePage'),
  options
);

export const SessionExpiryPage = universal(
  import(/* webpackChunkName: "sessionExpiryPage" */ './containers/Pages/SessionExpiryPage/SessionExpiryPage'),
  options
);

export const ThankYouManager = universal(
  import(/* webpackChunkName: "ThankYouManager" */ './containers/Pages/Registry/ThankYouManager/ThankYouManager'),
  options
);

export const TrackInternationalOrder = universal(
  import(/* webpackChunkName: "trackInternationalOrder" */ './containers/Pages/TrackInternationalOrder/TrackInternationalOrder'),
  options
);

export const WalletRegistration = universal(
  import(/* webpackChunkName: "wallet-registration" */ './containers/Pages/WalletRegistration/WalletRegistration'),
  options
);

export const EmailCouponRedirect = universal(
  import(/* webpackChunkName: "EmailCouponRedirect" */ './containers/Pages/EmailCouponRedirect/EmailCouponRedirect'),
  options
);

export const HighAPRReasons = universal(
  import(/* webpackChunkName: "highAPRReasons" */ './containers/Pages/HighAPRReasons/HighAPRReasons'),
  options
);

export const InstantCreditExperiencePage = universal(
  import(/* webpackChunkName: "instantCreditExperience" */ './containers/Pages/InstantCreditExperiencePage/InstantCreditExperiencePage'),
  options
);

export const CollegeLanding = universal(
  import(/* webpackChunkName: "CollegeLanding" */ './containers/Pages/CollegeLanding/CollegeLanding'),
  options
);

export const Weblinks = universal(
  import(/* webpackChunkName: "Weblinks" */ './containers/Pages/Weblinks/Weblinks'),
  options
);

export const OrganizationLanding = universal(
  import(/* webpackChunkName: "OrganizationLanding" */ './containers/Pages/OrganizationLanding/OrganizationLanding'),
  options
);

export const OrganizationWeblink = universal(
  import(/* webpackChunkName: "OrganizationWeblink" */ './containers/Pages/OrganizationWeblink/OrganizationWeblink'),
  options
);

export const AccountMyFunds = universal(
  import(/* webpackChunkName: "AccountMyFunds" */ './containers/Pages/AccountMyFunds/AccountMyFunds'),
  options
);

export const AccountReorder = universal(
  import(/* webpackChunkName: "AccountReorder" */ './containers/Pages/AccountReorder/AccountReorder'),
  options
);

export const BeyondPlus = universal(
  import(/* webpackChunkName: "BeyondPlus" */ './containers/Pages/BeyondPlus/BeyondPlus'),
  options
);

export const BeyondPlusPage = universal(
  import(/* webpackChunkName: "BeyondPlus" */ './containers/Pages/BeyondPlusPage/BeyondPlusPage'),
  options
);

export const BeyondPlusHandRaiser = universal(
  import(/* webpackChunkName: "BeyondPlusHandRaiser" */ './containers/Pages/BeyondPlushandraiser/BeyondPlusHandRaiser'),
  options
);

export const CustomerSurvey = universal(
  import(/* webpackChunkName: "CustomerSurvey" */ './containers/Pages/CustomerSurvey/CustomerSurvey'),
  options
);

export const ComparePage = universal(
  import(/* webpackChunkName: "ComparePage" */ './containers/Pages/Compare/ComparePage/ComparePage'),
  options
);

export const CollegeChecklist = universal(
  import(/* webpackChunkName: "CollegeChecklist" */ './containers/Pages/CollegeChecklist/CollegeChecklist'),
  options
);

export const MoverChecklist = universal(
  import(/* webpackChunkName: "MoverChecklist" */ './containers/Pages/MoverChecklist/MoverChecklist'),
  options
);

export const PNHChecklist = universal(
  import(/* webpackChunkName: "PNHChecklist" */ './containers/Pages/PNHChecklist/PNHChecklist'),
  options
);

export const ListOwnerView = universal(
  import(/* webpackChunkName: "list-owner" */ './containers/Pages/CollegeChecklist/ListOwnerView/ListOwnerView'),
  options
);

export const MoversListOwnerView = universal(
  import(/* webpackChunkName: "MoversListOwner" */ './containers/Pages/MoverChecklist/MoversListOwnerView/MoversListOwnerView'),
  options
);

export const PNHListOwnerView = universal(
  import(/* webpackChunkName: "PNHListOwner" */ './containers/Pages/PNHChecklist/PNHListOwnerView/PNHListOwnerView'),
  options
);

export const PNHChecklistOwner = universal(
  import(/* webpackChunkName: "PNHChecklistOwner" */ './containers/Pages/PNHChecklist/PNHChecklistOwner/PNHChecklistOwner'),
  options
);

export const CheckListHome = universal(
  import(/* webpackChunkName: "list-home" */ './containers/Pages/CollegeChecklist/CheckListHome/CheckListHome'),
  options
);

export const PNHCheckListHome = universal(
  import(/* webpackChunkName: "list-home" */ './containers/Pages/PNHChecklist/PNHCheckListHome/CheckListHome'),
  options
);

export const ChecklistOwner = universal(
  import(/* webpackChunkName: "checklist-owner" */ './containers/Pages/CollegeChecklist/ChecklistOwner/ChecklistOwner'),
  options
);

export const ArticlePage = universal(
  import(/* webpackChunkName: "article-page" */ './contentHub/containers/ArticlePage/ArticlePage'),
  options
);

export const CustomOrders = universal(
  import(/* webpackChunkName: "custom-orders" */ './containers/Pages/Tbs/CustomOrders/CustomOrders'),
  options
);

export const OrderSearch = universal(
  import(/* webpackChunkName: "order-search" */ './containers/Pages/Tbs/OrderSearch/OrderSearch'),
  options
);

export const RecommendItems = universal(
  import(/* webpackChunkName: "recommend-items" */ './containers/Pages/Tbs/RecommendItems/RecommendItems')
);

export const OrderDetail = universal(
  import(/* webpackChunkName: "order-detail" */ './containers/Pages/Tbs/OrderDetail/OrderDetail'),
  options
);

export const RecommenderLandingPage = universal(
  import(/** webpackChunkName: "recommender-page" */ './containers/Pages/Registry/RecommenderLanding/RecommenderLanding'),
  options
);

export const MieSearch = universal(
  import(/* webpackChunkName: "mieSearch-page" */ './containers/Pages/Tbs/MieSearch/MieSearch'),
  options
);

export const Collegelookbook = universal(
  import(/* webpackChunkName: "Collegelookbook-page" */ './containers/Pages/Collegelookbook/Collegelookbook'),
  options
);

export const PrintRegistry = universal(
  import(/* webpackChunkName: "PrintRegistry" */ './containers/Pages/Registry/RegistryOwner/PrintRegistry/PrintRegistry'),
  options
);

export const PrintChecklist = universal(
  import(/* webpackChunkName: "PrintChecklist" */ './containers/Pages/PNHChecklist/PNHChecklistOwner/PrintChecklist/PrintChecklist'),
  options
);

export const EventsPage = universal(
  import(/* webpackChunkName: "EventsPage" */ './containers/Pages/EventsPage/EventsPage'),
  options
);

export const ShallowProfileRegistration = universal(
  import(/* webpackChunkName: "ShallowProfileRegistration" */ './containers/Pages/ShallowProfileRegistration/ShallowProfileRegistration'),
  options
);

export const CustomerFacingForm = universal(
  import(/* webpackChunkName: "CustomerFacingForm" */ './containers/Pages/CustomerFacingForm/CustomerFacingForm'),
  options
);

export const DeleteAccountOfCustomer = universal(
  import(/* webpackChunkName: "DeleteAccountOfCustomer" */ './containers/Pages/DeleteCustomerAccount/DeleteCustomerAccount'),
  options
);

export const BuyingGuidePage = universal(
  import(/* webpackChunkName: "BuyingGuidePage" */ './containers/BuyingGuide/BuyingGuidePage/BuyingGuidePage'),
  options
);

export const SubscriptionMSI = universal(
  import(/* webpackChunkName: "SubscriptionMsi" */ './containers/Pages/SubscriptionMSI/SubscriptionMSI'),
  options
);

export const CollegeSavingsPass = universal(
  import(/* webpackChunkName: "savings-pass" */ './containers/Pages/SavingsPass/CollegeSavingsPass/CollegeSavingsPass'),
  options
);

export const MilitarySavingsPass = universal(
  import(/* webpackChunkName: "savings-pass" */ './containers/Pages/SavingsPass/MilitarySavingsPass/MilitarySavingsPass'),
  options
);

export const CurbsidePickupRedirection = universal(
  import(/* webpackChunkName: "curbside-pickup-redirection" */ './containers/Pages/CurbsidePickupRedirection/CurbsidePickupRedirection'),
  options
);

export const ForbiddenHttpErrorPage = universal(
  import(/* webpackChunkName: "error-page */ '@bbb-app/error-pages/containers/http-error-pages/ForbiddenPage'),
  options
);

export const ProductNotFoundPage = universal(
  import(/* webpackChunkName: "error-page */ './containers/Pages/ErrorPage/HttpErrorPages/ProductNotFoundPage'),
  options
);

export const GenericErrorPageX = universal(
  import(/* webpackChunkName: "error-page */ '@bbb-app/error-pages/containers/http-error-pages/GenericErrorPage'),
  options
);

export const CurbsideEditPickupRedirection = universal(
  import(/* webpackChunkName: "curbside-pickup-redirection" */ './containers/Pages/CurbsidePickupRedirection/CurbsideEditPickupRedirection'),
  options
);

export const SeoExperience = universal(
  import(/* webpackChunkName: "seoExperience" */ './containers/SlotMachineDetails/SeoExperience/SeoExperience'),
  options
);

export const ShoppingList = universal(
  import(/* webpackChunkName: "shoppingList" */ './containers/Pages/ShoppingList/ShoppingList'),
  options
);
/* eslint-enable extra-rules/no-commented-out-code */
