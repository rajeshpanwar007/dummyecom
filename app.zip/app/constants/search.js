/**
 * Defines the regex for the common filter-related URL segments
 * used on Search and other PLPs.
 */
export const ROUTE_PLP_FILTERABLE_PATH =
  '/:sws(fl_[A-Za-z-0-9_]+)?/:friendlyFacets(_[A-Za-z-0-9_-]+)?/:startPerPage(\\d+-\\d+)?/:store(store-\\d+)?/:sdd(sdd-[0-9]+_[0-9]+)?/:ed(edd-[A-Za-z-0-9_-]+)?/:sddZip(sddZip-[A-Za-z-0-9_-]+)?/:facets?';

/**
 * Defines the regex for the virtual caegory URL params
 * used on L1, L2, L3 pages
 */
export const VIRTUAL_CATEGORY_PATH = `/:virtualId(v_[A-Za-z-0-9_-]+)?`;
/**
 * Defines the regex for the Category Route.
 * @type {string}
 */

/**
 * Cookie injected by ATG can will be used to populate search clist when ATG data is not in store.
 * @type {string}
 */

export const ROUTE_CATEGORY_L1_PATH =
  '/store/category/:level1?/:categoryId(\\d+)/';

/**
 * Defines the regex for the CLP PLP Route .
 * @type {string}
 */
export const ROUTE_CLP_CATEGORY_PATH = `/store/category/:level1/:categoryId(\\d+)`;

/**
 * Defines the regex for the Category Routes for specific L1s that should render L2/L3 templates.
 * /store/category/:level1(whats-new||new-arrivals||clearance-savings||clearance)/:categoryId(\\d+)/
 * @type {string}
 */
const STATE_KEY = 'search';

/**
 * Defines the regex for the PLP Routes
 * @type {string}
 */
export const ROUTE_PLP_PATH = `/store/(category||s||brand)`;

/**
 * Defines the regex for the Search Results Route
 * @type {string}
 */

/**
+ * Defines the regex for the Brand Route.
+ * @type {string}
+ */

/**
 * Namespace used to delineate Search actions
 *
 * @type {string}
 */
export const NAMESPACE = 'BBB/Search';

/**
 * State key
 * @type {string}
 */

export const SS_STATE_KEY = 'sitespect';

/**
 * Site Config State Key
 */

/**
 * Site Config State Key
 */
export const SITE_CONFIG_STATE_KEY = 'siteConfig';

/**
 * PLP Config State Key
 */
export const PLP_CONFIG_STATE_KEY = 'plpconfiguration';

/**
 * SRP Config State Key
 */
export const SRP_CONFIG_STATE_KEY = 'searchResults';

/**
 * Key name for the pricing range facet
 * @type {string}
 */
export const PRICE_KEY = 'LOW_PRICE';

/**
 * Key name for the rating facet
 * @type {string}
 */
export const RATING_KEY = 'RATINGS';

/**
 * Action type for setting state before a request
 * @type {string}
 */
export const PREPARE_FOR_REQUEST = `${NAMESPACE}/PREPARE_FOR_REQUEST`;

/**
 * Action type for fetching category data
 * @type {string}
 */
export const FETCH_CATEGORY = `${NAMESPACE}/FETCH_CATEGORY`;

/**
 * Action type for fetching category FACET data
 * @type {string}
 */
export const FETCH_CATEGORY_FACET = `${NAMESPACE}/FETCH_CATEGORY_FACET`;

/**
 * Applied to search string when pagination, sort, or per page dropdown changes
 * @type {string}
 */
export const UPDATE_CATEGORY_FILTER = `${NAMESPACE}/UPDATE_CATEGORY_FILTER`;

/**
 * Applied when user changes a filter on the search page results page.
 * @type {string}
 */
export const UPDATE_SEARCH_FILTER = `${NAMESPACE}/UPDATE_SEARCH_FILTER`;

/**
 * Initializes parameters during category page load.
 * @type {string}
 */
export const INITIALIZE_PARAMS = `${NAMESPACE}/INITIALIZE_PARAMS`;

/**
 * Used to indicate that filters must be cleared.
 * @type {string}
 */
export const CLEAR_SELECTED_FILTER = `${NAMESPACE}/CLEAR_SELECTED_FILTER`;

/**
 * Used to indicate that filters must be cleared.
 * @type {string}
 */
export const CLEAR_AND_UPDATE_SELECTED_FILTER = `${NAMESPACE}/CLEAR_AND_UPDATE_SELECTED_FILTER`;

/**
 * Sets the applied filters array to indicate which filters were selected.
 * @type {string}
 */
export const SET_APPLIED_FILTER = `${NAMESPACE}/SET_APPLIED_FILTER`;

/**
 * Sets the store availability flag
 * @type {string}
 */
export const SET_STORE_AVAILABILITY = `${NAMESPACE}/SET_STORE_AVAILABILITY`;

/**
 * Opens the compare products dialog
 * @type {string}
 */
export const OPEN_COMPARE = `${NAMESPACE}/OPEN_COMPARE`;

/**
 * Add product to ideaboard
 * @type {string}
 */
export const ADD_TO_IDEABOARD = `${NAMESPACE}/ADD_TO_IDEABOARD`;

/**
 * Old scroll category action replacing with product exposure
 * @type {string}
 */
export const SCROLL_CATEGORY = `${NAMESPACE}/SCROLL_CATEGORY`;

/**
 * New Product exposure for Tealium/Snowplow
 * @type {string}
 */
export const PRODUCT_EXPOSURE = `${NAMESPACE}/PRODUCT_EXPOSURE`;
export const OBSERVE_PRODUCTS = `${NAMESPACE}/OBSERVE_PRODUCTS`;
/**
 * Sets the small screen view type (e.g. list or grid)
 * @type {string}
 */
export const SET_SMALL_VIEW_TYPE = `${NAMESPACE}/SET_SMALL_VIEW_TYPE`;

/**
 * The available small view type for the Category/Search pages
 */
export const SMALL_VIEW_TYPES = {
  GRID: { value: 'grid', iconType: 'grid' },
  LIST: { value: 'list', iconType: 'list' },
};
export const GRID_VIEW_TYPE = 'GRID';
export const LIST_VIEW_TYPE = 'LIST';

/**
 * Sets the Ssarch results page data object with data from Solr.
 * @type {string}
 */
export const SET_SEARCH_RESULTS = `${NAMESPACE}/SET_SEARCH_RESULTS`;

/**
 * Used to fetch search results data.
 * @type {string}
 */
export const FETCH_SEARCH_RESULTS = `${NAMESPACE}/FETCH_SEARCH_RESULTS`;

/**
 * Used to fetch facet results data.
 * @type {string}
 */
export const FETCH_FACET_RESULTS = `${NAMESPACE}/FETCH_FACET_RESULTS`;

/**
 * Used to fetch Store info and make SOLR call to fetch store item count .
 * @type {string}
 */
export const PACK_HOLD_STORE_DATA = `${NAMESPACE}/PACK_HOLD_STORE_DATA`;

export const PACK_HOLD_STORE_DATA_SUCCESS = `${NAMESPACE}/PACK_HOLD_STORE_DATA_SUCCESS`;
export const FAVOURITE_STORE_ITEM = `${NAMESPACE}/FAVOURITE_STORE_ITEM`;

/**
 * It will add PNH list in search store
 */
export const SELECT_PNH_LIST_ID = `${NAMESPACE}/SELECT_PNH_LIST_ID`;

/**
 * Save data to be used for personalization
 * @type {string}
 */
export const SET_PERSONALIZATION_DATA = `${NAMESPACE}/SET_PERSONALIZATION_DATA`;

/**
 * Used to save keywords searched for.
 * @type {string}
 */
export const SAVE_SEARCH_TERM = `${NAMESPACE}/SAVE_SEARCH_TERM`;

/**
 * Used to clear keywords searched for.
 * @type {string}
 */
export const CLEAR_SEARCH_TERM = `${NAMESPACE}/CLEAR_SEARCH_TERM`;

/**
 * Used to save sku ids for items in the cart
 * @type {string}
 */
export const UPDATE_CART_SKU_IDS = `${NAMESPACE}/UPDATE_CART_SKU_IDS`;

/**
 * The cookie name for storing paga size selected  by user.
 * @type {string}
 */

/**
 * Default value for sort by used to display "Sort by" option on category pages.
 * @type {string}
 */

/**
 * Delimiter for sws terms used for tracking and parsing in the url. the list is maintained on the frontend.
 * @type {string}
 */
export const SWS_TERM_DELIM = 'fl_';
/**
 * Regex expression for parsing page and items per page stored in search URL.
 * E.g. 10-48 parses to Page 10, 48 items per page.
 * @type {RegExp}
 */
export const REGEX_START_PER_PAGE = /(\d+)-(\d+)/;

/**
 * Regex express for parsing store number in search URL.
 * E.g. store-333 indicates store number 333
 * @type {RegExp}
 */
export const REGEX_STORE_NUMBER = /^store-(\d+)$/;

/**
 * Default value for sort by option used to display "BEST MATCH" on search pages.
 * @type {string}
 */

/**
 * Default value for sort by option used to display "MOST POPULAR" on search college checklist category pages.
 * @type {string}
 */
export const DEFAULT_CATEGORY_CHECKLIST_SORT_BY = 'MOST_POPULAR desc';

/**
 * Default value for sort by option used to display "MOST POPULAR" on search mover checklist category pages.
 * @type {string}
 */
export const DEFAULT_CATEGORY_MOVER_CHECKLIST_SORT_BY = 'MOST_POPULAR desc';

export const DEFAULT_CATEGORY_PNH_CHECKLIST_SORT_BY = 'MOST_POPULAR desc';

/**
 * Action type for indicating an error has occurred.
 * @type {string}
 */
export const HANDLE_ERROR_COND = `${NAMESPACE}/HANDLE_ERROR_COND`;

/**
 * Set search within search term
 * @type {string}
 */
export const SET_SEARCH_WITHIN_SEARCH_TERM = `${NAMESPACE}/SET_SEARCH_WITHIN_SEARCH_TERM`;

/**
 * The <Rating /> component accepts a value between 0 and 1,
 * so this is used here to convert values from the API
 * response, which are numbers in the 0-5 range.
 */

/**
 * The <ProductTile /> component accepts an array of attributes.
 * This array needs to be limited to certain number of items.
 * This is that limit.
 */
export const ATTRIBUTE_LIMIT = 3;

/**
 * The mode the filters are running in.
 *
 * @type {string}
 */
export const MODE_SEARCH_RESULTS_PAGE = 'search-results-page';

/**
 * The mode the filters are running in.
 *
 * @type {string}
 */
export const MODE_CATEGORY_PAGE = 'category-page';

export const FETCH_CATEGORY_ERROR = `${NAMESPACE}/FETCH_CATEGORY_ERROR`;
export const ERROR_CATEGORY_NOT_FOUND = `${NAMESPACE}/ERROR_CATEGORY_NOT_FOUND`;
export const ERROR_CATEGORY_SERVICE_FAILED = `${NAMESPACE}/ERROR_CATEGORY_SERVICE_FAILED`;
export const RESET_START_TO_INITIAL = `${NAMESPACE}/RESET_START_TO_INITIAL`;
export const RESET_START_TO_ZERO = `${NAMESPACE}/RESET_START_TO_ZERO`;

/**
 * Action type to set region data.
 *
 * @type {string}
 */
export const SET_REGION_DATA = `${NAMESPACE}/SET_REGION_DATA`;

/**
 * Set scroll top
 * @type {string}
 */
export const SET_SCROLL_TOP = `${NAMESPACE}/SET_SCROLL_TOP`;

/**
 * Exports query parameter names used on Search and Category grids.
 */

export const FETCH_BRAND = `${NAMESPACE}/FETCH_BRAND`;
export const FETCH_BRAND_FACET = `${NAMESPACE}/FETCH_BRAND_FACET`;
export const FETCH_BRAND_ERROR = `${NAMESPACE}/FETCH_BRAND_ERROR`;

/**
+ * Action type for setting brand data
+ * @type {string}
+ */
export const SET_BRAND = `${NAMESPACE}/SET_BRAND`;
export const BRAND_DEFAULT_EXPERIENCE = '/store/brand/';

/**
 * Name of cookie for retrieving logged in user's profile id
 *
 * @type {string}
 */
export const ATG_PROFILE_COOKIE = 'ATG_PROFILE_DATA';

/**
 * Regex for snowplow cookies
 *
 * @type {RegExp}
 */
export const SNOWPLOW_COOKIE_REGEX = /_sp_id(?:\.[a-f0-9]+)?(?:=([^;]+);)?/;

/**
 * Name of cookie for retrieving user's history of search terms and cart sku ids
 * Format of data: search term 1,search term 2|41676301,43519194,43519170
 *
 * @type {string}
 */
export const PERSONALIZATION_COOKIE = 'personalizationList';

/**
 * Name of cookie for retrieving user's Recently Viewed Items.
 * Format of data: recentlyViewedItem1,recentlyViewedItem2,recentlyViewedItem3,....
 *
 * @type {string}
 */

/**
 * Name of cookie for retrieving user's history of search terms
 * Format of data: search term 1,search term 2
 *
 * @type {string}
 */

/**
 * Threshold for how many facets should be shown in the
 * "summary" heading text for SEO.
 *
 * @type {number}
 */
export const MAX_FACETS_FOR_SUMMARY = 2;

/**
 * Search radius for finding a store near you
 */
export const DEFAULT_STORE_RADIUS = 25;

export const SET_PNH_STORE_DETAILS = `${NAMESPACE}/SET_PNH_STORE_DETAILS`;

/**
 * Action type for setting the "in store" item count
 *
 * @type {string}
 */
export const SET_STORE_COUNT = `${NAMESPACE}/SET_STORE_COUNT`;

/**
 * Matches text up to the last underscore for department facets
 *
 * @type {RegExp}
 */
export const DEPARTMENT_FACETS_REGEX = /(\d+)\/(?:.*(?=(_)))_/;

/**
 * Constant for department facet.
 *
 * @type {string}
 */
export const DEPARTMENT_FACETS_KEY = 'CATEGORY_HIERARCHY';

/**
 * Constant for college category exceptions.
 *
 * @type {string}
 */
export const COLLEGE = 'college';

/**
 * Constant for university category exceptions.
 *
 * @type {string}
 */
export const UNIVERSITY = 'university';

/**
 * Constant for brand template type
 *
 * @type {string}
 */
export const SET_BRAND_TEMPLATE_TYPE = 'SET_BRAND_TEMPLATE_TYPE';

/**
 * Action type for setting the "department facet" to store
 *
 * @type {string}
 */
export const SET_DEPARTMENT_FACET = `${NAMESPACE}/SET_DEPARTMENT_FACET`;

/**
 * Action type for signaling the product grid mount lifecycle phase
 *
 * @type {string}
 */
export const PRODUCT_GRID_MOUNTED = `${NAMESPACE}/PRODUCT_GRID_MOUNTED`;

/**
 * Action type for updating the product listing items with new prices.
 *
 * @type {string}
 */
export const REPRICE_LISTING = `${NAMESPACE}/REPRICE_LISTING`;

/**
 * The leaf (max) level for categories
 *
 * @type {number}
 */
export const LEAF_CATEGORY_LEVEL = 3;

export const SET_PRODUCT_ID_FOR_ANCHOR = `${NAMESPACE}/SET_PRODUCT_ID_FOR_ANCHOR`;

export const RESET_PRODUCT_ID_AFTER_ANCHOR = `${NAMESPACE}/RESET_PRODUCT_ID_AFTER_ANCHOR`;
export const CHECK_PRODUCT_DATA_LOADED = `${NAMESPACE}/CHECK_PRODUCT_DATA_LOADED`;
export const SET_PRODUCT_GRID_RENDER_FLAG = `${NAMESPACE}/SET_PRODUCT_GRID_RENDER_FLAG`;
export const UPDATE_ATTRIBUTES_LIST = `${NAMESPACE}/UPDATE_ATTRIBUTES_LIST`;
export const NUMFOUND_UNDEFINED_MSG = `Cannot read property 'numFound' of undefined`;
export const SCROLL_TO_TOP_RESET = 'scrollToTopReset';
/* PLP EDD Availability Constants*/
export const FETCH_EDD_FACET_DATA = `${NAMESPACE}/FETCH_EDD_FACET_DATA`;
export const UPDATE_EDD_OPT_SELECTION = `${NAMESPACE}/UPDATE_EDD_OPT_SELECTION`;
export const UPDATE_SDD_OPT_SELECTION = `${NAMESPACE}/UPDATE_SDD_OPT_SELECTION`;
export const REPRICE_SAGA_KEY = `${STATE_KEY}REPRICE_SAGA`;
export const PACK_AND_HOLD_SAGA_KEY = `${STATE_KEY}PACK_AND_HOLD_SAGA`;
export const SET_EDD_FACET_COUNT = `${NAMESPACE}/SET_EDD_FACET_COUNT`;
export const SET_SDD_FACET_COUNT = `${NAMESPACE}/SET_SDD_FACET_COUNT`;
export const SET_EDD_FACET_DATA = `${NAMESPACE}/SET_EDD_FACET_DATA`;
export const FETCH_EDD_FACET_DATA_ERROR = `${NAMESPACE}/FETCH_EDD_FACET_DATA_ERROR`;
export const PRODUCT_EXPOSURE_SAGA_KEY = `TEALIUM_PRODUCT_EXPOSURE_SAGA`;
export const UPDATE_EDD_ZIP_CODE = `${NAMESPACE}/UPDATE_EDD_ZIP_CODE`;
export const UPDATE_EDD_AVAILABILITY = `${NAMESPACE}/UPDATE_EDD_AVAILABILITY`;

export const CHECKLIST_CATEGORY_IDENTIFIER = 'CHECKLIST_CATEGORY';
export const CATEGORY_IDENTIFIER = 'PLP_CATEGORY';
export const SEARCH_SAGA_KEY = 'SEARCH_SAGA';
export const SEARCH_WITH_IN_SEARCH_FLAG = 'SEARCH_WITH_IN_SEARCH_FLAG';
export const SWS_CONTENT_NOT_FOUND = 'SWS_CONTENT_NOT_FOUND';
export const FETCH_ZIP_TIME_ZONE_MAPPING_SUCCESS =
  'FETCH_ZIP_TIME_ZONE_MAPPING_SUCCESS';
export const FETCH_ZIP_TIME_ZONE_MAPPING_ERROR =
  'FETCH_ZIP_TIME_ZONE_MAPPING_ERROR';
export const SEARCH_CDP_BADGE = '7464,5400';
export const ERROR_RESET = 'ERROR_RESET';
export const FETCH_PICK_UP_STORE_DETAILS = 'BBB/FETCH_PICK_UP_STORE_DETAILS';
export const CLEAR_PICK_UP_STORE_DETAILS = 'BBB/CLEAR_PICK_UP_STORE_DETAILS';
export const IS_SEARCH_RESULT_PAGE = 'IS_SEARCH_RESULT_PAGE';
export const PRODUCT_MIN_URL =
  '/apis/services/composite/product-listing/v1.0/product-min';
export const TOGGLE_CONTENT_LOADING = `${NAMESPACE}/TOGGLE_CONTENT_LOADING`;

/**
 * Action type for fetching more FACET data
 * @type {string}
 */
export const FETCH_MORE_FACETS = `${NAMESPACE}/FETCH_MORE_FACETS`;
export const FETCH_MORE_FACETS_SUCCESS = `${NAMESPACE}/FETCH_MORE_FACETS_SUCCESS`;
export const DISABLE_SDD_CHECKBOX = `${NAMESPACE}/DISABLE_SDD_CHECKBOX`;
export const MOBILE_SLOT_CATEGORY = 15020;
export const DESKTOP_SLOT_CATEGORY = 15015;
export const MOBILE_SLOT_SEARCH = 15010;
export const DESKTOP_SLOT_SEARCH = 15005;
export const PIQ_CLICK_TRACKER = `BBB/Search/PIQ_CLICK_TRACKER`;
export const SAVE_PROMOTEIQ_KEY = 'savePromoteIQ';
