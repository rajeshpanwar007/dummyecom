export const FACEBOOK = 'facebook';
export const TWITTER = 'twitter';
export const PINTEREST = 'pinterest';
export const GOOGLEPLUS = 'googleplus';
export const MAIL = 'mail';

// Standard and latest share URLs (April 2018)

export const FACEBOOK_URL = 'https://www.facebook.com/sharer/sharer.php?u=';
export const TWITTER_URL = 'https://twitter.com/intent/tweet?text=';
export const PINTEREST_URL =
  'https://www.pinterest.com/pin/create/button/?url=';
export const GOOGLEPLUS_URL = 'https://plus.google.com/share?url=';

// Pinterest share image
// TODO in US: Replace this absolute path of current existing PROD image with a relative path in the newer environment.

export const pinterestImage =
  'https://www.buybuybaby.com/static/assets/favicon/BuyBuyBaby/apple-touch-icon.png';
export const TEALIUM_PAGE_INFO = {
  page_type: 'Registry',
  page_name: 'email registry',
};
