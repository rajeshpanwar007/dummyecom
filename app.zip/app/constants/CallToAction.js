/*
 * This file is renamed from `AddToCart.js` to `CallToAction.js`
 * these constants are used by CTA components `AddToCart` and `AddToRegistry` for error handling
 * `ACTION_CART` and `ACTION_REGISTRY` are set in the state `callToActionValue` of ProductDetails component
 * with respect to the action choosen by the user
 * Accordingly labels  are created as ATC_NO_COLOR, ATR-NO_COLOR
 * and are fetched from CMS like `${callToActionValue}_[NO_COLOR|NO_SIZE|NO_LTL]`
 */
export const NO_QTY = 'NO_QTY';
export const NO_PRICE = 'NO_PRICE';
export const NO_SIZE = 'NO_SIZE';
export const NO_SWATCH = 'NO_SWATCH';
export const NO_LTL = 'NO_LTL';
export const ACTION_CART = 'ATC';
export const ACTION_REGISTRY = 'ATR';
export const ACTION_PROTECTION_PLAN = 'APP';
export const NO_FINISH = 'NO_FINISH';
export const NO_COLOR_SIZE = 'NO_COLOR_SIZE';
export const NO_FINISH_SIZE = 'NO_FINISH_SIZE';
export const NO_COLOR = 'NO_COLOR';
