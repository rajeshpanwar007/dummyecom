# Sample Test Cases

Run sample test cases with coverage using PhantomJS:
```bash
yarn run test:sample
```

## Other Commands

Run unit tests once:
```bash
npm test
```

Run tests in watch mode for continuous development:
```bash
yarn run test:watch
```

Any browser, default is PhantomJS:
```bash
yarn run test -- --browsers=PhantomJS
yarn run test -- --browsers=Chrome
yarn run test -- --browsers=Firefox
yarn run test -- --browsers=Safari
```

Coverage:
```bash
yarn run test -- --coverage
```
OR
```bash
yarn run test:coverage
```

Run tests for any folder/file (Regex):
```bash
yarn run test -- --grep '.*/utils/identity/.*'
```
OR
```bash
yarn run test -- --grep '.*/utils/identity/tests/identity.test.js'
```
