/**
 * app.js
 *
 * This is the entry file for the application, only setup and boilerplate
 * code.
 */
/* eslint-disable
  global-require,
  no-shadow,
  import/no-unresolved,
  import/extensions,
  import/first */
// Needed for redux-saga es6 generator support
// import '@babel/polyfill';
// import 'core-js/stable';
// import 'regenerator-runtime/runtime';

// Import all the third party stuff
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider, ReactReduxContext } from 'react-redux';
// import { useScroll } from 'react-router-scroll';
import { ConnectedRouter } from 'connected-react-router/immutable';
// import { AppContainer, setConfig } from 'react-hot-loader';
import { pathOr } from 'lodash/fp';
import CommonUtil from '@bbb-app/utils/commonUtil';
import App from 'containers/App';
import navMarkupUtil from '@bbb-app/utils/navMarkupUtil';
// Import CSS reset and Global Styles
import '@bbb-app/styles/inline/index.css';
// Importing styles from main folder (included in main CSS (bbb*) bundle)
import '@bbb-app/styles/main/index.css';

// Sync history and store, as the connected-react-router reducer
// is under the non-default key ("routing"), selectLocationState
// must be provided for resolving how to retrieve the "route" in the state
import history from '@bbb-app/utils/history';

// Prepare the SVG icon sprite map
import { initFontLoading } from '@bbb-app/utils/fonts';
import labelsContentUtil from '@bbb-app/utils/labelsContentUtil';
import deferFunctionOnEvent from '@bbb-app/utils/deferOnEventUtil';
import { setMultiAppRef } from '@bbb-app/utils/multiAppUtil';
import { MULTI_APP_REF } from '@bbb-app/constants/globalConstants';
// import { routes } from 'routes';
import configureStore from './store';
import rootSaga from './sagas/rootSaga';

// import fetchDataForRoute from './utils/fetchDataForRoute';

import { headerInit } from './app.header';

// Import routes
// import createRoutes from './routes';

initFontLoading();
setMultiAppRef(MULTI_APP_REF.MAIN_APP);

// Create redux store with history
// this uses the singleton browserHistory provided by react-router
// Optionally, this could be changed to leverage a created history
// e.g. `const browserHistory = useRouterHistory(createBrowserHistory)();`
/* eslint-disable no-underscore-dangle */
const initialState = window.__INITIAL_STATE__;

if (
  pathOr(false, ['viewportConfig'], initialState) &&
  pathOr(false, ['siteConfig', 'DesktopWeb'], initialState)
) {
  // Do viewport merging before App hydration happens.
  const desktopConfig = CommonUtil.mergeDeep(
    Object.assign({}, initialState.viewportConfig),
    initialState.siteConfig.DesktopWeb
  );
  initialState.siteConfig.DesktopWeb = desktopConfig;
}
// Setting labels object received from server side
// in labels util before App hydration happens.
labelsContentUtil.setLabelsContent(initialState.labels);

/* eslint-enable no-underscore-dangle */
const store = configureStore(initialState, history);
store.runSaga(rootSaga);

/*
function onUpdate() {
  // Prevent duplicate fetches when first loaded.
  // Explanation: On server-side render, we already have __INITIAL_STATE__
  // So when the client side onUpdate kicks in, we do not need to fetch twice.
  // We set it to null so that every subsequent client-side navigation will
  // still trigger a fetch data.
  // Read more: https://github.com/choonkending/react-webpack-node/pull/203#discussion_r60839356
  if (window.__INITIAL_STATE__ !== null) {
    window.__INITIAL_STATE__ = null;
    return;
  }

  fetchDataForRoute(this.state)
    .then((data) => {
      return store.dispatch({ type: 'REQUEST_SUCCESS', data });
    });
}
*/
function getStaticMarkup() {
  const $nav = document.getElementById('nav-container');
  if ($nav) {
    navMarkupUtil.setNavMarkup($nav.innerHTML);
  }
}

const render = App => {
  ReactDOM.hydrate(
    <Provider store={store} context={ReactReduxContext}>
      <ConnectedRouter history={history}>
        <App store={store} />
      </ConnectedRouter>
    </Provider>,
    document.getElementById('reactApp')
  );
};
/* eslint-disable extra-rules/no-commented-out-code */
// TODO: Taran will check

// Hot reloadable translation json files
// if (module.hot) {
//   // modules.hot.accept does not accept dynamic dependencies,
//   // have to be constants at compile-time
//   module.hot.accept('./i18n', () => {
//     render(translationMessages);
//   });
// }
const pageIdentifier = pathOr('', ['route', 'pageIdentifier'], initialState);

getStaticMarkup();
deferFunctionOnEvent({
  deferOnPages: ['CART', 'Checkout'],
  eventName: 'loadDeferChunk',
  func: headerInit,
  pageIdentifier,
  once: true,
});

setTimeout(() => {
  render(App);
}, 0);

// TODO: Taran will check its usage

// Chunked polyfill for browsers without Intl support
// if (!window.Intl) {
//   (new Promise((resolve) => {
//     resolve(import('intl'));
//   }))
//     .then(() => Promise.all([
//       import('intl/locale-data/jsonp/en.js'),
//       import('intl/locale-data/jsonp/de.js'),
//     ]))
//     .then(() => render(translationMessages))
//     .catch((err) => {
//       throw err;
//     });
// } else {
//   render(translationMessages);
// }

// TODO: reimplement the following commented out code
// for the OfflinePlugin runtime, when static assets,
// multisite, caching, etc. are finalized

// Install ServiceWorker and AppCache in the end since
// it's not most important operation and if main code fails,
// we do not want it installed
// if (process.env.NODE_ENV === 'production') {
//   require('offline-plugin/runtime').install(); // eslint-disable-line global-require
// }

// setConfig({ logLevel: 'debug' }); // React Hot Loader
/* istanbul ignore next */
if (process.env.NODE_ENV === 'development' && module.hot) {
  module.hot.accept('containers/App', () => {
    const App = require('containers/App').default;
    render(App);
  });
}
