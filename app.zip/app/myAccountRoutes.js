import { setPageIdentifier } from '@bbb-app/redux/route-data/actions';
import {
  PAGE_NAME_MY_REGISTRIES,
  PAGE_NAME_MY_CHECKLIST,
  PAGE_NAME_MYOFFER,
  PERSONAL_INFO_PAGE,
  REVIEW_YOUR_PRODUCTS,
  ACCOUNT_ORDERS_PAGE,
  FAVORITE_STORE,
  ACCOUNT_MY_FUNDS,
  ACCOUNT_PREFERENCES,
  MANAGE_CREDIT_CARD,
  ACCOUNT_ADDRESS_BOOK,
  MY_ACCOUNT_DASHBOARD,
  BEYOND_PLUS_SUBSCRIPTION,
  ACCOUNT_REORDER,
  ACCOUNT_ORDER_DETAILS,
  ROUTE_SHALLOW_PROFILE_REGISTRATION,
  PAGE_NAME_SHALLOW_PROFILE_REGISTRATION,
  SUBSCRIPTION,
  MY_SUBSCRIPTIONS,
  COLLEGE_SAVINGS_PASS,
  MILITARY_SAVINGS_PASS,
  ROUTE_MILITARY_SAVINGS_PASS,
  ROUTE_COLLEGE_SAVINGS_PASS,
  PAGE_NAME_REGISTRY_NOTIFICATIONS,
  PAGE_NAME_SHOPPING_LIST,
} from '@bbb-app/constants/route/route';
import {
  AccountFavoriteStore,
  AccountVersionComponentWrapper,
  AccountPreferences,
  MyAccountDashboard,
  MyOffers,
  MyRegistries,
  PersonalInfo,
  ReviewYourProducts,
  AccountMyFunds,
  AccountReorder,
  BeyondPlus,
  AccountOrders,
  ShallowProfileRegistration,
  SubscriptionMSI,
  CollegeSavingsPass,
  MilitarySavingsPass,
  AccountAddressBook,
  RegistryNotifications,
  ShoppingList,
} from './asyncRoutes';

import MyChecklists from './containers/Pages/MyChecklists/MyChecklists.async';

const myAccountRoutes = [
  {
    path: '/store/account/myaccount',
    component: MyAccountDashboard,
    exact: true,
    routeData: {
      pageName: MY_ACCOUNT_DASHBOARD,
    },
  },
  {
    path: '/store/account/address_book',
    component: AccountAddressBook,
    exact: true,
    routeData: {
      pageName: ACCOUNT_ADDRESS_BOOK,
    },
  },
  {
    path: '/store/account/view_credit_card',
    component: AccountVersionComponentWrapper,
    exact: true,
    routeData: {
      pageName: MANAGE_CREDIT_CARD,
    },
  },
  {
    path: '/store/account/preferences',
    component: AccountPreferences,
    exact: true,
    routeData: {
      pageName: ACCOUNT_PREFERENCES,
    },
  },
  {
    path: '/store/account/myfunds',
    component: AccountMyFunds,
    exact: true,
    routeData: {
      pageName: ACCOUNT_MY_FUNDS,
    },
  },
  {
    path: '/store/account/favoritestore',
    component: AccountFavoriteStore,
    exact: true,
    routeData: {
      pageName: FAVORITE_STORE,
    },
  },
  {
    path: '/store/account/notifications',
    component: RegistryNotifications,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_REGISTRY_NOTIFICATIONS,
    },
  },
  {
    path: '/store/account/shoppingList',
    component: ShoppingList,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_SHOPPING_LIST,
    },
  },
  {
    path: '/store/account/my_registries',
    component: MyRegistries,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_MY_REGISTRIES,
      fetchData: [setPageIdentifier],
    },
  },
  {
    path: '/store/account/my_lists',
    component: MyChecklists,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_MY_CHECKLIST,
      fetchData: [setPageIdentifier],
    },
  },
  {
    path: '/store/account/personalinfo',
    component: PersonalInfo,
    routeData: {
      pageName: PERSONAL_INFO_PAGE,
    },
  },
  {
    path: '/store/account/coupons',
    component: MyOffers,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_MYOFFER,
    },
  },
  {
    path: '/store/account/order_detail',
    component: AccountVersionComponentWrapper,
    exact: true,
    routeData: {
      pageName: ACCOUNT_ORDER_DETAILS,
    },
  },
  {
    path: '/store/account/reorder',
    component: AccountReorder,
    exact: true,
    routeData: {
      pageName: ACCOUNT_REORDER,
    },
  },
  {
    path: '/store/account/order_summary',
    component: AccountOrders,
    routeData: {
      pageName: ACCOUNT_ORDERS_PAGE,
    },
  },
  {
    path: '/store/account/process_pie_redirect',
    component: ReviewYourProducts,
    exact: true,
    routeData: {
      pageName: REVIEW_YOUR_PRODUCTS,
    },
  },
  {
    path: '/store/account/beyondPlusSubscription',
    component: BeyondPlus,
    exact: true,
    routeData: {
      pageName: BEYOND_PLUS_SUBSCRIPTION,
    },
  },
  {
    path: ROUTE_SHALLOW_PROFILE_REGISTRATION,
    component: ShallowProfileRegistration,
    exact: true,
    routeData: {
      pageName: PAGE_NAME_SHALLOW_PROFILE_REGISTRATION,
    },
  },
  {
    path: SUBSCRIPTION,
    component: SubscriptionMSI,
    exact: true,
    routeData: {
      pageName: MY_SUBSCRIPTIONS,
    },
  },
  {
    path: ROUTE_COLLEGE_SAVINGS_PASS,
    component: CollegeSavingsPass,
    exact: true,
    routeData: {
      pageName: COLLEGE_SAVINGS_PASS,
    },
  },
  {
    path: ROUTE_MILITARY_SAVINGS_PASS,
    component: MilitarySavingsPass,
    exact: true,
    routeData: {
      pageName: MILITARY_SAVINGS_PASS,
    },
  },
];

export default myAccountRoutes;
