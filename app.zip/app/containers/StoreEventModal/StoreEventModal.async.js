/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';
import { options } from '@bbb-app/universal-component/options';

const StoreEventModal = universal(
  import(/* webpackChunkName: "StoreEventModal" */ './StoreEventModal'),
  options
);

export default StoreEventModal;
/* eslint-enable extra-rules/no-commented-out-code */
