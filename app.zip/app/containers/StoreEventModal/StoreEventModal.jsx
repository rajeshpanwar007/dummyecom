import { connect } from 'react-redux';
import { compose } from 'redux';
import { createStructuredSelector } from 'reselect';
import toJS from '@bbb-app/hoc/toJS';
import injectReducer from '@bbb-app/hoc/injectReducer';
import { closeEventPageModal } from '@bbb-app/search-stores/containers/store-event-modal/actions';
import reducer from '@bbb-app/search-stores/containers/store-event-modal/reducer';
import {
  showEventModal,
  zipSubmitted,
  eventName,
  contentId,
  isFetchingEventStores,
} from '@bbb-app/search-stores/containers/store-event-modal/selectors';
import StoreEventModal from '../../components/StoreEventModal/StoreEventModal';

export const mapStateToProps = createStructuredSelector({
  showEventModal: showEventModal(),
  zipSubmitted: zipSubmitted(),
  eventName: eventName(),
  contentId: contentId(),
  isFetchingEventStores: isFetchingEventStores(),
});

export const mapDispatchToProps = dispatch => {
  return {
    closeEventModal: () => dispatch(closeEventPageModal()),
  };
};

const withConnect = connect(mapStateToProps, mapDispatchToProps);
export const withReducer = injectReducer({
  key: 'storeEventFlow',
  reducer,
});

export default compose(withReducer, withConnect)(toJS(StoreEventModal));
