import { fromJS, Map } from 'immutable';
import getOr from 'lodash/fp/getOr';
import { merge, keys, set } from 'lodash';
import { isBrowser } from '@bbb-app/utils/common';
import { DEFAULT } from '@bbb-app/utils/constants';
import {
  CONTENTHUB_GROUP_PAGE_KEY,
  CONTENTHUB_TAGS_PAGE_KEY,
  BUYING_GUIDE_GROUP_PAGE_KEY,
  SET_INVALID_EXPERIENCE_KEY,
  SET_USER_SEGMENT,
  EXPERIENCE_JSON_SUCCESS,
  SET_ROUTE,
  PAGE_EXPERIENCE_JSON_SUCCESS,
  FETCH_EXPERIENCE,
  EXPERIENCE_JSON_FAILURE,
  EXPERIENCE_SET_SUCCESS,
  UNSET_USER_SEGMENT,
} from '@bbb-app/constants/experienceConstants';
import { getLastUpdatedBootStrapTimeStamp } from '@bbb-app/utils/ExperienceData';
import {
  PAGE_NAME_ARTICLE_GROUP,
  PAGE_NAME_ARTICLE_TAGS,
} from '@bbb-app/constants/route/route';
import { TIMESTAMP, SET_CURRENT_TTL } from '@bbb-app/constants/appConstants';

function getContentHubIdentifier(pageName, path, identifier) {
  if (pageName === PAGE_NAME_ARTICLE_GROUP) {
    return `${CONTENTHUB_GROUP_PAGE_KEY}.${path
      .split('/')
      .slice(0, 3)
      .join('/')}/`;
  }
  if (pageName === PAGE_NAME_ARTICLE_TAGS) {
    return `${CONTENTHUB_TAGS_PAGE_KEY}.${path
      .split('/')
      .slice(0, 3)
      .join('/')}/`;
  }
  if (pageName === 'contentHubStatic') {
    return `contentHub.staticPages.${path}`;
  }
  if (pageName === 'buyingGuideStatic') {
    return `buyingGuide.staticPages.${path}`;
  }
  if (pageName === 'buyingGuideGroup') {
    return `${BUYING_GUIDE_GROUP_PAGE_KEY}.${path
      .split('/')
      .slice(0, 4)
      .join('/')}/`;
  }

  return identifier;
}

const initialState = Map({
  mapping: Map({
    category: Map(),
    products: Map(),
  }),
  templates: Map(),
  route: Map(),
  isFetching: false,
  isInvalidExperience: false,
});

function updateExperienceState(args, state) {
  if (args) {
    const { params, data } = args;
    const newState = JSON.parse(JSON.stringify(state));
    newState.isFetching = false;
    // merging experience object in templates object of experience state
    merge(newState.templates, data);
    const templateId = keys(data);
    // if mapping is also a part of response will merge here otherwise will create and merge
    let mappingData = {};
    const { identifier, value, pageName } = params;
    if (identifier && value) {
      switch (identifier) {
        case 'contentHub' || 'buyingGuide':
          set(
            mappingData,
            getContentHubIdentifier(pageName, value, identifier),
            {
              templateId: templateId[0],
            }
          );
          break;
        default:
          mappingData = {
            [identifier]: {
              [value]: {
                templateId: templateId[0],
              },
            },
          };
      }
    }
    merge(newState.mapping, mappingData);
    return fromJS(newState);
  }
  return state;
}

function setExperienceSuccess(args, state) {
  if (args && args.data) {
    const response = getOr(
      {},
      'data.TemplateData.ResponseBody.templates',
      args
    );
    const isInvalidExperience = state.get('isInvalidExperience', false);
    if (isBrowser()) {
      const data = {
        templates: response,
        mapping:
          (args.data.CategoriesData && args.data.CategoriesData.ResponseBody) ||
          {},
        route: state.get('route'),
        [TIMESTAMP]: getLastUpdatedBootStrapTimeStamp(),
        isFetching: false,
        isInvalidExperience,
      };
      return state.mergeDeep(data);
    }

    return fromJS({
      templates: response,
      mapping:
        (args.data.CategoriesData && args.data.CategoriesData.ResponseBody) ||
        {},
      route: state.get('route'),
      [TIMESTAMP]: null,
      isFetching: false,
      isInvalidExperience,
    });
  }
  return state;
}

function setRouteState(args, state) {
  if (args) {
    return state.set('routeURL', args);
  }
  return state;
}

function updateExperienceStateError(state) {
  const newState = JSON.parse(JSON.stringify(state));
  newState.isFetching = false;
  return fromJS(newState);
}

/* eslint complexity: ["error", 12]*/
function experienceReducer(
  state = initialState,
  { type, args, invalidExp, userSegment, configKey }
) {
  /* istanbul ignore next */
  switch (type) {
    case SET_USER_SEGMENT:
      return state
        .set('userSegment', userSegment)
        .set('resetUserSegmentCookie', true);
    case UNSET_USER_SEGMENT:
      return state
        .set('userSegment', DEFAULT)
        .set('resetUserSegmentCookie', false);
    case SET_ROUTE:
      return setRouteState(args, state);
    case FETCH_EXPERIENCE:
      return state.set('isFetching', true);
    case EXPERIENCE_JSON_SUCCESS:
      return setExperienceSuccess(args, state);
    case EXPERIENCE_SET_SUCCESS:
      return state.set('isFetching', false);
    case PAGE_EXPERIENCE_JSON_SUCCESS:
      return updateExperienceState(args, state);
    case EXPERIENCE_JSON_FAILURE:
      return updateExperienceStateError(state);
    case SET_CURRENT_TTL:
      if (configKey === 'experience') {
        return state.set(TIMESTAMP, Date.now());
      }
      return state;
    case SET_INVALID_EXPERIENCE_KEY:
      return state.set('isInvalidExperience', invalidExp);
    default:
      return state;
  }
}

export default experienceReducer;
