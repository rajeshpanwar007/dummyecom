import { call, put, takeLatest, select, take, fork } from 'redux-saga/effects';
import { cloneDeep } from 'lodash/fp';
import pathOr from 'lodash/fp/pathOr';
import {
  getIdByExperienceType,
  getParamTypeByExperienceType,
  fetchPreviewContentActionWithContentIds,
} from '@bbb-app/utils/experience';
import { isPreview } from '@bbb-app/utils/common';
import getApiEndPointsFromStore from '@bbb-app/utils/getApiEndPointsFromStore';
import ServiceUtil from '@bbb-app/utils/serviceUtil';
import hpTestUtil from '@bbb-app/utils/hpTestUtil';
import { getContent } from '@bbb-app/pure-content/containers/sagas';
import { setExperienceData } from '@bbb-app/utils/ExperienceData';
import {
  FETCH_CONTENT,
  FETCH_EXPERIENCE,
  FETCH_PAGE_EXPERIENCE,
  EXPERIENCE_JSON_FAILURE,
  PAGE_EXPERIENCE_JSON_SUCCESS,
} from '@bbb-app/constants/experienceConstants';
import {
  FETCH_CONTENT_SUCCESS,
  FETCH_CONTENT_ERROR,
} from '@bbb-app/pure-content/containers/constants';
import {
  setPageExperience,
  experienceError,
  setExperienceSuccess,
} from './actions';

const getState = state => state;

export function* fetchDynamicContentAfterPageExperience({
  result,
  siteId,
  channel,
  isPreviewMode,
  args,
}) {
  const state = yield select(getState);
  const newResultData = cloneDeep(result);
  const regions =
    newResultData.data[Object.keys(newResultData.data)[0]].regions;
  const contentActions = fetchPreviewContentActionWithContentIds(
    args,
    regions,
    state
  );
  let dynamicContent;
  if (contentActions) {
    contentActions.forEach(action => {
      if (action.type === FETCH_CONTENT) {
        dynamicContent = action;
      }
    });
  }
  if (dynamicContent) {
    const { contentParams, mainParams } = dynamicContent;
    yield fork(getContent, {
      contentParams,
      mainParams,
      siteId,
      channel,
      isPreview: isPreviewMode,
    });
    take([FETCH_CONTENT_SUCCESS, FETCH_CONTENT_ERROR]);
    return yield put(setPageExperience(result));
  }
  return yield put(setPageExperience(result));
}
export function* getPageExperience({ args, siteId, channel }) {
  // check isPreview mode is on or not
  const isPreviewMode = isPreview();
  if (isPreviewMode) {
    try {
      const expType = 'preview';
      const paramType = getParamTypeByExperienceType(args);
      const pageName = args.pageName;
      let paramValue;
      if (pageName === 'RegistryOwnerHome' || pageName === 'FriendRegistry') {
        paramValue = args.pagePath.replace(`/${args.id}`, '');
      } else if (args.pagePath === '/' && hpTestUtil()) {
        paramValue = hpTestUtil();
      } else {
        paramValue =
          args.experienceIdentifier === 'products'
            ? args.type
            : getIdByExperienceType(args);
      }

      if (!paramValue) {
        return yield put(experienceError());
      }
      const dateObj = pathOr(null, 'query.date', args)
        ? { date: args.query.date }
        : {};
      const {
        body: { data: pageExperienceData },
      } = yield call(ServiceUtil.triggerServerRequest, {
        url: getApiEndPointsFromStore('experiencePreview'),
        method: 'GET',
        params: {
          param_type: paramType,
          param_value: paramValue,
          expType,
          ...dateObj,
        },
        isPreview: isPreviewMode,
        siteId,
      });
      // need to pass args as well for updating mapping object, if not a part of response
      const result = {
        data: pageExperienceData,
        params: {
          identifier: args.experienceIdentifier,
          value: paramValue,
          pageName: args.pageName,
        },
      };
      return yield call(fetchDynamicContentAfterPageExperience, {
        result,
        siteId,
        channel,
        isPreviewMode,
        args,
      });
    } catch (error) {
      return yield put(experienceError(error.body));
    }
  }
  return yield put(experienceError());
}

export function* pageExperienceSaga() {
  yield takeLatest(FETCH_PAGE_EXPERIENCE, getPageExperience);
}

export function* getExperience() {
  let experience = null;
  try {
    experience = yield call(ServiceUtil.triggerServerRequest, {
      url: getApiEndPointsFromStore('experience'),
    });
    yield call(setExperienceData, experience && experience.body);
    return yield put(setExperienceSuccess());
  } catch (err) {
    return yield put(experienceError(err.body));
  } finally {
    experience = null;
  }
}

export function* experienceSaga() {
  yield takeLatest(FETCH_EXPERIENCE, getExperience);
}

/**
 * Added to support preview rendering prefetching.
 *
 * @param siteId
 * @param args
 */
export function* fetchDynamicRegionsMetadata({ siteId, args }) {
  yield fork(getPageExperience, { args, siteId });
  take([PAGE_EXPERIENCE_JSON_SUCCESS, EXPERIENCE_JSON_FAILURE]); // Block for either success or failure.
}

export default [experienceSaga, pageExperienceSaga];
