import {
  EXPERIENCE_JSON_SUCCESS,
  FETCH_EXPERIENCE,
  FETCH_PAGE_EXPERIENCE,
  PAGE_EXPERIENCE_JSON_SUCCESS,
  EXPERIENCE_JSON_FAILURE,
  SET_ROUTE,
  EXPERIENCE_SET_SUCCESS,
  UNSET_USER_SEGMENT,
} from '@bbb-app/constants/experienceConstants';

export const setExperience = args => {
  return {
    type: EXPERIENCE_JSON_SUCCESS,
    args,
  };
};

export const setExperienceSuccess = () => {
  return {
    type: EXPERIENCE_SET_SUCCESS,
  };
};

export const setPageExperience = args => {
  return {
    type: PAGE_EXPERIENCE_JSON_SUCCESS,
    args,
  };
};

export const fetchPageExperience = (args, pageName) => {
  return {
    type: FETCH_PAGE_EXPERIENCE,
    args: { ...args, pageName },
  };
};

export const setRouteURL = args => {
  return {
    type: SET_ROUTE,
    args,
  };
};

export const experienceError = args => {
  return {
    type: EXPERIENCE_JSON_FAILURE,
    args,
  };
};

export const fetchExperience = () => {
  return {
    type: FETCH_EXPERIENCE,
  };
};

export function unsetUserSegment() {
  return {
    type: UNSET_USER_SEGMENT,
  };
}
