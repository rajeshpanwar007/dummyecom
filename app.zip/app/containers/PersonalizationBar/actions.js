import {
  FETCH_P_BAR,
  FETCH_P_BAR_SUCCESS,
  FETCH_P_BAR_ERROR,
  FETCH_P_BAR_TILE_DATA_SUCCESS,
} from './constants';

export function fetchPBar(customerId) {
  return {
    type: FETCH_P_BAR,
    customerId,
  };
}

export function fetchPBarSuccess(data) {
  return {
    type: FETCH_P_BAR_SUCCESS,
    data,
  };
}

export function fetchPBarError(error) {
  return {
    type: FETCH_P_BAR_ERROR,
    error,
  };
}

export function fetchPBarTileDataSuccess(data) {
  return {
    type: FETCH_P_BAR_TILE_DATA_SUCCESS,
    data,
  };
}
