export const FETCH_P_BAR = 'BBB/FETCH_P_BAR';
export const FETCH_P_BAR_SUCCESS = 'BBB/FETCH_P_BAR_SUCCESS';
export const FETCH_P_BAR_ERROR = 'BBB/FETCH_P_BAR_ERROR';
export const SELECTED_IDEABOARDS_KEY = 'AddToIdeaboard';

export const P_BAR_STATE_KEY = 'PersonalizationBar';
export const REGISTRY_STATE_KEY = 'Registry';
export const REGISTRY_DETAILS_STATE_KEY = 'registryDetails';

export const TEALIUM_PAGE_IDENTIFIER = 'promo impression';
export const TEALIUM_PAGE_NAME_BREADCRUMB = 'Home Page';
export const TEALIUM_PAGE_CHANNEL = 'Home Page';
export const REGISTRY_TITLE = 'My Registry';

export const DEFAULT_ERROR_MESSAGE = 'response is not correct';

// Tagging ICIDs for persoanlization bar
export const TEALIUM_ORDERS_ICID = 'hp_hompag_pzb_myorders_14579';
export const TEALIUM_REGISTRY_ICID = 'hp_hompag_pzb_myregistry_14579';
export const TEALIUM_FAVORITE_ICID = 'hp_hompag_pz_favstore_14579';
export const TEALIUM_FUNDS_ICID = 'hp_hompag_pz_myfunds_14579';
export const TEALIUM_IDEABOARD_ICID = 'hp_hompag_pz_myideaboards_14579';
export const TEALIUM_MYOFFERS_CID = 'hp_hompag_pzb_myoffers_14579';
export const TEALIUM_BEYONDPLUS_CID = 'hp_hompag_pz_beyondplus_14579';
export const TEALIUM_PAGE_INFO = {
  page_type: 'Home Page',
  page_name: 'Home Page',
};
export const FETCH_P_BAR_TILE_DATA_SUCCESS = 'FETCH_P_BAR_TILE_DATA_SUCCESS';
