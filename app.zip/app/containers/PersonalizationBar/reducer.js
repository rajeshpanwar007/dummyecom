import { fromJS } from 'immutable';

import {
  FETCH_P_BAR,
  FETCH_P_BAR_SUCCESS,
  FETCH_P_BAR_ERROR,
  FETCH_P_BAR_TILE_DATA_SUCCESS,
} from './constants';

const initialState = fromJS({
  isFetching: false,
  data: null,
  error: null,
  pBarTileData: null,
});

export function pBarReducer(stateParam, { type, data, error }) {
  const state = typeof stateParam === 'undefined' ? initialState : stateParam;
  switch (type) {
    case FETCH_P_BAR:
      return state.set('isFetching', true);
    case FETCH_P_BAR_SUCCESS: {
      return state.set('data', data);
    }
    case FETCH_P_BAR_TILE_DATA_SUCCESS:
      return state
        .set('isFetching', false)
        .set('pBarTileData', data)
        .set('error', null);
    case FETCH_P_BAR_ERROR:
      return state.set('isFetching', false).set('error', error);
    default:
      return state;
  }
}
export default pBarReducer;
