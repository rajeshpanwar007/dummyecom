import React from 'react';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import isUserLoggedIn from '@bbb-app/utils/isUserLoggedIn';
import isUserRecognized from '@bbb-app/utils/isUserRecognized';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import { triggerTealiumEvent } from '@bbb-app/actions/tealium/triggerTealiumEvent';
import toJS from '@bbb-app/hoc/toJS';
import { getBeyondPlusData } from '@bbb-app/selectors/accountSelectors';
import injectReducer from '@bbb-app/hoc/injectReducer';
import injectSaga from '@bbb-app/hoc/injectSaga';
import PBar from '../../components/PBar/PBar';
import { fetchPBar } from './actions';
import {
  P_BAR_STATE_KEY,
  TEALIUM_PAGE_IDENTIFIER,
  TEALIUM_PAGE_NAME_BREADCRUMB,
  TEALIUM_PAGE_CHANNEL,
  TEALIUM_PAGE_INFO,
} from './constants';
import reducer from './reducer';
import saga from './sagas';
import {
  makeSelectLabels,
  selectPBarDetailsIsFetching,
  selectPBarDetailsError,
  selectPBarDetailsData,
  selectPBarTileSpecificData,
} from './selectors';

export class PersonalizationBar extends React.PureComponent {
  constructor(props) {
    super(props);
    this.isApiCalled = false;
  }

  componentDidMount() {
    const { profile } = this.props;
    if (
      this.props.enablePersonalizationBar &&
      profile &&
      !isInternationalUser() &&
      (isUserRecognized() || isUserLoggedIn())
    ) {
      this.props.getPBarDataOnMount(profile.repositoryId);
      this.isApiCalled = true;
    }
  }

  componentWillReceiveProps(nextProps) {
    const { profile } = nextProps;
    if (
      this.props.enablePersonalizationBar &&
      profile &&
      !isInternationalUser() &&
      (isUserRecognized() || isUserLoggedIn()) &&
      !this.isApiCalled
    ) {
      this.props.getPBarDataOnMount(profile.repositoryId);
      this.isApiCalled = true;
    }
  }

  render() {
    return (
      <ErrorBoundary>
        <div id="personalizationBar" className={'componentWrapper'}>
          <PBar
            profile={this.props.profile}
            pBarData={this.props.pBarData}
            pBarTileData={this.props.pBarTileData}
            labels={this.props.labels}
            isLoggedIn={isUserLoggedIn()}
            {...this.props}
          />
        </div>
      </ErrorBoundary>
    );
  }
}

PersonalizationBar.propTypes = {
  labels: PropTypes.object,
  profile: PropTypes.object,
  getPBarDataOnMount: PropTypes.func,
  enablePersonalizationBar: PropTypes.bool,
  pBarData: PropTypes.array,
  pBarTileData: PropTypes.object,
};

export const mapStateToProps = createStructuredSelector({
  labels: makeSelectLabels(),
  pBarDataIsFetching: selectPBarDetailsIsFetching(),
  pBarDataError: selectPBarDetailsError(),
  pBarData: selectPBarDetailsData(),
  pBarTileData: selectPBarTileSpecificData(),
  registryData: selectPBarTileSpecificData('REGISTRY'),
  bpData: getBeyondPlusData(),
});
export const mapDispatchToProps = dispatch => {
  return {
    getPBarDataOnMount(customerId) {
      dispatch(fetchPBar(customerId));
    },
    fireTealiumAction(tealiumObj) {
      const tealiumInfo = {
        pagename_breadcrumb: TEALIUM_PAGE_NAME_BREADCRUMB,
        channel: TEALIUM_PAGE_CHANNEL,
        ...tealiumObj,
      };
      const actionType = TEALIUM_PAGE_IDENTIFIER;
      const pageName = TEALIUM_PAGE_INFO;
      dispatch(triggerTealiumEvent(actionType, tealiumInfo, pageName));
    },
  };
};

const withConnect = connect(mapStateToProps, mapDispatchToProps);
const withReducer = injectReducer({ key: P_BAR_STATE_KEY, reducer });
const withSaga = injectSaga({ key: P_BAR_STATE_KEY, saga });

export default compose(withReducer, withSaga, withConnect)(
  toJS(PersonalizationBar)
);
