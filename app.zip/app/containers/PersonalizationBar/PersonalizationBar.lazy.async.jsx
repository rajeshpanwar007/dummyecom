/**
 * Created by Anil Jangra on 9/26/2019
 */
/* eslint-disable extra-rules/no-commented-out-code */
import universal from 'react-universal-component';
import React from 'react';
import LazyLoad from '@bbb-app/core-ui/lazy-load';
import { options } from '@bbb-app/universal-component/options';
import isComponentNotInFirstRegion from '@bbb-app/utils/isComponentNotInFirstRegion';

const PersonalizationBarLazyAsync = universal(
  import(/* webpackChunkName: "async-PersonalizationBar" */ './PersonalizationBar'),
  options
);
const PersonalizationBar = props => {
  // eslint-disable-next-line react/prop-types
  const isLazyLoad = isComponentNotInFirstRegion(props.region);
  if (isLazyLoad) {
    return (
      <LazyLoad threshold={100}>
        <PersonalizationBarLazyAsync {...props} />
      </LazyLoad>
    );
  }
  return <PersonalizationBarLazyAsync {...props} />;
};
export default PersonalizationBar;

/* eslint-enable extra-rules/no-commented-out-code */
