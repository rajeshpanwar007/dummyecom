import { createSelector } from 'reselect';
import { Map } from 'immutable';
import {
  REGISTRY_STATE_KEY,
  P_BAR_STATE_KEY,
  SELECTED_IDEABOARDS_KEY,
} from './constants';

export const selectLabels = state => state.get('labels');
export const makeSelectLabels = () => {
  return createSelector(selectLabels, labelsState =>
    labelsState.get('PersonalizationBar')
  );
};

export const selectedIdeaboards = state =>
  state.get(SELECTED_IDEABOARDS_KEY, Map());
export const selectedLabels = state => state.get('labels');

export const fetchCopiedIdeaboardData = () =>
  createSelector(selectedIdeaboards, data => data.get('copiedIdeaboard'));

export const profileDataState = state => {
  const accountSignIn = state.get('accountSignIn');
  return accountSignIn;
};

export const makeSelectProfile = () =>
  createSelector(profileDataState, accountSignIn =>
    accountSignIn.get('profile')
  );

export const selectPBarDetails = state => state.get(P_BAR_STATE_KEY);

export const selectPBarDetailsIsFetching = () => {
  return createSelector(selectPBarDetails, pBarState =>
    pBarState.get('isFetching')
  );
};
export const selectPBarDetailsError = () => {
  return createSelector(selectPBarDetails, pBarState => pBarState.get('error'));
};
export const selectPBarDetailsData = () => {
  return createSelector(selectPBarDetails, pBarState => pBarState.get('data'));
};
export const getRegistryDetails = state => {
  return state.get(REGISTRY_STATE_KEY);
};

export const selectPBarTileSpecificData = tile =>
  createSelector(selectPBarDetails, pBarState => {
    const data = pBarState.get('pBarTileData');
    if (tile) {
      return data && data[tile];
    }
    return data;
  });
