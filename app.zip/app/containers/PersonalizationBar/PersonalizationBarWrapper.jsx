/**
 * Created by Anil Jangra on 1/31/2020
 */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { makeSelectGlobalSwitchConfig } from '@bbb-app/selectors/configSelector';
import isInternationalUser from '@bbb-app/utils/isInternationalUser';
import isUserRecognizedOrLoggedIn from '@bbb-app/utils/isUserRecognizedOrLoggedIn';
import toJS from '@bbb-app/hoc/toJS';
import { makeSelectProfile } from '@bbb-app/selectors/accountSelectors';
import PersonalizationBar from './PersonalizationBar.lazy.async';
export const PersonalizationBarWrapper = props => {
  const isNotGuest = isUserRecognizedOrLoggedIn();
  const { enablePersonalizationBar, profile } = props;
  if (
    enablePersonalizationBar &&
    profile &&
    !isInternationalUser() &&
    isNotGuest
  ) {
    return (
      <PersonalizationBar
        profile={profile}
        enablePersonalizationBar={enablePersonalizationBar}
      />
    );
  }
  return '';
};

PersonalizationBarWrapper.propTypes = {
  enablePersonalizationBar: PropTypes.bool,
  profile: PropTypes.object,
};

export const mapStateToProps = createStructuredSelector({
  enablePersonalizationBar: makeSelectGlobalSwitchConfig(
    'enablePersonalizationBar'
  ),
  profile: makeSelectProfile(),
});

export default connect(mapStateToProps, null)(toJS(PersonalizationBarWrapper));
