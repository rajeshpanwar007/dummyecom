import { call, put, takeLatest } from 'redux-saga/effects';
import getApiEndPointsFromStore from '@bbb-app/utils/getApiEndPointsFromStore';
import ServiceUtil from '@bbb-app/utils/serviceUtil';
import {
  fetchPBarSuccess,
  fetchPBarError,
  fetchPBarTileDataSuccess,
} from './actions';

import { FETCH_P_BAR } from './constants';

export function* getPBar({ customerId }) {
  try {
    const url = getApiEndPointsFromStore('pBar');

    const {
      body: { serviceStatus, errorMessages, data },
    } = yield call(ServiceUtil.triggerServerRequest, {
      url,
      method: 'GET',
      headers: {
        'atg-rest-depth': 3,
      },
      params: {},
    });

    /* istanbul ignore else  */
    if (serviceStatus === 'SUCCESS') {
      yield* getPBarTileData(data, customerId);
      return yield put(fetchPBarSuccess(data));
    }

    return yield put(fetchPBarError(errorMessages.message));
  } catch (err) {
    return yield put(fetchPBarError(err.body));
  }
}
export function* getPBarTileData(pBarData, customerId) {
  try {
    const nodes =
      pBarData && pBarData.length > 0
        ? pBarData
            .map(item => {
              return { node: item.name, responseType: 'skinny' };
            })
            .filter(item => item.node !== 'FAV_STORE')
        : [];
    const customerInfoUrl =
      getApiEndPointsFromStore('customerInfo') ||
      '/apis/stateful/v1.0/customers/:customerId/customer-info';
    const url = customerInfoUrl.replace(':customerId', customerId);
    const {
      body: { serviceStatus, errorMessages, data },
    } = yield call(ServiceUtil.triggerServerRequest, {
      url,
      method: 'GET',
      params: { nodes: encodeURI(JSON.stringify(nodes)) },
    });

    /* istanbul ignore else  */
    if (serviceStatus === 'SUCCESS') {
      return yield put(fetchPBarTileDataSuccess(data));
    }
    return yield put(fetchPBarError(errorMessages.message));
  } catch (error) {
    return yield put(fetchPBarError(error.body));
  }
}
export function* getPBarSaga() {
  yield takeLatest(FETCH_P_BAR, getPBar);
}

export default [getPBarSaga];
