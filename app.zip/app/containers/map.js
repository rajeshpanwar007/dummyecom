/**
 * This map.js file is not being used now for rendering Experience driven components on XT end and is used only for in-context CMS
 * preview. Each main route has it's own ExperienceMapping file, so in case any new PureContent component is to be added,
 * it needs to be added in those files as well, for it to be available on those routes.
 *
 * So, add new PureContent components in this file(for in-context preview) and page specific ExperienceMapping file as well.
 * Route for page specific experience mapping files = app/containers/ExperienceMapping
 */

import 'regenerator-runtime/runtime';
import { BrowserRouter as Router } from 'react-router-dom';
import Footer from '@bbb-app/footer/containers/Footer';
/** import '../styles/index.css'; **/
import Header from '@bbb-app/header/containers/Header';
import { updateViewportConfigOnResize as updateSiteConfig } from '@bbb-app/redux/viewport-configuration/actions';
import GoogleDFP from '@bbb-app/google-dfp/containers/GoogleDfp.async';
import TeaserListWithThumbnail from './PureContent/CMPending-TeaserListWithThumbnail/TeaserListWithThumbnail';
import MultiImageContentBlock from './PureContent/MultiImageContentBlock/MultiImageContentBlock';
import combineReducers from '../reducers';
import allSagas from '../sagas/rootSaga';
import ProductDetails from './Pages/PDP/ProductDetails/ProductDetails';
import BrandBanner from './PureContent/BrandBanner/BrandBanner';
import BuyingGuideBreadcrumb from './PureContent/BuyingGuideBreadcrumb/BuyingGuideBreadcrumb';
import Breadcrumbs from './Pages/PDP/Breadcrumbs/Breadcrumbs';
import Overview from './Pages/PDP/Overview/Overview';
import Features from './Pages/PDP/Features/Features';
import Specs from './Pages/PDP/Specs/Specs';
import SocialAnnex from './ThirdParty/SocialAnnex/SocialAnnex';
import WebCollage from './ThirdParty/WebCollage/WebCollage';
import PDPNavigations from './Pages/PDP/PDPNavigations/PDPNavigations';
import RelatedCategories from './Pages/PDP/RelatedCategories/RelatedCategories';
import CMSPageHeader from './PureContent/Header/Header';
import StoryCMSPageHeader from './PureContent/Header/HeaderCMSTitle';
import StoryTiles from './PureContent/AcrossTile/AcrossTile';
import StoryHeroModule from './PureContent/Hero/Hero';
import ContactUsForm from './Pages/ContactUs/ContactUsForm/ContactUsForm';
import DesignerPick from './PureContent/DesignerPick/DesignerPick.async.lazy';
import BuildYourRegistry from './PureContent/BuildYourRegistry/BuildYourRegistry';
import NeedHelp from './PureContent/NeedHelp/NeedHelp';
import ContentLinks from './PureContent/ContentLinks/ContentLinks';
import MerchandisingModule from './PureContent/MerchandisingModule/MerchandisingModule';
import RegistryTwoUpCTA from './PureContent/RegistryTwoUpCTA/RegistryTwoUpCTA';
import Certona from './Certona/Certona';
import QnA from './BazaarVoice/QnA/QnA';
import Reviews from './BazaarVoice/Reviews/Reviews';
import OpenContainer from './PureContent/CMPending-OpenContainer/OpenContainer';
import GiftCardCheckBalance from './Pages/GiftCard/GiftCardCheckBalance/GiftCardCheckBalance';
import CategoryModule from './PureContent/CategoryModule/CategoryModule';
import CategoryBreadcrumbs from './PureContent/Breadcrumbs/Breadcrumbs';
import L2Category from './PureContent/L2Category/L2Category';
import RecentlyViewed from './common/RecentlyViewed/RecentlyViewed';
import ProductGrid from './PureContent/ProductGrid/ProductGrid';
import ExpertPicks from './PureContent/ExpertPicks/ExpertPicks';
import CountdownClock from './PureContent/CountdownTimer/CountdownTimer.async';
import ProductItemList from './Pages/PDP/ProductItemList/ProductItemList';
import IdeaBoard from './Ideaboard/Ideaboard';
import FeaturedCategories from './FeaturedCategories/FeaturedCategories';
import EverlivingCopy from '../containers/Pages/PDP/EverlivingCopy/EverlivingCopy';
import HeroModule from './PureContent/HeroModule/HeroModule';
import ContentModule from './PureContent/ContentModule/ContentModule';
import ContentFullWidthContentBlock from './PureContent/ContentFullWidthContentBlock/ContentFullWidthContentBlock';
import TipsModule from './PureContent/TipsModule/TipsModule';
import GooglePLA from './ThirdParty/GooglePLA/GooglePLA';
import RegistryToolsNavigation from './Pages/RegistryTools/RegistryToolsNavigation/RegistryToolsNavigation';
import AnnouncementCard from './Pages/RegistryTools/AnnouncementCard/AnnouncementCard.async';
import Separator from '../components/common/Separator';
import MarketingBanner from './PureContent/MarketingBanner/MarketingBanner';
import HeroFormField from '../containers/SDD/HeroFormField/HeroFormField';
import RegistryGuidesAndTools from './PureContent/RegistryGuidesAndTools/RegistryGuidesAndTools';
import SeoFooterTemplate from './SeoFooterTemplate/SeoFooterTemplate';
import SingleBrandSpotLight from './PureContent/SingleBrandSpotlight/SingleBrandSpotlight';
import CollageContent2 from './PureContent/CollageContent/CollageContent';
import MsePromo from './PureContent/MSEPromo/MSEPromo';
import MultiPurposeStoryBlock from './PureContent/MultiPurposeContentBlock/MultiPurposeContentBlock';
import HeaderDropdown from './Pages/Registry/RegistryTypeDropdown/RegistryTypeDropdown';
import RegistryStartFind from './PureContent/RegistryStartFind/RegistryStartFind';
import PerfectGift from './PureContent/PerfectGift/PerfectGift';
import RegistryExclusiveBrands from './PureContent/RegistryExclusiveBrands/RegistryExclusiveBrands';
import RegistryFeaturedRegistry from './PureContent/RegistryFeaturedRegistry/RegistryFeaturedRegistry';
import RegistryFindRegistry from './PureContent/RegistryFindRegistry/RegistryFindRegistry';
import FindMyCollege from '../containers/Pages/CollegeLanding/FindMyCollege/FindMyCollege';
import ProductCarousel from './common/ProductCarousel/ProductCarousel';
import MoversSignUpNow from '../containers/Pages/Mover/MoversSignUpNow/MoversSignUpNow';
import SEOCopy from '../containers/PureContent/SEOCopy/SEOCopy';
import HookLogic from '../containers/HookLogic/HookLogic';
import RegistrySignInButton from '../containers/Pages/Registry/RegistrySignInButton/RegistrySignInButton';
import ApplyForWebInstantCredit from '../components/common/ApplyForWebInstantCredit/ApplyForWebInstantCredit.async';
import Article from '../contentHub/containers/Article/Article';
import BlogTagHeader from '../contentHub/containers/BlogTagHeader/BlogTagHeader';
import Blog12UpTiles from '../contentHub/containers/Blog12UpTiles/Blog12UpTiles';
import BlogSectionDropdown from '../contentHub/containers/SectionHeader/SectionHeader';
import IdeasStoryTile from '../contentHub/containers/IdeasStoryTile/IdeasStoryTile';
import BlogBreadCrumb from '../contentHub/containers/BlogBreadCrumb/BlogBreadCrumb';
import TellFriend from './Pages/Registry/TellAFriend/TellAFriend';
import WeddingBook from './Pages/Registry/WeddingBook/WeddingBookContainer';
import PersonalizationBar from '../containers/PersonalizationBar/PersonalizationBarWrapper';
import { QuickLinks } from '../containers/PureContent/Tbs/QuickLinks/QuickLinks.async';
import CuratedCategories from '../containers/CuratedCategories/CuratedCategories.async';
import OrganizationComponent from '../containers/Pages/OrganizationLanding/OrganizationComponent/OrganizationComponent';
import ProductBundling from '../containers/Pages/PDP/ProductBundling/ProductBundling.async';
import RelatedSearchTopics from '../containers/RelatedSearchTopics/RelatedSearchTopics';
import RegistryQuickPicks from './PureContent/RegistryQuickPicks/RegistryQuickPicks';
import RelatedSearchTopicsComponent from '../components/RelatedSearchTopicsComponent';
import SlotMachine from './PureContent/SlotMachine/SlotMachine';
import Incentives from './PureContent/Incentives/Incentives';
import RegistryIncentive from '../containers/Pages/Registry/RegistryIncentive/RegistryIncentive.async';
import RegistryDashboardRecommendation from './Pages/Registry/RegistryDashboardRecommendation/RegistryDashboardRecommendation.async';
import GraphicBanner from './PureContent/Banner/Banner';

export {
  updateSiteConfig,
  ContactUsForm,
  CMSPageHeader,
  StoryCMSPageHeader,
  StoryTiles,
  StoryHeroModule,
  TeaserListWithThumbnail,
  MultiImageContentBlock,
  ProductDetails,
  ContentModule,
  ContentFullWidthContentBlock,
  combineReducers,
  allSagas,
  Router,
  Footer,
  Header,
  Overview,
  Features,
  Specs,
  WebCollage,
  SocialAnnex,
  PDPNavigations,
  RelatedCategories,
  Breadcrumbs,
  BuyingGuideBreadcrumb,
  HeroModule,
  DesignerPick,
  BuildYourRegistry,
  NeedHelp,
  ContentLinks,
  MerchandisingModule,
  Certona,
  Reviews,
  QnA,
  OpenContainer,
  GiftCardCheckBalance,
  BrandBanner,
  CategoryModule,
  CategoryBreadcrumbs,
  RecentlyViewed,
  L2Category,
  ProductGrid,
  ExpertPicks,
  ProductItemList,
  GoogleDFP,
  IdeaBoard,
  FeaturedCategories,
  EverlivingCopy,
  TipsModule,
  GooglePLA,
  RegistryToolsNavigation,
  AnnouncementCard,
  Separator,
  MarketingBanner,
  HeroFormField,
  RegistryGuidesAndTools,
  SeoFooterTemplate,
  SingleBrandSpotLight,
  CountdownClock,
  CollageContent2,
  MsePromo,
  MultiPurposeStoryBlock,
  HeaderDropdown,
  RegistryStartFind,
  PerfectGift,
  RegistryExclusiveBrands,
  RegistryFeaturedRegistry,
  RegistryFindRegistry,
  FindMyCollege,
  ProductCarousel,
  MoversSignUpNow,
  SEOCopy,
  HookLogic,
  RegistrySignInButton,
  ApplyForWebInstantCredit,
  Article,
  BlogTagHeader,
  Blog12UpTiles,
  BlogSectionDropdown,
  IdeasStoryTile,
  BlogBreadCrumb,
  TellFriend,
  WeddingBook,
  PersonalizationBar,
  QuickLinks,
  CuratedCategories,
  OrganizationComponent,
  ProductBundling,
  RelatedSearchTopics,
  RegistryTwoUpCTA,
  RegistryQuickPicks,
  RelatedSearchTopicsComponent,
  SlotMachine,
  Incentives,
  RegistryIncentive,
  RegistryDashboardRecommendation,
  GraphicBanner,
};
