import { createSelector } from 'reselect';
import { Map } from 'immutable';
import { GIFT_REGISTRIES_DETAILS_STATE_KEY } from '@bbb-app/constants/registryConstants';

export const selectRegistryDetails = state =>
  state.get(GIFT_REGISTRIES_DETAILS_STATE_KEY, Map());

export const makeSelectRegistryList = () =>
  createSelector(selectRegistryDetails, registryState =>
    registryState.get('registryList')
  );
