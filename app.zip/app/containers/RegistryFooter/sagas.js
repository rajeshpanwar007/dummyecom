import { call, put, takeLatest } from 'redux-saga/effects';
import getApiEndPointsFromStore from '@bbb-app/utils/getApiEndPointsFromStore';

import ServiceUtil from '@bbb-app/utils/serviceUtil';

import {
  fetchRegistryFooterSuccess,
  fetchRegistryFooterError,
} from './actions';

import { FETCH_REGISTRYFOOTER_DATA } from './constants';

export function* getfetchRegistryFooter() {
  const url = getApiEndPointsFromStore('registryFooter');
  try {
    const {
      body: { serviceStatus, errorMessages, data },
    } = yield call(ServiceUtil.triggerServerRequest, {
      url,
      method: 'POST',
      headers: {
        'x-bbb-channel': 'MobileWeb',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    if (serviceStatus === 'SUCCESS') {
      return yield put(fetchRegistryFooterSuccess(data.stickyFooterResponse));
    }
    return yield put(fetchRegistryFooterError(errorMessages.message));
  } catch (error) {
    return yield put(fetchRegistryFooterError(error.body));
  }
}

export function* RegistryFooterSagas() {
  yield takeLatest(FETCH_REGISTRYFOOTER_DATA, getfetchRegistryFooter);
}

export default [RegistryFooterSagas];
