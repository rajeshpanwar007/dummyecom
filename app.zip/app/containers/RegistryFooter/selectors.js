import { createSelector } from 'reselect';
import { Map } from 'immutable';
import { GIFT_REGISTRIES_DETAILS_STATE_KEY } from '@bbb-app/constants/registryConstants';

export const configState = state => state.get('viewportConfig', Map());

export const switchConfigSelector = () =>
  createSelector(configState, viewPortConfig =>
    viewPortConfig.get('switchConfig', Map())
  );

export const selectRegistryDetails = state =>
  state.get(GIFT_REGISTRIES_DETAILS_STATE_KEY, Map());

export const makeSelectActiveRegistry = () =>
  createSelector(selectRegistryDetails, registryState =>
    registryState.get('activeRegistry')
  );

export const makeSelectActiveRegistryID = () =>
  createSelector(selectRegistryDetails, registryState =>
    registryState.getIn(['activeRegistry', 'registryId'])
  );
