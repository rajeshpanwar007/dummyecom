import {
  FETCH_REGISTRYFOOTER_ERROR,
  FETCH_REGISTRYFOOTER_SUCCESS,
  FETCH_REGISTRYFOOTER_DATA,
  FETCH_IS_REGISTRYFOOTER_VISIBLE,
} from './constants';

export function fetchRegistryFooter() {
  return {
    type: FETCH_REGISTRYFOOTER_DATA,
  };
}

export function fetchRegistryFooterSuccess(data) {
  return {
    type: FETCH_REGISTRYFOOTER_SUCCESS,
    data,
  };
}

export function fetchRegistryFooterError(error) {
  return {
    type: FETCH_REGISTRYFOOTER_ERROR,
    error,
  };
}

export function showRegistryFooter(showRegistryFooterFlag) {
  return {
    type: FETCH_IS_REGISTRYFOOTER_VISIBLE,
    showRegistryFooterFlag,
  };
}
