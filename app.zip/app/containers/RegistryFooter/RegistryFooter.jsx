import React from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { connect } from 'react-redux';
import pathOr from 'lodash/fp/pathOr';
import { createStructuredSelector } from 'reselect';
import { isEmpty } from 'lodash';

import toJS from '@bbb-app/hoc/toJS';
import {
  makeSelectSwitchConfig,
  selectDeviceConfig,
} from '@bbb-app/selectors/configSelector';
import { pageIdentifierSelector } from '@bbb-app/selectors/registrySelectors';
import ErrorBoundary from '@bbb-app/core-ui/error-boundary';
import { triggerTealiumEvent } from '@bbb-app/actions/tealium/triggerTealiumEvent';
import { PNH_CHECKLIST } from '@bbb-app/constants/registryConstants';
import injectReducer from '@bbb-app/hoc/injectReducer';
import injectSaga from '@bbb-app/hoc/injectSaga';
import {
  makeSelectOwnRecomendedList,
  moverListEnableFlag,
} from '../InteractiveChecklist/selectors';

import RegistryFooterComponent from '../../components/RegistryFooter';
import {
  STICKY_LINK_COUNT,
  REGISTRYFOOTER_KEY,
  STATIC_PAGES,
} from './constants';
import { fetchRegistryFooter, showRegistryFooter } from './actions';
import {
  configState,
  switchConfigSelector,
  makeSelectActiveRegistry,
  makeSelectActiveRegistryID,
} from './selectors';
import { makeSelectRegistryList } from './RegistryFooterCartSelector';
import {
  registryFooterSelector,
  makeSelectRegistryFooterVisible,
  registryLabelSelector,
} from './RegistryFooterSelector';
import { putActiveRegistry } from '../InteractiveChecklist/actionWithInjectSaga';
import { otherListClick } from '../InteractiveChecklist/actionWithInjectReducer';
import { setRegistryFooterRenderedStatus } from './../FixedElementComponent/actions';
import { makeSelectRegistrySiteConfig } from '../Pages/Registry/RegistryOwner/FlipFlop/selectors';
import reducer from './reducer';
import saga from './sagas';
import {
  IS_PNH_CHECKLIST_ENABLE_SFOOTER,
  IS_PNH_CHECKLIST_ENABLE_IC,
} from '../InteractiveChecklist/constants';

/**
* This container will enable the sticky footer feature on mobile devices
* for authenticated or recognized registrants.
*/
export class RegistryFooter extends React.PureComponent {
  /**
* @param {array} routes -  Link's route array needed for Interactive Checklist.
* @param {boolean} locationChange - determines if location is changed
* @param {object} registryFooterData - sticky footer data object, to populate the RegistryFooter component
* @param {object} siteConfig - to get the endpoints, configured in siteconfig.
* @param {object} registryLabel - all required labels for the components.
* @param {object} switchConfig - sticky footer switch configuration, configured in siteconfig.
* @param {function} selectActiveRegistry - to get the active registry ID for registry panel
* @param {string} pageIdentifier - sticky footer pagewise switch configuration, configured in siteconfig.
*/
  static propTypes = {
    routes: PropTypes.array,
    locationChange: PropTypes.bool,
    onComponentMount: PropTypes.func,
    registryFooterData: PropTypes.object,
    registryLabel: PropTypes.object,
    switchConfig: PropTypes.object,
    selectActiveRegistry: PropTypes.func,
    setRegistryFooterRenderedStatus: PropTypes.func,
    pageIdentifier: PropTypes.string,
    activeRegistry: PropTypes.object,
    activeRegistryID: PropTypes.string,
    registryList: PropTypes.array,
    onClickOtherList: PropTypes.func,
    ownRecomendedList: PropTypes.array,
    isRegistryFooterVisible: PropTypes.bool,
    showRegistryFooter: PropTypes.func,
    registrySiteConfig: PropTypes.object,
  };

  componentDidMount() {
    if (this.props.activeRegistryID) {
      this.props.onComponentMount();
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.activeRegistryID !== nextProps.activeRegistryID) {
      this.props.onComponentMount();
    }
  }

  getPrerequisiteFulfilled = (
    registryFooterEnable,
    registryFooterData,
    registryList,
    ownRecomendedList
  ) => {
    let isPrerequisiteFulfilled = false;
    const enableCollegeCheckList = pathOr(
      false,
      'CollegeChecklist.enableCollegeCheckList',
      this.props.switchConfig
    );
    if (
      registryFooterEnable &&
      !isEmpty(registryFooterData) &&
      !isEmpty(registryFooterData.footer.stickyLinks) &&
      (!isEmpty(registryList) ||
        (!isEmpty(ownRecomendedList) && enableCollegeCheckList))
    ) {
      isPrerequisiteFulfilled = true;
    }
    return isPrerequisiteFulfilled;
  };
  staticPageIdentifier = pageIdentifier => {
    if (pageIdentifier.toLowerCase() === STATIC_PAGES.toLowerCase()) {
      return pageIdentifier.charAt(0).toUpperCase() + pageIdentifier.slice(1);
    }
    return null;
  };

  render() {
    const {
      switchConfig,
      registryFooterData,
      pageIdentifier,
      registryList,
      ownRecomendedList,
    } = this.props;
    let registryFooterEnable = false;
    let interactiveCheckListFlag = false;
    let staticRegistryFooterEnable = false;
    let staticInteractiveCheckListFlag = false;
    const staticPageIdentifier = this.staticPageIdentifier(pageIdentifier);
    if (pageIdentifier && switchConfig) {
      if (staticPageIdentifier) {
        staticRegistryFooterEnable =
          !!switchConfig[staticPageIdentifier] &&
          !!switchConfig[staticPageIdentifier].enableStickyFooter;
        staticInteractiveCheckListFlag =
          !!switchConfig[staticPageIdentifier] &&
          !!switchConfig[staticPageIdentifier].interactiveCheckList;
      }
      registryFooterEnable = !staticRegistryFooterEnable
        ? !!switchConfig[pageIdentifier] &&
          !!switchConfig[pageIdentifier].enableStickyFooter
        : staticRegistryFooterEnable;
      interactiveCheckListFlag = !staticInteractiveCheckListFlag
        ? !!switchConfig[pageIdentifier] &&
          !!switchConfig[pageIdentifier].interactiveCheckList
        : staticInteractiveCheckListFlag;
    }
    const isPrerequisiteFulfilled = this.getPrerequisiteFulfilled(
      registryFooterEnable,
      registryFooterData,
      registryList,
      ownRecomendedList
    );
    if (isPrerequisiteFulfilled && !this.props.isRegistryFooterVisible) {
      this.props.showRegistryFooter(true);
    } else if (!isPrerequisiteFulfilled) {
      this.props.showRegistryFooter(false);
    }
    if (isPrerequisiteFulfilled)
      return (
        <ErrorBoundary>
          <RegistryFooterComponent
            data={registryFooterData}
            ownRecomendedList={ownRecomendedList}
            stickyLinksCount={STICKY_LINK_COUNT}
            routes={this.props.routes}
            locationChange={this.props.locationChange}
            endpoints={pathOr(
              null,
              'viewportConfig.siteConfig.endpoints',
              this.props
            )}
            registryLabel={this.props.registryLabel}
            activeRegistry={this.props.activeRegistry}
            selectActiveRegistry={this.props.selectActiveRegistry}
            activeRegistryID={this.props.activeRegistryID}
            registryList={registryList}
            switchConfig={switchConfig}
            pageIdentifier={pageIdentifier}
            interactiveCheckListFlag={interactiveCheckListFlag}
            onClickOtherList={this.props.onClickOtherList}
            setRegistryFooterRenderedStatus={
              this.props.setRegistryFooterRenderedStatus
            }
            registrySiteConfig={this.props.registrySiteConfig}
            {...this.props}
            staticPageIdentifier={staticPageIdentifier}
          />
        </ErrorBoundary>
      );
    return null;
  }
}

export const mapStateToProps = createStructuredSelector({
  registryFooterData: registryFooterSelector(),
  registryLabel: registryLabelSelector(),
  activeRegistry: makeSelectActiveRegistry(),
  activeRegistryID: makeSelectActiveRegistryID(),
  registryList: makeSelectRegistryList(),
  switchConfig: switchConfigSelector(),
  pageIdentifier: pageIdentifierSelector(),
  ownRecomendedList: makeSelectOwnRecomendedList(),
  viewportConfig: configState,
  isRegistryFooterVisible: makeSelectRegistryFooterVisible(),
  registrySiteConfig: makeSelectRegistrySiteConfig(),
  isMoverListEnable: moverListEnableFlag(),
  isPNHChecklistEnabledIC: makeSelectSwitchConfig([
    PNH_CHECKLIST,
    IS_PNH_CHECKLIST_ENABLE_IC,
  ]),

  isPNHChecklistEnabledSFooter: makeSelectSwitchConfig([
    PNH_CHECKLIST,
    IS_PNH_CHECKLIST_ENABLE_SFOOTER,
  ]),
  deviceBreakpoints: selectDeviceConfig,
});

export const mapDispatchToProps = dispatch => ({
  onComponentMount() {
    dispatch(fetchRegistryFooter());
  },
  selectActiveRegistry: registryID => {
    dispatch(putActiveRegistry(registryID));
  },
  setRegistryFooterRenderedStatus: () => {
    dispatch(setRegistryFooterRenderedStatus());
  },
  onClickOtherList: () => {
    dispatch(otherListClick());
  },
  showRegistryFooter: showRegistryFooterFlag => {
    dispatch(showRegistryFooter(showRegistryFooterFlag));
  },
  fireTealiumAction(actionType, tealiumInfo, pageName) {
    dispatch(triggerTealiumEvent(actionType, tealiumInfo, pageName));
  },
});

const withConnect = connect(mapStateToProps, mapDispatchToProps);
const withReducer = injectReducer({
  key: REGISTRYFOOTER_KEY,
  reducer,
});
const withSaga = injectSaga({ key: REGISTRYFOOTER_KEY, saga });

export default compose(withReducer, withSaga, withConnect)(
  toJS(RegistryFooter)
);
