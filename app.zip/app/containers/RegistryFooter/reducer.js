import { fromJS } from 'immutable';

import {
  FETCH_REGISTRYFOOTER_SUCCESS,
  FETCH_REGISTRYFOOTER_ERROR,
  FETCH_REGISTRYFOOTER_DATA,
  FETCH_IS_REGISTRYFOOTER_VISIBLE,
} from './constants';

const initialState = fromJS({
  data: null,
  isFetching: false,
  error: null,
  isRegistryFooterVisible: false,
});

function RegistryFooterReducer(
  state = initialState,
  { type, error, data, showRegistryFooterFlag }
) {
  switch (type) {
    case FETCH_REGISTRYFOOTER_DATA:
      return state.set('isFetching', true).set('error', null);
    case FETCH_REGISTRYFOOTER_SUCCESS:
      return state.set('isFetching', false).set('data', data);
    case FETCH_REGISTRYFOOTER_ERROR:
      return state
        .set('isFetching', false)
        .set('error', error)
        .set('data', null);
    case FETCH_IS_REGISTRYFOOTER_VISIBLE:
      return state.set('isRegistryFooterVisible', showRegistryFooterFlag);
    default:
      return state;
  }
}

export default RegistryFooterReducer;
