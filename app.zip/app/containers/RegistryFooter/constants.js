export const FETCH_REGISTRYFOOTER_SUCCESS = 'BBB/REGISTRYFOOTER/success';
export const FETCH_REGISTRYFOOTER_ERROR = 'BBB/REGISTRYFOOTER/error';
export const FETCH_REGISTRYFOOTER_DATA = 'BBB/REGISTRYFOOTER/data';
export const REGISTRYFOOTER_KEY = 'registryFooter';
export const FETCH_IS_REGISTRYFOOTER_VISIBLE = 'BBB/REGISTRYFOOTER/visible';
/* Number of tabs in footer before more tab */
export const STICKY_LINK_COUNT = 4;
export const STATIC_PAGES = 'StaticPages';
