export { default } from './RegistryFooter';

export { default as sagas } from './sagas';

export { default as reducer } from './reducer';

export { REGISTRYFOOTER_KEY as stateKey } from './constants';
