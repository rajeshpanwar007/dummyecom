import { createSelector } from 'reselect';
import { Map } from 'immutable';
import { selectLabels } from '@bbb-app/header/containers/selectors';

export const configState = state => state.get('viewportConfig', Map());

export const registryFooterState = state => state.get('registryFooter', Map());

export const registryFooterSelector = () =>
  createSelector(registryFooterState, registryFooterData =>
    registryFooterData.get('data')
  );

export const makeSelectRegistryFooterVisible = () =>
  createSelector(registryFooterState, registryFooterData =>
    registryFooterData.get('isRegistryFooterVisible', false)
  );

export const registryLabelSelector = () =>
  createSelector(selectLabels, registryLabel =>
    registryLabel.get('InteractiveChecklist')
  );
