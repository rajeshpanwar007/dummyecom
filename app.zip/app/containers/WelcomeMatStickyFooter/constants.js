export const WELCOME_MAT_MOBILE_STATE_KEY = 'WelcomeMatMobile';
export const APPLY_CSS_MOBILE = 'BBB/WelcomeMat/Mobile/ApplyCss/Val';
export const RENDER_WEL_MAT_FOOTER_MOBILE =
  'BBB/WelcomeMatStickyFooterRender/Mobile/Val';
export const RESET_WEL_MAT_STICKY_FOOTER =
  'BBB/WelcomeMatStickyFooterReset/Mobile';
