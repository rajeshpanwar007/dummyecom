import {
  APPLY_CSS_MOBILE,
  RENDER_WEL_MAT_FOOTER_MOBILE,
  RESET_WEL_MAT_STICKY_FOOTER,
} from './constants';

export function applyModalCssOnMobile(cssStatus) {
  return {
    type: APPLY_CSS_MOBILE,
    cssStatus,
  };
}

export function renderWelcomeMatStickyFooter(renderStatus) {
  return {
    type: RENDER_WEL_MAT_FOOTER_MOBILE,
    renderStatus,
  };
}

export function resetWelcomeMatStickyFooter() {
  return {
    type: RESET_WEL_MAT_STICKY_FOOTER,
  };
}
