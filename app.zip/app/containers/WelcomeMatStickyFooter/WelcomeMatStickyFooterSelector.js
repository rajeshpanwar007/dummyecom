import { Map } from 'immutable';

export const selectLabels = state => state.get('labels', Map());

export const makeSelectSwitchConfig = state => {
  return state && state.getIn(['viewportConfig', 'switchConfig'], Map());
};
