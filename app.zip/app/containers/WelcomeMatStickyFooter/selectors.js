import { createSelector } from 'reselect';
import { Map } from 'immutable';
export const selectLabels = state => state.get('labels', Map());

export const welcomeMatMobileState = state =>
  state.get('WelcomeMatMobile', Map());

export const makeSelectCssApplyOnMobile = () =>
  createSelector(welcomeMatMobileState, wcMobileState =>
    wcMobileState.get('applyCssMobile', false)
  );

export const makeSelectRenderWelMatStickyFooter = () =>
  createSelector(welcomeMatMobileState, wcMobileState =>
    wcMobileState.get('renderWelMatStickyFooter', false)
  );

export const makeSelectLabels = () => {
  return createSelector(selectLabels, labelsState => labelsState.get('Global'));
};
