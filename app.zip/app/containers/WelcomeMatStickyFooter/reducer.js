import { fromJS } from 'immutable';
import {
  APPLY_CSS_MOBILE,
  RENDER_WEL_MAT_FOOTER_MOBILE,
  RESET_WEL_MAT_STICKY_FOOTER,
} from './constants';

export const initialState = fromJS({
  applyCssMobile: false,
  renderWelMatStickyFooter: false,
});

function welcomeMatMobileReducer(
  state = initialState,
  { type, cssStatus, renderStatus }
) {
  switch (type) {
    case APPLY_CSS_MOBILE:
      return state.set('applyCssMobile', cssStatus);

    case RENDER_WEL_MAT_FOOTER_MOBILE:
      return state.set('renderWelMatStickyFooter', renderStatus);

    case RESET_WEL_MAT_STICKY_FOOTER:
      return state
        .set('applyCssMobile', false)
        .set('renderWelMatStickyFooter', false);

    default:
      return state;
  }
}

export default welcomeMatMobileReducer;
