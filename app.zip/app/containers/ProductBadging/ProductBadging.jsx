import React from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import PropTypes from 'prop-types';
import { makeSelectSwitchConfig } from '@bbb-app/selectors/configSelector';
import toJS from '@bbb-app/hoc/toJS';
import { ProductBadgingComponent } from '../../components/ProductBadging/ProductBadging';

const propTypes = {
  productBadgingConfig: PropTypes.object,
};

/**
 * Container to handle global switch separately in Product Badging
 * @param {object} props
 */
export const ProductBadging = props => {
  const { enableProductBadge } = props.productBadgingConfig;
  if (enableProductBadge) return <ProductBadgingComponent {...props} />;
  return null;
};

ProductBadging.propTypes = propTypes;

export const mapStateToProps = createStructuredSelector({
  productBadgingConfig: makeSelectSwitchConfig('ProductBadging'),
});

export default connect(mapStateToProps)(toJS(ProductBadging));
