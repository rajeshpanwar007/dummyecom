import { all } from 'redux-saga/effects';
import isFunction from 'lodash/fp/isFunction';
import siteSpectSaga from '@bbb-app/site-spect/sagas';
import qasSaga from '@bbb-app/qas-validation/containers/sagas';
import referredContentSagas from '@bbb-app/referred-content/sagas';
import footerSagas from '@bbb-app/footer/containers/sagas';
import tealiumSaga from '@bbb-app/tealium/containers/sagas';
import recognizedUserSaga from '@bbb-app/actions/recognized-user/sagas';
import ContentSagas from '@bbb-app/pure-content/containers/sagas';
import siteConfigSagas from '@bbb-app/redux/site-configuration/sagas';
import labelsSagas from '@bbb-app/redux/labels/sagas';
import headerSagas from '@bbb-app/header/containers/saga';
import metaTagSaga from '@bbb-app/seo/containers/saga';
import GlobalNotificationSagas from '@bbb-app/global-notification/container/sagas';
import miniCartSagas from '@bbb-app/mini-cart/containers/sagas';
import searchResultsSagas from '@bbb-app/search-bar/containers/sagas';
import navigationSagas from '@bbb-app/navigation/containers/sagas';
import akamaiHeaderSagas from '@bbb-app/redux/akamai/sagas';
import sessionConfirmationNumberSagas from '@bbb-app/redux/session-confirmation-number/sagas';
import dashboardSagas from '@bbb-app/redux/profile-data/saga';
import sddMarketEligibilitySagas from '@bbb-app/redux/market-eligibility/sagas';

import pdpSagas from '../containers/Pages/PDP/ProductDetails/sagas';
import experienceSagas from '../containers/Experience/sagas';
import AppModal from '../containers/AppModals/sagas';
import facetSelectionSaga from '../containers/ThirdParty/Tealium/Events/facetSelection/facetSelectionSaga';
import CreateCollegeChecklistSagas from '../containers/Pages/CollegeChecklist/pageTransitionSaga';
import MoverChecklistSagas from '../containers/Pages/MoverChecklist/sagas';
import getBrandListingsSaga from '../containers/Pages/BrandListing/sagas';
import RelatedSearchTopicsSaga from '../containers/RelatedSearchTopics/sagas';
import InstantOfferTemplateSaga from '../containers/InstantOffer/sagas';
import organizationSagas from '../containers/Pages/OrganizationLanding/sagas';
import storeSagas from '../containers/Search/storeSagas';

export const runSagas = sagas => {
  if (Array.isArray(sagas)) {
    return sagas.map(saga => saga());
  }

  if (isFunction(sagas)) {
    return Array.of(sagas());
  }

  throw new TypeError(`${sagas} should be an Array or Function`);
};

export const allSagas = () => [
  ...runSagas(metaTagSaga),
  ...runSagas(pdpSagas),
  ...runSagas(headerSagas),
  ...runSagas(footerSagas),
  ...runSagas(dashboardSagas),
  ...runSagas(sessionConfirmationNumberSagas),
  ...runSagas(akamaiHeaderSagas),
  ...runSagas(sddMarketEligibilitySagas),
  ...runSagas(labelsSagas),
  ...runSagas(referredContentSagas),
  ...runSagas(experienceSagas),
  ...runSagas(searchResultsSagas),
  ...runSagas(siteConfigSagas),
  ...runSagas(navigationSagas),
  ...runSagas(miniCartSagas),
  ...runSagas(ContentSagas),
  ...runSagas(recognizedUserSaga),
  ...runSagas(siteSpectSaga),
  ...runSagas(tealiumSaga),
  ...runSagas(GlobalNotificationSagas),
  ...runSagas(facetSelectionSaga),
  ...runSagas(CreateCollegeChecklistSagas),
  ...runSagas(MoverChecklistSagas),
  ...runSagas(getBrandListingsSaga),
  ...runSagas(AppModal),
  ...runSagas(organizationSagas),
  ...runSagas(RelatedSearchTopicsSaga),
  ...runSagas(InstantOfferTemplateSaga),
  ...runSagas(storeSagas),
  ...runSagas(qasSaga),
];

export default function* rootSaga() {
  yield all(allSagas());
}
