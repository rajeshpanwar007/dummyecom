import sinon from 'sinon';

import { runSagas } from '../rootSaga';

describe('#runSagas', () => {
  const sagasWithInputAndOutput = [
    {
      input: [() => 10, () => 20],
      output: [10, 20],
    },
    {
      input: () => 10,
      output: [10],
    },
  ];

  sagasWithInputAndOutput.forEach(({ input, output }) => {
    it(`should return ${output} for passed ${input}`, () => {
      expect(runSagas(input)).to.deep.equal(output);
    });
  });

  it('should call passed saga wrapped in an array', () => {
    const saga = sinon.stub();
    const sagas = Array.of(saga);

    runSagas(sagas);

    /* eslint no-unused-expressions: 0 */
    expect(saga).to.have.been.called;
  });

  it('should call passed saga if not wrapped in an array', () => {
    const sagas = sinon.stub();

    runSagas(sagas);

    /* eslint no-unused-expressions: 0 */
    expect(sagas).to.have.been.called;
  });

  it('should throw "TypeError" if passed saga is not an array or function', () => {
    const sagas = 'sagas';
    const runSagasWithInputBinded = runSagas.bind(null, sagas);

    expect(runSagasWithInputBinded).to.throw(
      TypeError,
      `${sagas} should be an Array or Function`
    );
  });
});
