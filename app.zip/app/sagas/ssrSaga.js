import { all } from 'redux-saga/effects';
import { allSagas, runSagas } from './rootSaga';
import collegeSagas from '../containers/Pages/CollegeLanding/sagas';
import registryDetailsPageTransitionSaga from '../containers/Pages/Registry/RegistryOwner/registryDetailsPageTransitionSaga';
import QuickPicksLandingSaga from '../containers/Pages/Registry/QuickPicks/Landing/sagas';
import QuickPicksCollectionSaga from '../containers/Pages/Registry/QuickPicks/Collection/sagas';
import RegistryToolsNavigationSaga from '../containers/Pages/RegistryTools/RegistryToolsNavigation/saga';
import checklistCategorySagas from '../containers/Search/ChecklistCategory/sagas';
import searchSagas from '../containers/Search/sagas';

const extendSagasChain = () => [
  ...runSagas(collegeSagas),
  ...runSagas(registryDetailsPageTransitionSaga),
  ...runSagas(QuickPicksLandingSaga),
  ...runSagas(QuickPicksCollectionSaga),
  ...runSagas(RegistryToolsNavigationSaga),
  ...runSagas(checklistCategorySagas),
  ...runSagas(searchSagas),
];

/**
 * this file will run only on server end, so that the saga which required only on server end we can add in extendSagasChain method
 */
export default function* ssrSaga() {
  yield all([allSagas(), extendSagasChain()]);
}
