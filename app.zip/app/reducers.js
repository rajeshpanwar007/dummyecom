/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 */

import { combineReducers } from 'redux-immutable';
import { connectRouter } from 'connected-react-router/immutable';
import history from '@bbb-app/utils/history';

import myAccountSiteConfigReducer from '@bbb-app/utils/myAccountUtils/reducers';
import { MYACCOUNT_SITE_CONFIG_KEY as myAccountSiteConfigKey } from '@bbb-app/utils/myAccountUtils/constants';

import { STATE_KEY as siteSpectStateKey } from '@bbb-app/site-spect/constants';
import siteSpectReducer from '@bbb-app/site-spect/reducer';

import { QAS_STATE_KEY as qasStateKey } from '@bbb-app/qas-validation/containers/constants';
import qasReducer from '@bbb-app/qas-validation/containers/reducer';

import FormWrapperReducer from '@bbb-app/forms/containers/FormWrapper/reducer';
import { FORM_WRAPPER_STATE_KEY as formWrapperStateKey } from '@bbb-app/forms/containers/FormWrapper/constants';

import { PRIMARY_LINK_STATE_KEY as primaryLinkStateKey } from '@bbb-app/plp-primary-link/containers/primaryLinkConstants';
import PrimaryLinkReducer from '@bbb-app/plp-primary-link/containers/reducer';

import { STATE_KEY as navStateKey } from '@bbb-app/navigation/containers/navConstants';
import navReducer from '@bbb-app/navigation/containers/reducer';

import { INSTANT_OFFER_STATE_KEY as instantOfferStateKey } from '@bbb-app/instant-offer/containers/constants';

import { MOBILE_SCREEN_STATE_KEY as isMobileScreenStateKey } from '@bbb-app/constants/state-keys/configStateKeys';
import currentViewportConfigReducer from '@bbb-app/redux/current-viewport/reducer';

import {
  ACCOUNT_STATE_KEY as accountStateKey,
  ACCOUNT_SIGNIN_DETAILS_STATE_KEY as accountSignInStateKey,
} from '@bbb-app/constants/state-keys/accountStateKeys';

import { GIFT_REGISTRIES_DETAILS_STATE_KEY as GiftRegistriesDetailsStateKey } from '@bbb-app/constants/registryConstants';

import {
  HEADER_STATE_KEY as headerStateKey,
  LABELS_STATE_KEY as labelsStateKey,
} from '@bbb-app/constants/appConstants';
import headerReducer from '@bbb-app/header/containers/reducer';
import labelsReducer from '@bbb-app/redux/labels/reducer';

import { TEALIUM_STATE_KEY as tealiumStateKey } from '@bbb-app/tealium/constants';

import { DEVICE_TYPE_STATE_KEY as deviceTypeStateKey } from '@bbb-app/responsive-media-query/constants';
import DeviceTypeReducer from '@bbb-app/responsive-media-query/reducer';

import { REFERRED_CONTENT_STATE_KEY as referredContentStateKey } from '@bbb-app/referred-content/constants';
import referredContentReducer from '@bbb-app/referred-content/reducer';

import { ASSOCIATE_SIGNIN_STATE_KEY as associateSignInStateKey } from '@bbb-app/tbs/containers/associate-signin/constants';
import AssociateLoginReducer from '@bbb-app/tbs/containers/associate-signin/reducer';

import { FOOTER_KEY as footerStateKey } from '@bbb-app/footer/containers/constants';
import footerReducer from '@bbb-app/footer/containers/reducer';

import { RECOGNIZED_USER_STATE_KEY as recognizedUserStateKey } from '@bbb-app/constants/accountConstants';
import recognizedUserReducer from '@bbb-app/actions/recognized-user/reducer';

import {
  AKAMAI_HEADER_STATE_KEY as saveAkamaiHeaderStateKey,
  SDD_MARKET_ELIGIBILITY_STATE_KEY as sddMarketEligibilityStateKey,
  SEARCH_STATE_KEY as searchStateKey,
} from '@bbb-app/constants/state-keys/searchStateKeys';

import { META_TAG_STATE_KEY as metaTagStateKey } from '@bbb-app/seo/containers/constants';
import metaTagReducer from '@bbb-app/seo/containers/reducer';

import { COUNTRY_CURRENCY_STATE_KEY as countryCurrencyStateKey } from '@bbb-app/country-currency-modal/containers/constants';
import countryCurrencyModalReducer from '@bbb-app/country-currency-modal/containers/reducer';

import { DCH_STATE_KEY as dynamicContentHeaderStateKey } from '@bbb-app/pure-content/containers/DynamicContentHeaders/constants';
import dynamicContentHeaderReducer from '@bbb-app/pure-content/containers/DynamicContentHeaders/reducer';

import { SITE_CONFIG_STATE_KEY as siteConfigStateKey } from '@bbb-app/redux/site-configuration/constants';
import siteConfigconfigReducer from '@bbb-app/redux/site-configuration/reducer';

import { SITE_VIEWPORT_STATE_KEY as viewportConfigStateKey } from '@bbb-app/redux/viewport-configuration/constants';
import viewportConfigReducer from '@bbb-app/redux/viewport-configuration/reducer';

import environmentConfigReducer from '@bbb-app/redux/env-configuration/reducer';
import { ENV_CONFIG_STATE_KEY as environmentConfigStateKey } from '@bbb-app/redux/env-configuration/constants';

import routeReducer from '@bbb-app/redux/route-data/reducer';

import { GLOBAL_NOTIFICATION_KEY as GlobalNotificationStateKey } from '@bbb-app/global-notification/container/constants';
import GlobalNotificationReducer from '@bbb-app/global-notification/container/reducer';

import { SITE_INITIAL_VIEWPORT_STATE_KEY as initialViewportStateKey } from '@bbb-app/redux/initial-viewport/constants';
import initialViewportConfigReducer from '@bbb-app/redux/initial-viewport/reducer';

import GiftRegistriesDetailsReducer from '@bbb-app/get-registry-details/containers/reducer';
import { SEARCH_RESULTS_STATE_KEY as searchResultsStateKey } from '@bbb-app/search-bar/containers/constants';
import { MINICART_STATE_KEY as miniCartStateKey } from '@bbb-app/mini-cart/containers/constants';
import miniCartReducer from '@bbb-app/mini-cart/containers/reducer';
import searchResultsReducer from '@bbb-app/search-bar/containers/reducer';

// eslint-disable-next-line no-restricted-imports
import { SESSION_EXPIRED_REDIRECTION_KEY as CartCheckoutSessionExpiredStateKey } from '@bbb-app/checkout-app/common/containers/session-expired-redirection/constants';
// eslint-disable-next-line no-restricted-imports
import CartCheckoutSessionExpiredReducer from '@bbb-app/checkout-app/common/containers/session-expired-redirection/reducer';

import { PICKUP_IN_STORE_STATE_KEY as PickupInStoreStateKey } from '@bbb-app/pick-up-in-store/containers/pick-up-in-store-modal/constants';
import { EXPERIENCE_CONTENT_STATE_KEY as contentStateKey } from '@bbb-app/pure-content/containers/constants';
import { STATE_KEY as googleDFP } from '@bbb-app/google-dfp/containers/constants';
import saveAkamaiHeaderReducer from '@bbb-app/redux/akamai/reducer';
import googleDFPReducer from '@bbb-app/google-dfp/containers/reducer';

import { SESSION_CONFIRMATION_NUMBER_STATE_KEY as sessionConfirmationNumberStateKey } from '@bbb-app/redux/session-confirmation-number/constants';
import sessionConfirmationNumberReducer from '@bbb-app/redux/session-confirmation-number/reducer';

import {
  getMyFundsDisplayReducer,
  getProfileStatusReducer,
} from '@bbb-app/redux/profile-data/reducers';

import { SESSION_EXPIRED_REDIRECTION_KEY as SessionExpiredRedirectionStateKey } from '@bbb-app/redux/session-expired-redirection/constants';
import SessionExpiredRedirectionReducer from '@bbb-app/redux/session-expired-redirection/reducer';
import accountSignInReducer from '@bbb-app/account-signin/containers/reducer';
import {
  PROFILE_STATUS_KEY as profileStatusKey,
  FETCH_MY_FUNDS_STATE_KEY as myFundsDisplayStateKey,
} from '@bbb-app/redux/profile-data/constants';

import PickupInStoreModalReducer from '@bbb-app/pick-up-in-store/containers/pick-up-in-store-modal/reducer';
import tealiumReducer from '@bbb-app/tealium/containers/reducer';
import ContentReducer from '@bbb-app/pure-content/containers/reducer';
import sddMarketEligibilityReducer from '@bbb-app/redux/market-eligibility/reducer';

import instantOfferReducer from './containers/InstantOffer/reducer';

import appReducer from './containers/App/reducer';
import experienceReducer from './containers/Experience/reducer';

import { TEALIUM_ATC_ATR_STATE_KEY as tealiumATCATRStateKey } from './containers/ThirdParty/Tealium/ATCATRModalTealiumHandler/constants';
import tealiumATCATRReducer from './containers/ThirdParty/Tealium/ATCATRModalTealiumHandler/reducers';

import searchReducer from './containers/Search/reducer';

import pdpReducer from './containers/Pages/PDP/combinedReducer';
import { PDP_STATE_KEY as pdpStateKey } from './containers/Pages/PDP/constants';

import accountReducer from './containers/Pages/MyAccountDashboard/combinedReducer';

import { REGISTRY_DETAILS_STATE_KEY as registryDetailsStateKey } from '../app/containers/Pages/Registry/RegistryOwner/constants';
import registryDetailsReducer from '../app/containers/Pages/Registry/RegistryOwner/reducer';

import { GLOBAL_APP_MODAL_KEY as GlobalAppModalKey } from './containers/SDD/constants';
import GlobalAppModalReducer from './containers/AppModals/reducer';

import { FIXED_ELEMENT_STATE_KEY as fixedElementComponentStateKey } from './containers/FixedElementComponent/constants';
import fixedElementComponentReducer from './containers/FixedElementComponent/reducer';

import { STATE_KEY as collegeStateKey } from './containers/College/constants';
import collegeReducer from './containers/College/reducer';

import { RELATED_SEARCH_TOPICS_KEY as relatedSearchTopicsKey } from './containers/RelatedSearchTopics/constants';
import RelatedSearchTopicsReducer from './containers/RelatedSearchTopics/reducer';

import CreateCollegeChecklistReducer from './containers/Pages/CollegeChecklist/reducer';
import organizationLandingReducer from './containers/Pages/OrganizationLanding/reducer';
import BrandListingReducer from './containers/Pages/BrandListing/reducer';

/**
 * Creates the main reducer with the asynchronously loaded ones
 */
export default function createReducer(asyncReducers) {
  return combineReducers({
    route: routeReducer,
    global: appReducer,
    router: connectRouter(history),
    [metaTagStateKey]: metaTagReducer,
    [tealiumStateKey]: tealiumReducer,
    [tealiumATCATRStateKey]: tealiumATCATRReducer,
    [headerStateKey]: headerReducer,
    [footerStateKey]: footerReducer,
    [accountStateKey]: accountReducer,
    [myFundsDisplayStateKey]: getMyFundsDisplayReducer,
    [searchStateKey]: searchReducer,
    [pdpStateKey]: pdpReducer,
    experience: experienceReducer,
    [labelsStateKey]: labelsReducer,
    [siteConfigStateKey]: siteConfigconfigReducer,
    [viewportConfigStateKey]: viewportConfigReducer,
    [initialViewportStateKey]: initialViewportConfigReducer,
    [isMobileScreenStateKey]: currentViewportConfigReducer,
    [environmentConfigStateKey]: environmentConfigReducer,
    [referredContentStateKey]: referredContentReducer,
    [sessionConfirmationNumberStateKey]: sessionConfirmationNumberReducer,
    [sddMarketEligibilityStateKey]: sddMarketEligibilityReducer,
    [accountSignInStateKey]: accountSignInReducer,
    [searchResultsStateKey]: searchResultsReducer,
    [navStateKey]: navReducer,
    [contentStateKey]: ContentReducer,
    [deviceTypeStateKey]: DeviceTypeReducer,
    [miniCartStateKey]: miniCartReducer,
    [recognizedUserStateKey]: recognizedUserReducer,
    [primaryLinkStateKey]: PrimaryLinkReducer,
    [siteSpectStateKey]: siteSpectReducer,
    [GlobalNotificationStateKey]: GlobalNotificationReducer,
    [GlobalAppModalKey]: GlobalAppModalReducer,
    [SessionExpiredRedirectionStateKey]: SessionExpiredRedirectionReducer,
    [GiftRegistriesDetailsStateKey]: GiftRegistriesDetailsReducer,
    [formWrapperStateKey]: FormWrapperReducer,
    brandListings: BrandListingReducer,
    [PickupInStoreStateKey]: PickupInStoreModalReducer,
    [instantOfferStateKey]: instantOfferReducer,
    [saveAkamaiHeaderStateKey]: saveAkamaiHeaderReducer,
    [dynamicContentHeaderStateKey]: dynamicContentHeaderReducer,
    [CartCheckoutSessionExpiredStateKey]: CartCheckoutSessionExpiredReducer,
    [collegeStateKey]: collegeReducer,
    [fixedElementComponentStateKey]: fixedElementComponentReducer,
    [profileStatusKey]: getProfileStatusReducer,
    [googleDFP]: googleDFPReducer,
    collegeChecklist: CreateCollegeChecklistReducer,
    [associateSignInStateKey]: AssociateLoginReducer,
    organizationLanding: organizationLandingReducer,
    [relatedSearchTopicsKey]: RelatedSearchTopicsReducer,
    [myAccountSiteConfigKey]: myAccountSiteConfigReducer,
    [qasStateKey]: qasReducer,
    [countryCurrencyStateKey]: countryCurrencyModalReducer,
    [registryDetailsStateKey]: registryDetailsReducer,
    ...asyncReducers,
  });
}
